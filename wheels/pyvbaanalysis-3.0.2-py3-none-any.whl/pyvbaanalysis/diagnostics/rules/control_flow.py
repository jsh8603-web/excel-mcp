"""Rule family: control-flow rules.

Ported from xlide_vscode/src/analyzer/diagnostics/rules/controlFlow.ts: Exit
statement kinds, statement context (If/Then, Case/loop-exit/leading-dot
placement), For/Next control-variable matching, duplicate Case Else, Else without
If, malformed leaf statements, the duplicate/undefined label rules (over
flow/procedureLabels), the For Each element/source type rule (type inference +
host model), and the conditional-compilation branch-order rule (shared cc helper).
"""

from __future__ import annotations

import re
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace

from ...completion.type_completion import resolve_type_name
from ...conditional import ConditionalActivityTracker, inactive_node_skip
from ...host.host_model import HostObjectModel
from ...flow.procedure_labels import (
    collect_procedure_label_declarations,
    collect_procedure_label_references,
)
from ...lexer.keyword_table import is_reserved_identifier
from ...lexer.token_helpers import is_decimal_line_number, starts_physical_line
from ...lexer.token_kinds import TokenKind, VbaToken
from ...lexer.tokenize import tokenize
from ...parser.nodes import (
    AssignmentNode,
    BodyNode,
    CallNode,
    ConditionalDirectiveNode,
    DoBlockNode,
    ForBlockNode,
    IfBlockNode,
    IfBranchKind,
    LeafStatementNode,
    ModuleNode,
    ProcedureNode,
    ProcKind,
    SelectBlockNode,
    Span,
    StatementNode,
    WithBlockNode,
    is_leaf_statement,
    iter_body_nodes,
    iter_body_nodes_in_context,
)
from ...symbols.name_resolution import BareIdentifierContext
from ...symbols.symbol_model import ModuleSymbols, VbaProjectTypeName, VbaSymbol
from ...types.type_inference import (
    DeclaredValueShape,
    SourceDeclaredShape,
    declaration_shape_environment_for,
    declared_shape_for_source_binding,
    procedure_symbol_for,
)
from ...types.type_names import is_known_scalar_type, normalize_type
from ..context import PushFn
from ..walker import (
    ProcedureStatementVisitor,
    absolute_span,
    active_module_members,
    for_each_procedure_body_line,
    for_each_statement,
    is_inactive_node,
    raw_expression_tokens,
    statement_tokens,
    statement_tokens_after_leading_label,
    token_name,
    token_text,
)
from .shared import (
    report_repeated_keys,
    scan_conditional_compilation_branch_order,
    source_expression_syntax_problem,
)

# -- checkForEachLoopTypes -------------------------------------------------

_ShapeResolver = Callable[[str, BareIdentifierContext], SourceDeclaredShape]


def check_for_each_loop_types(
    mod: ModuleNode,
    symbols: ModuleSymbols,
    project_visible_symbols: Sequence[VbaSymbol] | None,
    project_types: Sequence[VbaProjectTypeName] | None,
    model: HostObjectModel | None,
    activity: ConditionalActivityTracker | None,
    push: PushFn,
) -> None:
    """A For Each control variable must be Variant/Object; its source a collection/array.

    User-defined-Type and Enum control-variable typing resolves through the
    project-type registry / host model (resolveTypeName); a UDT- or Enum-declared
    control variable is reported with its specific shape, a host class is accepted,
    and the known-scalar cases are flagged As-is.
    """
    for member in active_module_members(mod, activity):
        if not isinstance(member, ProcedureNode):
            continue
        shapes = declaration_shape_environment_for(symbols, member)
        proc_sym = procedure_symbol_for(symbols, member)

        def resolve_shape(name: str, context: BareIdentifierContext) -> SourceDeclaredShape:
            return declared_shape_for_source_binding(
                symbols, proc_sym, project_visible_symbols, name, context
            )

        _check_for_each_loop_types_in_body(
            member.body, shapes, project_types, model, activity, push, resolve_shape
        )


def _check_for_each_loop_types_in_body(
    body: list[BodyNode],
    shapes: Mapping[str, DeclaredValueShape],
    project_types: Sequence[VbaProjectTypeName] | None,
    model: HostObjectModel | None,
    activity: ConditionalActivityTracker | None,
    push: PushFn,
    resolve_shape: _ShapeResolver,
) -> None:
    for node in iter_body_nodes(body, inactive_node_skip(activity)):
        if isinstance(node, ForBlockNode):
            _check_for_each_control_variable_type(
                node, shapes, project_types, model, push, resolve_shape
            )
            _check_for_each_source_type(
                node, shapes, project_types, model, push, resolve_shape
            )


def _check_for_each_control_variable_type(
    node: ForBlockNode,
    shapes: Mapping[str, DeclaredValueShape],
    project_types: Sequence[VbaProjectTypeName] | None,
    model: HostObjectModel | None,
    push: PushFn,
    resolve_shape: _ShapeResolver,
) -> None:
    if not node.each or not node.control_variable or node.control_variable_span is None:
        return
    resolved = resolve_shape(node.control_variable, BareIdentifierContext.ASSIGNMENT_TARGET)
    shape = resolved.shape if resolved.resolved else shapes.get(node.control_variable.lower())
    if shape is None:
        return
    # Over an array the VBE accepts only a Variant control variable: `For Each o In
    # arr` with o As Object is "For Each control variable on arrays must be Variant"
    # (XLIDE issue #125, measured in Excel 16.0), and so is a String.
    source_name = _simple_for_each_source_name(node.source_expression) if node.source_expression else None
    source_shape: DeclaredValueShape | None = None
    if source_name:
        resolved_source = resolve_shape(source_name, BareIdentifierContext.EXPRESSION)
        source_shape = resolved_source.shape if resolved_source.resolved else shapes.get(source_name.lower())
    if source_shape is not None and source_shape.is_array and not shape.is_array:
        normalized = normalize_type(shape.as_type)
        if shape.as_type and normalized != "variant":
            push(
                "forEachControlVariableType",
                f"For Each control variable '{node.control_variable}' must be Variant when the source is "
                f"an array, but it is declared As {shape.as_type}.",
                node.control_variable_span,
            )
            return
    problem = _for_each_control_variable_type_problem(shape, project_types, model)
    if problem is None:
        return
    push(
        "forEachControlVariableType",
        f"For Each control variable '{node.control_variable}' must be Variant or Object, "
        f"but {problem}.",
        node.control_variable_span,
    )


def _check_for_each_source_type(
    node: ForBlockNode,
    shapes: Mapping[str, DeclaredValueShape],
    project_types: Sequence[VbaProjectTypeName] | None,
    model: HostObjectModel | None,
    push: PushFn,
    resolve_shape: _ShapeResolver,
) -> None:
    if not node.each or not node.source_expression or node.source_expression_span is None:
        return
    what = source_expression_syntax_problem(node.source_expression)
    if what:
        push(
            "malformedStatement",
            f"For Each takes a variable, a member or a call after In, and {what} is none of them. "
            "This is a VBE compile error: Syntax error.",
            node.source_expression_span,
        )
        return
    source_name = _simple_for_each_source_name(node.source_expression)
    if not source_name:
        return
    resolved = resolve_shape(source_name, BareIdentifierContext.EXPRESSION)
    shape = resolved.shape if resolved.resolved else shapes.get(source_name.lower())
    if shape is None:
        return
    problem = _for_each_source_type_problem(shape, project_types, model)
    if problem is None:
        return
    push(
        "forEachSourceType",
        f"For Each source '{source_name}' must be a collection object or array, but {problem}.",
        node.source_expression_span,
    )


def _for_each_control_variable_type_problem(
    shape: DeclaredValueShape,
    project_types: Sequence[VbaProjectTypeName] | None,
    model: HostObjectModel | None,
) -> str | None:
    if shape.is_array:
        return "it is an array variable"
    if not shape.as_type:
        return None
    resolved = resolve_type_name(shape.as_type, project_types, model)
    if resolved is not None and resolved.kind == "userType":
        return f"it is declared As user-defined Type '{shape.as_type}'"
    if resolved is not None and resolved.kind == "enum":
        return f"it is declared As Enum '{shape.as_type}'"
    if resolved is not None and resolved.kind != "primitive":
        return None
    normalized = normalize_type(shape.as_type)
    if not normalized or normalized in ("variant", "object"):
        return None
    if is_known_scalar_type(normalized):
        return f"it is declared As {shape.as_type}"
    return None


def _for_each_source_type_problem(
    shape: DeclaredValueShape,
    project_types: Sequence[VbaProjectTypeName] | None,
    model: HostObjectModel | None,
) -> str | None:
    if shape.is_array or not shape.as_type:
        return None
    resolved = resolve_type_name(shape.as_type, project_types, model)
    if resolved is not None and resolved.kind != "primitive":
        return None
    normalized = normalize_type(shape.as_type)
    if not normalized or normalized in ("variant", "object"):
        return None
    if is_known_scalar_type(normalized):
        return f"it is declared As {shape.as_type}"
    return None


def _simple_for_each_source_name(source_expression: str) -> str | None:
    toks = raw_expression_tokens(source_expression)
    return token_name(toks[0]) if len(toks) == 1 else None


# -- checkExitStatements ---------------------------------------------------


def _expected_exit_word(kind: ProcKind) -> str:
    if kind is ProcKind.SUB:
        return "Sub"
    if kind is ProcKind.FUNCTION:
        return "Function"
    return "Property"


def _enclosing_proc_label(kind: ProcKind) -> str:
    if kind is ProcKind.SUB:
        return "Sub"
    if kind is ProcKind.FUNCTION:
        return "Function"
    return "Property procedure"


def _exit_target(source: str, span: Span) -> tuple[str, Span] | None:
    toks = statement_tokens_after_leading_label(source, span)
    if len(toks) < 2 or toks[0].raw_text.lower() != "exit":
        return None
    w = toks[1].raw_text.lower()
    if w == "sub":
        word = "Sub"
    elif w == "function":
        word = "Function"
    elif w == "property":
        word = "Property"
    else:
        return None  # Exit Do / Exit For etc.
    return (word, Span(span.start + toks[0].start, span.start + toks[1].end))


def check_exit_statements(source: str, push: PushFn) -> ProcedureStatementVisitor:
    """Exit Sub/Function/Property must match the enclosing procedure kind."""

    def factory(member: ProcedureNode) -> Callable[[LeafStatementNode], None] | None:
        # VBE special-cases Property Get: it accepts `Exit Function` and `Exit Sub` in
        # addition to `Exit Property` (oracle-verified), since a Property Get is
        # internally value-returning. Property Let/Set and Sub/Function still require
        # the matching keyword, so only Property Get is exempt.
        if member.proc_kind is ProcKind.PROPERTY_GET:
            return None
        expected = _expected_exit_word(member.proc_kind)
        label = _enclosing_proc_label(member.proc_kind)

        def visitor(stmt: LeafStatementNode) -> None:
            hit = _exit_target(source, stmt.span)
            if hit is not None and hit[0] != expected:
                word, hit_span = hit
                push(
                    "exitWrongProcedure",
                    f"'Exit {word}' is not valid inside a {label}; use 'Exit {expected}'.",
                    hit_span,
                )

        return visitor

    return factory


# -- checkStatementContext -------------------------------------------------


@dataclass(frozen=True, slots=True)
class _StatementContext:
    for_depth: int = 0
    do_depth: int = 0
    with_depth: int = 0
    select_depth: int = 0


def _exit_phrase_span(base: Span, first_start: int, target_end: int) -> Span:
    return Span(base.start + first_start, base.start + target_end)


def _check_context_statement(
    source: str, stmt: LeafStatementNode, ctx: _StatementContext, push: PushFn
) -> None:
    toks = statement_tokens_after_leading_label(source, stmt.span)
    if not toks:
        return
    first = toks[0]
    w0 = token_text(first)

    if w0 == "if" and not any(token_text(t) == "then" for t in toks):
        push("ifMissingThen", "If statement is missing 'Then'.", absolute_span(stmt.span, first))

    if w0 == "case" and ctx.select_depth == 0:
        push(
            "caseOutsideSelect",
            "'Case' can only appear inside a 'Select Case' block.",
            absolute_span(stmt.span, first),
        )

    if first.raw_text == "." and ctx.with_depth == 0:
        push(
            "memberAccessOutsideWith",
            "A statement that starts with '.' must be inside a With block.",
            absolute_span(stmt.span, first),
        )

    leading_member = toks[1] if len(toks) > 1 else None
    if first.raw_text == "." and ctx.with_depth > 0 and (leading_member is None or token_name(leading_member) is None):
        push(
            "invalidExpressionSyntax",
            "Incomplete member access: type a member name after '.'.",
            absolute_span(stmt.span, first),
        )

    if w0 == "exit":
        target = toks[1] if len(toks) > 1 else None
        target_word = token_text(target)
        if target is not None and target_word == "for" and ctx.for_depth == 0:
            push(
                "exitOutsideBlock",
                "'Exit For' can only appear inside a For loop.",
                _exit_phrase_span(stmt.span, first.start, target.end),
            )
        elif target is not None and target_word == "do" and ctx.do_depth == 0:
            push(
                "exitOutsideBlock",
                "'Exit Do' can only appear inside a Do loop.",
                _exit_phrase_span(stmt.span, first.start, target.end),
            )


def _check_for_next_control_variable(
    node: ForBlockNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    if (
        not node.control_variable
        or node.control_variable_span is None
        or not node.next_variable
        or node.next_variable_span is None
        or (activity is not None and activity.is_inactive(node.control_variable_span))
        or (activity is not None and activity.is_inactive(node.next_variable_span))
    ):
        return
    if node.control_variable.lower() == node.next_variable.lower():
        return
    # The header and its `Next` must sit under the same arms for the pairing to
    # mean anything. A `For i` guarded by one chain and a `Next j` guarded by
    # another is a pairing no build necessarily makes: each arm is internally
    # consistent, and the parser just sees one loop (XLIDE issue #58).
    if activity is not None and not activity.in_same_branch(
        node.control_variable_span, node.next_variable_span
    ):
        return
    push(
        "nextVariableMismatch",
        f"Next variable '{node.next_variable}' does not match active For control variable "
        f"'{node.control_variable}'.",
        node.next_variable_span,
    )


def _check_context_body(
    source: str,
    body: list[BodyNode],
    ctx: _StatementContext,
    activity: ConditionalActivityTracker | None,
    push: PushFn,
) -> None:
    for node, node_ctx in iter_body_nodes_in_context(
        body, ctx, _block_body_context, inactive_node_skip(activity)
    ):
        if isinstance(node, (StatementNode, AssignmentNode, CallNode)):
            _check_context_statement(source, node, node_ctx, push)
        elif isinstance(node, ForBlockNode):
            _check_for_next_control_variable(node, activity, push)
        elif isinstance(node, IfBlockNode):
            _check_malformed_if_headers(source, node, push)
        # ConditionalDirective / VariableGroup: no context check.


def _block_body_context(block: BodyNode, ctx: _StatementContext) -> _StatementContext:
    """The statement context inside a block's body. If and While bodies keep the
    enclosing context."""
    if isinstance(block, ForBlockNode):
        return replace(ctx, for_depth=ctx.for_depth + 1)
    if isinstance(block, DoBlockNode):
        return replace(ctx, do_depth=ctx.do_depth + 1)
    if isinstance(block, WithBlockNode):
        return replace(ctx, with_depth=ctx.with_depth + 1)
    if isinstance(block, SelectBlockNode):
        return replace(ctx, select_depth=ctx.select_depth + 1)
    return ctx


# Reserved keywords that can never appear inside a value expression, so finding
# one in a block-If branch condition is always a malformed header. `If`, `Else`,
# and `ElseIf` are statement-keywords and `Then` is a marker-keyword
# (MS-VBAL 3.3.5.2); none has any expression meaning. Operator keywords
# (`And`, `Or`, `Not`, `Is`, `TypeOf`, `New`, ...) are intentionally excluded.
_IF_CONDITION_RESERVED_KEYWORDS: frozenset[str] = frozenset({"if", "then", "else", "elseif"})


def _check_malformed_if_headers(source: str, node: IfBlockNode, push: PushFn) -> None:
    """Flags a reserved If-control keyword sitting inside a block-If branch's
    condition, which the VBE rejects with a Syntax error. Covers `If If True Then`
    (the `If` keyword where the condition expression belongs) and
    `If True Then Then` (a second `Then` before the block-opening `Then`).

    No false positives: it only matches `if`/`then`/`else`/`elseif` KEYWORD tokens,
    so identifiers that merely contain those substrings (`IfCount`, `ThenValue`)
    and legal expression keywords are never flagged. `#If`/`#ElseIf` directives are
    a separate ConditionalDirective node, not an IfBlock, so they never reach here."""
    for branch in node.branches:
        if branch.branch_kind is IfBranchKind.ELSE:
            continue
        toks = statement_tokens(source, branch.header_span)
        # The branch's leading If/ElseIf keyword (skip a leading line number or label).
        start_kw = -1
        for i, tok in enumerate(toks):
            if tok.kind is TokenKind.KEYWORD:
                if token_text(tok) in ("if", "elseif"):
                    start_kw = i
                break
            if tok.kind is not TokenKind.INTEGER_LITERAL and tok.raw_text != ":":
                break
        if start_kw < 0:
            continue
        # The block-opening `Then` is the last `then` keyword on the header line.
        close_then = -1
        for i in range(len(toks) - 1, start_kw, -1):
            if toks[i].kind is TokenKind.KEYWORD and token_text(toks[i]) == "then":
                close_then = i
                break
        if close_then < 0:
            continue
        for i in range(start_kw + 1, close_then):
            tok = toks[i]
            if tok.kind is TokenKind.KEYWORD and token_text(tok) in _IF_CONDITION_RESERVED_KEYWORDS:
                push(
                    "ifReservedKeywordInCondition",
                    f"Unexpected '{tok.raw_text}' in the If condition.",
                    absolute_span(branch.header_span, tok),
                )
                break


# -- checkDuplicateLabels / checkUndefinedLabels ---------------------------


def check_duplicate_labels(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    for member in active_module_members(mod, activity):
        if not isinstance(member, ProcedureNode):
            continue
        placed: dict[str, list[Span]] = {}
        for label in collect_procedure_label_declarations(source, member, activity):
            earlier = placed.get(label.key)
            if earlier is None:
                placed[label.key] = [label.span]
                continue
            # Only a label that could be compiled beside this one collides; two
            # arms of one chain are never built together (XLIDE issue #58).
            collides = any(
                activity is None or not activity.mutually_exclusive(prior, label.span)
                for prior in earlier
            )
            earlier.append(label.span)
            if collides:
                push(
                    "duplicateLabel",
                    f"Label '{label.text}' is already defined in procedure '{member.name}'.",
                    label.span,
                )


# The reserved words a line may start with before a colon without a syntax error,
# because the VBE reads them as their own statement there: `End:`, `Stop:`,
# `Close:`, `Do:` (Do without Loop), `Print:` and the like (issue #272, measured in
# Excel 16.0). Every other reserved word is "Syntax error" as a label. Rem starts a
# comment.
_RESERVED_LINE_STARTS: frozenset[str] = frozenset(
    {"close", "end", "resume", "return", "stop", "doevents", "do", "else", "endif", "loop", "next", "wend", "rem"}
)

# The reserved words that, before a colon, are a statement the VBE refuses for
# another reason.
_RESERVED_LINE_ERRORS: Mapping[str, str] = {
    "print": "Method not valid without suitable object",
    "scale": "Method not valid without suitable object",
    "cdec": "Argument not optional",
    "date": "Invalid use of property",
}

# /^([ \t]*)([A-Za-z][A-Za-z0-9_]*)[ \t]*:(?!=)/
_LINE_LABEL_RE = re.compile(r"([ \t]*)([A-Za-z][A-Za-z0-9_]*)[ \t]*:(?!=)")
# /[ \t]_[ \t]*\r?\n$/ (JavaScript's `$` without the m flag is the end of the text)
_CONTINUED_LINE_END_RE = re.compile(r"[ \t]_[ \t]*\r?\n\Z")


def check_reserved_labels(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    """A line label cannot be a reserved word (issue #272, measured in Excel 16.0
    for every reserved word): `GoTo Fix` and a line `Fix:` are "Syntax error", where
    `GoTo Mid` and `Mid:` compile, since Mid is a library function a label may
    shadow. A jump's target is checked after GoTo, GoSub, On ... GoTo and Resume,
    `On Error GoTo 0` and `Resume Next` aside."""

    def reserved(tok: VbaToken | None) -> bool:
        return (
            tok is not None
            and tok.kind is not TokenKind.INTEGER_LITERAL
            and is_reserved_identifier(tok.raw_text)
        )

    for member in active_module_members(mod, activity):
        if not isinstance(member, ProcedureNode):
            continue

        # A line that starts `Word:`. Read from the source, since the parser takes
        # `Dim:` and `Const:` as declarations and splits `Fix:` at the colon (issue
        # #272).
        def visit_line(line: Span) -> None:
            if activity is not None and activity.is_inactive(line):
                return
            label = _LINE_LABEL_RE.match(source[line.start : line.end])
            lower = label.group(2).lower() if label is not None else None
            if (
                label is None
                or not lower
                or not is_reserved_identifier(lower)
                or lower in _RESERVED_LINE_STARTS
                or (
                    line.start > 0
                    and _CONTINUED_LINE_END_RE.search(source[max(0, line.start - 64) : line.start])
                    is not None
                )
            ):
                return
            indent = len(label.group(1))
            word = label.group(2)
            span = Span(line.start + indent, line.start + indent + len(word))
            error = _RESERVED_LINE_ERRORS.get(lower)
            push(
                "malformedStatement",
                f"'{word}:' is the statement {word}, not a line label. This is a VBE compile "
                f"error: {error}."
                if error
                else f"'{word}' is a reserved word, so '{word}:' cannot be a line label. This is "
                "a VBE compile error: Syntax error.",
                span,
            )

        for_each_procedure_body_line(source, member, visit_line)

        def visit_statement(stmt: LeafStatementNode) -> None:
            toks = statement_tokens(source, stmt.span)
            for k in range(len(toks) - 1):
                word = token_text(toks[k])
                jumps = (
                    word == "goto"
                    or word == "gosub"
                    or (word == "resume" and token_text(toks[k + 1]) != "next")
                )
                if not jumps:
                    continue
                # `On x GoTo A, B`: each target after the comma too.
                for t in range(k + 1, len(toks), 2):
                    if reserved(toks[t]):
                        push(
                            "malformedStatement",
                            f"'{toks[t].raw_text}' is a reserved word, so it cannot name a line "
                            "label to jump to. This is a VBE compile error: Syntax error.",
                            absolute_span(stmt.span, toks[t]),
                        )
                        break
                    if (word != "goto" and word != "gosub") or (
                        t + 1 >= len(toks) or toks[t + 1].raw_text != ","
                    ):
                        break

        for_each_statement(member.body, visit_statement, activity)


def check_undefined_labels(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    for member in active_module_members(mod, activity):
        if not isinstance(member, ProcedureNode):
            continue
        declarations: dict[str, list[Span]] = {}
        for label in collect_procedure_label_declarations(source, member, activity):
            declarations.setdefault(label.key, []).append(label.span)
        for ref in collect_procedure_label_references(source, member, activity):
            # A label in a different arm from the reference is not a target: the
            # build that compiles the `GoTo` does not compile that label
            # (XLIDE issue #58).
            reachable = any(
                activity is None or not activity.mutually_exclusive(span, ref.span)
                for span in declarations.get(ref.key, ())
            )
            if not reachable:
                push(
                    "undefinedLabel",
                    f"Label '{ref.text}' is not defined in procedure '{member.name}'.",
                    ref.span,
                )


# The largest line number the VBE accepts, the top of the Long range.
_MAX_LINE_NUMBER = 2147483647

# /^\d+$/: JavaScript's `\d` is ASCII only.
_DIGITS_RE = re.compile(r"[0-9]+")


def check_line_number_range(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    """A line number is 0 to 2147483647. `2147483648 x = 1` and `-1 x = 1` are each
    "Syntax error" in the VBE (issue #210, measured in Excel 16.0)."""
    for member in active_module_members(mod, activity):
        if not isinstance(member, ProcedureNode):
            continue

        def visit(stmt: LeafStatementNode) -> None:
            toks = statement_tokens(source, stmt.span)
            first = toks[0] if toks else None
            if (
                first is not None
                and first.kind is TokenKind.INTEGER_LITERAL
                and _DIGITS_RE.fullmatch(first.raw_text) is not None
                and int(first.raw_text) > _MAX_LINE_NUMBER
            ):
                push(
                    "invalidLineNumber",
                    f"Line number {first.raw_text} is past {_MAX_LINE_NUMBER}, the largest the VBE "
                    "accepts. This is a VBE compile error: Syntax error.",
                    absolute_span(stmt.span, first),
                )
                return
            # `x = 1: 20 y = 2`, `10 L1: 20`: a line number after a colon, even in a
            # one-line If's tail (issue #230, measured in Excel 16.0).
            if first is not None and is_decimal_line_number(first) and not starts_physical_line(
                source, stmt.span.start
            ):
                push(
                    "invalidLineNumber",
                    f"Line number {first.raw_text} is not at the start of its line, the only place "
                    "one goes. This is a VBE compile error: Syntax error.",
                    absolute_span(stmt.span, first),
                )
                return
            # `-1 x = 1`: a negative number where a line number goes. A statement
            # never opens with a minus, so this is no expression.
            number = toks[1] if len(toks) > 1 else None
            following = toks[2] if len(toks) > 2 else None
            if (
                first is not None
                and first.raw_text == "-"
                and number is not None
                and number.kind is TokenKind.INTEGER_LITERAL
                and _DIGITS_RE.fullmatch(number.raw_text) is not None
                and following is not None
                and following.kind in (TokenKind.IDENTIFIER, TokenKind.KEYWORD)
            ):
                push(
                    "invalidLineNumber",
                    f"A line number cannot be negative: -{number.raw_text}. This is a VBE compile "
                    "error: Syntax error.",
                    Span(absolute_span(stmt.span, first).start, absolute_span(stmt.span, number).end),
                )

        for_each_statement(member.body, visit, activity)


# -- checkElseBranchOrder --------------------------------------------------


def check_else_branch_order(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    _check_conditional_compilation_else_branch_order(source, mod, push)
    _check_if_block_else_branch_order(source, mod, activity, push)


def _check_conditional_compilation_else_branch_order(
    source: str, mod: ModuleNode, push: PushFn
) -> None:
    # Conditional-compilation directives are checked structurally, regardless of
    # branch activity (a malformed #If block fails to compile either way).
    for issue in scan_conditional_compilation_branch_order(mod).issues:
        if issue.kind == "elseifAfterElse":
            message = (
                "'#ElseIf' cannot appear after '#Else' in the same conditional-compilation block."
            )
        else:
            message = "Only one '#Else' branch is allowed in a conditional-compilation block."
        push("elseBranchOrder", message, _conditional_directive_keyword_span(source, issue.directive))


def _check_if_block_else_branch_order(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    for member in active_module_members(mod, activity):
        if isinstance(member, ProcedureNode):
            _check_if_block_else_branch_order_in_body(source, member.body, activity, push)


def _check_if_block_else_branch_order_in_body(
    source: str, body: list[BodyNode], activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    for node in iter_body_nodes(body, inactive_node_skip(activity)):
        if isinstance(node, IfBlockNode):
            _check_single_if_block_else_branch_order(source, node, activity, push)


def _check_single_if_block_else_branch_order(
    source: str, node: IfBlockNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    elses_above: list[Span] = []
    for child in node.body:
        if is_inactive_node(activity, child) or not is_leaf_statement(child):
            continue
        toks = statement_tokens_after_leading_label(source, child.span)
        if not toks:
            continue
        word = token_text(toks[0])
        if word not in ("elseif", "else"):
            continue
        if child.single_line_if_tail:
            continue  # after a one-line If's colon: never a clause of this block
        # Only an `Else` that could be compiled beside this branch counts as
        # preceding it (XLIDE issue #58).
        after = any(
            activity is None or not activity.mutually_exclusive(prior, child.span)
            for prior in elses_above
        )
        if word == "elseif":
            if after:
                push(
                    "elseBranchOrder",
                    "'ElseIf' cannot appear after 'Else' in the same If block.",
                    absolute_span(child.span, toks[0]),
                )
        else:
            if after:
                push(
                    "elseBranchOrder",
                    "Only one 'Else' branch is allowed in an If block.",
                    absolute_span(child.span, toks[0]),
                )
            elses_above.append(child.span)


def _conditional_directive_keyword_span(source: str, directive: ConditionalDirectiveNode) -> Span:
    tokens = [
        tok
        for tok in tokenize(source[directive.span.start : directive.span.end])
        if tok.kind is not TokenKind.COMMENT and tok.kind is not TokenKind.NEWLINE
    ]
    marker = tokens[0] if tokens else None
    keyword = tokens[1] if len(tokens) > 1 else None
    if marker is not None and marker.kind is TokenKind.DIRECTIVE and keyword is not None:
        return Span(directive.span.start + marker.start, directive.span.start + keyword.end)
    return directive.span


def check_statement_context(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    for member in active_module_members(mod, activity):
        if isinstance(member, ProcedureNode):
            _check_context_body(source, member.body, _StatementContext(), activity, push)


# -- checkDuplicateCaseElse ------------------------------------------------


def _for_each_select_block(
    body: list[BodyNode],
    activity: ConditionalActivityTracker | None,
    visit: Callable[[SelectBlockNode], None],
) -> None:
    for node in iter_body_nodes(body, inactive_node_skip(activity)):
        if isinstance(node, SelectBlockNode):
            visit(node)


def check_duplicate_case_else(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    """A `Select Case` block may contain at most one `Case Else` (MS-VBAL 5.4.2.10;
    oracle-verified `duplicate_case_else_compile`). Only the block's own clauses
    count, and every `Case Else` shares one key: only the arms of one `#If` chain
    are alternatives, and an undecidable branch still counts, which is what a
    genuine repeat inside one arm needs."""

    def case_else_key(node: BodyNode) -> str | None:
        if not is_leaf_statement(node) or (activity is not None and activity.is_inactive(node.span)):
            return None
        return "case else" if _case_else_tokens(source, node.span) is not None else None

    def report(repeat: BodyNode, earlier: BodyNode) -> None:
        hit = _case_else_tokens(source, repeat.span)
        assert hit is not None
        case_tok, else_tok = hit
        push(
            "duplicateCaseElse",
            "A 'Select Case' block can have only one 'Case Else'.",
            Span(absolute_span(repeat.span, case_tok).start, absolute_span(repeat.span, else_tok).end),
        )

    def visit_select(select: SelectBlockNode) -> None:
        report_repeated_keys(select.body, activity, case_else_key, lambda node: node.span, report)

    for member in active_module_members(mod, activity):
        if isinstance(member, ProcedureNode):
            _for_each_select_block(member.body, activity, visit_select)


def _case_else_tokens(source: str, span: Span) -> tuple[VbaToken, VbaToken] | None:
    """The `Case` and `Else` tokens of a `Case Else` clause, or None."""
    toks = statement_tokens_after_leading_label(source, span)
    if len(toks) < 2 or token_text(toks[0]) != "case" or token_text(toks[1]) != "else":
        return None
    return toks[0], toks[1]


# -- checkElseWithoutIf ----------------------------------------------------


def check_else_without_if(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    def visit(body: list[BodyNode]) -> None:
        # Each node comes with whether the body holding it is an If block's, and
        # that body's count of one-line Ifs on the current logical line still
        # without an Else. Each may take one `Else` after a colon (MS-VBAL
        # 5.4.2.9), innermost first.
        for node, (inside_if_block, open_ifs) in iter_body_nodes_in_context(
            body,
            (False, [0]),
            lambda block, _: (isinstance(block, IfBlockNode), [0]),
            inactive_node_skip(activity),
        ):
            if not is_leaf_statement(node):
                continue
            toks = statement_tokens_after_leading_label(source, node.span)
            first = toks[0] if toks else None
            word = token_text(first) if first is not None else ""
            else_tail = node.single_line_if_tail and word == "else" and open_ifs[0] > 0
            open_ifs[0] = max(
                0, (open_ifs[0] if node.single_line_if_tail else 0) + _ifs_minus_elses(toks)
            )
            if else_tail:
                continue  # `If a Then b = 1: Else c = 2`
            if inside_if_block and not node.single_line_if_tail:
                continue  # a legit Else/ElseIf header inside its If block
            if first is not None and (word == "else" or word == "elseif"):
                push(
                    "elseWithoutIf",
                    f"'{first.raw_text}' can only appear inside an 'If' block.",
                    absolute_span(node.span, first),
                )

    for member in active_module_members(mod, activity):
        if isinstance(member, ProcedureNode):
            visit(member.body)


def _ifs_minus_elses(toks: Sequence[VbaToken]) -> int:
    """`If` keyword tokens minus `Else` ones: the one-line Ifs a statement leaves
    open. `End If` and member names (`obj.If`, `rs!Else`) are neither."""
    open_count = 0
    for i, tok in enumerate(toks):
        prev = toks[i - 1] if i > 0 else None
        if prev is not None and prev.raw_text in (".", "!"):
            continue
        word = token_text(tok) if tok.kind == TokenKind.KEYWORD else ""
        if word == "if" and token_text(prev) != "end":
            open_count += 1
        elif word == "else":
            open_count -= 1
    return open_count


# -- checkMalformedStatements ----------------------------------------------


def check_malformed_statements(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    def inspect(stmt: LeafStatementNode) -> None:
        toks = statement_tokens(source, stmt.span)
        if not toks:
            return
        first = toks[0]
        second = toks[1] if len(toks) > 1 else None
        if (
            second is not None
            and second.raw_text == "="
            and first.kind in (TokenKind.INTEGER_LITERAL, TokenKind.FLOAT_LITERAL, TokenKind.STRING_LITERAL)
        ):
            push("invalidAssignmentTarget", "Cannot assign to a literal value.", absolute_span(stmt.span, first))
        if token_text(first) == "open":
            problem = _malformed_open_statement(toks)
            if problem is not None:
                push("openMissingForMode", problem, absolute_span(stmt.span, first))

    for member in active_module_members(mod, activity):
        if isinstance(member, ProcedureNode):
            for_each_statement(member.body, inspect, activity)


# The words the mode clause of an Open statement is made of.
_OPEN_MODE_WORDS = frozenset({"input", "output", "append", "binary", "random"})


def _malformed_open_statement(toks: Sequence[VbaToken]) -> str | None:
    """Why an `Open` statement will not compile, or None when it will.

    `For mode` is OPTIONAL: `Open path As #f` opens the file for Random access, and
    `Open path Access Read As #f` compiles too (XLIDE issue #97; both run in Excel
    16.0). What the VBE refuses is a mode word standing without its `For`
    ("Expected: For", oracle case corpus_edges_005_malformed_open_compile) and a
    statement with no `As` clause at all ("Syntax error": `Open path` and
    `Open path Len = 4`, measured 2026-09-26).
    """
    saw_as = False
    for i in range(1, len(toks)):
        word = token_text(toks[i])
        if word == "as":
            saw_as = True
            continue
        if word in _OPEN_MODE_WORDS and token_text(toks[i - 1]) != "for":
            # Output, Append, Random and Binary are contextual words a variable may
            # be named, so a mode word is one only where the grammar puts it: after
            # the path expression and before what follows the mode
            # (`Open path Output #1`, `Open path Output As #1`).
            prev = toks[i - 1]
            following = token_text(toks[i + 1]) if i + 1 < len(toks) else ""
            ends_operand = prev.kind is not TokenKind.OPERATOR and prev.raw_text not in ("(", ",")
            starts_clause = following in ("", "as", "access", "lock", "shared", "#")
            if ends_operand and starts_clause:
                return f"An 'Open' statement's mode '{toks[i].raw_text}' must follow 'For'."
    return None if saw_as else "An 'Open' statement requires an 'As #filenumber' clause."