"""Rule family: TypeOf ... Is expression rules.

Ported from xlide_vscode/src/analyzer/diagnostics/rules/typeOfIs.ts. The
TypeOf-missing-operand syntax check is host-free and ported. is-operator-non-object
is a BinaryExpr `Is` visitor: a provably-scalar operand of `Is` is a type error. It
fires on expression-reachable forms (`If x Is Nothing`, `b = x Is Nothing`) and is
silent on `Debug.Print x Is Nothing`, a reserved-name receiver statement parses as
a raw StatementNode, so the inner `Is` never reaches the expression walk. This
matches XLIDE byte-for-byte (verified by running XLIDE's analyzer: it too is silent
on the Debug.Print form and fires on the If form); the entire is-operator-non-object
oracle corpus happens to use the dormant Debug.Print form, so those cases are
documented as XLIDE-dormant in the test rather than satisfied.

typeof-is-always-false ports the SAFE v1: a simple-identifier operand whose declared
type resolves to a CONCRETE object class that is mutually incompatible with the
target object class makes `TypeOf x Is T` provably False. Object/Variant/scalar/
unknown/interface operands and any pair that could be assignment-compatible stay
quiet (no-FP). The object-compatibility check is a faithful port of
resolveKnownObjectAssignmentType + objectAssignmentIncompatibilityReason
(typeInference.ts), reusing the host alias resolver and project class members.
"""

from __future__ import annotations

import dataclasses
import re
from collections.abc import Callable, Mapping, Sequence
from collections.abc import Set as AbstractSet
from typing import cast

from ...completion.member_access import (
    KnownObjectAssignmentType,
    MemberCompletionContext,
    resolve_known_object_assignment_type,
    simple_type_name_for_assignment,
)
from ...completion.event_handlers import event_handler_document_type_for_context
from ...conditional import ConditionalActivityTracker
from ...host.host_default_members import HOST_DEFAULT_MEMBERS
from ...host.host_model import HostMember, get_host_members, get_host_type, resolve_host_alias
from ...host.type_extensibility import host_type_resolves_when_compiling
from ...js_compat import js_trim
from ...lexer.token_kinds import TokenKind, VbaToken
from ...lexer.tokenize import tokenize_cached
from ...parser.nodes import (
    BinaryExpr,
    DoBlockNode,
    ExprNode,
    IdentifierExpr,
    IndexExpr,
    LiteralExpr,
    LiteralKind,
    MemberAccessExpr,
    MemberAccessKind,
    ModuleNode,
    ParenExpr,
    ProcedureNode,
    Span,
    StatementNode,
    TypeOfIsExpr,
    UnaryExpr,
    WhileBlockNode,
    iter_body_nodes,
)
from ...parser.parse_expression import parse_expression
from ...runtime.vba_value_results import (
    ARGUMENT_TYPED_FUNCTIONS,
    BARE_VALUE_RESULT_FUNCTIONS,
    TYPEOF_KEYWORD_OPERANDS,
    VALUE_RESULT_FUNCTIONS,
)
from ...identity_cache import IdentityLru
from ...symbols.symbol_model import (
    ModuleSymbolKind,
    ModuleSymbols,
    VbaProcedureSignature,
    VbaSymbol,
    VbaSymbolKind,
    qualified_procedure_key,
)
from ...symbols.name_resolution import BareIdentifierContext
from ...types.type_inference import (
    SCALAR_OBJECT_ASSIGNMENT_REASON,
    procedure_symbol_for,
    source_identifier_bound,
    type_environment_for,
)
from ...types.type_names import is_known_scalar_type, normalize_type
from ..call_extraction import CallableTypeSignature, InferredArgumentType
from ..callable_signatures import (
    SourceNameScope,
    bare_callable_source_shadowed,
    callable_type_signatures_for,
    source_name_scope_for,
)
from ..context import PushFn, statement_tokens
from ..exprwalk import ProcedureExpressionVisitor, for_each_sub_expression
from ..walker import (
    active_module_members,
    block_footer_line_span,
    block_header_line_span,
    is_inactive_node,
    token_text,
)

_TRAILING_ARRAY_RE = re.compile(r"\s*\(\s*\)\s*$")


def check_type_of_missing_operand(
    source: str, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    """`TypeOf` requires an object expression before `Is`; `TypeOf Is Y` is a syntax error."""
    toks = [
        tok
        for tok in tokenize_cached(source)
        if tok.kind is not TokenKind.COMMENT and tok.kind is not TokenKind.NEWLINE
    ]
    for i in range(len(toks) - 1):
        if (toks[i].canonical_text or toks[i].raw_text).lower() != "typeof":
            continue
        if (toks[i + 1].canonical_text or toks[i + 1].raw_text).lower() != "is":
            continue
        span = Span(toks[i].start, toks[i + 1].end)
        if activity is not None and activity.is_inactive(span):
            continue
        push("typeofMissingOperand", "'TypeOf' requires an object expression before 'Is'.", span)


# -- checkIsOperatorOperands (is-operator-non-object) -----------------------

_IS_NON_OBJECT_LITERAL_KINDS: dict[LiteralKind, str] = {
    LiteralKind.INTEGER: "integer",
    LiteralKind.FLOAT: "float",
    LiteralKind.STRING: "string",
    LiteralKind.DATE: "date",
    LiteralKind.BOOLEAN: "boolean",
}


def _non_object_operand(
    operand: ExprNode,
    env: dict[str, str],
    call_result: Callable[[ExprNode], tuple[str, str] | None] | None = None,
) -> tuple[Span, str] | None:
    """A provably non-object (scalar) operand of `Is`, or None."""
    # `(n) Is Nothing` is the same Type mismatch (issue #1415, measured in
    # Excel, Word, PowerPoint and Access 16.0).
    expr = operand
    while isinstance(expr, ParenExpr):
        expr = expr.inner
    # `a(0) Is Nothing` for a Long array: its element is a Long (issue #1415).
    if isinstance(expr, IndexExpr) and isinstance(expr.callee, IdentifierExpr):
        array_type = env.get(expr.callee.name.lower())
        element = js_trim(_TRAILING_ARRAY_RE.sub("", array_type, count=1)) if array_type is not None else None
        if element and is_known_scalar_type(element.lower()):
            article = "an" if element[0].lower() in "aeiou" else "a"
            return (expr.span, f"an element of '{expr.callee.name}' is {article} {element}")
    result = call_result(expr) if call_result is not None else None
    if result is not None and result[0] == "value":
        return (expr.span, f"VBA's '{result[1]}' returns a value")
    if result is not None and is_known_scalar_type(_TRAILING_ARRAY_RE.sub("", result[0]).strip().lower()):
        return (expr.span, f"'{result[1]}' returns {result[0]}")
    if isinstance(expr, LiteralExpr):
        kind = _IS_NON_OBJECT_LITERAL_KINDS.get(expr.literal_kind)
        if kind is not None:
            return (expr.span, f"'{expr.raw}' is a {kind} literal")
        return None  # Nothing / Null / Empty -> not provably scalar
    if isinstance(expr, IdentifierExpr):
        declared = env.get(expr.name.lower())
        if not declared:
            return None  # undeclared / unknown -> quiet
        # Strip only a trailing array `()` marker -- NOT normalize_type's leading-`vb`
        # strip, which would wrongly collapse a user class named `vbLong` to a scalar.
        raw = _TRAILING_ARRAY_RE.sub("", declared).strip().lower()
        if is_known_scalar_type(raw):
            return (expr.span, f"'{expr.name}' is declared As {declared}")
        return None  # Variant / Object / class -> quiet
    return None  # member / call / paren / array / New / unary -> quiet (v1)


def _call_result_type(
    expr: ExprNode,
    env: dict[str, str],
    module_signatures: Mapping[str, CallableTypeSignature],
    source_names: SourceNameScope,
) -> tuple[str, str] | None:
    """The declared result of a call to a project or same-module Function, `Bar()`
    or `Other.Foo()`, typed by the DefType of the module that declares it, with the
    name to show for the call. None for a variable's element, a name a source
    variable takes, and VBA's own functions, which were not measured (XLIDE issue
    #1411)."""
    if not isinstance(expr, IndexExpr):
        return None
    callee = expr.callee
    if isinstance(callee, IdentifierExpr):
        lower = callee.name.lower()
        if lower in env or bare_callable_source_shadowed(callee.name, source_names):
            return None
        signature = module_signatures.get(lower)
        type_ = signature.return_type if signature is not None else None
        return (type_, callee.name) if type_ else None
    if (
        isinstance(callee, MemberAccessExpr)
        and callee.access_kind is not MemberAccessKind.BANG
        and isinstance(callee.object_, IdentifierExpr)
    ):
        qualifier = callee.object_.name
        if qualifier.lower() in env or qualifier.lower() in source_names.callable_shadows:
            return None
        signature = module_signatures.get(qualified_procedure_key(qualifier, callee.member))
        type_ = signature.return_type if signature is not None else None
        return (type_, f"{qualifier}.{callee.member}") if type_ else None
    return None


def _enum_type_names(symbols: ModuleSymbols, project_visible_symbols: Sequence[VbaSymbol] | None) -> frozenset[str]:
    """The Enums this module and the project make visible, lowercase. A name
    another kind of symbol of the project also takes is left out."""
    enums: set[str] = set()
    others: set[str] = set()
    for sym in [*(symbols.root.children or []), *(project_visible_symbols or [])]:
        (enums if sym.kind is VbaSymbolKind.ENUM else others).add(sym.name.lower())
    return frozenset(enums - others)


def _enum_operand(operand: ExprNode, env: dict[str, str], enums: AbstractSet[str]) -> tuple[Span, str] | None:
    """`n Is Nothing` and `TypeOf n Is Collection` with n declared As an Enum,
    of this module or another: Type mismatch (XLIDE issue #1416, measured in
    Excel, Word, PowerPoint and Access 16.0)."""
    expr = operand
    while isinstance(expr, ParenExpr):
        expr = expr.inner
    if not isinstance(expr, IdentifierExpr):
        return None
    declared = env.get(expr.name.lower())
    if declared and js_trim(declared).lower() in enums:
        return (expr.span, f"'{expr.name}' is declared As {declared}, an Enum")
    return None


def _runtime_value_result(
    expr: ExprNode,
    form: str,
    env: dict[str, str],
    shadowed: Callable[[str], bool],
) -> tuple[str, str] | None:
    """A call to one of VBA's own functions whose result is a value under `Is`
    (form "is") or `TypeOf` (form "typeof"), vba_value_results.py, XLIDE issue
    #1416: `CDbl(1)`, `VBA.Mid$(s, 1)`, `Erl`. None when `shadowed` says a
    source or object name takes the function's name or `VBA`'s, and for a bare
    keyword-named TypeOf operand, which is a Syntax error reported in
    expressions.py. The result's type is "value"."""
    target = expr.callee if isinstance(expr, IndexExpr) else expr
    args = expr.args if isinstance(expr, IndexExpr) else []
    if isinstance(target, IdentifierExpr):
        if shadowed(target.name):
            return None
        display = target.name
        qualified = False
        if target.type_suffix and target.type_suffix != "$":
            return None
        name = target.name + (target.type_suffix or "")
    elif (
        isinstance(target, MemberAccessExpr)
        and target.access_kind is not MemberAccessKind.BANG
        and isinstance(target.object_, IdentifierExpr)
        and target.object_.name.lower() == "vba"
        and not shadowed("VBA")
    ):
        if target.type_suffix and target.type_suffix != "$":
            return None
        name = f"{target.member}{target.type_suffix or ''}"
        display = f"VBA.{name}"
        qualified = True
    else:
        return None
    lower = name.lower()
    if not qualified and form == "typeof" and lower in TYPEOF_KEYWORD_OPERANDS:
        return None
    value = (
        lower in VALUE_RESULT_FUNCTIONS
        or (not qualified and lower in BARE_VALUE_RESULT_FUNCTIONS)
        or (
            not qualified
            and form == "is"
            and lower in ARGUMENT_TYPED_FUNCTIONS
            and len(args) > 0
            and all(arg.value is not None and _provably_scalar(arg.value, env, shadowed) for arg in args)
        )
    )
    if not value:
        return None
    return ("value", f"{display}{'(...)' if args or isinstance(expr, IndexExpr) else ''}")


def _without_control_locals(
    env: dict[str, str],
    implicit_locals: AbstractSet[str] | None,
    object_names: AbstractSet[str],
) -> dict[str, str]:
    """The environment without the implicit locals a control's name takes. With
    DefLng and no Option Explicit, `Picker = 1` in a form whose ComboBox is
    Picker assigns the control's Value; it declares no Long (XLIDE issue #1419).
    A copy, since the environment is shared."""
    controls = [name for name in implicit_locals or () if name in object_names]
    if not controls:
        return env
    out = dict(env)
    for name in controls:
        out.pop(name, None)
    return out


# Arithmetic and `&`, which give a value when both sides are values.
_SCALAR_OPERATORS = frozenset({"+", "-", "*", "/", "\\", "^", "Mod", "&"})


def _provably_scalar(expr: ExprNode, env: dict[str, str], shadowed: Callable[[str], bool]) -> bool:
    """An argument that is provably a value: a literal, a typed variable or
    element, a value call, or arithmetic on those. Upstream recurses through the
    operands; an explicit stack does the same here, every operand having to be
    a value."""
    pending = [expr]
    while pending:
        node = pending.pop()
        if isinstance(node, ParenExpr):
            pending.append(node.inner)
            continue
        if isinstance(node, UnaryExpr) and node.operator == "-":
            pending.append(node.operand)
            continue
        if isinstance(node, BinaryExpr):
            if node.operator not in _SCALAR_OPERATORS:
                return False
            pending.append(node.right)
            pending.append(node.left)
            continue
        if _non_object_operand(node, env, lambda inner: _runtime_value_result(inner, "is", env, shadowed)) is None:
            return False
    return True


def check_is_operator_operands(
    symbols: ModuleSymbols,
    push: PushFn,
    project_procedures: Mapping[str, Sequence[VbaProcedureSignature]] | None = None,
    project_visible_symbols: Sequence[VbaSymbol] | None = None,
    object_names: AbstractSet[str] = frozenset(),
) -> ProcedureExpressionVisitor:
    """The `Is` operator requires object operands; a provably-scalar operand is an error."""

    module_signatures = callable_type_signatures_for(symbols, project_procedures)
    enums: list[frozenset[str]] = []

    def enum_names() -> frozenset[str]:
        if not enums:
            enums.append(_enum_type_names(symbols, project_visible_symbols))
        return enums[0]

    def factory(member: ProcedureNode) -> Callable[[ExprNode], None]:
        implicit_locals = symbols.implicit_locals.get(member.span.start) if symbols.implicit_locals else None
        env = _without_control_locals(type_environment_for(symbols, member), implicit_locals, object_names)
        source_names = source_name_scope_for(symbols, member, project_visible_symbols)
        proc_sym = procedure_symbol_for(symbols, member)

        # A VBA function's name answers the source, or the module's own object,
        # before VBA: a control or a predeclared class named Timer makes `Timer`
        # that object (XLIDE issue #1419, measured in all four hosts).
        def shadowed(name: str) -> bool:
            return (
                name.lower() in env
                or name.lower() in object_names
                or source_identifier_bound(
                    symbols, proc_sym, project_visible_symbols, name, BareIdentifierContext.EXPRESSION
                )
            )

        def result_of(form: str) -> Callable[[ExprNode], tuple[str, str] | None]:
            def results(expr: ExprNode) -> tuple[str, str] | None:
                return _call_result_type(expr, env, module_signatures, source_names) or _runtime_value_result(
                    expr, form, env, shadowed
                )

            return results

        calls = result_of("is")
        type_of_calls = result_of("typeof")

        def operand(
            side: ExprNode, results: Callable[[ExprNode], tuple[str, str] | None]
        ) -> tuple[Span, str] | None:
            return _non_object_operand(side, env, results) or _enum_operand(side, env, enum_names())

        def visitor(expr: ExprNode) -> None:
            # `TypeOf n Is Collection` with n a Long is the same compile error,
            # Type mismatch (XLIDE issue #1411, measured in Excel, Word,
            # PowerPoint and Access 16.0). A literal operand is a Syntax error,
            # which expressions.py reports (XLIDE issue #1416).
            if isinstance(expr, TypeOfIsExpr):
                type_of_offender = (
                    None if isinstance(expr.operand, LiteralExpr) else operand(expr.operand, type_of_calls)
                )
                if type_of_offender is not None:
                    push(
                        "isOperatorNonObject",
                        f"'TypeOf ... Is' requires an object operand, but {type_of_offender[1]}, which is not an object.",
                        type_of_offender[0],
                    )
                return
            if not isinstance(expr, BinaryExpr) or expr.operator != "Is":
                return
            offender = operand(expr.left, calls) or operand(expr.right, calls)
            if offender is not None:
                span, detail = offender
                push(
                    "isOperatorNonObject",
                    f"The 'Is' operator requires object operands, but {detail}, "
                    "which is not an object.",
                    span,
                )

        return visitor

    return factory


def check_is_operands_in_conditions(
    source: str,
    mod: ModuleNode,
    symbols: ModuleSymbols,
    activity: ConditionalActivityTracker | None,
    push: PushFn,
    project_procedures: Mapping[str, Sequence[VbaProcedureSignature]] | None = None,
    project_visible_symbols: Sequence[VbaSymbol] | None = None,
    object_names: AbstractSet[str] = frozenset(),
) -> None:
    """The same check on the conditions the expression walk does not parse: a
    single-line If's, and a Do or While loop's (XLIDE issue #325, measured in Excel
    16.0: each is a compile error, Type mismatch)."""
    check_operands = check_is_operator_operands(
        symbols, push, project_procedures, project_visible_symbols, object_names
    )
    for member in active_module_members(mod, activity):
        if not isinstance(member, ProcedureNode):
            continue
        check_expression = check_operands(member)

        def check(
            span: Span,
            from_: int,
            to: Callable[[list[VbaToken]], int],
            check_expression: Callable[[ExprNode], None] = check_expression,
        ) -> None:
            # Absolute offsets, so the parsed nodes carry the source's spans.
            toks = [
                dataclasses.replace(tok, start=span.start + tok.start, end=span.start + tok.end)
                for tok in statement_tokens(source, span)
                if tok.kind is not TokenKind.COMMENT
            ]
            end = to(toks)
            if end <= from_:
                return
            parsed = parse_expression(toks, from_, end).expr
            if parsed is None:
                return
            for_each_sub_expression(parsed, check_expression)

        def if_condition_end(toks: list[VbaToken]) -> int:
            if token_text(toks[0] if toks else None) != "if":
                return -1
            return next((i for i, tok in enumerate(toks) if token_text(tok) == "then"), -1)

        def whole(toks: list[VbaToken]) -> int:
            return len(toks)

        for node in iter_body_nodes(member.body, lambda node: is_inactive_node(activity, node)):
            if isinstance(node, StatementNode) and node.single_line_if_branches:
                check(node.span, 1, if_condition_end)
            elif isinstance(node, (DoBlockNode, WhileBlockNode)):
                header = block_header_line_span(source, node.span)
                head_toks = statement_tokens(source, header)
                head0 = token_text(head_toks[0] if head_toks else None)
                head1 = token_text(head_toks[1] if len(head_toks) > 1 else None)
                from_ = 2 if head0 == "do" and head1 in ("while", "until") else 1 if head0 == "while" else -1
                if from_ > 0:
                    check(header, from_, whole)
                if isinstance(node, DoBlockNode):
                    footer = block_footer_line_span(source, node.span)
                    foot_toks = statement_tokens(source, footer)
                    if token_text(foot_toks[0] if foot_toks else None) == "loop" and token_text(
                        foot_toks[1] if len(foot_toks) > 1 else None
                    ) in ("while", "until"):
                        check(footer, 2, whole)


# -- checkTypeOfIsCompatibility (always-False) ------------------------------


_PROJECT_DOCUMENT_HOST_TYPES_CACHE = IdentityLru()


def _project_document_host_types(member_ctx: MemberCompletionContext) -> dict[str, str]:
    """Each document module's host class, lowercased and qualified
    (`excel.workbook` for ThisWorkbook): its designer's class where the workbook
    gave one, otherwise the class its document type or, failing that, its code
    name implies."""
    members = member_ctx.project_class_members
    cached = _PROJECT_DOCUMENT_HOST_TYPES_CACHE.get(member_ctx, members)
    if cached is not None:
        return cast(dict[str, str], cached)
    types: dict[str, str] = {}
    for candidate in members or []:
        if candidate.kind != "document":
            continue
        document_type = event_handler_document_type_for_context(
            candidate.name, ModuleSymbolKind.DOCUMENT, candidate.document_type
        )
        host_type = candidate.designer_class if candidate.designer_class is not None else (
            "Excel.Workbook" if document_type == "workbook"
            else "Excel.Chart" if document_type == "chart"
            else "Word.Document" if document_type == "document"
            else "Excel.Worksheet"
        )
        types[candidate.name.lower()] = host_type.lower()
    return cast(dict[str, str], _PROJECT_DOCUMENT_HOST_TYPES_CACHE.put(types, member_ctx, members))


def _implements_object_type(
    actual: KnownObjectAssignmentType, expected: KnownObjectAssignmentType
) -> bool:
    """Port of implementsObjectType: True when the actual project class declares
    `Implements <expected>` (honouring excel.-qualified host keys)."""
    expected_names = {expected.key}
    simple = simple_type_name_for_assignment(expected.display)
    if simple:
        expected_names.add(simple.lower())
    last_segment = expected.key.split(".")[-1]
    if last_segment:
        expected_names.add(last_segment)
    for implemented in actual.implements:
        lower = implemented.lower()
        if lower in expected_names or f"excel.{lower}" in expected_names:
            return True
    return False


_SCRIPTING_TYPE_RE = re.compile(r"^scripting\.(\w+)\Z", re.ASCII)
_WORKSHEET_OR_CHART_KEY_RE = re.compile(r"(^|\.)(worksheet|chart)$")

ObjectTypeResolver = Callable[[str | None, MemberCompletionContext], KnownObjectAssignmentType | None]


def object_assignment_incompatibility_reason(
    expected_raw: str | None,
    actual: InferredArgumentType | None,
    member_ctx: MemberCompletionContext,
    resolve_type: ObjectTypeResolver = resolve_known_object_assignment_type,
    share_interfaces: Callable[[str, str], bool] | None = None,
) -> str | None:
    """Port of objectAssignmentIncompatibilityReason: why an object-position target
    typed `expected_raw` cannot accept `actual`, or None when it can (the no-FP gate).

    Reused by the member-assignment Set branch. Returns the human reason string XLIDE
    emits; None whenever the operands are not both provably-incompatible object types
    (Variant/Nothing/Object/implements all stay quiet)."""
    expected = resolve_type(expected_raw, member_ctx)
    if expected is None or actual is None:
        return None
    actual_type = normalize_type(actual.type_)
    if not actual_type or actual_type in ("variant", "nothing"):
        return None
    if is_known_scalar_type(actual_type):
        return SCALAR_OBJECT_ASSIGNMENT_REASON
    # Object takes any object and could be any. VBA's Collection is a class
    # like any other here: `Set c = New Square` into a Collection, or
    # `Set q = New Collection` into a Square, raises 13 (XLIDE issue #202).
    if expected.kind == "generic" and expected.key == "object":
        return None
    actual_object = resolve_type(actual.type_, member_ctx)
    if actual_object is None:
        # A Scripting object CreateObject made is no Collection, sheet or class
        # of the project: 13 (XLIDE issue #685, measured in Excel 16.0).
        scripting = _SCRIPTING_TYPE_RE.match(actual_type)
        if scripting is not None:
            return (
                f"This object type is not compatible with {expected.display}."
                if expected.key != actual_type and expected.key != scripting.group(1)
                else None
            )
        # ActiveSheet, a Worksheet or a Chart: anything else refuses it (issue #685).
        return (
            f"This object type is not compatible with {expected.display}."
            if actual_type == "worksheet or chart"
            and _WORKSHEET_OR_CHART_KEY_RE.search(expected.key) is None
            else None
        )
    if actual_object.kind == "generic" and actual_object.key == "object":
        return None
    # DAO's types are known only by their default members, not by what each
    # one implements: a Recordset2 is a Recordset.
    if expected.key.startswith("dao.") or actual_object.key.startswith("dao."):
        return None
    if expected.key == actual_object.key:
        return None
    if expected.kind == "generic" or actual_object.kind == "generic":
        # A project class that implements Collection can stand in for one.
        project = (
            actual_object
            if actual_object.kind == "project"
            else expected if expected.kind == "project" else None
        )
        if project is not None and any(name.lower() == "collection" for name in project.implements):
            return None
        return f"This object type is not compatible with {expected.display}."
    if actual_object.kind == "host" and _HOST_VALUES_ALSO_OF_TYPE.get(actual_object.key) == expected.key:
        return None
    # A document module is the host's own object: the workbook ThisWorkbook
    # names is a Workbook, so `Set a = ActiveWorkbook` into `a As ThisWorkbook`
    # runs while that workbook is the active one (measured in Excel 16.0).
    # Which workbook the host value holds is not known here, but a value of
    # another host class is never the document.
    if (
        expected.kind == "project"
        and actual_object.kind == "host"
        and _project_document_host_types(member_ctx).get(expected.key) == actual_object.key
    ):
        return None
    if actual_object.kind == "project" and _implements_object_type(actual_object, expected):
        return None
    # A Set between two class types is checked when it runs, by QueryInterface,
    # so it compiles whenever the object could support the target (XLIDE issue
    # #109). The class an interface is implemented by can hold the interface's
    # value (`Set c = o`, casting back), and two interfaces one class implements
    # can hold each other's (`Set b = o`). Only project interfaces are known here.
    if (
        expected.kind == "project"
        and actual_object.kind == "project"
        and _project_types_can_share_instance(expected, actual_object, member_ctx, share_interfaces)
    ):
        return None
    return f"This object type is not compatible with {expected.display}."


_HAS_PARAMETERS_RE = re.compile(r"\([^)]")


def object_let_assignment_verdict(expected_raw: str | None, member_ctx: MemberCompletionContext) -> str:
    """Port of objectLetAssignmentVerdict: what a bare `name = value` does to a
    variable of a known object type (XLIDE issue #107, each case measured in Excel
    16.0). The VBE compiles it as a Let through the type's default member, so it is
    never "Set required" at compile time:

    - "lets": the type has a parameterless default member (Range's `_Default` is
      Value; a project class marks one with VB_UserMemId = 0), or is the generic
      Object, whose default member is looked up when it runs. `r = 5` writes A1.
      Nothing to report.
    - "argument": the default member takes an argument, so the VBE refuses the
      statement: `c = 5` on a Collection is "Argument not optional".
    - "noDefault": the type is fully known and has no default member, so the
      statement compiles and raises error 438 when it runs (`ws = 9`).
    - "unknown": the model cannot say. Nothing is reported.
    """
    expected = resolve_known_object_assignment_type(expected_raw, member_ctx)
    if expected is None:
        return "unknown"
    if expected.kind == "generic":
        return "argument" if expected.key == "collection" else "lets"
    if expected.kind == "project":
        project_type = next(
            (
                candidate
                for candidate in member_ctx.project_class_members or []
                if candidate.name.lower() == expected.key
            ),
            None,
        )
        if project_type is None or project_type.exhaustive is not True:
            return "unknown"
        default_member = next((member for member in project_type.members if member.default_member), None)
        if default_member is None:
            return "noDefault"
        from ..callable_signatures import parse_runtime_display_signature
        source_params = default_member.procedure_params or {}
        setter = source_params.get("propertyLet")
        params = setter[:-1] if setter is not None else source_params.get("propertyGet", source_params.get("function"))
        if params is not None:
            takes_argument = any(not param.optional and not param.param_array for param in params)
        else:
            parsed = parse_runtime_display_signature(default_member.name, default_member.signature or "")
            takes_argument = any(not param.optional and not param.param_array for param in parsed.params)
        return "argument" if takes_argument else "lets"
    alias = resolve_host_alias(expected_raw or "", member_ctx.model)
    library = _library_object_type(expected_raw)
    resolved = alias if alias is not None else library if library is not None else expected_raw or ""
    library_default = _library_default_verdict(resolved)
    if library_default is not None:
        return library_default
    host_default = _host_default_member(resolved, member_ctx)
    if host_default is not None:
        if (
            host_default.get("kind") == "method"
            or _HAS_PARAMETERS_RE.search(host_default.get("signature") or "") is not None
        ):
            return "argument"
        # The model keeps no parameters for a default property. One typed as
        # an element of the collection is its Item and takes the index:
        # Hyperlinks, Areas, Borders, Windows, Workbooks. One typed as a value
        # (Range, Style, Application) gives it. One typed Object is not
        # judged: Worksheets read as a value raises 13, Sheets 450 (XLIDE issue
        # #221, measured in Excel 16.0).
        if normalize_type(host_default.get("declaredType")) == "object":
            return "unknown"
        return "argument" if host_default.get("returns") else "lets"
    return "noDefault" if _host_type_has_no_default(resolved, member_ctx) else "unknown"


def _library_default_verdict(qualified: str, depth: int = 0) -> str | None:
    """What a library type's default member (DISPID 0) does to a Let: "argument"
    when it must be given one, else "lets", following a default property that
    returns another library type with a default of its own."""
    found = HOST_DEFAULT_MEMBERS.get(qualified)
    if found is None:
        return None
    if found.kind == "method" or found.required > 0:
        return "argument"
    if depth < 4 and found.returns in HOST_DEFAULT_MEMBERS:
        return _library_default_verdict(found.returns, depth + 1)
    return "lets"


_library_types_by_lower: dict[str, str] | None = None
_DAO_PREFIX_RE = re.compile(r"^dao\.", re.IGNORECASE)


def _library_object_type(type_name: str | None) -> str | None:
    """A DAO type as the default-member table spells it: `dao.recordset` is
    `DAO.Recordset`."""
    global _library_types_by_lower
    if not type_name or _DAO_PREFIX_RE.match(js_trim(type_name)) is None:
        return None
    if _library_types_by_lower is None:
        _library_types_by_lower = {
            key.lower(): key for key in HOST_DEFAULT_MEMBERS if key.startswith("DAO.")
        }
    return _library_types_by_lower.get(js_trim(type_name).lower())


def _host_default_member(qualified: str, member_ctx: MemberCompletionContext) -> HostMember | None:
    return next(
        (member for member in get_host_members(qualified, member_ctx.model) if member["name"] == "_Default"),
        None,
    )


def _host_type_has_no_default(resolved: str, member_ctx: MemberCompletionContext) -> bool:
    """Whether the host model's member list for the type proves it has no default
    member: the list is complete, and the type library resolves members while
    compiling or the type is Excel's."""
    host_type = get_host_type(resolved, member_ctx.model)
    if host_type is None or host_type.get("exhaustive") is not True:
        return False
    return host_type_resolves_when_compiling(resolved) or _EXCEL_PREFIX_RE.match(resolved) is not None


_EXCEL_PREFIX_RE = re.compile(r"^excel\.", re.IGNORECASE)


def _project_types_can_share_instance(
    expected: KnownObjectAssignmentType,
    actual: KnownObjectAssignmentType,
    member_ctx: MemberCompletionContext,
    share_interfaces: Callable[[str, str], bool] | None = None,
) -> bool:
    """Whether one project class can carry a value declared as the other: the
    expected class implements the actual type (a cast from an interface back to
    the class), or some project class implements both (a cast between two
    interfaces of one object)."""
    if _implements_object_type(expected, actual):
        return True
    if share_interfaces is not None:
        return share_interfaces(expected.key, actual.key)
    wanted = {expected.key, actual.key}
    for project_type in member_ctx.project_class_members or []:
        implemented = {name.lower() for name in project_type.implements or []}
        if wanted <= implemented:
            return True
    return False


# Host types the model returns where the type library returns another, so a value
# of the model's type is also a value of the library's. Excel's library types the
# Charts and Worksheets properties of Application and Workbook as Sheets, and a
# Sheets object is what they return at run time. The model returns its own Charts
# and Worksheets there, whose members completion offers (XLIDE issue #90).
_HOST_VALUES_ALSO_OF_TYPE: dict[str, str] = {
    "excel.charts": "excel.sheets",
    "excel.worksheets": "excel.sheets",
}


def _is_implemented_by_any_project_class(
    operand_type: KnownObjectAssignmentType, member_ctx: MemberCompletionContext
) -> bool:
    """True when any project class declares `Implements <operandType>`, so the
    operand could hold a subtype that is-a the target (stay quiet, no-FP)."""
    names = {operand_type.key, operand_type.display.lower()}
    for project_type in member_ctx.project_class_members or []:
        for implemented in project_type.implements or []:
            if implemented.lower() in names:
                return True
    return False


def _check_typeof_is(
    expr: TypeOfIsExpr, env: dict[str, str], member_ctx: MemberCompletionContext, push: PushFn
) -> None:
    if not isinstance(expr.operand, IdentifierExpr):
        return  # v1: only simple identifier operands have a known declared type
    operand_name = expr.operand.name
    declared = env.get(operand_name.lower())
    if not declared:
        return  # undeclared / unknown type -> quiet
    operand_type = resolve_known_object_assignment_type(declared, member_ctx)
    target_type = resolve_known_object_assignment_type(expr.type_name, member_ctx)
    if operand_type is None or target_type is None:
        return  # not both known object types -> quiet
    if operand_type.kind == "generic" or target_type.kind == "generic":
        return  # Object operand or `Is Object` -> quiet
    if operand_type.key == target_type.key:
        return  # same type (always True) -> quiet
    # Concrete-operand gate: an interface-typed operand could hold a subtype that
    # is-a the target, so only fire when no project class implements the operand.
    if operand_type.kind == "project" and _is_implemented_by_any_project_class(operand_type, member_ctx):
        return
    # Mutual incompatibility: neither type is assignable to the other. If either
    # is, `TypeOf` could be True, so stay quiet.
    operand_can_be_target = (
        object_assignment_incompatibility_reason(
            expr.type_name, InferredArgumentType(declared, declared, expr.span), member_ctx
        )
        is None
    )
    target_can_be_operand = (
        object_assignment_incompatibility_reason(
            declared, InferredArgumentType(expr.type_name, expr.type_name, expr.span), member_ctx
        )
        is None
    )
    if operand_can_be_target or target_can_be_operand:
        return
    push(
        "typeOfIsAlwaysFalse",
        f"'TypeOf ... Is {target_type.display}' is always False: '{operand_name}' is declared "
        f"As {operand_type.display}, which is never {target_type.display}.",
        expr.span,
    )


def check_type_of_is_compatibility(
    symbols: ModuleSymbols, member_ctx: MemberCompletionContext, push: PushFn
) -> ProcedureExpressionVisitor:
    def factory(member: ProcedureNode) -> Callable[[ExprNode], None]:
        env = type_environment_for(symbols, member)

        def visitor(expr: ExprNode) -> None:
            if isinstance(expr, TypeOfIsExpr):
                _check_typeof_is(expr, env, member_ctx, push)

        return visitor

    return factory


# The names the registry used before the 2f49b93 sync; the registry (F7) moves to
# the names above, and these go with it.
