"""Dead code: declarations nothing reads, private procedures nothing calls, and
statements nothing can reach.

Ported from xlide_vscode/src/analyzer/diagnostics/rules/deadCode.ts.

Every finding here is a structural fact about the module's own text, not a guess
about how it runs, and each one stops at the point where the text can no longer
prove it:

- A local or module-private variable is "unused" when no token in its scope names
  it, and "never read" when every token that does is a plain assignment to it.
  Passing it to a procedure counts as a read (ByRef may fill it), so does indexing
  it, a member access on it, a `For` loop over it, and any mention inside an
  inactive `#If` arm.
- Only Private procedures are reported as uncalled. A Public one may be wired to a
  button, a shape, the ribbon, a hotkey, `OnTime` or `Application.Run` in a file
  the analyzer cannot see, so its silence proves nothing. A Private one can only be
  reached from its own module, or by name in a string, which is why every string
  literal in the project is searched too. Event handlers and procedures with member
  attributes are never reported: the host calls those.
- Code after `Exit Sub`, `Exit Function`, `Exit Property`, `Exit Do`, `Exit For`,
  `GoTo`, `Resume`, `Return` or `End` in the same block is unreachable until a
  label, a line number, a `Case` or a `#If` gives the flow somewhere to land.
"""

from __future__ import annotations

import re
from collections.abc import Iterator, Mapping, Sequence
from collections.abc import Set as AbstractSet
from dataclasses import dataclass, field
from typing import Literal

from ...completion.event_handlers import event_handler_procedure_for_name
from ...conditional import ConditionalActivityTracker
from ...docs.doc_comment import attached_comments_start, whole_line_span
from ...js_compat import JS_WHITESPACE
from ...lexer.token_helpers import first_token_at_or_after, identifier_words
from ...lexer.token_kinds import TokenKind, VbaToken
from ...lexer.tokenize import tokenize_cached
from ...parser.nodes import (
    BodyNode,
    ConditionalDirectiveNode,
    IfBlockNode,
    ModuleNode,
    ProcedureNode,
    ProcKind,
    Span,
    StatementNode,
    VariableGroupNode,
    is_leaf_statement,
)
from ...references import ReferenceKind, classify_reference_kinds
from ...symbols.symbol_model import ModuleSymbolKind, ModuleSymbols, VbaSymbol, is_procedure_kind
from ..context import PushFn, statement_tokens
from ..model import (
    VbaDiagnosticData,
    VbaEdit,
    VbaRemoveDeclarationData,
    VbaRemoveUnreachableCodeData,
)
from ..walker import (
    active_module_members,
    declared_name_span,
    for_each_variable_group,
    is_inactive_node,
    token_text,
)

# ------------------------------------------------------------ unused names


@dataclass(slots=True)
class _TrackedDeclaration:
    name: str
    lower: str
    name_span: Span
    group: VariableGroupNode
    scope: Literal["local", "module"]


@dataclass(slots=True)
class _Reference:
    offset: int
    # Read by construction: a `For`/`For Each` control variable is read by the loop
    # itself, and `x(i) = v` reads the array it stores into.
    read_by_form: bool


def check_unused_declarations(
    source: str,
    mod: ModuleNode,
    symbols: ModuleSymbols,
    activity: ConditionalActivityTracker | None,
    push: PushFn,
) -> None:
    """Locals nothing uses, module-private variables and constants nothing uses, and
    variables whose only mentions assign to them."""
    tokens = tokenize_cached(source)
    attributed = {symbol.name_span.start for symbol in symbols.all if symbol.attributes}

    members = active_module_members(mod, activity)
    procedures = [member for member in members if isinstance(member, ProcedureNode)]

    # Module-level declarations that only this module can name.
    module_level: list[_TrackedDeclaration] = []
    for member in members:
        if not isinstance(member, VariableGroupNode) or member.with_events or not _is_module_private(member):
            continue
        for decl in member.declarations:
            if decl.name_span is None or decl.name_span.start in attributed:
                continue
            module_level.append(
                _TrackedDeclaration(decl.name, decl.name.lower(), decl.name_span, member, "module")
            )

    # Procedures whose parameters or locals shadow a module-level name: a mention
    # inside them binds to the shadow, not the module variable.
    shadowing: dict[str, list[Span]] = {}
    for proc in procedures:
        names = {param.name.lower() for param in proc.params}

        def collect(group: VariableGroupNode, _names: set[str] = names) -> None:
            _names.update(decl.name.lower() for decl in group.declarations)

        for_each_variable_group(proc.body, collect, activity)
        for lower in names:
            shadowing.setdefault(lower, []).append(proc.span)

    # One pass over the token stream serves every scope: the module-level names see
    # the whole module, each procedure's locals see its own span. Reference kinds
    # are then classified in one walk as well, so the cost stays linear in module
    # size however many procedures it has.
    scopes: list[tuple[int, int, list[_TrackedDeclaration]]] = []
    if module_level:
        scopes.append((0, len(source), module_level))
    for proc in procedures:
        locals_: list[_TrackedDeclaration] = []

        def track(group: VariableGroupNode, _locals: list[_TrackedDeclaration] = locals_) -> None:
            for decl in group.declarations:
                if decl.name_span is None or decl.name_span.start in attributed:
                    continue
                _locals.append(_TrackedDeclaration(decl.name, decl.name.lower(), decl.name_span, group, "local"))

        for_each_variable_group(proc.body, track, activity)
        if locals_:
            scopes.append((proc.span.start, proc.span.end, locals_))
    if not scopes:
        return

    references_by_scope = [
        _collect_references(
            tokens,
            start,
            end,
            {decl.name_span.start for decl in declarations},
            {decl.lower for decl in declarations},
        )
        for start, end, declarations in scopes
    ]
    all_offsets = [
        ref.offset for references in references_by_scope for refs in references.values() for ref in refs
    ]
    kinds = classify_reference_kinds(source, all_offsets)

    for (_start, _end, declarations), references in zip(scopes, references_by_scope):
        for tracked in declarations:
            own = references.get(tracked.lower, [])
            if tracked.scope == "module":
                shadows = shadowing.get(tracked.lower, [])
                own = [
                    ref for ref in own
                    if not any(span.start <= ref.offset < span.end for span in shadows)
                ]
            _report(source, tracked, own, kinds, push)


def _is_module_private(group: VariableGroupNode) -> bool:
    modifier = group.modifier.lower()
    if modifier in ("private", "dim"):
        return True
    # A bare `Const` at module level is private by default (MS-VBAL 5.2.3.2).
    return group.is_const and modifier == ""


def _report(
    source: str,
    decl: _TrackedDeclaration,
    references: list[_Reference],
    kinds: Mapping[int, ReferenceKind],
    push: PushFn,
) -> None:
    if not references:
        if decl.group.is_const:
            what = "Constant"
        elif decl.scope == "module":
            what = "Module-level variable"
        else:
            what = "Local variable"
        removal = _remove_declaration_data(source, decl)
        push(
            "unusedVariable",
            f"{what} '{decl.name}' is declared but never used.",
            decl.name_span,
            VbaDiagnosticData(remove_declaration=removal) if removal is not None else None,
        )
        return
    if decl.group.is_const:
        return
    ever_written = any(kinds.get(ref.offset) == "write" and not ref.read_by_form for ref in references)
    ever_read = any(ref.read_by_form or kinds.get(ref.offset) != "write" for ref in references)
    if ever_written and not ever_read:
        push(
            "variableNeverRead",
            f"Variable '{decl.name}' is assigned but its value is never read.",
            decl.name_span,
        )


def _collect_references(
    tokens: Sequence[VbaToken],
    start: int,
    end: int,
    declared: AbstractSet[int],
    names: AbstractSet[str],
) -> dict[str, list[_Reference]]:
    """Every mention of one of `names` within [start, end) that could bind to a
    variable: not a member name, not a named-argument name, not a declaration site.
    Keyed by lowercased name.

    Upstream collects every name in the scope. Only the scope's own declarations
    are ever looked up, so this collects just those: every other mention would also
    have been classified as a read or a write, and on a large module that work
    cost more than the rest of the rule."""
    out: dict[str, list[_Reference]] = {}
    first = first_token_at_or_after(tokens, start)
    prev = tokens[first - 1] if first >= 1 else None
    prev2 = tokens[first - 2] if first >= 2 else None
    for i in range(first, len(tokens)):
        token = tokens[i]
        if token.start >= end:
            break
        if token.kind is TokenKind.IDENTIFIER or token.kind is TokenKind.KEYWORD:
            word = token_text(token)
            following = tokens[i + 1] if i + 1 < len(tokens) else None
            if (
                word in names
                and token.start not in declared
                and not _is_member_name(prev)
                and not _is_named_argument(following)
            ):
                prev_word = token_text(prev)
                read_by_form = (
                    prev_word == "for"
                    or (prev_word == "each" and token_text(prev2) == "for")
                    or (
                        following is not None
                        and following.kind is TokenKind.PUNCTUATION
                        and following.raw_text == "("
                    )
                )
                out.setdefault(word, []).append(_Reference(token.start, read_by_form))
        if token.kind is not TokenKind.COMMENT:
            prev2 = prev
            prev = token
    return out


def _is_member_name(prev: VbaToken | None) -> bool:
    return prev is not None and (
        (prev.kind is TokenKind.PUNCTUATION and prev.raw_text == ".")
        or (prev.kind is TokenKind.OPERATOR and prev.raw_text == "!")
    )


def _is_named_argument(following: VbaToken | None) -> bool:
    return following is not None and following.kind is TokenKind.OPERATOR and following.raw_text == ":="


def _remove_declaration_data(source: str, decl: _TrackedDeclaration) -> VbaRemoveDeclarationData | None:
    """The edit that removes one declaration: its whole line when it stands alone
    there, else its own name (and separator) from a `Dim a, b` list. None when the
    statement shares its line with something else."""
    group = decl.group
    line_start, line_end = whole_line_span(source, group.span.start, group.span.end)
    line_text = source[line_start:line_end]
    if len(group.declarations) == 1:
        # Only the declaration (and perhaps a comment) on its line.
        statement_text = source[group.span.start : group.span.end]
        rest = re.sub(r"\r?\n$", "", line_text.replace(statement_text, "", 1)).strip()
        if rest != "" and not rest.startswith("'"):
            return None
        if "\n" in statement_text:
            return None
        # A module variable's doc comment goes with it; left behind, it would
        # document the declaration that came next.
        start = attached_comments_start(source, group.span.start) if decl.scope == "module" else line_start
        return VbaRemoveDeclarationData(decl.name, VbaEdit(Span(start, line_end), ""))
    index = next(
        (
            i
            for i, candidate in enumerate(group.declarations)
            if candidate.name_span is not None and candidate.name_span.start == decl.name_span.start
        ),
        -1,
    )
    if index < 0:
        return None
    own = group.declarations[index]
    if index < len(group.declarations) - 1:
        following = group.declarations[index + 1]
        return VbaRemoveDeclarationData(decl.name, VbaEdit(Span(own.span.start, following.span.start), ""))
    previous = group.declarations[index - 1]
    return VbaRemoveDeclarationData(decl.name, VbaEdit(Span(previous.span.end, own.span.end), ""))


# ---------------------------------------------------- uncalled procedures

_AUTO_MACRO = re.compile(r"^auto_(open|close|activate|deactivate|exec|new|add|remove)$", re.IGNORECASE)
_ATTRIBUTE_LINE = re.compile(r"^\s*Attribute\b", re.IGNORECASE)


def check_unused_private_procedures(
    source: str,
    mod: ModuleNode,
    symbols: ModuleSymbols,
    module_kind: ModuleSymbolKind,
    activity: ConditionalActivityTracker | None,
    project_string_literal_words: AbstractSet[str] | None,
    push: PushFn,
) -> None:
    """Private procedures no token in the module and no string in the project names."""
    # The procedure symbol at each start offset, first one wins as upstream's
    # `symbols.all.find` does. Built once: looking it up per candidate by scanning the
    # symbol list is quadratic, and a large class has a thousand private procedures.
    procedure_symbol_at: dict[int, VbaSymbol] = {}
    for symbol in symbols.all:
        if is_procedure_kind(symbol.kind):
            procedure_symbol_at.setdefault(symbol.full_span.start, symbol)
    candidates = [
        member
        for member in active_module_members(mod, activity)
        if isinstance(member, ProcedureNode)
        and any(modifier.lower() == "private" for modifier in member.modifiers)
        and member.name_span is not None
        and not _has_member_attribute(source, member, procedure_symbol_at)
        and not _is_host_called(member.name, module_kind)
    ]
    if not candidates:
        return
    declaration_sites = {
        member.name_span.start
        for member in mod.members
        if isinstance(member, ProcedureNode) and member.name_span is not None
    }
    # Every mention of a name, by offset: a Function assigning its own return value
    # names itself, and a procedure calling only itself is still dead, so mentions
    # inside the procedure's own body do not count for it.
    mentions: dict[str, list[int]] = {}
    own_string_words: set[str] = set()
    for token in tokenize_cached(source):
        if token.kind in (TokenKind.IDENTIFIER, TokenKind.KEYWORD) and token.start not in declaration_sites:
            mentions.setdefault(token_text(token), []).append(token.start)
        elif token.kind is TokenKind.STRING_LITERAL and project_string_literal_words is None:
            own_string_words.update(identifier_words(token.raw_text))
    string_words = project_string_literal_words if project_string_literal_words is not None else own_string_words

    for proc in candidates:
        lower = proc.name.lower()
        outside = any(
            offset < proc.span.start or offset >= proc.span.end for offset in mentions.get(lower, ())
        )
        if outside or lower in string_words:
            continue
        if proc.proc_kind is ProcKind.SUB:
            message = f"Private Sub '{proc.name}' is never called."
        elif proc.proc_kind is ProcKind.FUNCTION:
            message = f"Private Function '{proc.name}' is never called."
        else:
            message = f"Private Property '{proc.name}' is never used."
        push("unusedProcedure", message, declared_name_span(source, proc.span, proc.name))


def _has_member_attribute(
    source: str, proc: ProcedureNode, procedure_symbol_at: Mapping[int, VbaSymbol]
) -> bool:
    """Whether a procedure carries an `Attribute` line: a hotkey, a description, a
    default member. An exported module writes the line inside the procedure under
    its header; the symbol table attaches one written after it."""
    if proc.attributes:
        return True
    symbol = procedure_symbol_at.get(proc.span.start)
    if symbol is not None and symbol.attributes:
        return True
    return any(
        isinstance(node, StatementNode) and _ATTRIBUTE_LINE.match(source[node.span.start : node.span.end])
        for node in proc.body
    )


def _is_host_called(name: str, module_kind: ModuleSymbolKind) -> bool:
    """Whether the host, not code, calls a procedure by this name: an event handler
    (`Worksheet_Change`, `CommandButton1_Click`, `Class_Initialize`, an interface
    member `IFoo_Bar`) in an object module, or an `Auto_Open` style macro in a
    standard one."""
    if event_handler_procedure_for_name(name) is not None:
        return True
    if module_kind is ModuleSymbolKind.STANDARD:
        return _AUTO_MACRO.match(name) is not None
    return "_" in name


# ------------------------------------------------------- unreachable code


@dataclass(slots=True)
class _UnreachableRun:
    """One statement list being walked: the exit that ended its reachable code,
    and the dead span after that exit not yet reported."""

    nodes: Iterator[BodyNode]
    terminator: str | None = None
    dead: Span | None = None
    # A Dim, Static or Const is not run: it names the variable for the whole
    # procedure, so code after it still compiles with it. The fix must not
    # delete one (issue #466, measured in Excel 16.0).
    declarations: list[Span] = field(default_factory=list)
    declares_inside: bool = False


# Under On Error Resume Next a Resume with no error pending raises 20, which is
# skipped, so the next line runs (issue #446, measured in Excel 16.0).
# Upstream's /\bon\s+(?:local\s+)?error\s+resume\s+next\b/i, with JavaScript's
# ASCII word boundary and Unicode-aware `\s` spelled out.
_JS_S = "[" + re.escape(JS_WHITESPACE) + "]"
_ON_ERROR_RESUME_NEXT_RE = re.compile(
    rf"(?<![A-Za-z0-9_])on{_JS_S}+(?:local{_JS_S}+)?error{_JS_S}+resume{_JS_S}+next(?![A-Za-z0-9_])",
    re.IGNORECASE | re.ASCII,
)


def check_unreachable_code(
    source: str, mod: ModuleNode, activity: ConditionalActivityTracker | None, push: PushFn
) -> None:
    """Statements after an unconditional exit in the same block, until a landing
    point."""
    resume_runs = False

    def report(run: _UnreachableRun) -> None:
        if run.dead is not None and run.terminator is not None:
            start, end = whole_line_span(source, run.dead.start, run.dead.end)
            keeps = run.declares_inside or any(
                decl.start < end and decl.end > start for decl in run.declarations
            )
            push(
                "unreachableCode",
                f"Unreachable code after '{run.terminator}'.",
                run.dead,
                None
                if keeps
                else VbaDiagnosticData(
                    remove_unreachable_code=VbaRemoveUnreachableCodeData(VbaEdit(Span(start, end), ""))
                ),
            )
        run.dead = None
        run.declares_inside = False

    def flush(run: _UnreachableRun) -> None:
        report(run)
        run.terminator = None

    def walk_body(body: Sequence[BodyNode]) -> None:
        # One run per statement list, kept on a stack rather than in recursive
        # calls, so nesting depth is not bounded by Python's recursion limit. A
        # block's lists are walked, in order, when the block is reached, and the
        # enclosing list resumes after them.
        runs = [_UnreachableRun(iter(body))]
        while runs:
            run = runs[-1]
            entered_block = False
            for node in run.nodes:
                if is_inactive_node(activity, node):
                    continue
                if isinstance(node, ConditionalDirectiveNode):
                    flush(run)
                    continue
                if run.terminator is not None and _is_declaration(source, node):
                    report(run)
                    run.declarations.append(node.span)
                    continue
                if is_leaf_statement(node) and node.single_line_if_tail:
                    # It runs only with its single-line If's branch (MS-VBAL 5.4.2.9):
                    # an Exit there ends nothing, and it is dead when its If is.
                    if run.terminator is not None:
                        run.dead = Span(run.dead.start if run.dead is not None else node.span.start, node.span.end)
                    continue
                if is_leaf_statement(node):
                    toks = statement_tokens(source, node.span)
                    if _is_landing_point(source, node, toks):
                        flush(run)
                        exit_text = _terminal_statement(_tokens_after_line_number(toks), resume_runs)
                        if exit_text is not None:
                            run.terminator = exit_text
                        continue
                    if run.terminator is not None:
                        run.dead = Span(run.dead.start if run.dead is not None else node.span.start, node.span.end)
                        continue
                    exit_text = _terminal_statement(toks, resume_runs)
                    if exit_text is not None:
                        run.terminator = exit_text
                    continue
                # A block node.
                if run.terminator is not None:
                    if not _block_has_landing_point(source, node):
                        run.dead = Span(run.dead.start if run.dead is not None else node.span.start, node.span.end)
                        run.declares_inside = run.declares_inside or _block_declares(source, node)
                        continue
                    flush(run)
                runs.extend(_UnreachableRun(iter(nested)) for nested in reversed(_block_bodies(node)))
                entered_block = True
                break
            if not entered_block:
                flush(run)
                runs.pop()

    for member in active_module_members(mod, activity):
        if isinstance(member, ProcedureNode):
            resume_runs = (
                _ON_ERROR_RESUME_NEXT_RE.search(source, member.span.start, member.span.end) is not None
            )
            walk_body(member.body)


def _is_label_line(source: str, node: BodyNode, toks: Sequence[VbaToken]) -> bool:
    return (
        isinstance(node, StatementNode)
        and len(toks) == 1
        and toks[0].kind in (TokenKind.IDENTIFIER, TokenKind.KEYWORD)
        and source[node.span.end : node.span.end + 1] == ":"
    )


def _is_landing_point(source: str, node: BodyNode, toks: Sequence[VbaToken]) -> bool:
    """A label, a line number, or a `Case` arm: somewhere control can arrive."""
    if not toks:
        return False
    if toks[0].kind is TokenKind.INTEGER_LITERAL:
        return True
    if _is_label_line(source, node, toks):
        return True
    return token_text(toks[0]) in ("case", "else", "elseif")


def _tokens_after_line_number(toks: Sequence[VbaToken]) -> Sequence[VbaToken]:
    return toks[1:] if toks and toks[0].kind is TokenKind.INTEGER_LITERAL else toks


def _terminal_statement(toks: Sequence[VbaToken], resume_runs: bool = False) -> str | None:
    if not toks:
        return None
    head = token_text(toks[0])
    second = token_text(toks[1]) if len(toks) > 1 else ""
    if head == "exit" and second in ("sub", "function", "property", "do", "for"):
        return f"Exit {toks[1].canonical_text or toks[1].raw_text}"
    if head == "goto" and len(toks) >= 2:
        return f"GoTo {toks[1].raw_text}"
    if head == "resume" and not resume_runs:
        return "Resume" if len(toks) == 1 else f"Resume {toks[1].canonical_text or toks[1].raw_text}"
    if head == "end" and len(toks) == 1:
        return "End"
    if head == "return" and len(toks) == 1:
        return "Return"
    return None


def _is_declaration(source: str, node: BodyNode) -> bool:
    """A Dim, Static or Const statement."""
    if isinstance(node, VariableGroupNode):
        return True
    if not is_leaf_statement(node):
        return False
    after = _tokens_after_line_number(statement_tokens(source, node.span))
    head = token_text(after[0] if after else None)
    return head in ("dim", "static", "const")


def _block_declares(source: str, node: BodyNode) -> bool:
    """Whether a block holds a declaration at any depth.

    Upstream recurses per nested block; the bodies still to search wait on a stack
    here, so nesting depth is not bounded by Python's recursion limit."""
    pending = _block_bodies(node)
    while pending:
        for child in pending.pop():
            if _is_declaration(source, child):
                return True
            pending.extend(_block_bodies(child))
    return False


def _block_bodies(node: BodyNode) -> list[Sequence[BodyNode]]:
    """A block's statement lists: an If block's arms, which leave out the
    Else/ElseIf header lines its flat body keeps, or the block's body."""
    if isinstance(node, IfBlockNode):
        return [branch.body for branch in node.branches]
    child = getattr(node, "body", None)
    return [child] if isinstance(child, list) else []


def _block_has_landing_point(source: str, node: BodyNode) -> bool:
    # The bodies still to search wait on a stack instead of in recursive calls, so
    # nesting depth is not bounded by Python's recursion limit.
    pending = _block_bodies(node)
    while pending:
        for child_node in pending.pop():
            if is_leaf_statement(child_node):
                toks = statement_tokens(source, child_node.span)
                if toks and toks[0].kind is TokenKind.INTEGER_LITERAL:
                    return True
                if _is_label_line(source, child_node, toks):
                    return True
            elif isinstance(child_node, ConditionalDirectiveNode):
                return True
            else:
                pending.extend(_block_bodies(child_node))
    return False
