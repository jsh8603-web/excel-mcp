"""Shared VBE export-format handling for the file and workbook readers.

A VBA module exported by the VBE, or read out of an Office file, is the code body
preceded by an export header. The header is:

* optional ``Attribute VB_*`` lines (valid module statements the parser tolerates), and
* for class, document, and UserForm modules, a non-VBA designer block: a leading
  ``VERSION ...`` line followed by a balanced ``Begin ... End`` block.

The parser handles Attribute lines but not the designer block, so this module
strips the designer block, derives the module name from the VB_Name attribute, and
classifies the module kind. Both reader.loose_file and reader.workbook build on it,
so the export-format knowledge lives in exactly one place.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from ..symbols import ImplicitMember, ModuleInput, ModuleSymbolKind

_VB_NAME_RE = re.compile(
    r'^\s*Attribute\s+VB_Name\s*=\s*"([^"]*)"', re.IGNORECASE | re.MULTILINE
)
# A document module's VB_Base names a host document coclass; a class module's
# VB_Base (present in workbook reads, absent in .cls file exports) names the generic
# VBA class base instead. Classify on the GUID value, not the mere presence of the
# attribute, so class modules read out of a workbook are not mistaken for documents.
_VB_BASE_GUID_RE = re.compile(
    r'^\s*Attribute\s+VB_Base\s*=\s*"?0?\{?'
    r"([0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12})",
    re.IGNORECASE | re.MULTILINE,
)
# The host document-module coclass CLSIDs. A document module's VB_Base is one
# of these; a class module's is the generic VBA class base
# ({FCFB3D2A-A0FA-1068-A738-08002B3371B5}), which is deliberately not listed.
_DOCUMENT_BASE_GUIDS = frozenset(
    {
        "00020819-0000-0000-C000-000000000046",  # Excel.Workbook (ThisWorkbook)
        "00020820-0000-0000-C000-000000000046",  # Excel.Worksheet (sheet modules)
        "00020821-0000-0000-C000-000000000046",  # Excel.Chart (chart sheet modules)
        "00020906-0000-0000-C000-000000000046",  # Word.Document (ThisDocument)
    }
)
# A UserForm's VB_Base names two GUIDs, the form's class and its designer; a
# class or document module names one. A container keeps a form's design in a
# storage of its own, so its code-behind carries no designer block, and this is
# what marks it (upstream classifyModuleType).
_VB_BASE_LINE_RE = re.compile(r'^\s*Attribute\s+VB_Base\s*=\s*"([^"]*)"', re.IGNORECASE | re.MULTILINE)
_GUID_RE = re.compile(r"\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}")
# The base the VBE writes on every class module it creates. Whatever its other
# attributes, a module on this base is a class.
_CLASS_BASE_GUID = "FCFB3D2A-A0FA-1068-A738-08002B3371B5"
_VB_BASE_RE = re.compile(r"^\s*Attribute\s+VB_Base\s*=", re.IGNORECASE | re.MULTILINE)
# Host code-behind that names no CLSID: Word's ThisDocument declares
# VB_Base = "1Normal.ThisDocument". Office marks every document module
# PredeclaredId + Exposed, so with a base named the pair is the host-generic
# document signature (UserForms are Exposed = False and are caught by the
# designer block before this runs). Without a base it is not: a class can have
# both, as stdVBA's predeclared public classes do (upstream classifyModuleType).
_VB_PREDECLARED_TRUE_RE = re.compile(
    r'^\s*Attribute\s+VB_PredeclaredId\s*=\s*True\s*$', re.IGNORECASE | re.MULTILINE
)
_VB_EXPOSED_TRUE_RE = re.compile(
    r'^\s*Attribute\s+VB_Exposed\s*=\s*True\s*$', re.IGNORECASE | re.MULTILINE
)
# A UserForm designer block opens with ``Begin {GUID} Name`` (a 38-char braced GUID).
_DESIGNER_BEGIN_RE = re.compile(r"^\s*Begin\s*\{[0-9A-Fa-f-]{36}\}", re.MULTILINE)
_VERSION_FORM_RE = re.compile(r"^\s*VERSION\s+5\.", re.IGNORECASE)
_VERSION_CLASS_RE = re.compile(r"^\s*VERSION\s+\d+\.\d+\s+CLASS", re.IGNORECASE)


@dataclass(frozen=True, slots=True)
class LoadedModule:
    """One VBA module ready for analysis: its name, kind, and code-body source.

    ``source`` is the body with any non-VBA designer header removed, so it can be
    passed straight to analyze_module (or wrapped in a ModuleInput for a project pass).
    ``designer_block`` is the header text removed ahead of it, empty when there was
    none, so ``designer_block + source`` is the module text as read and a span in
    ``source`` lies ``len(designer_block)`` characters further into that text.
    """

    name: str
    kind: ModuleSymbolKind
    source: str
    designer_block: str = ""
    # A UserForm's controls, read from its designer storage by a container
    # reader. None when nothing read them: a loose .frm carries them in its own
    # designer block, which the project index parses.
    implicit_members: tuple[ImplicitMember, ...] | None = None
    # The host class a design makes the module (`Access.Form`, `Access.Report`),
    # which is what `Me` is there. None for a UserForm, always MSForms.UserForm.
    designer_class: str | None = None

    def as_module_input(self) -> ModuleInput:
        """The project-analysis input for this module, with everything the
        reader learned about it that its text does not say."""
        return ModuleInput(
            module_name=self.name,
            module_kind=self.kind,
            source=self.source,
            implicit_members=self.implicit_members,
            designer_class=self.designer_class,
        )


def strip_export_header(text: str) -> str:
    """Remove the leading non-VBA designer block (a ``VERSION`` line plus a balanced
    ``Begin ... End`` block).

    Attribute lines are valid module statements the parser handles, so they are kept.
    A plain module with no ``VERSION`` line is returned unchanged. A truncated or
    corrupt header whose ``Begin`` block never closes is also returned unchanged
    rather than swallowing the whole body (a corrupt export stays visible).
    """
    return _split_designer_block(text)[1]


def _split_designer_block(text: str) -> tuple[str, str]:
    """Split ``text`` into the designer block strip_export_header removes and the
    body it keeps. The two parts join back to ``text``; the block is empty when
    nothing is removed."""
    lines = text.splitlines(keepends=True)
    if not lines or not lines[0].lstrip().upper().startswith("VERSION"):
        return "", text
    # Skip blank lines after VERSION, then consume a balanced Begin..End designer block.
    j = 1
    while j < len(lines) and lines[j].strip() == "":
        j += 1
    if not (j < len(lines) and lines[j].strip().lower().startswith("begin")):
        # A VERSION line with no designer block: strip just the VERSION line.
        return lines[0], "".join(lines[1:])
    depth = 0
    for k in range(j, len(lines)):
        token = lines[k].strip().lower()
        # Designer blocks open with `Begin <...>` and close with a bare `End`. VBA
        # code uses `End Sub` / `End Function` / etc., which must not count as closers
        # (it only matters once a malformed block scans into the body).
        if token.startswith("begin"):
            depth += 1
        elif token == "end":
            depth -= 1
            if depth <= 0:
                return "".join(lines[: k + 1]), "".join(lines[k + 1 :])
    # The Begin block never balanced (truncated/corrupt export): do not strip the body.
    return "", text


def classify_module_kind(
    text: str,
    *,
    extension: str | None = None,
    pyopenvba_standard: bool | None = None,
) -> ModuleSymbolKind:
    """Classify a module as standard, class, document, or UserForm.

    Signals, strongest first: a UserForm designer block, ``.frm`` extension or a
    ``VB_Base`` naming two GUIDs (a form's code-behind read from a container); an
    ``Attribute VB_Base`` line whose GUID is a host document coclass (ThisWorkbook,
    sheet, chart, or Word ThisDocument modules); a ``.bas`` extension or a
    pyOpenVBA standard flag, each of which states outright that the module is
    standard; a ``VB_Base`` naming the VBE's class base; the host-generic
    PredeclaredId + Exposed pair beside a ``VB_Base`` line, which identifies
    document code-behind that names no CLSID (Word's ThisDocument declares
    ``VB_Base = "1Normal.ThisDocument"``); then ``.cls`` or the pyOpenVBA "other"
    bucket; falling back to the ``VERSION ... CLASS`` header. ``pyopenvba_standard``
    is True for a pyOpenVBA standard module, False for its "other" bucket
    (class/document/designer), or None when no workbook reader supplied it.
    """
    ext = (extension or "").lower().lstrip(".")
    head = text[:8000]
    if ext == "frm" or _VERSION_FORM_RE.match(head) or _DESIGNER_BEGIN_RE.search(head):
        return ModuleSymbolKind.USERFORM
    base_line = _VB_BASE_LINE_RE.search(head)
    if base_line is not None and len(_GUID_RE.findall(base_line.group(1))) >= 2:
        return ModuleSymbolKind.USERFORM
    base = _VB_BASE_GUID_RE.search(head)
    if base is not None and base.group(1).upper() in _DOCUMENT_BASE_GUIDS:
        return ModuleSymbolKind.DOCUMENT
    # A standard module is never a document, and both a .bas extension and the
    # container's own module-type flag say so directly, so each outranks the
    # attribute signature below; upstream only ever applies that signature where
    # neither statement is available (a workbook read, or a .cls file).
    if ext == "bas" or pyopenvba_standard is True:
        return ModuleSymbolKind.STANDARD
    if base is not None and base.group(1).upper() == _CLASS_BASE_GUID:
        return ModuleSymbolKind.CLASS
    if (
        _VB_BASE_RE.search(head)
        and _VB_PREDECLARED_TRUE_RE.search(head)
        and _VB_EXPOSED_TRUE_RE.search(head)
    ):
        return ModuleSymbolKind.DOCUMENT
    if ext == "cls":
        return ModuleSymbolKind.CLASS
    if pyopenvba_standard is False:
        return ModuleSymbolKind.CLASS
    return ModuleSymbolKind.CLASS if _VERSION_CLASS_RE.match(head) else ModuleSymbolKind.STANDARD


def module_name_from_text(text: str, fallback: str) -> str:
    """The VB_Name attribute value, or ``fallback`` when the header has none."""
    match = _VB_NAME_RE.search(text)
    return match.group(1) if match is not None and match.group(1) else fallback


def loaded_module_from_text(
    text: str,
    *,
    name: str | None = None,
    extension: str | None = None,
    name_fallback: str | None = None,
    pyopenvba_standard: bool | None = None,
) -> LoadedModule:
    """Turn raw exported module text into a LoadedModule (name, kind, code body).

    Pass ``name`` when the source already knows it (a workbook reader has the VBE
    component name); otherwise the VB_Name attribute is used, then ``name_fallback``
    (typically a file stem), then ``"Module"``.
    """
    kind = classify_module_kind(
        text, extension=extension, pyopenvba_standard=pyopenvba_standard
    )
    resolved_name = name or module_name_from_text(text, name_fallback or "Module")
    designer_block, source = _split_designer_block(text)
    return LoadedModule(
        name=resolved_name, kind=kind, source=source, designer_block=designer_block
    )
