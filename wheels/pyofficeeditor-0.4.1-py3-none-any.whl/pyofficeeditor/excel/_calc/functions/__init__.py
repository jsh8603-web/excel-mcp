"""The worksheet functions, one module per family.

Importing this package registers every function in
:data:`~pyofficeeditor.excel._calc.registry.FUNCTIONS`.
"""

from __future__ import annotations

from pyofficeeditor.excel._calc.functions import (
    aggregate,
    arithmetic,
    arrays,
    conditional,
    database,
    dates,
    distributions,
    engineering,
    financial,
    grouping,
    information,
    lambdas,
    logical,
    lookup,
    matrix,
    pivotdata,
    statistics,
    subtotal,
    text,
)

__all__ = [
    "aggregate",
    "arithmetic",
    "arrays",
    "conditional",
    "database",
    "dates",
    "distributions",
    "engineering",
    "financial",
    "grouping",
    "information",
    "lambdas",
    "logical",
    "lookup",
    "matrix",
    "pivotdata",
    "statistics",
    "subtotal",
    "text",
]
