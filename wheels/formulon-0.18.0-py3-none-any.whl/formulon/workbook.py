"""Pythonic wrapper around the Formulon C ABI (WASM transport).

Public surface:
  * :class:`Workbook` -- context-manager around an ``fm_workbook_t*`` handle.
  * :class:`Value` -- frozen dataclass mirroring ``fm_value_t``.
  * :class:`FormulonError` -- exception raised on host-side failures.
  * :class:`Cell`, :class:`DefinedName`, :class:`Table` -- iteration tuples.

Cell-level Excel errors (``#DIV/0!``, ``#VALUE!``, etc.) are reported as
``Value`` instances with ``kind == ValueKind.ERROR``; only host-side
problems (NULL handle, parse failure during ``Workbook.load``, OOM)
raise :class:`FormulonError`.

Sheet, row, column, and count arguments are 32-bit on the C ABI. A value
that does not fit the parameter it is bound for raises ``ValueError``
before the call crosses into WebAssembly, where it would otherwise be
truncated modulo 2**32 into a different, valid-looking coordinate.

The transport is WebAssembly (``formulon_capi.wasm``) loaded via
``wasmtime``; see :mod:`formulon._c` for the low-level memory and call
plumbing.
"""

from __future__ import annotations

import numbers
import struct
from dataclasses import dataclass, field
from enum import IntEnum
from functools import wraps
from inspect import isgeneratorfunction
from typing import (
    Dict,
    Iterator,
    List,
    Literal,
    Mapping,
    NamedTuple,
    Optional,
    Sequence,
    Tuple,
    TypedDict,
    Union,
    cast,
)

from . import _structs as S
from ._c import LIB, FormulonError, ValueKind, _sint, _uint, fm_value_t_size

__all__ = [
    "CalcMode",
    "Cell",
    "CellNode",
    "CellStyle",
    "CellXf",
    "CfCellResult",
    "CfColor",
    "CfIcon",
    "CfMatch",
    "CfValueObject",
    "ColorContext",
    "GradientFill",
    "GradientStop",
    "ImageFormat",
    "DrawingObjectKind",
    "AnchorKind",
    "AnchorEditAs",
    "ImageInfo",
    "DrawingObject",
    "ChartAxisCrosses",
    "ChartAxisInfo",
    "ChartAxisKind",
    "ChartAxisPatch",
    "ChartAxisTitleText",
    "ChartBlanksAs",
    "ChartCategories",
    "ChartData",
    "ChartDataSeries",
    "ChartDataSource",
    "ChartFillInfo",
    "ChartFillPatch",
    "ChartGrouping",
    "ChartInfo",
    "ChartInsertKind",
    "ChartLabelPosition",
    "ChartLabelsInfo",
    "ChartLabelsPatch",
    "ChartLegendInfo",
    "ChartLegendPosition",
    "ChartLineDash",
    "ChartLineInfo",
    "ChartLinePatch",
    "ChartMarkerInfo",
    "ChartMarkerPatch",
    "ChartMarkerSymbol",
    "ChartPlotInfo",
    "ChartPlotPatch",
    "ChartPlotType",
    "ChartPointInfo",
    "ChartPointPatch",
    "ChartPointState",
    "ChartPreviewOverrides",
    "ChartSeriesDirection",
    "ChartSeriesInfo",
    "ChartSeriesPatch",
    "ChartSeriesRanges",
    "ChartSheetRange",
    "ChartSourceInfo",
    "ChartTitleInfo",
    "ChartTitleKind",
    "ChartUnresolved",
    "FilterKind",
    "FilterOperator",
    "DynamicFilterType",
    "RefMode",
    "SortBy",
    "SortMethod",
    "DateTimeGrouping",
    "ValidationErrorStyle",
    "ColorResolution",
    "ColorSpec",
    "ColumnLayout",
    "Comment",
    "ConditionalFormat",
    "ConditionalFormatInput",
    "ColorScale",
    "DataBar",
    "DataValidation",
    "DataValidationInput",
    "DefinedName",
    "DifferentialFormat",
    "DisplayStatus",
    "EffectiveStyle",
    "ErrorCode",
    "ExternalLink",
    "ExternalLinkKind",
    "FillRecord",
    "FontRecord",
    "FormulonError",
    "FunctionMetadata",
    "GeometryMode",
    "Hyperlink",
    "IterativeSettings",
    "LogLevel",
    "IconSet",
    "MarginsPt",
    "MergeRange",
    "PageLayout",
    "PaperInfo",
    "PassthroughPart",
    "PivotAggregation",
    "PivotAxis",
    "PivotCalendar",
    "PivotCell",
    "PivotCellKind",
    "PivotDataFieldSpec",
    "PivotDateGrouping",
    "PivotFieldInfo",
    "PivotFieldSpec",
    "PivotFilterSpec",
    "PivotFilterType",
    "PivotFilterValueKind",
    "PivotItemInfo",
    "PivotStyleInfo",
    "PivotLayout",
    "PivotReportLayout",
    "PivotShowValuesAs",
    "PivotSortOrder",
    "PivotWorksheetSource",
    "PrintTitles",
    "ReadDiagnostics",
    "RectPt",
    "RowLayout",
    "SaveDiagnostics",
    "ResolvedColor",
    "SheetFormatDefaults",
    "ProtectedRange",
    "SheetProtection",
    "SheetView",
    "Shape",
    "ShapePaint",
    "DataTable",
    "DataTableInput",
    "Slicer",
    "SlicerCrossFilter",
    "SlicerSortOrder",
    "SheetVisibility",
    "Sparkline",
    "SparklineAxisType",
    "SparklineEmptyCells",
    "SparklineGroup",
    "SparklineType",
    "SpillInfo",
    "EffectiveStyleSource",
    "Table",
    "Theme",
    "ThemeFonts",
    "ThemeScriptFont",
    "ThemeSource",
    "Value",
    "ValueKind",
    "WidthModel",
    "Workbook",
    "WorkbookProtection",
    "AutoFilter",
    "AutoFilterSortState",
    "AutoFilterDateGroup",
    "AutoFilterColumn",
    "Mention",
    "Person",
    "AutoFilterSortCondition",
    "ThreadedComment",
    "ValidationOutcome",
]


# ---------------------------------------------------------------------------
# Error type
# ---------------------------------------------------------------------------

# `formulon::FormulonErrorCode` ordinals. The C ABI intentionally exposes
# status codes as integers, so bindings retain these matching stable values.
_STATUS_NOT_FOUND = 6
# 7000-band: bindings / C API (src/utils/error.h).
_STATUS_BINDING_INVALID_HANDLE = 7000
_STATUS_BINDING_NULL_POINTER = 7001

# `fm_cell_range_next_cursor` reports UINT64_MAX when no further cell exists.
_CELL_RANGE_NO_CURSOR = (1 << 64) - 1

#: Excel formula profile id accepted by `Workbook.set_excel_profile_id`.
ExcelProfileId = Literal[
    "mac-365-ja_JP",
    "win-365-ja_JP",
    "mac-365-en_US",
    "win-365-en_US",
    "mac-365-de_DE",
    "win-365-de_DE",
    "mac-365-fr_FR",
    "win-365-fr_FR",
    "mac-365-zh_CN",
    "win-365-zh_CN",
    "mac-365-ko_KR",
    "win-365-ko_KR",
    "mac-365-th_TH",
    "win-365-th_TH",
    "mac-365-es_ES",
    "win-365-es_ES",
    "mac-365-es_MX",
    "win-365-es_MX",
    "mac-365-pt_BR",
    "win-365-pt_BR",
    "mac-365-ru_RU",
    "win-365-ru_RU",
    "mac-365-zh_TW",
    "win-365-zh_TW",
    "mac-365-it_IT",
    "win-365-it_IT",
    "mac-365-nl_NL",
    "win-365-nl_NL",
]

# `fm_date_order_t` ordinals, indexed by the C value.
_DATE_ORDERS = ("mdy", "ymd", "dmy")

# `FormulonError` itself lives in `formulon._c` (imported above): its
# constructor needs to run from inside that module's WASM call trampoline,
# on a `wasmtime.Trap`, which this module cannot depend on without a cycle.


@dataclass(frozen=True)
class SaveDiagnostics:
    """Bytes and loss counters returned by ``save_with_diagnostics``.

    A field means the same thing whichever container was written; where
    the underlying event exists in only one container, the other simply
    never raises it. Coverage is partial by design -- an all-zero result
    means none of these losses occurred, not that nothing was logged.

    Summing the fields does **not** give "how many things did I lose":
    ``dropped_part_count`` and ``dropped_relationship_count`` both rise
    for one dropped part.
    """

    bytes: bytes
    #: Formula cells emitted as cached literals. Zero for XLSX.
    downgraded_formula_count: int
    #: Sheet features not lowered to records. Zero for XLSX.
    deferred_feature_count: int
    #: Passthrough parts dropped for a path collision. Both containers.
    dropped_part_count: int
    #: Relationships dropped because their target part is gone. Both
    #: containers. Rises with ``dropped_part_count`` for one dropped part.
    dropped_relationship_count: int
    #: Tables emitted under a writer-assigned id. Zero for XLSB.
    renumbered_part_count: int


@dataclass(frozen=True)
class ReadDiagnostics:
    """Loss and recovery counters captured while loading a workbook.

    Same contract as :class:`SaveDiagnostics`: one meaning per field
    across both containers, partial coverage by design.
    """

    #: Formula cells whose stored formula could not be decoded. XLSB only.
    undecoded_formula_count: int
    #: Defined names skipped for the same reason. XLSB only.
    undecoded_defined_name_count: int
    #: Package parts whose content type could not be resolved. XLSB only;
    #: the XLSX reader keeps unmodelled parts as passthrough.
    undecoded_part_count: int
    #: Presentation-overlay entries dropped for an unusable reference.
    #: XLSX only.
    skipped_feature_count: int
    #: Workbook parts with an unrecognised content type. Max 1. XLSX only.
    unknown_content_type_count: int


def _check(status: int, op: str) -> None:
    """Raise :class:`FormulonError` if ``status`` is non-zero."""
    if status != 0:
        raise FormulonError(status, op=op)


# `_uint` / `_sint` live in `formulon._c` (imported above) alongside
# `FormulonError`: they validate a value right at the WASM call boundary
# that module owns, and `_c.py`'s own `fm_status_string` call needs one too.

# ---------------------------------------------------------------------------
# Value POD
# ---------------------------------------------------------------------------


# The one payload field each scalar kind carries; the other kinds carry none.
_VALUE_PAYLOAD_FIELD = {
    ValueKind.NUMBER: "number",
    ValueKind.BOOL: "boolean",
    ValueKind.TEXT: "text",
    ValueKind.ERROR: "error_code",
}


@dataclass(frozen=True)
class Value:
    """Pythonic mirror of ``fm_value_t``.

    Exactly one of ``number`` / ``boolean`` / ``text`` / ``error_code`` is
    populated according to ``kind``. The constructor enforces the
    invariant: ``kind`` is coerced to :class:`ValueKind`, a missing or
    extra payload raises ``ValueError`` and a payload of the wrong type
    raises ``TypeError``.
    """

    kind: ValueKind
    number: Optional[float] = None
    boolean: Optional[bool] = None
    text: Optional[str] = None
    error_code: Optional[int] = None

    def __post_init__(self) -> None:
        kind = self.kind
        if not isinstance(kind, ValueKind):
            kind = ValueKind(_sint(kind, "kind"))
            object.__setattr__(self, "kind", kind)
        required = _VALUE_PAYLOAD_FIELD.get(kind)
        for name in _VALUE_PAYLOAD_FIELD.values():
            if name != required and getattr(self, name) is not None:
                raise ValueError(f"formulon: Value(kind={kind.name}) takes no {name}")
        if required is None:
            return
        payload = getattr(self, required)
        if payload is None:
            raise ValueError(f"formulon: Value(kind={kind.name}) requires {required}")
        if kind == ValueKind.NUMBER:
            if isinstance(payload, bool) or not isinstance(payload, numbers.Real):
                raise TypeError(f"formulon: Value.number must be a real number, got {type(payload).__name__}")
            object.__setattr__(self, "number", float(payload))
        elif kind == ValueKind.BOOL:
            if not isinstance(payload, bool):
                raise TypeError(f"formulon: Value.boolean must be a bool, got {type(payload).__name__}")
        elif kind == ValueKind.TEXT:
            if not isinstance(payload, str):
                raise TypeError(f"formulon: Value.text must be a str, got {type(payload).__name__}")
        else:
            object.__setattr__(self, "error_code", _sint(payload, "error_code"))

    @classmethod
    def _from_wasm(cls, ptr: int) -> "Value":
        """Decode an ``fm_value_t`` stored at WASM offset ``ptr``.

        Layout (wasm32): int32 kind | 4 pad | union (8 bytes).

        Reserved kinds (ARRAY / REF / LAMBDA) currently surface as bare
        ``Value(kind=...)`` with no payload; they are reserved in the C
        ABI for a later bundle.
        """
        buf = LIB.read_bytes(ptr, fm_value_t_size)
        kind_int = struct.unpack_from("<i", buf, 0)[0]
        kind = ValueKind(kind_int)
        if kind is ValueKind.NUMBER:
            number = struct.unpack_from("<d", buf, 8)[0]
            return cls(kind=kind, number=number)
        if kind is ValueKind.BOOL:
            boolean = struct.unpack_from("<i", buf, 8)[0]
            return cls(kind=kind, boolean=bool(boolean))
        if kind is ValueKind.TEXT:
            text_ptr = struct.unpack_from("<I", buf, 8)[0]
            return cls(kind=kind, text=LIB.read_cstr(text_ptr))
        if kind is ValueKind.ERROR:
            error_code = struct.unpack_from("<i", buf, 8)[0]
            return cls(kind=kind, error_code=int(error_code))
        # BLANK / ARRAY / REF / LAMBDA: no scalar payload.
        return cls(kind=kind)

    def to_python(self) -> Union[None, float, bool, str, "Value"]:
        """Convert to a native Python type.

        - ``BLANK`` -> ``None``
        - ``NUMBER`` -> ``float``
        - ``BOOL`` -> ``bool``
        - ``TEXT`` -> ``str``
        - ``ERROR`` -> the :class:`Value` itself (Excel cell errors are
          values, not Python exceptions; callers inspect ``error_code``)
        - ``ARRAY`` / ``REF`` / ``LAMBDA`` -> the :class:`Value` itself
          (passthrough, payload not yet exposed by the C ABI)
        """
        if self.kind is ValueKind.BLANK:
            return None
        if self.kind is ValueKind.NUMBER:
            return self.number  # type: ignore[return-value]
        if self.kind is ValueKind.BOOL:
            return self.boolean  # type: ignore[return-value]
        if self.kind is ValueKind.TEXT:
            return self.text  # type: ignore[return-value]
        # ERROR / ARRAY / REF / LAMBDA: surface the wrapping Value.
        return self


# ---------------------------------------------------------------------------
# Iteration tuples
# ---------------------------------------------------------------------------


class Cell(NamedTuple):
    """One row of ``Workbook.iter_cells()``."""

    row: int
    col: int
    formula: Optional[str]
    value: Value


class DefinedName(NamedTuple):
    """One row of ``Workbook.iter_defined_names()``."""

    name: str
    formula: str
    local_sheet_id: int
    #: The note Excel shows in the Name Manager; empty when none.
    comment: str = ""
    #: Whether the name is hidden from the Name Manager.
    hidden: bool = False


class TableColumn(NamedTuple):
    """One column of :attr:`Table.columns`.

    ``totals_row_function`` is the ``ST_TotalsRowFunction`` token (``"none"``
    when absent); ``totals_row_formula`` is the ``custom`` function's formula.
    """

    name: str
    totals_row_function: str = "none"
    totals_row_label: str = ""
    totals_row_formula: str = ""


class Table(NamedTuple):
    """One row of ``Workbook.iter_tables()``.

    ``style_name`` may name a custom style (:meth:`Workbook.get_table_style`);
    ``has_style_info`` is false without ``<tableStyleInfo>``, when the four
    toggles read false. The row counts are 0 or 1.
    """

    name: str
    display_name: str
    ref: str
    sheet_index: int
    style_name: str = ""
    has_style_info: bool = False
    show_first_column: bool = False
    show_last_column: bool = False
    show_row_stripes: bool = False
    show_column_stripes: bool = False
    header_row_count: int = 1
    totals_row_count: int = 0
    columns: Tuple[TableColumn, ...] = ()


@dataclass(frozen=True)
class TableStyleElement:
    """One region of a custom table style.

    ``type`` is the ``ST_TableStyleType`` token (``"wholeTable"``,
    ``"firstRowStripe"``, ``"pageFieldLabels"``, ...); ``size`` is the stripe
    band size; ``dxf_id`` indexes the differential formats, ``None`` for a
    region listed without formatting.
    """

    type: str
    size: int = 1
    dxf_id: Optional[int] = None


@dataclass(frozen=True)
class TableStyle:
    """A custom table / PivotTable style from ``<tableStyles>``."""

    name: str
    pivot: bool = True
    table: bool = True
    elements: Tuple[TableStyleElement, ...] = ()


class PassthroughPart(NamedTuple):
    """One row of ``Workbook.iter_passthrough()``."""

    path: str


# ---------------------------------------------------------------------------
# Enumerations (mirror the C ABI ordinals)
# ---------------------------------------------------------------------------


class GeometryMode(IntEnum):
    """Which Windows column-width figure a geometry call uses."""

    DISPLAY = 0
    PRINT = 1


class CollationStrength(IntEnum):
    """Text fold selected for a collation call (``fm_collation_strength_t``).

    The strength selects the text fold only; type boundaries never depend on it.
    """

    #: The fold of ``=``, criteria, SEARCH and approximate lookup.
    COMPARE = 0
    #: The fold of SORT, UNIQUE, XLOOKUP, GROUPBY and pivots.
    DYNAMIC = 1
    #: The fold of MATCH 0 and VLOOKUP FALSE.
    CLASSIC_EXACT = 2


@dataclass(frozen=True)
class CollationClasses:
    """Result of :meth:`Workbook.collation_classes`.

    ``class_ids`` holds one id per input value, dense from 0 in ascending
    SORT order; ``class_count`` is the number of distinct classes.
    """

    class_ids: List[int]
    class_count: int


class DisplayStatus(IntEnum):
    """Outcome of a display-text rendering (``fm_display_status_t``)."""

    OK = 0
    OVERFLOW = 1
    INVALID_FORMAT = 2


class FilterKind(IntEnum):
    """Criterion of an AutoFilter column (``fm_filter_kind_t``)."""

    NONE = 0
    VALUES = 1
    CUSTOM = 2
    TOP10 = 3
    DYNAMIC = 4
    COLOR = 5
    ICON = 6


class FilterOperator(IntEnum):
    """Comparison operator of a custom AutoFilter condition (``fm_filter_operator_t``)."""

    EQUAL = 0
    LESS_THAN = 1
    LESS_THAN_OR_EQUAL = 2
    NOT_EQUAL = 3
    GREATER_THAN_OR_EQUAL = 4
    GREATER_THAN = 5


class DynamicFilterType(IntEnum):
    """Dynamic AutoFilter type, in `ST_DynamicFilterType` schema order (``fm_dynamic_filter_type_t``)."""

    NULL = 0
    ABOVE_AVERAGE = 1
    BELOW_AVERAGE = 2
    TOMORROW = 3
    TODAY = 4
    YESTERDAY = 5
    NEXT_WEEK = 6
    THIS_WEEK = 7
    LAST_WEEK = 8
    NEXT_MONTH = 9
    THIS_MONTH = 10
    LAST_MONTH = 11
    NEXT_QUARTER = 12
    THIS_QUARTER = 13
    LAST_QUARTER = 14
    NEXT_YEAR = 15
    THIS_YEAR = 16
    LAST_YEAR = 17
    YEAR_TO_DATE = 18
    Q1 = 19
    Q2 = 20
    Q3 = 21
    Q4 = 22
    M1 = 23
    M2 = 24
    M3 = 25
    M4 = 26
    M5 = 27
    M6 = 28
    M7 = 29
    M8 = 30
    M9 = 31
    M10 = 32
    M11 = 33
    M12 = 34


class SortBy(IntEnum):
    """What a sort condition sorts by (``fm_sort_by_t``)."""

    VALUE = 0
    CELL_COLOR = 1
    FONT_COLOR = 2
    ICON = 3


class SortMethod(IntEnum):
    """Sort method of an AutoFilter sort state (``fm_sort_method_t``)."""

    NONE = 0
    PIN_YIN = 1
    STROKE = 2


class DateTimeGrouping(IntEnum):
    """Granularity of an AutoFilter date-group item (``fm_date_time_grouping_t``)."""

    YEAR = 0
    MONTH = 1
    DAY = 2
    HOUR = 3
    MINUTE = 4
    SECOND = 5


class ValidationErrorStyle(IntEnum):
    """Data-validation error style (``fm_validation_error_style_t``)."""

    STOP = 0
    WARNING = 1
    INFORMATION = 2


class ColorContext(IntEnum):
    """Where a colour is used (``fm_color_context_t``); decides what auto means."""

    FONT = 0
    FILL_FOREGROUND = 1
    FILL_BACKGROUND = 2
    BORDER = 3


class ImageFormat(IntEnum):
    """Raster format of an image (``fm_image_format_t``)."""

    UNKNOWN = 0
    PNG = 1
    JPEG = 2
    GIF = 3
    BMP = 4


class DrawingObjectKind(IntEnum):
    """What a drawing anchor holds (``fm_drawing_object_kind_t``)."""

    PICTURE = 0
    SHAPE = 1
    CHART = 2
    GROUP = 3
    CONNECTOR = 4
    GRAPHIC_FRAME = 5
    OTHER = 6


class AnchorKind(IntEnum):
    """Anchor element type of a drawing object (``fm_anchor_kind_t``)."""

    ONE_CELL = 0
    TWO_CELL = 1
    ABSOLUTE = 2


class AnchorEditAs(IntEnum):
    """How a drawing object follows row and column edits (``fm_anchor_edit_as_t``)."""

    TWO_CELL = 0
    ONE_CELL = 1
    ABSOLUTE = 2


class ShapePaint(IntEnum):
    """How a shape's fill or outline is specified (``fm_shape_paint_t``)."""

    UNSET = 0
    SOLID = 1
    NONE = 2
    OTHER = 3


class SlicerSortOrder(IntEnum):
    """Item sort order of a table slicer (``fm_slicer_sort_t``)."""

    ASCENDING = 0
    DESCENDING = 1


class SlicerCrossFilter(IntEnum):
    """How a table slicer shows items the other filters exclude (``fm_slicer_cross_filter_t``)."""

    SHOW_ITEMS_WITH_DATA_AT_TOP = 0
    SHOW_ITEMS_WITH_NO_DATA = 1
    NONE = 2


class SparklineType(IntEnum):
    """Sparkline group type (``fm_sparkline_type_t``)."""

    LINE = 0
    COLUMN = 1
    STACKED = 2


class SparklineAxisType(IntEnum):
    """Sparkline axis scaling (``fm_sparkline_axis_type_t``)."""

    INDIVIDUAL = 0
    GROUP = 1
    CUSTOM = 2


class SparklineEmptyCells(IntEnum):
    """How a sparkline plots empty cells (``fm_sparkline_empty_cells_t``)."""

    GAP = 0
    ZERO = 1
    SPAN = 2


class ColorResolution(IntEnum):
    """How a colour was resolved (``fm_color_resolution_t``)."""

    EXACT = 0
    DEFAULT_THEME = 1
    INDEX_OUT_OF_RANGE = 2
    THEME_UNPARSEABLE = 3
    AUTO_CONTEXT = 4


class ThemeSource(IntEnum):
    """Where the reported theme colours came from."""

    PART = 0
    DEFAULT = 1
    UNPARSEABLE = 2


class EffectiveStyleSource(IntEnum):
    """Which level supplied a cell's effective xf."""

    CELL = 0
    ROW = 1
    COLUMN = 2
    DEFAULT = 3


class CalcMode(IntEnum):
    """Workbook-level calc mode (``<calcPr calcMode>`` policy).

    Round-trip metadata apart from ``AUTO_NO_TABLE``: the engine recalcs all
    dirty cells on every :meth:`Workbook.recalc` regardless of this value,
    except that ``AUTO_NO_TABLE`` leaves the What-If data tables to
    :meth:`Workbook.recalc_data_tables`.
    """

    AUTO = 0
    MANUAL = 1
    AUTO_NO_TABLE = 2


class RefMode(IntEnum):
    """Reference notation formulas are shown in (``<calcPr refMode>``)."""

    A1 = 0
    R1C1 = 1


class SheetVisibility(IntEnum):
    """Sheet tab visibility, mirroring OOXML ``<sheet state>``.

    ``VERY_HIDDEN`` differs from ``HIDDEN`` in that Excel leaves such a
    sheet out of its "Unhide" dialog, which is how a workbook keeps a
    settings or lookup sheet out of a user's reach.
    """

    VISIBLE = 0
    HIDDEN = 1
    VERY_HIDDEN = 2


class LogLevel(IntEnum):
    """Minimum severity for the engine's structured log stream.

    ``OFF`` discards every record and is the default: an embedded library
    must not write to the host's stderr unless the host asks it to.
    """

    DEBUG = 0
    INFO = 1
    WARN = 2
    ERROR = 3
    OFF = 4


class ErrorCode(IntEnum):
    """Excel cell-error ordinals (mirror of ``formulon::ErrorCode``).

    These are the values carried by :attr:`Value.error_code` and accepted
    by :meth:`Workbook.set_error`.
    """

    NULL = 0
    DIV0 = 1
    VALUE = 2
    REF = 3
    NAME = 4
    NUM = 5
    NA = 6
    GETTING_DATA = 7
    SPILL = 8
    CALC = 9
    FIELD = 10
    BLOCKED = 11
    CONNECT = 12
    EXTERNAL = 13
    BUSY = 14
    PYTHON = 15
    UNKNOWN = 16


class ExternalLinkKind(IntEnum):
    """External-link kind carried by :attr:`ExternalLink.kind`."""

    UNKNOWN = 0
    EXTERNAL_BOOK = 1
    OLE = 2
    DDE = 3


class PivotAxis(IntEnum):
    """PivotTable axis for a field."""

    ROW = 0
    COL = 1
    VALUE = 2
    PAGE = 3


class WorkbookFormat(IntEnum):
    """Container format selector for :meth:`Workbook.save_as`.

    Mirrors ``fm_workbook_format_t``. ``UNKNOWN`` is not a valid save
    target.
    """

    UNKNOWN = 0
    XLSX = 1
    XLSB = 2


class PivotAggregation(IntEnum):
    """Aggregation function for a value-axis field."""

    SUM = 0
    COUNT = 1
    AVERAGE = 2
    MAX = 3
    MIN = 4
    PRODUCT = 5
    COUNT_NUMBERS = 6
    STDDEV = 7
    STDDEVP = 8
    VAR = 9
    VARP = 10


class PivotShowValuesAs(IntEnum):
    """Show-values-as derivation applied to a data-field aggregate."""

    NORMAL = 0
    PERCENT_OF_ROW = 1
    PERCENT_OF_COL = 2
    PERCENT_OF_TOTAL = 3
    RUNNING_TOTAL_IN_ROW = 4
    RUNNING_TOTAL_IN_COL = 5
    INDEX = 6
    DIFFERENCE_FROM = 7
    PERCENT_DIFFERENCE_FROM = 8
    PERCENT_OF_PARENT_ROW = 9
    PERCENT_OF_PARENT_COL = 10
    PERCENT_OF_PARENT = 11
    PERCENT_OF = 12
    PERCENT_OF_RUNNING_TOTAL = 13
    RANK_ASCENDING = 14
    RANK_DESCENDING = 15


class PivotFilterType(IntEnum):
    """Filter type for an active (slicer-applied) pivot filter."""

    VALUE_TOP_10 = 0
    VALUE_GREATER_THAN = 1
    VALUE_BETWEEN = 2
    LABEL_CONTAINS = 3
    LABEL_BEGINS_WITH = 4
    LABEL_DATE = 5


class PivotFilterValueKind(IntEnum):
    """Discriminator for a pivot filter spec's variant payload."""

    NONE = -1
    INT = 0
    DOUBLE = 1
    TEXT = 2


class PivotDateGrouping(IntEnum):
    """Date-grouping granularity for a pivot field.

    ``DAYS`` is Excel's "By: Days" grouping (an explicit interval, e.g.
    a real Excel "week" is ``DAYS`` with ``interval_days=7``); there is
    no separate week granularity.
    """

    DAY = 0
    MONTH = 1
    QUARTER = 2
    YEAR = 3
    DAYS = 4
    HOUR = 5
    MINUTE = 6
    SECOND = 7


class PivotCalendar(IntEnum):
    """Calendar system used by pivot date grouping."""

    GREGORIAN = 0
    JAPANESE = 1


class PivotCellKind(IntEnum):
    """Discriminator for a projected PivotTable layout cell."""

    HEADER = 0
    ROW_LABEL = 1
    COL_LABEL = 2
    DATA = 3
    ROW_SUBTOTAL = 4
    COL_SUBTOTAL = 5
    GRAND_TOTAL = 6
    BLANK = 7


class PivotReportLayout(IntEnum):
    """Pivot report layout setting (distinct from :class:`PivotLayout`)."""

    COMPACT = 0
    TABULAR = 1
    OUTLINE = 2


class PivotSortOrder(IntEnum):
    """Sibling item order of a pivot field (``fm_pivot_sort_order_t``).

    ``MANUAL`` keeps items in the order added with
    :meth:`Workbook.pivot_field_add_item` and takes no ``by_field`` key.
    """

    DESCENDING = 0
    ASCENDING = 1
    MANUAL = 2


# Sentinel value for ``PivotDataFieldSpec.show_as_base_item`` meaning
# "(previous)" / "(next)" (mirrors the C ABI constants).
PIVOT_SHOW_AS_BASE_PREVIOUS = 1048828
PIVOT_SHOW_AS_BASE_NEXT = 1048829

# Sentinel for ``CellStyle.builtin_id`` meaning "custom (no builtinId)".
CELL_STYLE_BUILTIN_ID_NONE = S.CELL_STYLE_BUILTIN_ID_NONE


# ---------------------------------------------------------------------------
# Structured value / input dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MergeRange:
    """Inclusive cell rectangle (0-based corners)."""

    first_row: int
    first_col: int
    last_row: int
    last_col: int


@dataclass(frozen=True)
class Hyperlink:
    """A sheet hyperlink covering an inclusive cell rectangle."""

    row: int
    col: int
    last_row: int
    last_col: int
    target: str
    location: str
    display: str
    tooltip: str


@dataclass(frozen=True)
class Comment:
    """A cell comment."""

    author: str
    text: str


class CommentEntry(NamedTuple):
    """One enumerated sheet comment, including its zero-based anchor."""

    row: int
    col: int
    author: str
    text: str


@dataclass(frozen=True)
class DataValidation:
    """A sheet ``<dataValidation>`` rule (getter result)."""

    ranges: List[MergeRange]
    type: int
    op: int
    error_style: Union[ValidationErrorStyle, int]
    allow_blank: bool
    show_input_message: bool
    show_error_message: bool
    show_dropdown: bool
    formula1: str
    formula2: str
    error_title: str
    error_message: str
    prompt_title: str
    prompt_message: str


@dataclass
class DataValidationInput:
    """Argument shape for :meth:`Workbook.add_validation`.

    Every field except ``type`` defaults to a benign zero/false/empty so
    callers populate only the parts they need. ``show_dropdown`` defaults
    to ``True`` to match the OOXML default (the in-cell dropdown arrow is
    shown for ``list`` validations unless explicitly suppressed).
    """

    type: int
    ranges: List[MergeRange] = field(default_factory=list)
    op: int = 0
    error_style: Union[ValidationErrorStyle, int] = ValidationErrorStyle.STOP
    allow_blank: bool = False
    show_input_message: bool = False
    show_error_message: bool = False
    show_dropdown: bool = True
    formula1: str = ""
    formula2: str = ""
    error_title: str = ""
    error_message: str = ""
    prompt_title: str = ""
    prompt_message: str = ""


# `dxf_id` value meaning "no differential format".
_FILTER_DXF_ID_NONE = 0xFFFFFFFF


@dataclass
class AutoFilterDateGroup:
    """One ``<dateGroupItem>`` of a values filter; finer fields than ``grouping`` are zero."""

    year: int = 0
    month: int = 0
    day: int = 0
    hour: int = 0
    minute: int = 0
    second: int = 0
    grouping: Union[DateTimeGrouping, int] = DateTimeGrouping.YEAR


@dataclass
class AutoFilterColumn:
    """One ``<filterColumn>``; only the fields of the criterion selected by ``kind`` are read."""

    col_id: int
    hidden_button: bool = False
    show_button: bool = True
    kind: Union[FilterKind, int] = FilterKind.NONE
    filter_blank: bool = False
    values: List[str] = field(default_factory=list)
    date_groups: List[AutoFilterDateGroup] = field(default_factory=list)
    custom_and: bool = False
    custom_count: int = 0
    op1: Union[FilterOperator, int] = FilterOperator.EQUAL
    val1: str = ""
    op2: Union[FilterOperator, int] = FilterOperator.EQUAL
    val2: str = ""
    top: bool = True
    percent: bool = False
    has_filter_val: bool = False
    top_val: float = 0.0
    filter_val: float = 0.0
    dynamic_type: Union[DynamicFilterType, int] = DynamicFilterType.NULL
    has_dyn_val: bool = False
    has_dyn_max_val: bool = False
    dyn_val: float = 0.0
    dyn_max_val: float = 0.0
    val_iso: str = ""
    max_val_iso: str = ""
    dxf_id: int = _FILTER_DXF_ID_NONE
    cell_color: bool = False
    icon_set: int = 0
    icon_id: int = 0
    has_icon_id: bool = False


@dataclass
class AutoFilterSortCondition:
    """One ``<sortCondition>`` of an AutoFilter sort state."""

    ref: MergeRange
    descending: bool = False
    sort_by: Union[SortBy, int] = SortBy.VALUE
    custom_list: str = ""
    dxf_id: int = 0
    has_dxf_id: bool = False
    icon_set: int = 0
    icon_id: int = 0
    has_icon_id: bool = False


@dataclass
class AutoFilterSortState:
    """The ``<sortState>`` of an AutoFilter; ``sort_method`` is a :class:`SortMethod`."""

    ref: MergeRange
    column_sort: bool = False
    case_sensitive: bool = False
    sort_method: Union[SortMethod, int] = SortMethod.NONE
    conditions: List[AutoFilterSortCondition] = field(default_factory=list)


@dataclass
class AutoFilter:
    """A sheet or table AutoFilter; ``range`` includes the header row, ``sort`` may be ``None``."""

    range: MergeRange
    columns: List[AutoFilterColumn] = field(default_factory=list)
    sort: Optional[AutoFilterSortState] = None


@dataclass(frozen=True)
class ValidationOutcome:
    """Result of :meth:`Workbook.validate_value`.

    ``has_rule`` is ``False`` (and ``valid`` ``True``) when no rule covers the
    cell; otherwise ``rule_index`` and ``error_style`` (a
    :class:`ValidationErrorStyle`) describe the applied rule.
    """

    has_rule: bool
    valid: bool
    rule_index: int
    error_style: Union[ValidationErrorStyle, int]


@dataclass
class Mention:
    """One ``@person`` mention; ``start`` and ``length`` are UTF-16 code units."""

    person_id: str
    mention_id: str
    start: int
    length: int


@dataclass
class ThreadedComment:
    """A threaded comment: a thread opener, or a reply when ``parent_id`` is non-empty."""

    id: str
    row: int = 0
    col: int = 0
    person_id: str = ""
    created: str = ""
    text: str = ""
    parent_id: str = ""
    done: bool = False
    mentions: List[Mention] = field(default_factory=list)


@dataclass
class Person:
    """One entry of the workbook's person list."""

    id: str
    display_name: str
    user_id: str = ""
    provider_id: str = ""


@dataclass
class ImageInfo:
    """Format and pixel size of an image."""

    format: Union[ImageFormat, int]
    px_width: int
    px_height: int


@dataclass
class DrawingObject:
    """One anchored object of a sheet's drawing; sizes and offsets are in EMU."""

    object_id: int
    kind: Union[DrawingObjectKind, int]
    anchor_kind: Union[AnchorKind, int]
    edit_as: Union[AnchorEditAs, int]
    from_row: int
    from_col: int
    from_row_off: int
    from_col_off: int
    to_row: int
    to_col: int
    to_row_off: int
    to_col_off: int
    cx: int
    cy: int
    image_format: Union[ImageFormat, int]
    name: str
    descr: str
    media_path: str


@dataclass
class Shape:
    """A shape, connector or group of a sheet's drawing; sizes and offsets are in EMU.

    The anchor fields read as in :class:`DrawingObject`. ``fill_rgb`` and
    ``line_rgb`` are ``0xRRGGBB`` when the matching kind is ``ShapePaint.SOLID``.
    ``rotation`` is in 60000ths of a degree; ``prst`` is empty for custom
    geometry or a group.
    """

    object_id: int
    kind: Union[DrawingObjectKind, int]
    anchor_kind: Union[AnchorKind, int]
    edit_as: Union[AnchorEditAs, int]
    from_row: int
    from_col: int
    from_row_off: int
    from_col_off: int
    to_row: int
    to_col: int
    to_row_off: int
    to_col_off: int
    cx: int
    cy: int
    name: str
    prst: str
    text: str
    text_box: bool
    fill_kind: Union[ShapePaint, int]
    fill_rgb: int
    line_kind: Union[ShapePaint, int]
    line_rgb: int
    line_width_emu: int
    rotation: int
    hidden: bool


@dataclass
class Slicer:
    """A table slicer of a worksheet; sizes and offsets are in EMU.

    ``object_id`` is the slicer's frame in the sheet's drawing (``0`` without
    one); the anchor fields read as in :class:`DrawingObject`, and ``to_*`` is
    zero unless the anchor is two-cell. ``cache_name``, ``table_name`` and
    ``column_name`` identify the slicer cache and the table column it filters;
    the selection itself lives in the table's AutoFilter. ``style`` is empty
    without a style.
    """

    object_id: int
    name: str
    caption: str
    cache_name: str
    table_name: str
    column_name: str
    style: str
    column_count: int
    row_height: int
    sort_order: Union[SlicerSortOrder, int]
    cross_filter: Union[SlicerCrossFilter, int]
    anchor_kind: Union[AnchorKind, int]
    from_row: int
    from_col: int
    from_row_off: int
    from_col_off: int
    to_row: int
    to_col: int
    to_row_off: int
    to_col_off: int


@dataclass
class DataTableInput:
    """An input cell of a data table; ``deleted`` marks one removed by a row or column delete."""

    row: int
    col: int
    deleted: bool


@dataclass
class DataTable:
    """A What-If data table (``TABLE()``): its result range and input cells, all 0-based.

    The row input cell receives the values of the row above the range, the column input cell those of the column
    left of it. A one-variable table has one input (``row_oriented`` says which, the other is ``None``), a
    two-variable table both. A deleted input makes the table evaluate to ``#REF!``.
    """

    first_row: int
    first_col: int
    last_row: int
    last_col: int
    two_dimensional: bool
    row_oriented: bool
    row_input: Optional[DataTableInput]
    col_input: Optional[DataTableInput]


@dataclass
class Sparkline:
    """One sparkline: the data ``formula`` (a sheet-qualified range without ``=``) and its single A1 ``location``."""

    formula: str
    location: str


@dataclass
class SparklineGroup:
    """A sparkline group of a sheet's worksheet extension list.

    A colour with ``kind=0`` is absent; ``manual_min`` / ``manual_max`` are
    ``None`` when the axis bound is not set. ``date_axis_ref`` is the group's
    date range, empty when absent.
    """

    type: Union[SparklineType, int] = SparklineType.LINE
    color_series: ColorSpec = field(default_factory=lambda: ColorSpec())
    color_negative: ColorSpec = field(default_factory=lambda: ColorSpec())
    color_axis: ColorSpec = field(default_factory=lambda: ColorSpec())
    color_markers: ColorSpec = field(default_factory=lambda: ColorSpec())
    color_first: ColorSpec = field(default_factory=lambda: ColorSpec())
    color_last: ColorSpec = field(default_factory=lambda: ColorSpec())
    color_high: ColorSpec = field(default_factory=lambda: ColorSpec())
    color_low: ColorSpec = field(default_factory=lambda: ColorSpec())
    markers: bool = False
    high: bool = False
    low: bool = False
    first: bool = False
    last: bool = False
    negative: bool = False
    display_x_axis: bool = False
    display_hidden: bool = False
    min_axis_type: Union[SparklineAxisType, int] = SparklineAxisType.INDIVIDUAL
    max_axis_type: Union[SparklineAxisType, int] = SparklineAxisType.INDIVIDUAL
    manual_min: Optional[float] = None
    manual_max: Optional[float] = None
    date_axis: bool = False
    date_axis_ref: str = ""
    line_weight: float = 0.75
    empty_cells_as: Union[SparklineEmptyCells, int] = SparklineEmptyCells.GAP
    sparklines: List[Sparkline] = field(default_factory=list)


class ChartPlotType(IntEnum):
    """Plot group kind (``fm_chart_plot_type_t``)."""

    BAR = 0
    BAR_3D = 1
    LINE = 2
    LINE_3D = 3
    AREA = 4
    AREA_3D = 5
    PIE = 6
    PIE_3D = 7
    DOUGHNUT = 8
    OF_PIE = 9
    SCATTER = 10
    BUBBLE = 11
    RADAR = 12
    STOCK = 13
    SURFACE = 14
    SURFACE_3D = 15
    CHARTEX = 16


class ChartInsertKind(IntEnum):
    """Kinds :meth:`Workbook.insert_chart` and :meth:`Workbook.set_chart_type` produce (``fm_chart_insert_kind_t``)."""

    COLUMN = 0
    BAR = 1
    LINE = 2
    AREA = 3
    PIE = 4
    SCATTER = 5
    DOUGHNUT = 6


class ChartGrouping(IntEnum):
    """Series grouping of a bar, line or area plot (``fm_chart_grouping_t``)."""

    CLUSTERED = 0
    STACKED = 1
    PERCENT_STACKED = 2
    STANDARD = 3


class ChartBlanksAs(IntEnum):
    """How blank cells plot (``fm_chart_blanks_as_t``); ``ABSENT`` omits the element."""

    ABSENT = 0
    GAP = 1
    ZERO = 2
    SPAN = 3


class ChartPointState(IntEnum):
    """State of a resolved data point (``fm_chart_point_state_t``)."""

    VALUE = 0
    GAP = 1
    CONNECT = 2


class ChartAxisKind(IntEnum):
    """Axis element type (``fm_chart_axis_kind_t``)."""

    CATEGORY = 0
    VALUE = 1
    DATE = 2
    SERIES = 3


class ChartAxisCrosses(IntEnum):
    """Where an axis crosses its partner (``fm_chart_axis_crosses_t``)."""

    ABSENT = 0
    AUTO_ZERO = 1
    MIN = 2
    MAX = 3
    AT = 4


class ChartTitleKind(IntEnum):
    """What a chart or axis title holds (``fm_chart_title_kind_t``)."""

    NONE = 0
    TEXT = 1
    REF = 2
    AUTO = 3


class ChartSeriesDirection(IntEnum):
    """Direction series are split from a source range (``fm_chart_series_direction_t``)."""

    AUTO = 0
    COLUMNS = 1
    ROWS = 2


class ChartLegendPosition(IntEnum):
    """Legend placement (``fm_chart_legend_position_t``); ``NONE`` is no legend."""

    NONE = 0
    BOTTOM = 1
    TOP = 2
    LEFT = 3
    RIGHT = 4
    TOP_RIGHT = 5


class ChartLineDash(IntEnum):
    """Outline dash style (``fm_chart_line_dash_t``)."""

    SOLID = 0
    DASH = 1
    DOT = 2
    DASH_DOT = 3
    OTHER = 4


class ChartMarkerSymbol(IntEnum):
    """Series marker symbol (``fm_chart_marker_symbol_t``); ``PICTURE`` is read-only and a patch carrying it is rejected."""

    NONE = 0
    AUTO = 1
    CIRCLE = 2
    SQUARE = 3
    DIAMOND = 4
    TRIANGLE = 5
    X = 6
    STAR = 7
    PLUS = 8
    DOT = 9
    DASH = 10
    PICTURE = 11


class ChartLabelPosition(IntEnum):
    """Data label placement (``fm_chart_label_position_t``)."""

    BEST_FIT = 0
    CENTER = 1
    INSIDE_BASE = 2
    INSIDE_END = 3
    OUTSIDE_END = 4
    ABOVE = 5
    BELOW = 6
    LEFT = 7
    RIGHT = 8


@dataclass
class ChartDataSource:
    """One series input: ``kind`` is ``"none"``, ``"ref"`` (``formula`` set) or ``"literal"`` (``literal`` set)."""

    kind: Literal["none", "ref", "literal"]
    formula: str = ""
    literal: List[Union[float, str]] = field(default_factory=list)


@dataclass
class ChartTitleInfo:
    """A chart or axis title; ``text`` is the flattened rich text (``TEXT``), ``formula`` the reference (``REF``)."""

    kind: Union[ChartTitleKind, int]
    text: str = ""
    formula: str = ""


@dataclass
class ChartFillInfo:
    """Solid fill; ``color`` is ``0xAARRGGBB`` and ``transparency`` a percentage, each ``None`` when absent."""

    color: Optional[int] = None
    transparency: Optional[float] = None


@dataclass
class ChartLineInfo:
    """Outline; ``none`` is an explicit no-line."""

    color: Optional[int] = None
    transparency: Optional[float] = None
    width_pt: Optional[float] = None
    dash: Optional[Union[ChartLineDash, int]] = None
    none: bool = False


@dataclass
class ChartMarkerInfo:
    """Series or point marker."""

    symbol: Union[ChartMarkerSymbol, int]
    size: Optional[int]
    fill: ChartFillInfo
    line: ChartLineInfo


@dataclass
class ChartLabelsInfo:
    """Data labels of a series."""

    show_value: bool
    show_category: bool
    show_series: bool
    show_percent: bool
    show_legend_key: bool
    separator: Optional[str]
    position: Optional[Union[ChartLabelPosition, int]]
    number_format: Optional[str]
    source_linked: bool
    font_color: Optional[int]
    font_size_pt: Optional[float]
    deleted: bool


@dataclass
class ChartPointInfo:
    """One formatted data point (``c:dPt``)."""

    idx: int
    fill: ChartFillInfo
    line: ChartLineInfo
    marker: Optional[ChartMarkerInfo]


@dataclass
class ChartSeriesInfo:
    """One series of a plot group; ``idx`` is its ``c:idx``."""

    idx: int
    order: int
    filtered: bool
    name: ChartDataSource
    categories: ChartDataSource
    values: ChartDataSource
    x: ChartDataSource
    y: ChartDataSource
    size: ChartDataSource
    fill: ChartFillInfo
    line: ChartLineInfo
    marker: Optional[ChartMarkerInfo]
    smooth: Optional[bool]
    points: List[ChartPointInfo]
    labels: Optional[ChartLabelsInfo]


@dataclass
class ChartPlotInfo:
    """One plot group; ``bar_direction`` is ``"col"``, ``"bar"`` or ``None``."""

    type: Union[ChartPlotType, int]
    chartex_layout: Optional[str]
    bar_direction: Optional[Literal["col", "bar"]]
    grouping: Optional[Union[ChartGrouping, int]]
    vary_colors: bool
    gap_width: Optional[int]
    overlap: Optional[int]
    hole_size: Optional[int]
    first_slice_angle: Optional[int]
    axis_ids: List[int]
    series: List[ChartSeriesInfo]


@dataclass
class ChartAxisInfo:
    """One axis; ``position`` is ``"b"``, ``"t"``, ``"l"`` or ``"r"``. ``crosses_at`` is ``None`` unless ``crosses`` is ``AT``."""

    id: int
    kind: Union[ChartAxisKind, int]
    position: Literal["b", "t", "l", "r"]
    deleted: bool
    cross_axis: int
    crosses: Union[ChartAxisCrosses, int]
    crosses_at: Optional[float]
    min: Optional[float]
    max: Optional[float]
    major_unit: Optional[float]
    minor_unit: Optional[float]
    log_base: Optional[float]
    reversed: bool
    number_format: Optional[str]
    source_linked: bool
    title: ChartTitleInfo
    major_gridlines: bool
    minor_gridlines: bool
    tick_label_position: Optional[str]


@dataclass
class ChartLegendInfo:
    """Legend state; ``hidden_series`` lists the ``c:idx`` of series whose legend entry is hidden."""

    position: Union[ChartLegendPosition, int]
    overlay: bool
    hidden_series: List[int] = field(default_factory=list)


@dataclass
class ChartSourceInfo:
    """The rectangle every series was split from and how it was split."""

    range: str
    direction: Union[ChartSeriesDirection, int]
    header_row: bool
    header_column: bool


@dataclass
class ChartInfo:
    """The typed view of a chart (:meth:`Workbook.get_chart`); ``source`` is ``None`` when series share no rectangle."""

    object_id: int
    name: str
    description: str
    is_chartex: bool
    is_pivot_chart: bool
    on_chartsheet: bool
    title: ChartTitleInfo
    auto_title_deleted: Optional[bool]
    legend: ChartLegendInfo
    blanks_as: Union[ChartBlanksAs, int]
    plot_visible_only: Optional[bool]
    date1904: bool
    style: Optional[int]
    plots: List[ChartPlotInfo]
    axes: List[ChartAxisInfo]
    hidden_categories: List[int]
    source: Optional[ChartSourceInfo]


@dataclass
class ChartSheetRange:
    """A rectangle of cells on one sheet (0-based, inclusive)."""

    sheet: int
    top: int
    left: int
    bottom: int
    right: int


@dataclass
class ChartSeriesRanges:
    """The resolved rectangles of each series input."""

    name: List[ChartSheetRange] = field(default_factory=list)
    categories: List[ChartSheetRange] = field(default_factory=list)
    values: List[ChartSheetRange] = field(default_factory=list)
    x: List[ChartSheetRange] = field(default_factory=list)
    y: List[ChartSheetRange] = field(default_factory=list)
    size: List[ChartSheetRange] = field(default_factory=list)


@dataclass
class ChartDataSeries:
    """One resolved series; ``values`` and ``states`` (:class:`ChartPointState`) are parallel.

    ``values`` is the y value in the XY domain; ``x`` is ``None`` outside it
    and ``sizes`` is ``None`` unless the series is a bubble series.
    ``format_code`` is the number format of the values; ``x_format_code`` is
    that of the x values, empty outside the XY domain.
    """

    plot_index: int
    idx: int
    name: Optional[str]
    format_code: str
    x_format_code: str
    filtered: bool
    values: List[float]
    states: List[int]
    x: Optional[List[float]]
    sizes: Optional[List[float]]
    ranges: ChartSeriesRanges


@dataclass
class ChartCategories:
    """Resolved categories; ``values`` is set for numeric (date) categories and ``generated`` when the labels are 1..n."""

    labels: List[str]
    levels: List[List[str]]
    values: Optional[List[float]]
    format_code: str
    generated: bool


@dataclass
class ChartAxisTitleText:
    """Resolved title text of one axis."""

    axis_id: int
    text: str


@dataclass
class ChartUnresolved:
    """An input that did not resolve; its points read as gaps.

    ``source`` is ``name``, ``cat``, ``val``, ``x``, ``y``, ``size``, ``title`` or ``axis_title``.
    """

    series_idx: int
    source: str
    axis_id: int


@dataclass
class ChartData:
    """A chart's series resolved against the current cell values (:meth:`Workbook.get_chart_data`)."""

    domain: Literal["category", "xy"]
    point_count: int
    categories: ChartCategories
    series: List[ChartDataSeries]
    title_text: Optional[str]
    axis_title_texts: List[ChartAxisTitleText]
    unresolved: List[ChartUnresolved]


class ChartFillPatch(TypedDict, total=False):
    """Fill patch: an omitted key is kept, ``None`` removes the element."""

    color: Optional[int]
    transparency: Optional[float]


class ChartLinePatch(TypedDict, total=False):
    """Outline patch; ``none`` is a bool and rejects ``None``."""

    color: Optional[int]
    transparency: Optional[float]
    width_pt: Optional[float]
    dash: Optional[Union[ChartLineDash, int]]
    none: bool


class ChartMarkerPatch(TypedDict, total=False):
    """Marker patch; ``symbol`` rejects ``None``."""

    symbol: Union[ChartMarkerSymbol, int]
    size: Optional[float]
    fill: ChartFillPatch
    line: ChartLinePatch


class ChartLabelsPatch(TypedDict, total=False):
    """Data-label patch; the ``show_*`` flags are bools and reject ``None``."""

    show_value: bool
    show_category: bool
    show_series: bool
    show_percent: bool
    show_legend_key: bool
    separator: Optional[str]
    position: Union[ChartLabelPosition, int]
    number_format: Optional[str]
    font_color: Optional[int]
    font_size_pt: Optional[float]


class ChartSeriesPatch(TypedDict, total=False):
    """Series patch.

    A reference is its new text; ``""`` removes ``name``, ``categories`` or ``x``
    (an empty ``values``, ``y`` or ``size`` is rejected). ``None`` on ``marker``
    or ``labels`` removes it.
    """

    name: str
    categories: str
    values: str
    x: str
    y: str
    size: str
    fill: ChartFillPatch
    line: ChartLinePatch
    marker: Optional[ChartMarkerPatch]
    smooth: bool
    labels: Optional[ChartLabelsPatch]


class ChartPointPatch(TypedDict, total=False):
    """Data-point patch; an empty patch (or ``None``) removes the point's formatting."""

    fill: ChartFillPatch
    line: ChartLinePatch
    marker: Optional[ChartMarkerPatch]


class ChartPlotPatch(TypedDict, total=False):
    """Plot-group patch; a field the plot type does not have is rejected. ``hole_size`` is 10..90 (doughnut only)."""

    gap_width: int
    overlap: int
    first_slice_angle: int
    vary_colors: bool
    hole_size: int


class ChartAxisPatch(TypedDict, total=False):
    """Axis patch.

    ``title`` takes the forms of :meth:`Workbook.set_chart_title`: text, or a
    :class:`ChartTitleInfo` (``AUTO`` leaves the text to the viewer, ``NONE``
    removes the title). ``None`` on ``title`` removes the axis title, on
    ``log_base`` makes the axis linear and on ``tick_label_position``
    (``nextTo``, ``low``, ``high``, ``none``) restores the default.
    ``crosses_at`` is read when ``crosses`` is ``AT``.
    """

    visible: bool
    title: Union[str, ChartTitleInfo, None]
    min: Optional[float]
    max: Optional[float]
    major_unit: Optional[float]
    number_format: Optional[str]
    major_gridlines: bool
    reversed: bool
    log_base: Optional[float]
    crosses: Union[ChartAxisCrosses, int]
    crosses_at: float
    tick_label_position: Optional[str]


class ChartPreviewOverrides(TypedDict, total=False):
    """Overrides for :meth:`Workbook.preview_chart_data`; an omitted key keeps the chart's own value."""

    source: str
    direction: Union[ChartSeriesDirection, int]
    header_row: bool
    header_column: bool
    blanks_as: Union[ChartBlanksAs, int]
    plot_visible_only: bool


@dataclass
class WorkbookProtection:
    """Workbook ``<workbookProtection>``. Hash fields are stored as given; the host computes them."""

    lock_structure: bool = False
    lock_windows: bool = False
    lock_revision: bool = False
    workbook_password: str = ""
    workbook_algorithm_name: str = ""
    workbook_hash_value: str = ""
    workbook_salt_value: str = ""
    workbook_spin_count: int = 0
    revisions_password: str = ""
    revisions_algorithm_name: str = ""
    revisions_hash_value: str = ""
    revisions_salt_value: str = ""
    revisions_spin_count: int = 0


@dataclass
class ProtectedRange:
    """A sheet ``<protectedRange>``; ``sqref`` is the A1 range list (``"B2:C3 E5"``)."""

    name: str
    sqref: str
    password: str = ""
    algorithm_name: str = ""
    hash_value: str = ""
    salt_value: str = ""
    spin_count: int = 0
    security_descriptor: str = ""


@dataclass
class SheetProtection:
    """Sheet ``<sheetProtection>`` flags. Booleans are real ``bool``."""

    enabled: bool = False
    algorithm_name: str = ""
    hash_value: str = ""
    salt_value: str = ""
    spin_count: int = 0
    legacy_password: str = ""
    sheet: bool = False
    objects: bool = False
    scenarios: bool = False
    format_cells: bool = False
    format_columns: bool = False
    format_rows: bool = False
    insert_columns: bool = False
    insert_rows: bool = False
    insert_hyperlinks: bool = False
    delete_columns: bool = False
    delete_rows: bool = False
    select_locked_cells: bool = False
    select_unlocked_cells: bool = False
    sort: bool = False
    auto_filter: bool = False
    pivot_tables: bool = False


@dataclass(frozen=True)
class CivilTime:
    """A wall-clock reading in local civil fields.

    Local calendar fields are carried rather than a timestamp so a pinned
    reading has no residual timezone interpretation: the same values
    reproduce the same results on any host, in any zone.
    """

    year: int
    month: int
    day: int
    hour: int = 0
    minute: int = 0
    second: int = 0


@dataclass(frozen=True)
class SheetView:
    """Per-sheet view: zoom, frozen-pane counts, tab visibility, and the
    display / orientation flags mirrored from OOXML ``<sheetView>``.

    ``visibility`` is the authoritative tab state; ``tab_hidden`` is its
    two-state view and is true for both hidden states, so code that knows
    only the bool sees a very-hidden sheet as hidden rather than visible.
    """

    zoom_scale: int
    freeze_rows: int
    freeze_cols: int
    tab_hidden: bool
    visibility: SheetVisibility = SheetVisibility.VISIBLE
    show_grid_lines: bool = True
    show_row_col_headers: bool = True
    show_zeros: bool = True
    right_to_left: bool = False
    tab_selected: bool = False
    view_mode: str = ""
    top_left_row: int = 0
    top_left_col: int = 0
    pane_top_left_row: int = 0
    pane_top_left_col: int = 0
    split_x: float = 0.0
    split_y: float = 0.0
    show_formulas: bool = False
    show_outline_symbols: bool = True


@dataclass(frozen=True)
class ColumnLayout:
    """A per-column-range layout override (inclusive ``[first, last]``).

    ``has_width`` is logical presence: it is true for the raw source bit or
    a legacy non-zero width. An explicit zero remains distinguishable from an
    absent width.
    """

    first: int
    last: int
    width: float
    hidden: bool
    outline_level: int
    has_width: bool = False
    has_style: bool = False
    style_xf: int = 0
    #: ``collapsed="1"``: the outline group this span summarises is collapsed.
    collapsed: bool = False


@dataclass(frozen=True)
class RowLayout:
    """A per-row layout override."""

    row: int
    height: float
    hidden: bool
    outline_level: int
    has_style: bool = False
    style_xf: int = 0
    #: A stored height is present; ``height`` is meaningful only then.
    has_height: bool = False
    #: ``customHeight="1"``: an explicit override rather than a cached auto height.
    custom_height: bool = False
    #: ``collapsed="1"``: the outline group this row summarises is collapsed.
    collapsed: bool = False


class IterativeSettings(NamedTuple):
    """Iterative-calculation settings read back by ``get_iterative``."""

    enabled: bool
    max_iterations: int
    max_change: float


@dataclass(frozen=True)
class PaginationResult:
    """Resolved physical pagination for one worksheet.

    ``print_area`` is the sheet's declared ``_xlnm.Print_Area`` as
    inclusive, zero-based ``(first_row, first_col, last_row, last_col)``
    rectangles. It is empty when the sheet declares no print area and is
    not backfilled with the used range; pagination itself still falls back
    to the used range, so ``page_count`` can be non-zero while this is
    empty. Break lists contain the zero-based row or column a new physical
    page begins before.
    """

    page_count: int
    print_area: List[tuple[int, int, int, int]]
    horizontal_breaks: List[int]
    vertical_breaks: List[int]
    paper: "PaperInfo"
    margins: "MarginsPt"
    printable: "RectPt"
    #: Effective scale as a factor (1.0 is 100%).
    scale: float
    #: 0 down-then-over, 1 over-then-down.
    page_order: int
    print_titles: "PrintTitles"
    pages: List["PageLayout"]
    #: Per-break manual flags, parallel to ``horizontal_breaks``.
    horizontal_break_manual: List[bool]
    #: Per-break manual flags, parallel to ``vertical_breaks``.
    vertical_break_manual: List[bool]


@dataclass(frozen=True)
class RectPt:
    """A rectangle in points."""

    x: float
    y: float
    width: float
    height: float


@dataclass(frozen=True)
class PaperInfo:
    """The paper a sheet prints on, after the orientation swap."""

    width_pt: float
    height_pt: float
    landscape: bool
    #: False when ``paperSize`` was unrecognised and A4 substituted.
    known: bool


@dataclass(frozen=True)
class MarginsPt:
    """Page margins in points."""

    left: float
    right: float
    top: float
    bottom: float
    header: float
    footer: float


@dataclass(frozen=True)
class PrintTitles:
    """Repeat rows / columns (0-based, inclusive); a span is valid only with its flag."""

    has_rows: bool
    first_row: int
    last_row: int
    has_cols: bool
    first_col: int
    last_col: int


@dataclass(frozen=True)
class PageLayout:
    """One physical page: the cell block it carries and where it sits."""

    area_index: int
    first_row: int
    last_row: int
    first_col: int
    last_col: int
    origin_x_pt: float
    origin_y_pt: float
    width_pt: float
    height_pt: float


@dataclass(frozen=True)
class SheetFormatDefaults:
    """Sheet default column / row metrics (``<sheetFormatPr>``).

    ``default_col_width`` is a stored width (characters with the column
    padding included) and ``default_row_height`` in points; each is
    meaningful only when its ``has_*`` flag is set.
    ``effective_default_col_width`` / ``effective_default_row_height`` are
    read-only values the sheet lays out with: the stated default, else the
    column Excel derives from ``base_col_width`` and the Normal font
    (Calibri 11, base 8: 9.140625, shown as 8.43) and 102/7 pt; the row height is 0 when
    ``zero_height`` hides rows by default. They are ignored when setting.
    """

    default_col_width: float = 0.0
    default_row_height: float = 0.0
    base_col_width: float = 8.0
    has_default_col_width: bool = False
    has_default_row_height: bool = False
    effective_default_col_width: float = 0.0
    effective_default_row_height: float = 0.0
    #: ``customHeight``: ``default_row_height`` is an explicit override rather
    #: than a cached figure Excel recomputes from the Normal font. ``None``
    #: keeps the stored flag when setting.
    custom_height: Optional[bool] = None
    #: ``zeroHeight``: rows are hidden unless they say otherwise. ``None``
    #: keeps the stored flag when setting.
    zero_height: Optional[bool] = None


@dataclass(frozen=True)
class WidthModel:
    """Column-width conversion model for the workbook's Normal font.

    ``points_per_char`` and ``padding_pt`` are per displayed character:
    ``chars * points_per_char + padding_pt``; stored widths go through
    ``column_chars_to_pt``.
    """

    points_per_char: float
    padding_pt: float
    normal_font_size: float
    #: False when the Normal font is not a measured calibration point.
    calibrated: bool
    normal_font_name: str
    platform: str


@dataclass(frozen=True)
class PageBreak:
    """One manual page break as the worksheet declares it.

    ``id`` is the zero-based row or column the break precedes; ``min`` /
    ``max`` bound the break on the perpendicular axis. ``manual`` is False
    for a break Excel computed and recorded rather than one a user placed.
    """

    id: int
    min: int
    max: int
    manual: bool


@dataclass(frozen=True)
class PageSetup:
    """Effective ``<pageSetup>`` values, with per-attribute presence.

    Every value field carries the setting in force. The ``*_stated`` flags
    say whether the XML actually declares it, which is the only way to tell
    ``scale="100"`` from an absent attribute that defaults to 100.

    ``fit_to_page`` lives in ``<sheetPr><pageSetUpPr>`` rather than
    ``<pageSetup>``; it is reported here because callers reason about it as
    part of one page-setup decision.
    """

    orientation: int
    paper_size: int
    scale: int
    fit_to_width: int
    fit_to_height: int
    fit_to_page: bool
    orientation_stated: bool
    paper_size_stated: bool
    scale_stated: bool
    fit_to_width_stated: bool
    fit_to_height_stated: bool
    fit_to_page_stated: bool


@dataclass(frozen=True)
class PageMargins:
    """Effective ``<pageMargins>`` values in inches, with presence flags."""

    left: float
    right: float
    top: float
    bottom: float
    header: float
    footer: float
    left_stated: bool
    right_stated: bool
    top_stated: bool
    bottom_stated: bool
    header_stated: bool
    footer_stated: bool


@dataclass(frozen=True)
class CfMatch:
    """A resolved conditional-format match for one cell.

    Active fields depend on ``kind`` (0 differential format, 1 color
    scale, 2 data bar, 3 icon set); the rest carry default-zero values.
    """

    kind: int
    priority: int
    dxf_id_engaged: bool
    dxf_id: int
    color: tuple  # (r, g, b, a)
    bar_length_pct: float
    bar_axis_position_pct: float
    bar_is_negative: bool
    bar_fill: tuple
    bar_border_engaged: bool
    bar_border: tuple
    bar_gradient: bool
    icon_set_name: int
    icon_index: int
    bar_direction: int = 0  # 0=context, 1=left to right, 2=right to left


@dataclass(frozen=True)
class CfCellResult:
    """One cell's CF matches inside a viewport-range evaluation."""

    row: int
    col: int
    matches: List[CfMatch]


@dataclass(frozen=True)
class CfColor:
    """RGBA color used by a visual conditional-format rule."""

    r: int
    g: int
    b: int
    a: int = 255


@dataclass(frozen=True)
class CfValueObject:
    """One conditional-format threshold (``fm_cfvo_t``)."""

    type: int
    value: Optional[str] = None
    gte: bool = True


@dataclass(frozen=True)
class ColorScale:
    thresholds: List[CfValueObject]
    colors: List[CfColor]


@dataclass(frozen=True)
class DataBar:
    """``<dataBar>`` payload of a conditional-format rule.

    The fields after ``max_length_pct`` live in the ``x14`` extension
    rather than the legacy element. ``None`` means "do not override the
    model default" -- gradient fill on, automatic axis, negative fill
    equal to ``fill``, no border, and a black axis. Reading a rule back
    always populates them, so ``add_conditional_format`` of a value
    returned by ``get_conditional_format_at`` reproduces the rule.
    """

    minimum: CfValueObject
    maximum: CfValueObject
    fill: CfColor
    show_value: bool = True
    min_length_pct: int = 10
    max_length_pct: int = 90
    gradient: Optional[bool] = None
    axis_position: Optional[int] = None
    negative_fill: Optional[CfColor] = None
    border: Optional[CfColor] = None
    negative_border: Optional[CfColor] = None
    axis_color: Optional[CfColor] = None
    direction: int = 0  # edge the bar grows from: 0=context, 1=left to right, 2=right to left


@dataclass(frozen=True)
class IconSet:
    """``<iconSet>`` payload of a conditional-format rule.

    ``percent`` is round-trip only: it is preserved across load and save
    but never consulted during evaluation. Each threshold in
    ``thresholds`` carries its own ``type``, and that type is what
    interprets it.

    ``floor`` is the lower bound of the lowest icon's bucket; a cell below
    it gets no icon. ``None`` means Excel's default, ``percent 0``; reading
    a rule back always populates it.
    """

    name: int
    thresholds: List[CfValueObject]
    reverse: bool = False
    show_value: bool = True
    percent: bool = True
    floor: Optional[CfValueObject] = None
    #: Custom icon set: the icon drawn for each level, empty when the set
    #: draws its own icons.
    icons: List["CfIcon"] = field(default_factory=list)


@dataclass(frozen=True)
class CfIcon:
    """One level of a custom icon set.

    ``icon_set`` is the ``ST_IconSetType`` spelling of the set the icon comes
    from (``"3Arrows"``, ``"3Triangles"``, ``"5Boxes"``, ``"NoIcons"`` for a
    level that draws nothing, ...); ``icon_id`` is the zero-based icon within it.
    """

    icon_set: str
    icon_id: int = 0


@dataclass(frozen=True)
class ConditionalFormat:
    """A conditional-format rule (getter result, flattened priority order)."""

    id: str
    type: int
    priority: int
    stop_if_true: bool
    sqref: List[MergeRange]
    dxf_id: Optional[int]
    formula1: str
    formula2: str
    op: Optional[int]
    rank: Optional[int]
    percent: bool
    bottom: bool
    above_average: bool
    equal_average: bool
    std_dev: Optional[float]
    text: str
    time_period: Optional[int]
    color_scale: Optional[ColorScale]
    data_bar: Optional[DataBar]
    icon_set: Optional[IconSet]


@dataclass
class ConditionalFormatInput:
    """Argument shape for :meth:`Workbook.add_conditional_format`.

    Set the corresponding visual payload for color-scale, data-bar, or
    icon-set rules. The C ABI validates each payload's cardinality.
    """

    sqref: List[MergeRange]
    type: int
    priority: int = 0
    stop_if_true: bool = False
    id: str = ""
    dxf_id: Optional[int] = None
    formula1: str = ""
    formula2: str = ""
    op: Optional[int] = None
    rank: Optional[int] = None
    percent: bool = False
    bottom: bool = False
    above_average: bool = False
    equal_average: bool = False
    std_dev: Optional[float] = None
    text: str = ""
    time_period: Optional[int] = None
    color_scale: Optional[ColorScale] = None
    data_bar: Optional[DataBar] = None
    icon_set: Optional[IconSet] = None


@dataclass(frozen=True)
class CellNode:
    """A workbook-wide cell coordinate (precedents / dependents trace)."""

    sheet: int
    row: int
    col: int


@dataclass(frozen=True)
class SpillInfo:
    """Dynamic-array spill region info for a cell."""

    engaged: bool
    anchor_row: int
    anchor_col: int
    rows: int
    cols: int


@dataclass(frozen=True)
class FunctionMetadata:
    """Catalog metadata for a single Formulon function."""

    name: str
    min_arity: int
    #: ``None`` denotes an unbounded variadic or a lazy / special form
    #: whose upper arity is unknown.
    max_arity: Optional[int]
    availability: int
    signature_template: Optional[str]
    description: Optional[str]


@dataclass(frozen=True)
class ErrorName:
    """One error value's spelling under a profile.

    ``canonical`` is the en-invariant text and ``localized`` the profile's
    Excel spelling. ``measured`` is ``False`` when the localized spelling
    is assumed rather than captured from Excel.
    """

    canonical: str
    localized: str
    measured: bool


@dataclass(frozen=True)
class LocaleFacts:
    """Scalar locale facts of one :data:`ExcelProfileId`.

    ``measured`` is ``True`` for the profiles captured from Excel (every
    ``mac-*`` id and ``win-365-ja_JP``) and ``False`` for the estimated
    ``win-*`` ids. Every scalar field is captured in each Mac locale, so
    ``measured`` covers them all; only ``error_names`` carries per-entry
    flags. ``date_order`` is ``"mdy"``, ``"ymd"`` or ``"dmy"``.
    ``error_names`` is indexed by error-code ordinal.
    """

    decimal_separator: str
    group_separator: str
    list_separator: str
    array_column_separator: str
    array_row_separator: str
    true_name: str
    false_name: str
    date_order: str
    currency_symbol: str
    #: ``True`` when the currency symbol follows the number.
    currency_suffix: bool
    #: ``True`` when one space separates the symbol and the number.
    currency_space: bool
    currency_default_decimals: int
    measured: bool
    #: ``True`` when the collation order of the profile was measured in Excel
    #: (every ``mac-*`` id); ``False`` for the estimated ``win-*`` ids, even
    #: ``win-365-ja_JP``, whose ``measured`` is ``True``.
    collation_measured: bool
    error_names: Tuple[ErrorName, ...]


def _cell_xf_has_alignment(record: "CellXf") -> bool:
    return (
        record.has_alignment is True
        or (record.has_horizontal_align if record.has_horizontal_align is not None else record.horizontal_align != 0)
        or (record.has_vertical_align if record.has_vertical_align is not None else record.vertical_align != 2)
        or (record.has_wrap_text if record.has_wrap_text is not None else record.wrap_text)
        or (record.has_justify_last_line if record.has_justify_last_line is not None else record.justify_last_line)
        or record.text_rotation is not None
        or record.indent is not None
        or record.relative_indent is not None
        or record.shrink_to_fit is not None
        or record.reading_order is not None
    )


@dataclass(frozen=True)
class CellXf:
    """A resolved ``<xf>`` style record."""

    font_index: int
    fill_index: int
    border_index: int
    num_fmt_id: int
    horizontal_align: int
    vertical_align: int
    wrap_text: bool
    #: ``None`` infers presence from explicitly supplied alignment values;
    #: ``False`` requests omission when all alignment values are defaults.
    #: Non-default values still imply that an alignment child is required.
    has_alignment: Optional[bool] = None
    justify_last_line: bool = False
    xf_id: int = 0
    text_rotation: Optional[int] = None
    indent: Optional[int] = None
    relative_indent: Optional[int] = None
    shrink_to_fit: Optional[bool] = None
    reading_order: Optional[int] = None
    has_horizontal_align: Optional[bool] = None
    has_vertical_align: Optional[bool] = None
    has_wrap_text: Optional[bool] = None
    has_justify_last_line: Optional[bool] = None
    apply_number_format: bool = False
    apply_font: bool = False
    apply_fill: bool = False
    apply_border: bool = False
    apply_alignment: bool = False
    apply_protection: bool = False
    quote_prefix: bool = False
    #: Presence of the ``<protection>`` child; ``locked`` / ``hidden`` are
    #: ignored on insertion without it.
    has_protection: bool = False
    locked: bool = True
    hidden: bool = False


@dataclass
class ColorSpec:
    """How an OOXML ``<color>`` element expressed its value.

    Records read from a file carry the original specification here. When
    ``kind`` is non-zero, it is authoritative; the owning record's
    ``*_argb`` field is not an Excel-rendered value for theme/indexed/auto.
    It is literal RGB for ``kind=1`` or a compatibility fallback otherwise.
    ``kind`` is ``0=none``, ``1=rgb``, ``2=theme``, ``3=indexed``, ``4=auto``;
    the default ``kind=0`` makes the writer emit ``*_argb`` as ``rgb``.
    """

    kind: Union[FilterKind, int] = FilterKind.NONE
    rgb: int = 0
    theme: int = 0
    tint: float = 0.0
    indexed: int = 0


@dataclass
class PhoneticRun:
    """One ``<rPh>`` block: ``text`` reads the span ``[sb, eb)``.

    Offsets are UTF-16 code units, which is how Excel indexes string
    positions. A whole-cell reading is the single run
    ``PhoneticRun(0, <length of the cell text>, kana)``.
    """

    sb: int = 0
    eb: int = 0
    text: str = ""


@dataclass
class PhoneticProperties:
    """How a cell's phonetic guide renders (OOXML ``<phoneticPr>``).

    ``font_id`` indexes the workbook's font table for the ruby text.
    ``type`` is the kana form: 0 half-width katakana, 1 full-width
    katakana, 2 hiragana, 3 no conversion. ``alignment`` is how the kana
    is distributed: 0 no control, 1 left, 2 center, 3 distributed.

    The all-zero default is the state Excel infers for a guide written
    with no ``<phoneticPr>`` element at all.
    """

    font_id: int = 0
    type: int = 0
    alignment: int = 0


@dataclass
class FontRecord:
    """A font record (``add_font`` input / ``get_font`` result).

    The ``has_*`` flags distinguish an absent OOXML element from an
    explicit ``val="0"``: on a differential font an absent ``<b>`` means
    "leave the source formatting unchanged" while ``<b val="0"/>`` means
    "switch bold off". ``color`` is authoritative when its ``kind`` is
    non-zero; ``color_argb`` is literal RGB for ``kind=1`` and a
    compatibility fallback for theme/indexed/auto selectors, not a
    rendered colour.
    """

    name: str = ""
    size: float = 11.0
    color_argb: int = 0
    bold: bool = False
    italic: bool = False
    strike: bool = False
    has_bold: bool = False
    has_italic: bool = False
    has_strike: bool = False
    #: ``<outline>`` / ``<shadow>`` / ``<condense>`` / ``<extend>`` toggles,
    #: with the same ``has_*`` rule as ``bold``.
    outline: bool = False
    shadow: bool = False
    condense: bool = False
    extend: bool = False
    has_outline: bool = False
    has_shadow: bool = False
    has_condense: bool = False
    has_extend: bool = False
    underline: int = 0
    #: 0=baseline, 1=superscript, 2=subscript.
    vert_align: int = 0
    has_family: bool = False
    family: int = 0
    has_charset: bool = False
    charset: int = 0
    #: False leaves the size unchanged; only a differential font honours it.
    has_size: bool = True
    #: ``<scheme>`` theme link: 0=absent, 1=major, 2=minor.
    scheme: int = 0
    color: ColorSpec = field(default_factory=ColorSpec)


@dataclass
class GradientStop:
    """One ``<stop>`` of a gradient fill: a colour at ``position`` (0..1)."""

    position: float = 0.0
    color_argb: int = 0
    color: ColorSpec = field(default_factory=ColorSpec)


@dataclass
class GradientFill:
    """A ``<gradientFill>``.

    ``type`` is 0 for linear and 1 for path. ``degree`` is a linear
    gradient's angle; ``left`` / ``right`` / ``top`` / ``bottom`` (0..1)
    locate a path gradient's focus.
    """

    type: int = 0
    degree: float = 0.0
    left: float = 0.0
    right: float = 0.0
    top: float = 0.0
    bottom: float = 0.0
    stops: List[GradientStop] = field(default_factory=list)


@dataclass
class FillRecord:
    """A fill record.

    ``fg`` and ``bg`` carry the authoritative OOXML colour selectors. Their
    sibling ``*_argb`` fields are literal RGB for ``kind=1`` or compatibility
    fallbacks otherwise; ``kind=0`` writes the sibling as ``rgb``. A
    ``gradient`` makes the record a ``<gradientFill>`` and the pattern fields
    are ignored.
    """

    pattern: int = 0
    fg_argb: int = 0
    bg_argb: int = 0
    fg: ColorSpec = field(default_factory=ColorSpec)
    bg: ColorSpec = field(default_factory=ColorSpec)
    gradient: Optional[GradientFill] = None


@dataclass
class DifferentialFormat:
    """An optional-style-fragment record used by conditional formats.

    ``border`` uses the same dictionary shape as :meth:`Workbook.add_border`.
    A number format is engaged when ``num_fmt_id`` is not ``None``.
    ``alignment_xml`` and ``protection_xml`` carry serialized OOXML child
    fragments; an empty string means absent. Their semantic content survives
    round-tripping, while XML lexical formatting may normalize on load.
    """

    font: Optional[FontRecord] = None
    fill: Optional[FillRecord] = None
    border: Optional[Dict[str, object]] = None
    num_fmt_id: Optional[int] = None
    num_fmt_code: str = ""
    alignment_xml: str = ""
    protection_xml: str = ""


def _decode_color(ptr: int) -> ColorSpec:
    d = S.COLOR_SPEC.unpack(LIB, ptr)
    return ColorSpec(kind=d["kind"], rgb=d["rgb"], theme=d["theme"], tint=d["tint"], indexed=d["indexed"])


def _pack_color(ptr: int, spec: ColorSpec) -> None:
    S.COLOR_SPEC.pack(
        LIB,
        ptr,
        {
            "kind": _uint(spec.kind, "kind", 8),
            "rgb": _uint(spec.rgb, "rgb"),
            "theme": _uint(spec.theme, "theme"),
            "tint": float(spec.tint),
            "indexed": _uint(spec.indexed, "indexed"),
        },
    )


def _decode_font(ptr: int) -> FontRecord:
    d = S.FONT_RECORD.unpack(LIB, ptr)
    return FontRecord(
        name=LIB.read_cstr(d["name"]),
        size=d["size"],
        color_argb=d["color_argb"],
        bold=bool(d["bold"]),
        italic=bool(d["italic"]),
        strike=bool(d["strike"]),
        has_bold=bool(d["has_bold"]),
        has_italic=bool(d["has_italic"]),
        has_strike=bool(d["has_strike"]),
        outline=bool(d["outline"]),
        shadow=bool(d["shadow"]),
        condense=bool(d["condense"]),
        extend=bool(d["extend"]),
        has_outline=bool(d["has_outline"]),
        has_shadow=bool(d["has_shadow"]),
        has_condense=bool(d["has_condense"]),
        has_extend=bool(d["has_extend"]),
        underline=d["underline"],
        vert_align=d["vert_align"],
        has_family=bool(d["has_family"]),
        family=d["family"],
        has_charset=bool(d["has_charset"]),
        charset=d["charset"],
        has_size=bool(d["has_size"]),
        scheme=d["scheme"],
        color=_decode_color(ptr + S.FONT_RECORD.offsets["color"][1]),
    )


def _pack_font(ptr: int, record: FontRecord, scope: _ArgScope) -> None:
    S.FONT_RECORD.pack(
        LIB,
        ptr,
        {
            "size": float(record.size),
            "color_argb": _uint(record.color_argb, "color_argb"),
            "bold": 1 if record.bold else 0,
            "italic": 1 if record.italic else 0,
            "strike": 1 if record.strike else 0,
            "has_bold": 1 if record.has_bold else 0,
            "has_italic": 1 if record.has_italic else 0,
            "has_strike": 1 if record.has_strike else 0,
            "outline": 1 if record.outline else 0,
            "shadow": 1 if record.shadow else 0,
            "condense": 1 if record.condense else 0,
            "extend": 1 if record.extend else 0,
            "has_outline": 1 if record.has_outline else 0,
            "has_shadow": 1 if record.has_shadow else 0,
            "has_condense": 1 if record.has_condense else 0,
            "has_extend": 1 if record.has_extend else 0,
            "underline": _uint(record.underline, "underline", 8),
            "vert_align": _uint(record.vert_align, "vert_align", 8),
            "has_family": 1 if record.has_family else 0,
            "family": _uint(record.family, "family", 8),
            "has_charset": 1 if record.has_charset else 0,
            "has_size": 1 if record.has_size else 0,
            "charset": _uint(record.charset, "charset", 8),
            "scheme": _uint(record.scheme, "scheme", 8),
        },
    )
    _pack_color(ptr + S.FONT_RECORD.offsets["color"][1], record.color)
    S.write_str_field(LIB, ptr, S.FONT_RECORD, "name", record.name, scope)


def _decode_fill(ptr: int) -> FillRecord:
    d = S.FILL_RECORD.unpack(LIB, ptr)
    gradient = None
    if d["has_gradient"]:
        stop_size = S.GRADIENT_STOP.size
        stops = []
        for i in range(d["gradient_stop_count"]):
            stop_ptr = d["gradient_stops"] + i * stop_size
            stop = S.GRADIENT_STOP.unpack(LIB, stop_ptr)
            stops.append(
                GradientStop(
                    position=stop["position"],
                    color_argb=stop["color_argb"],
                    color=_decode_color(stop_ptr + S.GRADIENT_STOP.offsets["color"][1]),
                )
            )
        gradient = GradientFill(
            type=d["gradient_type"],
            degree=d["gradient_degree"],
            left=d["gradient_left"],
            right=d["gradient_right"],
            top=d["gradient_top"],
            bottom=d["gradient_bottom"],
            stops=stops,
        )
    return FillRecord(
        pattern=d["pattern"],
        fg_argb=d["fg_argb"],
        bg_argb=d["bg_argb"],
        fg=_decode_color(ptr + S.FILL_RECORD.offsets["fg"][1]),
        bg=_decode_color(ptr + S.FILL_RECORD.offsets["bg"][1]),
        gradient=gradient,
    )


def _pack_fill(ptr: int, record: FillRecord, scope: _ArgScope) -> None:
    """Write ``record`` into the ``fm_fill_record`` at ``ptr``; the gradient
    stops are allocated through ``scope``."""
    values: Dict[str, object] = {
        "pattern": _uint(record.pattern, "pattern", 8),
        "fg_argb": _uint(record.fg_argb, "fg_argb"),
        "bg_argb": _uint(record.bg_argb, "bg_argb"),
    }
    gradient = record.gradient
    stops_ptr = 0
    if gradient is not None:
        stop_size = S.GRADIENT_STOP.size
        if gradient.stops:
            stops_ptr = scope.alloc(stop_size * len(gradient.stops))
            LIB.write_bytes(stops_ptr, b"\x00" * (stop_size * len(gradient.stops)))
            for i, stop in enumerate(gradient.stops):
                stop_ptr = stops_ptr + i * stop_size
                S.GRADIENT_STOP.pack(
                    LIB,
                    stop_ptr,
                    {"position": float(stop.position), "color_argb": _uint(stop.color_argb, "color_argb")},
                )
                _pack_color(stop_ptr + S.GRADIENT_STOP.offsets["color"][1], stop.color)
        values.update(
            has_gradient=1,
            gradient_type=_sint(gradient.type, "gradient.type"),
            gradient_degree=float(gradient.degree),
            gradient_left=float(gradient.left),
            gradient_right=float(gradient.right),
            gradient_top=float(gradient.top),
            gradient_bottom=float(gradient.bottom),
            gradient_stops=stops_ptr,
            gradient_stop_count=len(gradient.stops),
        )
    S.FILL_RECORD.pack(LIB, ptr, values)
    _pack_color(ptr + S.FILL_RECORD.offsets["fg"][1], record.fg)
    _pack_color(ptr + S.FILL_RECORD.offsets["bg"][1], record.bg)


def _decode_border_record(ptr: int) -> Dict[str, object]:
    sides: Dict[str, object] = {}
    for side in ("left", "right", "top", "bottom", "diagonal"):
        side_ptr = ptr + S.BORDER_RECORD.offsets[side][1]
        d = S.BORDER_SIDE.unpack(LIB, side_ptr)
        sides[side] = {
            "style": d["style"],
            "color_argb": d["color_argb"],
            "color": _decode_color(side_ptr + S.BORDER_SIDE.offsets["color"][1]),
        }
    outer = S.BORDER_RECORD.unpack(LIB, ptr)
    sides["diagonal_up"] = bool(outer["diagonal_up"])
    sides["diagonal_down"] = bool(outer["diagonal_down"])
    return sides


def _pack_border_record(ptr: int, sides: Dict[str, object]) -> None:
    S.BORDER_RECORD.pack(
        LIB,
        ptr,
        {
            "diagonal_up": 1 if sides.get("diagonal_up") else 0,
            "diagonal_down": 1 if sides.get("diagonal_down") else 0,
        },
    )
    for side in ("left", "right", "top", "bottom", "diagonal"):
        spec = sides.get(side) or {}
        side_ptr = ptr + S.BORDER_RECORD.offsets[side][1]
        S.BORDER_SIDE.pack(
            LIB,
            side_ptr,
            {
                "style": _uint(spec.get("style", 0), "style", 8),
                "color_argb": _uint(spec.get("color_argb", 0), "color_argb"),
            },
        )
        _pack_color(side_ptr + S.BORDER_SIDE.offsets["color"][1], spec.get("color") or ColorSpec())


class StyleBatchIndices(NamedTuple):
    """Indices assigned by :meth:`Workbook.add_batch`, per style table.

    Each list is positionally aligned with the request list it came from
    and is empty when that list was omitted.
    """

    fonts: List[int]
    fills: List[int]
    borders: List[int]
    cell_xfs: List[int]
    num_fmts: List[int]


@dataclass(frozen=True)
class CellStyle:
    """A named cell style (``<cellStyle>`` entry)."""

    name: str
    xf_id: int
    builtin_id: int = CELL_STYLE_BUILTIN_ID_NONE
    i_level: int = 0
    hidden: bool = False
    custom_builtin: bool = False


@dataclass(frozen=True)
class ThemeFonts:
    """The theme's major (heading) and minor (body) typefaces."""

    major_latin: str = ""
    major_east_asian: str = ""
    minor_latin: str = ""
    minor_east_asian: str = ""


@dataclass(frozen=True)
class ThemeScriptFont:
    """One ``a:font`` entry of a theme font set: an ISO 15924 ``script`` code (``Jpan``) and its ``typeface``."""

    script: str
    typeface: str


@dataclass(frozen=True)
class Theme:
    """The theme read back: ``colors`` are 12 ``0xFFRRGGBB`` values in ``a:clrScheme`` order.

    ``major_scripts`` / ``minor_scripts`` hold the per-script typefaces in the
    theme part's file order (the default Office theme's 47 scripts when the
    part is absent). To pick the face for a font whose ``scheme`` is major or
    minor, choose the script from the font's ``charset``: 128 -> ``Jpan``,
    129 -> ``Hang``, 134 -> ``Hans``, 136 -> ``Hant``, 222 -> ``Thai``,
    anything else -> the latin face in ``fonts``.
    """

    source: ThemeSource
    colors: List[int]
    fonts: ThemeFonts
    major_scripts: Tuple[ThemeScriptFont, ...] = ()
    minor_scripts: Tuple[ThemeScriptFont, ...] = ()


@dataclass(frozen=True)
class ResolvedColor:
    """A colour resolved to ``0xAARRGGBB`` and how it was resolved."""

    argb: int
    resolution: ColorResolution


@dataclass(frozen=True)
class EffectiveStyle:
    """The formatting a cell shows, read from its selected xf record.

    ``borders`` holds left, right, top, bottom, diagonal.
    """

    xf_index: int
    source: EffectiveStyleSource
    font_index: int
    fill_index: int
    border_index: int
    font: ResolvedColor
    fill_foreground: ResolvedColor
    fill_background: ResolvedColor
    borders: List[ResolvedColor]
    locked: bool
    hidden: bool
    num_fmt_code: str


@dataclass(frozen=True)
class ExternalLink:
    """An external-link record (``<externalReferences>`` entry)."""

    index: int
    rel_id: str
    part_path: str
    target: str
    target_external: bool
    kind: ExternalLinkKind


@dataclass(frozen=True)
class PivotCell:
    """One projected PivotTable layout cell."""

    row: int
    col: int
    value: Value
    kind: PivotCellKind
    depth: int
    field_name: str
    number_format: str


@dataclass(frozen=True)
class PivotLayout:
    """The projected rectangular layout of a PivotTable."""

    top: int
    left: int
    rows: int
    cols: int
    cells: List[PivotCell]


@dataclass(frozen=True)
class PivotWorksheetSource:
    """Optional worksheet-source metadata for a pivot cache."""

    ref: Optional[str] = None
    sheet: Optional[str] = None
    name: Optional[str] = None


@dataclass
class PivotFieldSpec:
    """Argument shape for :meth:`Workbook.pivot_field_add`.

    ``subtotal_top`` defaults to ``True``, Excel's default: a group's subtotal
    sits on its own heading row. ``False`` heads the group with a label-only
    row and closes it with an ``"<item> Total"`` row.
    """

    source_name: str
    custom_name: str = ""
    axis: "PivotAxis | int" = PivotAxis.ROW
    subtotal_top: bool = True
    number_format: str = ""


@dataclass(frozen=True)
class PivotFieldInfo:
    """A pivot field's definition, as read by :meth:`Workbook.pivot_field_at`.

    ``axis`` is ``None`` for a field that sits on no axis. ``cache_field_index``
    is the bound pivot-cache field (pivot field ``i`` binds to cache field
    ``i``), ``-1`` when the cache does not cover the field. The ``date_*``
    members describe the field's date grouping and are only meaningful when
    ``has_date_group`` is true; an unset year or serial reads ``-1``.
    ``subtotal_fns`` lists the custom subtotal functions in ascending
    aggregation order; ``default_subtotal`` is false whenever it is non-empty,
    since custom functions replace the automatic subtotal.
    """

    source_name: str
    custom_name: str
    axis: Optional[PivotAxis]
    subtotal_top: bool
    number_format: str
    cache_field_index: int
    sort_order: PivotSortOrder
    sort_by_field: str
    has_date_group: bool
    date_granularity: PivotDateGrouping
    date_calendar: PivotCalendar
    date_start_year: int
    date_end_year: int
    date_interval_days: int
    date_start_serial: float
    date_end_serial: float
    default_subtotal: bool
    subtotal_fns: Tuple[PivotAggregation, ...]


@dataclass(frozen=True)
class PivotItemInfo:
    """One pivot-field item, as read by :meth:`Workbook.pivot_field_item_at`.

    ``name`` is the item's own label (empty for an item bound only by cache
    index); ``cache_index`` indexes the bound cache field's shared items and
    is ``-1`` for an item bound by label only.
    """

    name: str
    cache_index: int
    visible: bool


@dataclass(frozen=True)
class PivotStyleInfo:
    """A pivot table's style, as read by :meth:`Workbook.pivot_style_info`.

    ``present`` is false when the definition has no style element; ``name``
    is empty when the element carries no style name.
    """

    present: bool
    name: str
    show_row_headers: bool
    show_col_headers: bool
    show_row_stripes: bool
    show_col_stripes: bool
    show_last_column: bool


@dataclass
class PivotDataFieldSpec:
    """Argument shape for ``pivot_data_field_add`` / ``pivot_data_field_set``.

    An empty or ``None`` ``name`` asks the engine to name the data field from
    the workbook profile's pivot wording (``"Sum of Sales"`` under en-US,
    ``"合計 / Sales"`` under ja-JP); that needs ``field_index`` to be in range.
    ``show_as_base_field`` / ``show_as_base_item`` use ``-1`` for "unset".
    """

    name: Optional[str]
    field_index: int
    aggregation: "PivotAggregation | int" = PivotAggregation.SUM
    number_format: str = ""
    show_as: "PivotShowValuesAs | int" = PivotShowValuesAs.NORMAL
    show_as_base_field: int = -1
    show_as_base_item: int = -1


@dataclass
class PivotFilterSpec:
    """Argument shape for :meth:`Workbook.pivot_filter_add`."""

    axis: "PivotAxis | int"
    field_name: str
    type: "PivotFilterType | int"
    value_kind: "PivotFilterValueKind | int" = PivotFilterValueKind.NONE
    value_int: int = 0
    value_double: float = 0.0
    value_text: str = ""
    value_high_kind: "PivotFilterValueKind | int" = PivotFilterValueKind.NONE
    value_high_int: int = 0
    value_high_double: float = 0.0
    data_field_index: int = 0


def _cell_xf_fields(record: CellXf) -> Dict[str, object]:
    """Project a :class:`CellXf` onto the ``fm_cell_xf`` field map.

    Shared by the direct ``<xf>`` writer and the named-style ``<xf>``
    writer, which pack the same struct, so the presence-flag defaulting
    lives in one place.
    """
    return {
        "font_index": _uint(record.font_index, "font_index"),
        "fill_index": _uint(record.fill_index, "fill_index"),
        "border_index": _uint(record.border_index, "border_index"),
        "num_fmt_id": _uint(record.num_fmt_id, "num_fmt_id", 16),
        "horizontal_align": _uint(record.horizontal_align, "horizontal_align", 8),
        "vertical_align": _uint(record.vertical_align, "vertical_align", 8),
        "wrap_text": 1 if record.wrap_text else 0,
        "has_alignment": 1
        if (record.has_alignment if record.has_alignment is not None else _cell_xf_has_alignment(record))
        else 0,
        "justify_last_line": 1 if record.justify_last_line else 0,
        "xf_id": _uint(record.xf_id, "xf_id"),
        "has_text_rotation": 1 if record.text_rotation is not None else 0,
        "text_rotation": _uint(record.text_rotation or 0, "text_rotation"),
        "has_indent": 1 if record.indent is not None else 0,
        "indent": _uint(record.indent or 0, "indent"),
        "has_relative_indent": 1 if record.relative_indent is not None else 0,
        "relative_indent": _sint(record.relative_indent or 0, "relative_indent"),
        "has_shrink_to_fit": 1 if record.shrink_to_fit is not None else 0,
        "shrink_to_fit": 1 if record.shrink_to_fit else 0,
        "has_reading_order": 1 if record.reading_order is not None else 0,
        "reading_order": _uint(record.reading_order or 0, "reading_order"),
        "has_horizontal_align": 1
        if (record.has_horizontal_align if record.has_horizontal_align is not None else record.horizontal_align != 0)
        else 0,
        "has_vertical_align": 1
        if (record.has_vertical_align if record.has_vertical_align is not None else record.vertical_align != 2)
        else 0,
        "has_wrap_text": 1 if (record.has_wrap_text if record.has_wrap_text is not None else record.wrap_text) else 0,
        "has_justify_last_line": 1
        if (record.has_justify_last_line if record.has_justify_last_line is not None else record.justify_last_line)
        else 0,
        "apply_number_format": 1 if record.apply_number_format else 0,
        "apply_font": 1 if record.apply_font else 0,
        "apply_fill": 1 if record.apply_fill else 0,
        "apply_border": 1 if record.apply_border else 0,
        "apply_alignment": 1 if record.apply_alignment else 0,
        "apply_protection": 1 if record.apply_protection else 0,
        "quote_prefix": 1 if record.quote_prefix else 0,
        "has_protection": 1 if record.has_protection else 0,
        "locked": 1 if record.locked else 0,
        "hidden": 1 if record.hidden else 0,
    }


# ---------------------------------------------------------------------------
# Workbook handle
# ---------------------------------------------------------------------------


def _tristate(flag: Optional[bool]) -> int:
    """Map an optional flag to the ABI's preserve / clear / set encoding.

    ``None`` becomes ``-1`` (leave the stored flag alone); ``False`` and
    ``True`` become ``0`` and ``1``.
    """
    if flag is None:
        return -1
    return 1 if flag else 0


class _ArgScope:
    """Owns every WASM allocation made to marshal one call's arguments.

    Enter it before the first allocation; every block allocated through it,
    packers included, is freed when the ``with`` block exits, normally or by
    an exception. It is also the one place a Python string becomes a C
    string pointer: ``None`` is NULL and ``""`` is a non-NULL empty string,
    except through :meth:`nonempty_cstr`, for a slot whose C contract reads
    an empty string as absent.
    """

    __slots__ = ("_ptrs",)

    def __init__(self) -> None:
        self._ptrs: List[int] = []

    def __enter__(self) -> "_ArgScope":
        return self

    def __exit__(self, *exc_info: object) -> None:
        ptrs, self._ptrs = self._ptrs, []
        for ptr in ptrs:
            LIB.free(ptr)

    def _take(self, size: int) -> int:
        ptr = LIB.alloc(size)
        if ptr:
            self._ptrs.append(ptr)
        return ptr

    def alloc(self, size: int) -> int:
        """Allocate ``size`` zeroed bytes; 0 when ``size`` is 0."""
        ptr = self._take(size)
        if ptr:
            LIB.write_bytes(ptr, b"\x00" * size)
        return ptr

    def out_ptr(self) -> int:
        """Allocate a zeroed 4-byte slot for an out-i32 / out-pointer."""
        return self.alloc(4)

    def out_u64(self) -> int:
        """Allocate a zeroed 8-byte slot for an out-uint64."""
        return self.alloc(8)

    def struct(self, layout: S.Struct) -> int:
        """Allocate one zeroed ``layout`` struct."""
        return self.alloc(layout.size)

    def struct_array(self, layout: S.Struct, count: int) -> int:
        """Allocate a zeroed contiguous array of ``count`` ``layout`` structs."""
        return self.alloc(layout.size * count)

    def value_array(self, count: int) -> int:
        """Allocate a zeroed contiguous array of ``count`` ``fm_value_t`` slots."""
        return self.alloc(fm_value_t_size * count)

    def buffer(self, data: bytes) -> int:
        """Copy ``data`` into WASM memory; 0 when it is empty."""
        ptr = self._take(len(data))
        if ptr:
            LIB.write_bytes(ptr, data)
        return ptr

    def cstr(self, value: str) -> int:
        """Copy ``value`` as a NUL-terminated UTF-8 string, ``""`` included.

        A lone surrogate becomes U+FFFD and a surrogate pair its code point,
        as the JavaScript bindings convert a UTF-16 string.
        """
        if not isinstance(value, str):
            raise TypeError(f"expected str, got {type(value).__name__}")
        try:
            encoded = value.encode("utf-8")
        except UnicodeEncodeError:
            utf16 = value.encode("utf-16-le", "surrogatepass")
            encoded = utf16.decode("utf-16-le", "replace").encode("utf-8")
        return self.buffer(encoded + b"\x00")

    def opt_cstr(self, value: Optional[str]) -> int:
        """NULL for ``None``; otherwise :meth:`cstr`."""
        return 0 if value is None else self.cstr(value)

    def nonempty_cstr(self, value: Optional[str]) -> int:
        """NULL for ``None`` and ``""``; otherwise :meth:`cstr`."""
        return 0 if value is None or value == "" else self.cstr(value)


def _read_image_info(ptr: int) -> ImageInfo:
    """Decode an ``fm_image_info`` block."""
    d = S.IMAGE_INFO.unpack(LIB, ptr)
    return ImageInfo(format=d["format"], px_width=d["px_width"], px_height=d["px_height"])


def _read_count(fn, *args, default_op: str = "count") -> int:
    """Call a ``(... , out_count*)`` ABI function and return the count."""
    with _ArgScope() as scope:
        out = scope.out_ptr()
        _check(fn(*args, out), getattr(fn, "__name__", default_op))
        return LIB.read_u32(out)


def _read_cstr_out(fn, *args, default_op: str = "text") -> str:
    """Call a ``(..., out_cstr*)`` ABI function and decode its result."""
    with _ArgScope() as scope:
        out = scope.out_ptr()
        _check(fn(*args, out), getattr(fn, "__name__", default_op))
        return LIB.read_cstr(LIB.read_u32(out))


_SHAPE_FIELDS = {
    "name": 0x1,
    "prst": 0x2,
    "anchor": 0x4,
    "text": 0x8,
    "text_box": 0x10,
    "fill": 0x20,
    "line": 0x40,
    "line_width": 0x80,
    "rotation": 0x100,
    "hidden": 0x200,
}


def _pack_shape(
    scope: _ArgScope,
    name,
    prst,
    text,
    text_box,
    anchor_kind,
    edit_as,
    from_row,
    from_col,
    from_row_off,
    from_col_off,
    to_row,
    to_col,
    to_row_off,
    to_col_off,
    cx,
    cy,
    fill_kind,
    fill_rgb,
    line_kind,
    line_rgb,
    line_width_emu,
    rotation,
    hidden,
) -> int:
    """Build an ``fm_shape`` input block; a ``None`` argument is a field left out of the mask."""
    ptr = scope.struct_array(S.SHAPE, 1)
    mask = 0
    values: Dict[str, int] = {}
    if text_box is not None:
        mask |= _SHAPE_FIELDS["text_box"]
        values["text_box"] = 1 if text_box else 0
    if anchor_kind is not None:
        mask |= _SHAPE_FIELDS["anchor"]
        values.update(
            anchor_kind=_sint(anchor_kind, "anchor_kind"),
            edit_as=_sint(edit_as, "edit_as"),
            from_row=_uint(from_row, "from_row"),
            from_col=_uint(from_col, "from_col"),
            from_row_off=_sint(from_row_off, "from_row_off", 64),
            from_col_off=_sint(from_col_off, "from_col_off", 64),
            to_row=_uint(to_row, "to_row"),
            to_col=_uint(to_col, "to_col"),
            to_row_off=_sint(to_row_off, "to_row_off", 64),
            to_col_off=_sint(to_col_off, "to_col_off", 64),
            cx=_sint(cx, "cx", 64),
            cy=_sint(cy, "cy", 64),
        )
    if fill_kind is not None:
        mask |= _SHAPE_FIELDS["fill"]
        values.update(fill_kind=_sint(fill_kind, "fill_kind"), fill_rgb=_uint(fill_rgb, "fill_rgb"))
    if line_kind is not None:
        mask |= _SHAPE_FIELDS["line"]
        values.update(line_kind=_sint(line_kind, "line_kind"), line_rgb=_uint(line_rgb, "line_rgb"))
    if line_width_emu is not None:
        mask |= _SHAPE_FIELDS["line_width"]
        values["line_width_emu"] = _sint(line_width_emu, "line_width_emu", 64)
    if rotation is not None:
        mask |= _SHAPE_FIELDS["rotation"]
        values["rotation"] = _sint(rotation, "rotation")
    if hidden is not None:
        mask |= _SHAPE_FIELDS["hidden"]
        values["hidden"] = 1 if hidden else 0
    for key, text_value in (("name", name), ("prst", prst), ("text", text)):
        if text_value is not None:
            mask |= _SHAPE_FIELDS[key]
            S.write_str_field(LIB, ptr, S.SHAPE, key, text_value, scope, allow_empty=True)
    values["fields"] = mask
    # `write_str_field` patched the pointer slots in place; pack the scalars around them.
    raw = bytearray(LIB.read_bytes(ptr, S.SHAPE.size))
    S.SHAPE.pack_into(raw, 0, values)
    LIB.write_bytes(ptr, bytes(raw))
    return ptr


_SLICER_FIELDS = {
    "name": 0x1,
    "caption": 0x2,
    "style": 0x4,
    "column_count": 0x8,
    "row_height": 0x10,
    "anchor": 0x20,
    "sort_order": 0x40,
    "cross_filter": 0x80,
}


def _pack_slicer(
    scope: _ArgScope,
    name,
    caption,
    style,
    column_count,
    row_height,
    anchor,
    sort_order,
    cross_filter,
) -> int:
    """Build an ``fm_slicer`` input block; a ``None`` argument is a field left out of the mask.

    ``anchor`` is ``None`` or ``(from_row, from_col, to_row, to_col)`` with optional trailing
    ``(from_row_off, from_col_off, to_row_off, to_col_off)``.
    """
    ptr = scope.struct_array(S.SLICER, 1)
    mask = 0
    values: Dict[str, int] = {}
    if column_count is not None:
        mask |= _SLICER_FIELDS["column_count"]
        values["column_count"] = _uint(column_count, "column_count")
    if row_height is not None:
        mask |= _SLICER_FIELDS["row_height"]
        values["row_height"] = _sint(row_height, "row_height", 64)
    if anchor is not None:
        mask |= _SLICER_FIELDS["anchor"]
        corner, offsets = tuple(anchor[:4]), tuple(anchor[4:]) or (0, 0, 0, 0)
        if len(corner) != 4 or len(offsets) != 4:
            raise TypeError("anchor must be (from_row, from_col, to_row, to_col) plus optional EMU offsets")
        values.update(
            from_row=_uint(corner[0], "from_row"),
            from_col=_uint(corner[1], "from_col"),
            to_row=_uint(corner[2], "to_row"),
            to_col=_uint(corner[3], "to_col"),
            from_row_off=_sint(offsets[0], "from_row_off", 64),
            from_col_off=_sint(offsets[1], "from_col_off", 64),
            to_row_off=_sint(offsets[2], "to_row_off", 64),
            to_col_off=_sint(offsets[3], "to_col_off", 64),
        )
    if sort_order is not None:
        mask |= _SLICER_FIELDS["sort_order"]
        values["sort_order"] = _sint(sort_order, "sort_order")
    if cross_filter is not None:
        mask |= _SLICER_FIELDS["cross_filter"]
        values["cross_filter"] = _sint(cross_filter, "cross_filter")
    for key, text_value in (("name", name), ("caption", caption), ("style", style)):
        if text_value is not None:
            mask |= _SLICER_FIELDS[key]
            S.write_str_field(LIB, ptr, S.SLICER, key, text_value, scope, allow_empty=True)
    values["fields"] = mask
    # `write_str_field` patched the pointer slots in place; pack the scalars around them.
    raw = bytearray(LIB.read_bytes(ptr, S.SLICER.size))
    S.SLICER.pack_into(raw, 0, values)
    LIB.write_bytes(ptr, bytes(raw))
    return ptr


_SPARKLINE_COLORS = (
    "color_series",
    "color_negative",
    "color_axis",
    "color_markers",
    "color_first",
    "color_last",
    "color_high",
    "color_low",
)


def _pack_sparkline_group(scope: _ArgScope, group: SparklineGroup) -> int:
    """Build an ``fm_sparkline_group`` input block from ``group`` (``sparklines`` is passed separately)."""
    ptr = scope.struct_array(S.SPARKLINE_GROUP, 1)
    S.SPARKLINE_GROUP.pack(
        LIB,
        ptr,
        {
            "type": _sint(group.type, "type"),
            "markers": 1 if group.markers else 0,
            "high": 1 if group.high else 0,
            "low": 1 if group.low else 0,
            "first": 1 if group.first else 0,
            "last": 1 if group.last else 0,
            "negative": 1 if group.negative else 0,
            "display_x_axis": 1 if group.display_x_axis else 0,
            "display_hidden": 1 if group.display_hidden else 0,
            "min_axis_type": _sint(group.min_axis_type, "min_axis_type"),
            "max_axis_type": _sint(group.max_axis_type, "max_axis_type"),
            "has_manual_min": 0 if group.manual_min is None else 1,
            "has_manual_max": 0 if group.manual_max is None else 1,
            "manual_min": float(group.manual_min or 0.0),
            "manual_max": float(group.manual_max or 0.0),
            "date_axis": 1 if group.date_axis else 0,
            "line_weight": float(group.line_weight),
            "empty_cells_as": _sint(group.empty_cells_as, "empty_cells_as"),
        },
    )
    for key in _SPARKLINE_COLORS:
        _pack_color(ptr + S.SPARKLINE_GROUP.offsets[key][1], getattr(group, key))
    S.write_str_field(LIB, ptr, S.SPARKLINE_GROUP, "date_axis_ref", group.date_axis_ref, scope)
    return ptr


def _pack_sparklines(scope: _ArgScope, sparklines: Sequence[Sparkline]) -> int:
    """Build an ``fm_sparkline`` array; an empty list still gets a valid block (the core rejects a zero count)."""
    ptr = scope.struct_array(S.SPARKLINE, max(len(sparklines), 1))
    for i, item in enumerate(sparklines):
        base = ptr + i * S.SPARKLINE.size
        S.write_str_field(LIB, base, S.SPARKLINE, "formula", item.formula, scope)
        S.write_str_field(LIB, base, S.SPARKLINE, "location", item.location, scope)
    return ptr


def _image_anchor_fields(
    anchor_kind,
    edit_as,
    row,
    col,
    row_off_emu,
    col_off_emu,
    width_emu,
    height_emu,
) -> Dict[str, int]:
    """Convert the shared image-anchor fields to their ABI representation."""
    return {
        "anchor_kind": _sint(anchor_kind, "anchor_kind"),
        "edit_as": _sint(edit_as, "edit_as"),
        "row": _uint(row, "row"),
        "col": _uint(col, "col"),
        "row_off_emu": _sint(row_off_emu, "row_off_emu", 64),
        "col_off_emu": _sint(col_off_emu, "col_off_emu", 64),
        "width_emu": _sint(width_emu, "width_emu", 64),
        "height_emu": _sint(height_emu, "height_emu", 64),
    }


# ---------------------------------------------------------------------------
# Chart marshalling
# ---------------------------------------------------------------------------

# `fm_chart_patch_op_t`: a zeroed patch field keeps, so only CLEAR and SET are written.
_PATCH_CLEAR = 1
_PATCH_SET = 2

_CHART_AXIS_POSITIONS = {0: "b", 1: "t", 2: "l", 3: "r"}
_CHART_BAR_DIRECTIONS = {1: "col", 2: "bar"}
_CHART_SOURCE_KINDS = {0: "none", 1: "ref", 2: "literal"}
# `fm_chart_role_t` order, which is also the order of `fm_chart_data_series_t.range_count`.
_CHART_ROLES = ("name", "categories", "values", "x", "y", "size")

# (patch key, C field, scalar kind) per patch struct.
_FILL_PATCH_SPEC = (("color", "color", "u32"), ("transparency", "transparency_pct", "f64"))
_LINE_PATCH_SPEC = (
    ("color", "color", "u32"),
    ("transparency", "transparency_pct", "f64"),
    ("width_pt", "width_pt", "f64"),
    ("dash", "dash", "i32"),
    ("none", "none", "bool"),
)
_MARKER_PATCH_SPEC = (("symbol", "symbol", "i32"), ("size", "size", "f64"))
_LABELS_PATCH_SPEC = (
    ("show_value", "show_value", "bool"),
    ("show_category", "show_category", "bool"),
    ("show_series", "show_series", "bool"),
    ("show_percent", "show_percent", "bool"),
    ("show_legend_key", "show_legend_key", "bool"),
    ("separator", "separator", "str"),
    ("position", "position", "i32"),
    ("number_format", "number_format", "str"),
    ("font_color", "font_color", "u32"),
    ("font_size_pt", "font_size_pt", "f64"),
)
_PLOT_PATCH_SPEC = (
    ("gap_width", "gap_width", "u32"),
    ("overlap", "overlap", "i32"),
    ("first_slice_angle", "first_slice_angle", "u32"),
    ("vary_colors", "vary_colors", "bool"),
    ("hole_size", "hole_size", "u32"),
)
_AXIS_PATCH_SPEC = (
    ("visible", "visible", "bool"),
    ("title", "title", "title"),
    ("min", "min", "f64"),
    ("max", "max", "f64"),
    ("major_unit", "major_unit", "f64"),
    ("number_format", "number_format", "str"),
    ("major_gridlines", "major_gridlines", "bool"),
    ("reversed", "reversed", "bool"),
    ("log_base", "log_base", "f64"),
    ("crosses", "crosses", "i32"),
    ("tick_label_position", "tick_label_pos", "str"),
)
# Patch fields whose `_op` companion drops the unit suffix of the value field.
_PATCH_OP_PREFIX = {"transparency_pct": "transparency", "width_pt": "width", "font_size_pt": "font_size"}
_PREVIEW_OVERRIDE_SPEC = (
    ("direction", "direction", "i32"),
    ("header_row", "header_row", "bool"),
    ("header_column", "header_column", "bool"),
    ("blanks_as", "blanks_as", "i32"),
    ("plot_visible_only", "plot_vis_only", "bool"),
)
_SERIES_REF_KEYS = ("name", "categories", "values", "x", "y", "size")


def _enum(cls, value: int):
    """Wrap ``value`` in ``cls``, keeping the raw integer for a member the binding does not know."""
    try:
        return cls(value)
    except ValueError:
        return value


def _nan_none(value: float) -> Optional[float]:
    return None if value != value else value


def _tri(value: int) -> Optional[bool]:
    """Decode an ``fm_chart_tri_t`` (absent / false / true)."""
    return None if value == 0 else value == 2


def _opt_cstr(ptr: int) -> Optional[str]:
    return LIB.read_cstr(ptr) if ptr else None


def _read_struct(fn, layout: S.Struct, *args) -> Dict[str, object]:
    """Call a ``(..., out_struct*)`` ABI function and decode the struct it fills."""
    with _ArgScope() as scope:
        ptr = scope.struct(layout)
        _check(fn(*args, ptr), getattr(fn, "__name__", layout.name))
        return layout.unpack(LIB, ptr)


def _read_chart_title(d: Dict[str, object]) -> ChartTitleInfo:
    return ChartTitleInfo(
        kind=_enum(ChartTitleKind, d["kind"]), text=LIB.read_cstr(d["text"]), formula=LIB.read_cstr(d["formula"])
    )


def _read_chart_fill(d: Dict[str, object]) -> ChartFillInfo:
    return ChartFillInfo(color=d["color"] if d["has_color"] else None, transparency=_nan_none(d["transparency_pct"]))


def _read_chart_line(d: Dict[str, object]) -> ChartLineInfo:
    return ChartLineInfo(
        color=d["color"] if d["has_color"] else None,
        transparency=_nan_none(d["transparency_pct"]),
        width_pt=_nan_none(d["width_pt"]),
        dash=_enum(ChartLineDash, d["dash"]) if d["has_dash"] else None,
        none=bool(d["none"]),
    )


def _read_chart_marker(d: Dict[str, object]) -> ChartMarkerInfo:
    return ChartMarkerInfo(
        symbol=_enum(ChartMarkerSymbol, d["symbol"]),
        size=d["size"] if d["has_size"] else None,
        fill=_read_chart_fill(d["fill"]),
        line=_read_chart_line(d["line"]),
    )


def _read_chart_labels(d: Dict[str, object]) -> ChartLabelsInfo:
    return ChartLabelsInfo(
        show_value=bool(d["show_value"]),
        show_category=bool(d["show_category"]),
        show_series=bool(d["show_series"]),
        show_percent=bool(d["show_percent"]),
        show_legend_key=bool(d["show_legend_key"]),
        separator=_opt_cstr(d["separator"]),
        position=_enum(ChartLabelPosition, d["position"]) if d["has_position"] else None,
        number_format=_opt_cstr(d["number_format"]),
        source_linked=bool(d["source_linked"]),
        font_color=d["font_color"] if d["has_font_color"] else None,
        font_size_pt=_nan_none(d["font_size_pt"]),
        deleted=bool(d["deleted"]),
    )


def _read_chart_data_source(chart: int, plot: int, series: int, role: int, d: Dict[str, object]) -> ChartDataSource:
    kind = _CHART_SOURCE_KINDS.get(d["kind"], "none")
    literal: List[Union[float, str]] = []
    if kind == "literal":
        for i in range(d["literal_count"]):
            point = _read_struct(LIB.fm_chart_series_literal_at, S.CHART_LITERAL, chart, plot, series, role, i)
            literal.append(LIB.read_cstr(point["text"]) if point["is_text"] else point["number"])
    return ChartDataSource(kind=kind, formula=LIB.read_cstr(d["formula"]), literal=literal)


def _read_chart_series(chart: int, plot: int, series: int) -> ChartSeriesInfo:
    d = _read_struct(LIB.fm_chart_series_at, S.CHART_SERIES, chart, plot, series)
    sources = {key: _read_chart_data_source(chart, plot, series, role, d[key]) for role, key in enumerate(_CHART_ROLES)}
    points: List[ChartPointInfo] = []
    for i in range(d["point_count"]):
        p = _read_struct(LIB.fm_chart_series_point_at, S.CHART_POINT, chart, plot, series, i)
        points.append(
            ChartPointInfo(
                idx=p["idx"],
                fill=_read_chart_fill(p["fill"]),
                line=_read_chart_line(p["line"]),
                marker=_read_chart_marker(p["marker"]) if p["has_marker"] else None,
            )
        )
    return ChartSeriesInfo(
        idx=d["idx"],
        order=d["order"],
        filtered=bool(d["filtered"]),
        fill=_read_chart_fill(d["fill"]),
        line=_read_chart_line(d["line"]),
        marker=_read_chart_marker(d["marker"]) if d["has_marker"] else None,
        smooth=_tri(d["smooth"]),
        points=points,
        labels=_read_chart_labels(d["labels"]) if d["has_labels"] else None,
        **sources,
    )


def _read_chart_plot(chart: int, plot: int) -> ChartPlotInfo:
    d = _read_struct(LIB.fm_chart_plot_at, S.CHART_PLOT, chart, plot)
    return ChartPlotInfo(
        type=_enum(ChartPlotType, d["type"]),
        chartex_layout=LIB.read_cstr(d["chartex_layout"]) or None,
        bar_direction=_CHART_BAR_DIRECTIONS.get(d["bar_dir"]),
        grouping=_enum(ChartGrouping, d["grouping"]) if d["has_grouping"] else None,
        vary_colors=_tri(d["vary_colors"]) is True,
        gap_width=d["gap_width"] if d["has_gap_width"] else None,
        overlap=d["overlap"] if d["has_overlap"] else None,
        hole_size=d["hole_size"] if d["has_hole_size"] else None,
        first_slice_angle=d["first_slice_angle"] if d["has_first_slice_angle"] else None,
        axis_ids=[
            _read_count(LIB.fm_chart_plot_axis_id_at, chart, _uint(plot, "plot"), _uint(i, "idx"))
            for i in range(d["axis_id_count"])
        ],
        series=[_read_chart_series(chart, plot, i) for i in range(d["series_count"])],
    )


def _read_chart_axis(chart: int, idx: int) -> ChartAxisInfo:
    d = _read_struct(LIB.fm_chart_axis_at, S.CHART_AXIS, chart, idx)
    return ChartAxisInfo(
        id=d["id"],
        kind=_enum(ChartAxisKind, d["kind"]),
        position=_CHART_AXIS_POSITIONS.get(d["position"], "b"),
        deleted=bool(d["deleted"]),
        cross_axis=d["cross_axis"],
        crosses=_enum(ChartAxisCrosses, d["crosses"]),
        crosses_at=_nan_none(d["crosses_at"]),
        min=_nan_none(d["min"]),
        max=_nan_none(d["max"]),
        major_unit=_nan_none(d["major_unit"]),
        minor_unit=_nan_none(d["minor_unit"]),
        log_base=_nan_none(d["log_base"]),
        reversed=bool(d["reversed"]),
        number_format=_opt_cstr(d["number_format"]),
        source_linked=bool(d["source_linked"]),
        title=_read_chart_title(d["title"]),
        major_gridlines=bool(d["major_gridlines"]),
        minor_gridlines=bool(d["minor_gridlines"]),
        tick_label_position=_opt_cstr(d["tick_label_pos"]),
    )


def _read_chart(chart: int) -> ChartInfo:
    """Decode an open ``fm_chart_t`` handle."""
    d = _read_struct(LIB.fm_chart_info, S.CHART_INFO, chart)
    source = None
    if d["source_range"]:
        source = ChartSourceInfo(
            range=LIB.read_cstr(d["source_range"]),
            direction=_enum(ChartSeriesDirection, d["source_direction"]),
            header_row=bool(d["source_header_row"]),
            header_column=bool(d["source_header_column"]),
        )
    return ChartInfo(
        object_id=d["object_id"],
        name=LIB.read_cstr(d["name"]),
        description=LIB.read_cstr(d["descr"]),
        is_chartex=bool(d["is_chartex"]),
        is_pivot_chart=bool(d["is_pivot_chart"]),
        on_chartsheet=bool(d["on_chartsheet"]),
        title=_read_chart_title(d["title"]),
        auto_title_deleted=_tri(d["auto_title_deleted"]),
        legend=ChartLegendInfo(
            position=_enum(ChartLegendPosition, d["legend_position"]),
            overlay=bool(d["legend_overlay"]),
            hidden_series=[
                _read_count(LIB.fm_chart_legend_hidden_at, chart, _uint(i, "idx"))
                for i in range(d["legend_hidden_count"])
            ],
        ),
        blanks_as=_enum(ChartBlanksAs, d["blanks_as"]),
        plot_visible_only=_tri(d["plot_vis_only"]),
        date1904=bool(d["date1904"]),
        style=d["style"] if d["has_style"] else None,
        plots=[_read_chart_plot(chart, i) for i in range(d["plot_count"])],
        axes=[_read_chart_axis(chart, i) for i in range(d["axis_count"])],
        hidden_categories=[
            _read_count(LIB.fm_chart_hidden_category_at, chart, _uint(i, "idx"))
            for i in range(d["hidden_category_count"])
        ],
        source=source,
    )


def _read_chart_data_array(ptr: int, count: int, fmt: str, width: int) -> Optional[List]:
    """Copy ``count`` values of struct format ``fmt`` out of a handle-owned array; ``None`` for a NULL array."""
    if not ptr:
        return None
    if count == 0:
        return []
    return list(struct.unpack(f"<{count}{fmt}", LIB.read_bytes(ptr, count * width)))


def _read_chart_data(data: int) -> ChartData:
    """Decode an open ``fm_chart_data_t`` handle."""
    info = _read_struct(LIB.fm_chart_data_info, S.CHART_DATA_INFO, data)
    labels: List[str] = []
    values: List[float] = []
    with _ArgScope() as scope:
        label_out = scope.out_ptr()
        value_out = scope.alloc(8)
        for i in range(info["category_label_count"]):
            _check(
                LIB.fm_chart_data_category_at(data, _uint(i, "idx"), label_out, value_out), "fm_chart_data_category_at"
            )
            labels.append(LIB.read_cstr(LIB.read_u32(label_out)))
            values.append(LIB.read_f64(value_out))
        levels: List[List[str]] = []
        for level in range(info["category_level_count"]):
            size = _read_count(LIB.fm_chart_data_category_level_size, data, _uint(level, "level"))
            names: List[str] = []
            for i in range(size):
                _check(
                    LIB.fm_chart_data_category_level_at(data, _uint(level, "level"), _uint(i, "idx"), label_out),
                    "fm_chart_data_category_level_at",
                )
                names.append(LIB.read_cstr(LIB.read_u32(label_out)))
            levels.append(names)

    series: List[ChartDataSeries] = []
    for i in range(info["series_count"]):
        s = _read_struct(LIB.fm_chart_data_series_at, S.CHART_DATA_SERIES, data, i)
        points = _read_struct(LIB.fm_chart_data_series_points, S.CHART_DATA_POINTS, data, i)
        n = points["count"]
        ranges = ChartSeriesRanges()
        for role, key in enumerate(_CHART_ROLES):
            for j in range(s["range_count"][role]):
                r = _read_struct(LIB.fm_chart_data_range_at, S.CHART_SHEET_RANGE, data, i, role, j)
                getattr(ranges, key).append(ChartSheetRange(**r))
        series.append(
            ChartDataSeries(
                plot_index=s["plot_index"],
                idx=s["idx"],
                name=_opt_cstr(s["name"]),
                format_code=LIB.read_cstr(s["format_code"]),
                x_format_code=LIB.read_cstr(s["x_format_code"]),
                filtered=bool(s["filtered"]),
                values=_read_chart_data_array(points["values"], n, "d", 8) or [],
                states=_read_chart_data_array(points["states"], n, "B", 1) or [],
                x=_read_chart_data_array(points["x"], n, "d", 8),
                sizes=_read_chart_data_array(points["sizes"], n, "d", 8) if s["has_sizes"] else None,
                ranges=ranges,
            )
        )
    return ChartData(
        domain="xy" if info["is_xy"] else "category",
        point_count=info["point_count"],
        categories=ChartCategories(
            labels=labels,
            levels=levels,
            values=values if info["category_value_count"] else None,
            format_code=LIB.read_cstr(info["category_format_code"]),
            generated=bool(info["categories_generated"]),
        ),
        series=series,
        title_text=_opt_cstr(info["title_text"]),
        axis_title_texts=[
            ChartAxisTitleText(axis_id=t["axis_id"], text=LIB.read_cstr(t["text"]))
            for t in (
                _read_struct(LIB.fm_chart_data_axis_title_at, S.CHART_AXIS_TITLE_TEXT, data, i)
                for i in range(info["axis_title_count"])
            )
        ],
        unresolved=[
            ChartUnresolved(series_idx=u["series_idx"], source=LIB.read_cstr(u["source"]), axis_id=u["axis_id"])
            for u in (
                _read_struct(LIB.fm_chart_data_unresolved_at, S.CHART_UNRESOLVED, data, i)
                for i in range(info["unresolved_count"])
            )
        ],
    )


def _title_fields(title: Union[str, ChartTitleInfo], scope: _ArgScope) -> Dict[str, object]:
    """Encode a title given as its text or as a :class:`ChartTitleInfo` (``fm_chart_title_t``)."""
    if isinstance(title, ChartTitleInfo):
        return {
            "kind": _sint(title.kind, "kind"),
            "text": scope.cstr(title.text),
            "formula": scope.cstr(title.formula),
        }
    return {"kind": 1, "text": scope.cstr(title)}


def _patch_scalar(kind: str, value, key: str, scope: _ArgScope):
    if kind == "u32":
        return _uint(value, key)
    if kind == "i32":
        return _sint(value, key)
    if kind == "bool":
        return 1 if value else 0
    if kind == "f64":
        return float(value)
    if kind == "title":
        return _title_fields(value, scope)
    return scope.cstr(value)


def _check_patch_keys(patch: Mapping, spec: Sequence, extra: Sequence[str], what: str) -> None:
    unknown = set(patch) - {key for key, _, _ in spec} - set(extra)
    if unknown:
        raise TypeError(f"formulon: unknown {what} key(s): {sorted(unknown)}")


def _encode_patch(
    spec: Sequence, patch: Mapping, extra: Sequence[str], what: str, scope: _ArgScope
) -> Dict[str, object]:
    """Encode the ``(op, value)`` pair of every ``spec`` key present in ``patch``.

    An absent key stays zero (keep), ``None`` writes the clear op and any other
    value the set op beside it.
    """
    _check_patch_keys(patch, spec, extra, what)
    out: Dict[str, object] = {}
    for key, field_name, kind in spec:
        if key not in patch:
            continue
        value = patch[key]
        op_field = _PATCH_OP_PREFIX.get(field_name, field_name) + "_op"
        if value is None:
            out[op_field] = _PATCH_CLEAR
        else:
            out[op_field] = _PATCH_SET
            out[field_name] = _patch_scalar(kind, value, key, scope)
    return out


def _encode_fill_patch(patch: Optional[Mapping], scope: _ArgScope) -> Dict[str, object]:
    return _encode_patch(_FILL_PATCH_SPEC, patch or {}, (), "fill patch", scope)


def _encode_line_patch(patch: Optional[Mapping], scope: _ArgScope) -> Dict[str, object]:
    return _encode_patch(_LINE_PATCH_SPEC, patch or {}, (), "line patch", scope)


def _encode_marker_patch(patch: Mapping, scope: _ArgScope) -> Dict[str, object]:
    out = _encode_patch(_MARKER_PATCH_SPEC, patch, ("fill", "line"), "marker patch", scope)
    out["fill"] = _encode_fill_patch(patch.get("fill"), scope)
    out["line"] = _encode_line_patch(patch.get("line"), scope)
    return out


def _encode_labels_patch(patch: Mapping, scope: _ArgScope) -> Dict[str, object]:
    return _encode_patch(_LABELS_PATCH_SPEC, patch, (), "labels patch", scope)


def _encode_optional_patch(out: Dict[str, object], key: str, patch: Mapping, encode, scope: _ArgScope) -> None:
    """Encode a nested patch that ``None`` removes (``<key>_op`` beside the nested struct)."""
    if key not in patch:
        return
    if patch[key] is None:
        out[key + "_op"] = _PATCH_CLEAR
    else:
        out[key + "_op"] = _PATCH_SET
        out[key] = encode(patch[key], scope)


def _encode_series_patch(patch: Mapping, scope: _ArgScope) -> Dict[str, object]:
    unknown = set(patch) - set(_SERIES_REF_KEYS) - {"fill", "line", "marker", "smooth", "labels"}
    if unknown:
        raise TypeError(f"formulon: unknown series patch key(s): {sorted(unknown)}")
    out: Dict[str, object] = {key: scope.cstr(patch[key]) for key in _SERIES_REF_KEYS if key in patch}
    out["fill"] = _encode_fill_patch(patch.get("fill"), scope)
    out["line"] = _encode_line_patch(patch.get("line"), scope)
    _encode_optional_patch(out, "marker", patch, _encode_marker_patch, scope)
    _encode_optional_patch(out, "labels", patch, _encode_labels_patch, scope)
    if "smooth" in patch:
        out["smooth_op"] = _PATCH_CLEAR if patch["smooth"] is None else _PATCH_SET
        out["smooth"] = 1 if patch["smooth"] else 0
    return out


def _encode_point_patch(patch: Optional[Mapping], scope: _ArgScope) -> Dict[str, object]:
    patch = patch or {}
    unknown = set(patch) - {"fill", "line", "marker"}
    if unknown:
        raise TypeError(f"formulon: unknown point patch key(s): {sorted(unknown)}")
    out: Dict[str, object] = {
        "fill": _encode_fill_patch(patch.get("fill"), scope),
        "line": _encode_line_patch(patch.get("line"), scope),
    }
    _encode_optional_patch(out, "marker", patch, _encode_marker_patch, scope)
    return out


def _encode_axis_patch(patch: Mapping, scope: _ArgScope) -> Dict[str, object]:
    out = _encode_patch(_AXIS_PATCH_SPEC, patch, ("crosses_at",), "axis patch", scope)
    if "crosses_at" in patch:
        out["crosses_at"] = float(patch["crosses_at"])
    return out


def _tri_flag(flag: Optional[bool]) -> int:
    """Map an optional flag to ``fm_chart_tri_t``: absent, false, true."""
    return 0 if flag is None else (2 if flag else 1)


def _header_mode(flag: Optional[bool]) -> int:
    """Map an optional flag to ``fm_chart_header_mode_t``: ``None`` is Excel's detection."""
    return 0 if flag is None else (1 if flag else 2)


def _id_array(values: Sequence[int], name: str, scope: _ArgScope) -> int:
    """Allocate ``values`` as a ``uint32_t`` array (NULL when empty)."""
    if not values:
        return 0
    ptr = scope.alloc(4 * len(values))
    LIB.write_bytes(ptr, struct.pack(f"<{len(values)}I", *(_uint(v, name) for v in values)))
    return ptr


def _read_owned_buffer(fn, *args, default_op: str = "save") -> bytes:
    """Call a save-style ABI function and copy its owned byte buffer."""
    with _ArgScope() as scope:
        data_ptr = 0
        try:
            out_ptr_ptr = scope.out_ptr()
            out_len_ptr = scope.out_ptr()
            _check(fn(*args, out_ptr_ptr, out_len_ptr), getattr(fn, "__name__", default_op))
            data_ptr = LIB.read_u32(out_ptr_ptr)
            data_len = LIB.read_u32(out_len_ptr)
            if data_len == 0 or data_ptr == 0:
                return b""
            return LIB.read_bytes(data_ptr, data_len)
        finally:
            if data_ptr:
                LIB.fm_buffer_free(data_ptr)


def _pack_merge_array(ranges: Sequence[MergeRange], scope: _ArgScope) -> int:
    """Pack a list of ``MergeRange`` into a contiguous WASM array.

    Returns the array pointer (0 when empty), allocated through ``scope``.
    """
    if not ranges:
        return 0
    size = S.MERGE_RANGE.size
    ptr = scope.alloc(size * len(ranges))
    for i, r in enumerate(ranges):
        _pack_merge_at(ptr + i * size, r)
    return ptr


def _check_value(value: Value) -> Value:
    """Reject anything but a :class:`Value`, whose constructor validated its payload."""
    if not isinstance(value, Value):
        raise TypeError(f"formulon: expected a Value, got {type(value).__name__}")
    return value


def _write_value_input(value: Value, value_ptr: int, scope: _ArgScope) -> None:
    """Write ``value`` as an ``fm_value_t`` at ``value_ptr``.

    ``value`` has passed :func:`_check_value`, so its payload matches its
    kind. A text payload's buffer is allocated through ``scope``.
    """
    payload = b"\x00" * 8
    if value.kind == ValueKind.NUMBER:
        payload = struct.pack("<d", value.number)
    elif value.kind == ValueKind.BOOL:
        payload = struct.pack("<i", 1 if value.boolean else 0) + b"\x00" * 4
    elif value.kind == ValueKind.ERROR:
        payload = struct.pack("<i", value.error_code) + b"\x00" * 4
    elif value.kind == ValueKind.TEXT:
        payload = struct.pack("<I", scope.cstr(value.text)) + b"\x00" * 4
    LIB.write_bytes(value_ptr, struct.pack("<i", value.kind) + b"\x00" * 4 + payload)


def _pack_mentions(mentions: Sequence[Mention], scope: _ArgScope) -> int:
    """Pack ``mentions`` into a contiguous ``fm_mention`` array (0 when empty)."""
    if not mentions:
        return 0
    base = scope.struct_array(S.MENTION, len(mentions))
    for i, m in enumerate(mentions):
        ptr = base + i * S.MENTION.size
        S.MENTION.pack(LIB, ptr, {"start": _uint(m.start, "start"), "length": _uint(m.length, "length")})
        S.write_str_field(LIB, ptr, S.MENTION, "person_id", m.person_id, scope)
        S.write_str_field(LIB, ptr, S.MENTION, "mention_id", m.mention_id, scope)
    return base


def _write_mentions(struct_ptr: int, layout: S.Struct, mentions: Sequence[Mention], scope: _ArgScope) -> None:
    """Store a mention array and its count into the ``mentions`` / ``mention_count`` fields."""
    LIB.write_bytes(struct_ptr + layout.offsets["mentions"][1], struct.pack("<I", _pack_mentions(mentions, scope)))
    LIB.write_bytes(struct_ptr + layout.offsets["mention_count"][1], struct.pack("<I", len(mentions)))


def _decode_mentions(base: int, count: int) -> List[Mention]:
    out: List[Mention] = []
    for i in range(count):
        d = S.MENTION.unpack(LIB, base + i * S.MENTION.size)
        out.append(
            Mention(
                person_id=LIB.read_cstr(d["person_id"]),
                mention_id=LIB.read_cstr(d["mention_id"]),
                start=d["start"],
                length=d["length"],
            )
        )
    return out


def _pack_merge_at(ptr: int, r: MergeRange) -> None:
    S.MERGE_RANGE.pack(
        LIB,
        ptr,
        {
            "first_row": _uint(r.first_row, "first_row"),
            "first_col": _uint(r.first_col, "first_col"),
            "last_row": _uint(r.last_row, "last_row"),
            "last_col": _uint(r.last_col, "last_col"),
        },
    )


def _decode_merge_at(ptr: int) -> MergeRange:
    d = S.MERGE_RANGE.unpack(LIB, ptr)
    return MergeRange(d["first_row"], d["first_col"], d["last_row"], d["last_col"])


_FILTER_COLUMN_BOOLS = (
    "hidden_button",
    "show_button",
    "filter_blank",
    "custom_and",
    "top",
    "percent",
    "has_filter_val",
    "has_dyn_val",
    "has_dyn_max_val",
    "cell_color",
    "has_icon_id",
)
_FILTER_COLUMN_INTS = ("kind", "custom_count", "op1", "op2", "dynamic_type", "icon_set", "icon_id")
_FILTER_COLUMN_DOUBLES = ("top_val", "filter_val", "dyn_val", "dyn_max_val")
_FILTER_COLUMN_STRINGS = ("val1", "val2", "val_iso", "max_val_iso")


def _pack_filter_column(ptr: int, col: AutoFilterColumn, scope: _ArgScope) -> None:
    fields: Dict[str, object] = {
        "col_id": _uint(col.col_id, "col_id"),
        "dxf_id": _uint(col.dxf_id, "dxf_id"),
    }
    for name in _FILTER_COLUMN_BOOLS:
        fields[name] = 1 if getattr(col, name) else 0
    for name in _FILTER_COLUMN_INTS:
        fields[name] = _sint(getattr(col, name), name)
    for name in _FILTER_COLUMN_DOUBLES:
        fields[name] = float(getattr(col, name))
    fields["value_count"] = _uint(len(col.values), "value_count")
    fields["date_group_count"] = _uint(len(col.date_groups), "date_group_count")
    S.FILTER_COLUMN.pack(LIB, ptr, fields)
    for name in _FILTER_COLUMN_STRINGS:
        S.write_str_field(LIB, ptr, S.FILTER_COLUMN, name, getattr(col, name), scope)
    if col.values:
        arr = scope.alloc(4 * len(col.values))
        for i, text in enumerate(col.values):
            text_ptr = scope.cstr(text)
            LIB.write_bytes(arr + 4 * i, struct.pack("<I", text_ptr))
        LIB.write_bytes(ptr + S.FILTER_COLUMN.offsets["values"][1], struct.pack("<I", arr))
    if col.date_groups:
        base = scope.struct_array(S.DATE_GROUP_ITEM, len(col.date_groups))
        for i, g in enumerate(col.date_groups):
            S.DATE_GROUP_ITEM.pack(
                LIB,
                base + i * S.DATE_GROUP_ITEM.size,
                {
                    "year": _uint(g.year, "year", 16),
                    "month": _uint(g.month, "month", 8),
                    "day": _uint(g.day, "day", 8),
                    "hour": _uint(g.hour, "hour", 8),
                    "minute": _uint(g.minute, "minute", 8),
                    "second": _uint(g.second, "second", 8),
                    "grouping": _uint(g.grouping, "grouping", 8),
                },
            )
        LIB.write_bytes(ptr + S.FILTER_COLUMN.offsets["date_groups"][1], struct.pack("<I", base))


def _pack_sort_condition(ptr: int, cond: AutoFilterSortCondition, scope: _ArgScope) -> None:
    S.SORT_CONDITION.pack(
        LIB,
        ptr,
        {
            "descending": 1 if cond.descending else 0,
            "sort_by": _sint(cond.sort_by, "sort_by"),
            "dxf_id": _uint(cond.dxf_id, "dxf_id"),
            "has_dxf_id": 1 if cond.has_dxf_id else 0,
            "icon_set": _sint(cond.icon_set, "icon_set"),
            "icon_id": _sint(cond.icon_id, "icon_id"),
            "has_icon_id": 1 if cond.has_icon_id else 0,
        },
    )
    _pack_merge_at(ptr + S.SORT_CONDITION.offsets["ref"][1], cond.ref)
    S.write_str_field(LIB, ptr, S.SORT_CONDITION, "custom_list", cond.custom_list, scope)


def _pack_auto_filter(ptr: int, af: AutoFilter, scope: _ArgScope) -> None:
    """Fill the ``fm_auto_filter`` at ``ptr``; every nested buffer is allocated through ``scope``."""
    S.AUTO_FILTER.pack(
        LIB,
        ptr,
        {
            "column_count": _uint(len(af.columns), "column_count"),
        },
    )
    off = S.AUTO_FILTER.offsets
    _pack_merge_at(ptr + off["range"][1], af.range)
    if af.columns:
        base = scope.struct_array(S.FILTER_COLUMN, len(af.columns))
        for i, col in enumerate(af.columns):
            _pack_filter_column(base + i * S.FILTER_COLUMN.size, col, scope)
        LIB.write_bytes(ptr + off["columns"][1], struct.pack("<I", base))
    sort = af.sort
    if sort is None:
        return
    fields = {
        "has_sort": 1,
        "column_sort": 1 if sort.column_sort else 0,
        "case_sensitive": 1 if sort.case_sensitive else 0,
        "sort_method": _sint(sort.sort_method, "sort_method"),
        "condition_count": _uint(len(sort.conditions), "condition_count"),
    }
    for name, value in fields.items():
        LIB.write_bytes(ptr + off[name][1], struct.pack("<i" if name != "condition_count" else "<I", value))
    _pack_merge_at(ptr + off["sort_ref"][1], sort.ref)
    if sort.conditions:
        base = scope.struct_array(S.SORT_CONDITION, len(sort.conditions))
        for i, cond in enumerate(sort.conditions):
            _pack_sort_condition(base + i * S.SORT_CONDITION.size, cond, scope)
        LIB.write_bytes(ptr + off["conditions"][1], struct.pack("<I", base))


def _decode_filter_column(ptr: int) -> AutoFilterColumn:
    d = S.FILTER_COLUMN.unpack(LIB, ptr)
    values: List[str] = []
    if d["value_count"]:
        raw = LIB.read_bytes(d["values"], 4 * d["value_count"])
        values = [LIB.read_cstr(p) for p in struct.unpack(f"<{d['value_count']}I", raw)]
    groups: List[AutoFilterDateGroup] = []
    for i in range(d["date_group_count"]):
        g = S.DATE_GROUP_ITEM.unpack(LIB, d["date_groups"] + i * S.DATE_GROUP_ITEM.size)
        groups.append(AutoFilterDateGroup(**g))
    kwargs: Dict[str, object] = {name: bool(d[name]) for name in _FILTER_COLUMN_BOOLS}
    kwargs.update({name: d[name] for name in _FILTER_COLUMN_INTS + _FILTER_COLUMN_DOUBLES})
    kwargs.update({name: LIB.read_cstr(d[name]) for name in _FILTER_COLUMN_STRINGS})
    return AutoFilterColumn(col_id=d["col_id"], dxf_id=d["dxf_id"], values=values, date_groups=groups, **kwargs)  # type: ignore[arg-type]


def _decode_sort_condition(ptr: int) -> AutoFilterSortCondition:
    d = S.SORT_CONDITION.unpack(LIB, ptr)
    return AutoFilterSortCondition(
        ref=_decode_merge_at(ptr + S.SORT_CONDITION.offsets["ref"][1]),
        descending=bool(d["descending"]),
        sort_by=d["sort_by"],
        custom_list=LIB.read_cstr(d["custom_list"]),
        dxf_id=d["dxf_id"],
        has_dxf_id=bool(d["has_dxf_id"]),
        icon_set=d["icon_set"],
        icon_id=d["icon_id"],
        has_icon_id=bool(d["has_icon_id"]),
    )


def _decode_auto_filter(ptr: int) -> AutoFilter:
    d = S.AUTO_FILTER.unpack(LIB, ptr)
    off = S.AUTO_FILTER.offsets
    sort = None
    if d["has_sort"]:
        sort = AutoFilterSortState(
            ref=_decode_merge_at(ptr + off["sort_ref"][1]),
            column_sort=bool(d["column_sort"]),
            case_sensitive=bool(d["case_sensitive"]),
            sort_method=d["sort_method"],
            conditions=[
                _decode_sort_condition(d["conditions"] + i * S.SORT_CONDITION.size) for i in range(d["condition_count"])
            ],
        )
    return AutoFilter(
        range=_decode_merge_at(ptr + off["range"][1]),
        columns=[_decode_filter_column(d["columns"] + i * S.FILTER_COLUMN.size) for i in range(d["column_count"])],
        sort=sort,
    )


def _pack_phonetic_run_array(runs: Sequence[PhoneticRun], scope: _ArgScope) -> int:
    """Pack a list of ``PhoneticRun`` into a contiguous WASM array.

    Returns the array pointer (0 when empty). Every buffer allocated here --
    the array and each run's kana string -- goes through ``scope``.
    """
    if not runs:
        return 0
    size = S.PHONETIC_RUN.size
    ptr = scope.alloc(size * len(runs))
    for i, run in enumerate(runs):
        slot = ptr + i * size
        S.PHONETIC_RUN.pack(LIB, slot, {"sb": _uint(run.sb, "sb"), "eb": _uint(run.eb, "eb")})
        S.write_str_field(LIB, slot, S.PHONETIC_RUN, "text", run.text, scope, allow_empty=True)
    return ptr


class Workbook:
    """Owns an ``fm_workbook_t*`` handle (a WASM i32 offset).

    Construction:
      Use one of :meth:`create_default`, :meth:`create_empty`, or
      :meth:`load`. Direct ``Workbook()`` instantiation is supported as a
      stub for subclassing but does not allocate a handle.

    Lifetime:
      Always release via :meth:`close`, ideally through ``with`` syntax::

          with Workbook.create_default() as wb:
              wb.set_number(0, 0, 0, 42.0)
              wb.recalc()
              print(wb.get_value(0, 0, 0).to_python())

      :meth:`close` is idempotent. The destructor calls ``close`` as a
      defensive net, but relying on garbage-collection ordering is
      unsafe; prefer the context-manager form.

    Threading:
      Each ``Workbook`` instance is single-threaded. The underlying
      wasmtime store is serialised process-wide by an internal lock in
      :mod:`formulon._c`, so cross-thread misuse cannot corrupt WASM
      state -- it just blocks. This no-pthread wheel deliberately exports
      only serial recalc; it has no public parallel-recalc entry point.
    """

    __slots__ = ("_handle",)

    def __init__(self) -> None:
        # 0 == NULL pointer. Use the factory methods to allocate.
        self._handle: int = 0

    # -- Factories ---------------------------------------------------------
    @classmethod
    def create_default(cls) -> "Workbook":
        """Build a default workbook (a single sheet named ``Sheet1``)."""
        wb = cls()
        with _ArgScope() as scope:
            out_ptr = scope.out_ptr()
            status = LIB.fm_workbook_create(out_ptr)
            _check(status, "fm_workbook_create")
            wb._handle = LIB.read_u32(out_ptr)
        return wb

    @classmethod
    def create_for_profile(cls, profile_id: str) -> "Workbook":
        """Build a new workbook with the defaults of an Excel profile.

        ``profile_id`` has the form ``{mac,win}-365-<locale>`` (see
        :meth:`set_excel_profile_id`). The workbook carries that profile as
        its :meth:`excel_profile_id` and takes the profile's locale defaults:
        body font (name, charset, minor theme scheme), phonetic font (font 1,
        ja/ko/zh only), Normal style name, vertical alignment, first sheet
        name, row height, margins and phonetic settings. ``mac-*`` values are
        measured; ``win-*`` ids are estimates (body size 11, no row height or
        base column width set). Unlike :meth:`create_default` no theme part is
        written, so the workbook reads the default Office theme. Changing
        font 0 later (:meth:`set_default_font`) leaves font 1 untouched.
        Unknown ids raise ``FormulonError``.
        """
        wb = cls()
        with _ArgScope() as scope:
            pid_ptr = scope.cstr(profile_id)
            out_ptr = scope.out_ptr()
            status = LIB.fm_workbook_create_for_profile(pid_ptr, out_ptr)
            _check(status, "fm_workbook_create_for_profile")
            wb._handle = LIB.read_u32(out_ptr)
        return wb

    @classmethod
    def create_empty(cls) -> "Workbook":
        """Build an empty workbook (no sheets).

        Saving an empty workbook fails just as Excel rejects sheet-less
        archives; callers are expected to add at least one sheet before
        :meth:`save`.

        The style table is seeded with Excel's reserved defaults exactly as
        :meth:`create_default` seeds it, so the first index :meth:`add_font`
        / :meth:`add_fill` / :meth:`add_border` hands back is non-zero.
        """
        wb = cls()
        with _ArgScope() as scope:
            out_ptr = scope.out_ptr()
            status = LIB.fm_workbook_create_empty(out_ptr)
            _check(status, "fm_workbook_create_empty")
            wb._handle = LIB.read_u32(out_ptr)
        return wb

    @classmethod
    def load(cls, data: Union[bytes, bytearray, memoryview]) -> "Workbook":
        """Load a workbook from an in-memory byte buffer.

        Auto-detects ``.xlsx`` vs ``.xlsb`` from the package contents --
        there is no filename to route on.

        Args:
          data: the raw archive bytes. Accepts any object that satisfies
            the buffer protocol.

        Raises:
          FormulonError: when the input cannot be parsed as a valid
            OOXML or XLSB archive.
        """
        if not isinstance(data, (bytes, bytearray, memoryview)):
            raise TypeError(f"Workbook.load: expected bytes-like, got {type(data).__name__}")
        buf = bytes(data)
        wb = cls()
        with _ArgScope() as scope:
            data_ptr = scope.buffer(buf) if len(buf) > 0 else 0
            out_ptr = scope.out_ptr()
            status = LIB.fm_workbook_load(data_ptr, _uint(len(buf), "len"), out_ptr)
            _check(status, "fm_workbook_load")
            wb._handle = LIB.read_u32(out_ptr)
        return wb

    # -- Lifecycle ---------------------------------------------------------
    def close(self) -> None:
        """Release the underlying handle. Idempotent."""
        if self._handle:
            LIB.fm_workbook_destroy(self._handle)
            self._handle = 0

    def __enter__(self) -> "Workbook":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # type: ignore[no-untyped-def]
        self.close()

    def __del__(self) -> None:  # pragma: no cover -- GC ordering best-effort
        try:
            self.close()
        except Exception:  # noqa: BLE001 -- destructors must not raise
            pass

    @property
    def is_valid(self) -> bool:
        """``True`` while the handle is still alive."""
        return self._handle != 0

    def memory_usage(self) -> int:
        """Return an estimate of the workbook's heap footprint, in bytes.

        Intended for a host that pools workbooks and needs a size to
        evict on. The figure covers the cell store, the shared-string
        storage, the passthrough part payloads and the workbook-level
        metadata. It **excludes** allocator overhead, the dependency
        graph and the style tables, so it is an estimate for relative
        pressure rather than the process's retained heap; a
        formula-heavy workbook undercounts by the size of its graph.

        The walk visits every materialised cell, so call it at coarse
        boundaries (after a load or a recalc) rather than per edit.
        """
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            _check(LIB.fm_workbook_memory_usage(h, out), "fm_workbook_memory_usage")
            return LIB.read_u32(out)

    def _require(self) -> int:
        if not self.is_valid:
            raise FormulonError(
                _STATUS_BINDING_INVALID_HANDLE,
                op="Workbook",
                _diagnostic_override=("handle is NULL or already closed", ""),
            )
        return self._handle

    def _check_live(self) -> int:
        """Re-validate the handle at a generator resume point.

        The iterator methods below hoist their C ABI handle out of the
        per-item loop, and a `yield` in that loop hands control back to
        the caller -- who can call `close()` before asking for the next
        item. Reading `self._handle` under `LIB.call_lock` (rather than
        `_require`'s plain attribute read) also closes the same window
        against a concurrent `close()` from another thread.
        """
        with LIB.call_lock:
            if not self._handle:
                raise FormulonError(
                    _STATUS_BINDING_INVALID_HANDLE,
                    op="Workbook",
                    _diagnostic_override=("handle is NULL or already closed", ""),
                )
            return self._handle

    # -- Sheets ------------------------------------------------------------
    def sheet_count(self) -> int:
        """Number of sheets in the workbook."""
        h = self._require()
        return int(LIB.fm_workbook_sheet_count(h))

    def active_sheet(self) -> int:
        """Index of the active sheet (``activeTab`` of the first workbook view).

        Without workbook views (an XLSB load) the first tab-selected sheet;
        ``0`` when the workbook records neither. Removing or hiding the
        active sheet activates the next visible sheet, else the previous one.
        """
        h = self._require()
        return _read_count(LIB.fm_workbook_get_active_sheet, h)

    def set_active_sheet(self, index: int) -> None:
        """Mark the sheet at ``index`` active so :meth:`save` records it.

        Creates a minimal ``<bookViews>`` when the workbook has none; other
        ``<workbookView>`` attributes survive, and ``firstSheet`` is lowered
        to ``index`` when larger. The sheet becomes the only tab-selected
        one. An out-of-range index or a hidden sheet raises.
        """
        h = self._require()
        _check(LIB.fm_workbook_set_active_sheet(h, _uint(index, "index")), "fm_workbook_set_active_sheet")

    def sheet_name(self, index: int) -> str:
        """Display name (UTF-8) of the sheet at ``index``."""
        h = self._require()
        return _read_cstr_out(
            LIB.fm_workbook_sheet_name,
            h,
            _uint(index, "index"),
            default_op="fm_workbook_sheet_name",
        )

    def add_sheet(self, name: str) -> None:
        """Append a new sheet with the given UTF-8 display name."""
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            status = LIB.fm_workbook_add_sheet(h, name_ptr)
            _check(status, "fm_workbook_add_sheet")

    # -- Cell mutation -----------------------------------------------------
    def set_number(self, sheet: int, row: int, col: int, value: float) -> None:
        """Store the number ``value`` at ``(sheet, row, col)``.

        ``sheet``, ``row`` and ``col`` are all 0-based.
        """
        h = self._require()
        status = LIB.fm_workbook_set_number(
            h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), float(value)
        )
        _check(status, "fm_workbook_set_number")

    def set_bool(self, sheet: int, row: int, col: int, value: bool) -> None:
        """Store the boolean ``value`` at ``(sheet, row, col)``.

        ``sheet``, ``row`` and ``col`` are all 0-based.
        """
        h = self._require()
        status = LIB.fm_workbook_set_bool(
            h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), 1 if value else 0
        )
        _check(status, "fm_workbook_set_bool")

    def set_error(self, sheet: int, row: int, col: int, error_code: int) -> None:
        """Store an Excel cell error at ``(sheet, row, col)``.

        ``sheet``, ``row`` and ``col`` are all 0-based. ``error_code`` is
        a ``formulon::ErrorCode`` ordinal, not a display literal: ``0`` is
        ``#NULL!``, ``1`` ``#DIV/0!``, ``2`` ``#VALUE!``, ``3`` ``#REF!``,
        ``4`` ``#NAME?``, ``5`` ``#NUM!``, ``6`` ``#N/A``. The same
        ordinals come back out through :attr:`Value.error_code`.
        """
        h = self._require()
        status = LIB.fm_workbook_set_error(
            h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), _sint(error_code, "error")
        )
        _check(status, "fm_workbook_set_error")

    def set_text(self, sheet: int, row: int, col: int, value: str) -> None:
        """Store the string ``value`` at ``(sheet, row, col)``.

        ``sheet``, ``row`` and ``col`` are all 0-based. The text is stored
        verbatim; a leading ``=`` does not make it a formula (use
        :meth:`set_formula`).
        """
        h = self._require()
        with _ArgScope() as scope:
            text_ptr = scope.cstr(value)
            status = LIB.fm_workbook_set_text(
                h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), text_ptr
            )
            _check(status, "fm_workbook_set_text")

    def set_blank(self, sheet: int, row: int, col: int) -> None:
        """Clear the cell at ``(sheet, row, col)``.

        ``sheet``, ``row`` and ``col`` are all 0-based. Clearing drops the
        stored value or formula; cell formatting is unaffected.
        """
        h = self._require()
        status = LIB.fm_workbook_set_blank(h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"))
        _check(status, "fm_workbook_set_blank")

    def set_formula(self, sheet: int, row: int, col: int, formula: str) -> None:
        """Store the formula ``formula`` at ``(sheet, row, col)``.

        ``sheet``, ``row`` and ``col`` are all 0-based. The leading ``=``
        is optional. The cell keeps its previous cached value until the
        next :meth:`recalc`.
        """
        h = self._require()
        with _ArgScope() as scope:
            formula_ptr = scope.cstr(formula)
            status = LIB.fm_workbook_set_formula(
                h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), formula_ptr
            )
            _check(status, "fm_workbook_set_formula")

    def set_phonetic(self, sheet: int, row: int, col: int, text: str) -> None:
        """Set the cell's phonetic guide (OOXML ``<rPh>``, furigana).

        ``sheet``, ``row`` and ``col`` are all 0-based. An empty ``text``
        removes the guide. The guide is display metadata attached to the
        cell's string; it does not affect evaluation.
        """
        h = self._require()
        with _ArgScope() as scope:
            text_ptr = scope.cstr(text)
            status = LIB.fm_workbook_set_cell_phonetic(
                h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), text_ptr
            )
            _check(status, "fm_workbook_set_cell_phonetic")

    def set_phonetic_runs(self, sheet: int, row: int, col: int, runs: Sequence[PhoneticRun]) -> None:
        """Set the cell's phonetic guide as one ``<rPh>`` block per run.

        ``sheet``, ``row`` and ``col`` are all 0-based. An empty ``runs``
        removes the guide. Unlike :meth:`set_phonetic`, which annotates the
        whole cell, this keeps the spans each reading covers -- the
        difference ``PHONETIC`` and a partially annotated cell depend on.

        The runs must be an ordered partition: each needs ``sb <= eb`` and
        must start at or after the previous run's ``eb``.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = _pack_phonetic_run_array(runs, scope)
            status = LIB.fm_workbook_set_cell_phonetic_runs(
                h,
                _uint(sheet, "sheet_index"),
                _uint(row, "row"),
                _uint(col, "col"),
                ptr,
                _uint(len(runs), "count"),
            )
            _check(status, "fm_workbook_set_cell_phonetic_runs")

    def get_phonetic_runs(self, sheet: int, row: int, col: int) -> List[PhoneticRun]:
        """Return the cell's ``<rPh>`` blocks, spans included.

        ``sheet``, ``row`` and ``col`` are all 0-based. An unannotated cell
        yields an empty list. :meth:`get_phonetic` returns the same readings
        concatenated, without the spans.
        """
        h = self._require()
        count = _read_count(
            LIB.fm_workbook_get_cell_phonetic_run_count,
            h,
            _uint(sheet, "sheet_index"),
            _uint(row, "row"),
            _uint(col, "col"),
            default_op="fm_workbook_get_cell_phonetic_run_count",
        )
        out: List[PhoneticRun] = []
        with _ArgScope() as scope:
            run_ptr = scope.struct(S.PHONETIC_RUN)
            for i in range(count):
                S.zero_struct(LIB, S.PHONETIC_RUN, run_ptr)
                _check(
                    LIB.fm_workbook_get_cell_phonetic_run(
                        h,
                        _uint(sheet, "sheet_index"),
                        _uint(row, "row"),
                        _uint(col, "col"),
                        _uint(i, "run_index"),
                        run_ptr,
                    ),
                    "fm_workbook_get_cell_phonetic_run",
                )
                fields = S.PHONETIC_RUN.unpack(LIB, run_ptr)
                # Decoded before the next read: the text points into the
                # handle's scratch, which every read refreshes.
                out.append(
                    PhoneticRun(
                        sb=fields["sb"],
                        eb=fields["eb"],
                        text=LIB.read_cstr(fields["text"]) if fields["text"] else "",
                    )
                )
        return out

    def set_phonetic_properties(self, sheet: int, row: int, col: int, properties: PhoneticProperties) -> None:
        """Set how the cell's phonetic guide renders.

        ``sheet``, ``row`` and ``col`` are all 0-based. Independent of
        :meth:`set_phonetic_runs` in both directions: editing the readings
        does not reset the rendering, and this does not touch the readings.
        Only observable on a cell that has runs, and every value-setting
        method clears both, so call it after the cell's text.
        """
        h = self._require()
        _check(
            LIB.fm_workbook_set_cell_phonetic_properties(
                h,
                _uint(sheet, "sheet_index"),
                _uint(row, "row"),
                _uint(col, "col"),
                _uint(properties.font_id, "font_id"),
                _uint(properties.type, "type"),
                _uint(properties.alignment, "alignment"),
            ),
            "fm_workbook_set_cell_phonetic_properties",
        )

    def get_phonetic_properties(self, sheet: int, row: int, col: int) -> PhoneticProperties:
        """Return how the cell's phonetic guide renders.

        ``sheet``, ``row`` and ``col`` are all 0-based. A cell with no
        annotation reports the all-zero default.
        """
        h = self._require()
        with _ArgScope() as scope:
            font_ptr = scope.out_ptr()
            type_ptr = scope.out_ptr()
            alignment_ptr = scope.out_ptr()
            _check(
                LIB.fm_workbook_get_cell_phonetic_properties(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(row, "row"),
                    _uint(col, "col"),
                    font_ptr,
                    type_ptr,
                    alignment_ptr,
                ),
                "fm_workbook_get_cell_phonetic_properties",
            )
            return PhoneticProperties(
                font_id=LIB.read_u32(font_ptr),
                type=LIB.read_u32(type_ptr),
                alignment=LIB.read_u32(alignment_ptr),
            )

    def has_phonetic_properties(self, sheet: int, row: int, col: int) -> bool:
        """Whether the cell's phonetic properties are explicit.

        True when they came from a ``<phoneticPr>`` element or
        :meth:`set_phonetic_properties` (an all-zero triple included), false
        for the state an absent element resolves to. The JS bindings report
        it as ``present`` on the phonetic-properties result.
        """
        h = self._require()
        return bool(
            _read_count(
                LIB.fm_workbook_has_cell_phonetic_properties,
                h,
                _uint(sheet, "sheet_index"),
                _uint(row, "row"),
                _uint(col, "col"),
            )
        )

    def get_show_phonetic(self, sheet: int, row: int, col: int) -> bool:
        """Whether the cell shows its phonetic guide (``<c ph="1">``)."""
        h = self._require()
        return bool(
            _read_count(
                LIB.fm_workbook_get_cell_show_phonetic,
                h,
                _uint(sheet, "sheet_index"),
                _uint(row, "row"),
                _uint(col, "col"),
            )
        )

    def set_show_phonetic(self, sheet: int, row: int, col: int, show: bool) -> None:
        """Set the cell's "Show Phonetic" display flag.

        Independent of the readings: value writes clear the readings but keep
        this flag. A formula cell's flag is neither saved nor read from a file.
        """
        h = self._require()
        _check(
            LIB.fm_workbook_set_cell_show_phonetic(
                h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), 1 if show else 0
            ),
            "fm_workbook_set_cell_show_phonetic",
        )

    def get_phonetic(self, sheet: int, row: int, col: int) -> str:
        """Return the cell's phonetic guide, or ``""`` when it has none.

        ``sheet``, ``row`` and ``col`` are all 0-based.
        """
        h = self._require()
        return _read_cstr_out(
            LIB.fm_workbook_get_cell_phonetic,
            h,
            _uint(sheet, "sheet_index"),
            _uint(row, "row"),
            _uint(col, "col"),
            default_op="fm_workbook_get_cell_phonetic",
        )

    # -- Cell read ---------------------------------------------------------
    def get_value(self, sheet: int, row: int, col: int) -> Value:
        """Read the cached value at ``(sheet, row, col)``.

        Reflects the most recent recalc; mutations made after the last
        :meth:`recalc` are not visible to dependents until you call
        :meth:`recalc` again.
        """
        h = self._require()
        with _ArgScope() as scope:
            value_ptr = scope.alloc(fm_value_t_size)
            status = LIB.fm_workbook_get_value(
                h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), value_ptr
            )
            _check(status, "fm_workbook_get_value")
            return Value._from_wasm(value_ptr)

    # -- Ad-hoc array evaluation ------------------------------------------
    def evaluate_cf_formula(
        self, sheet: int, row: int, col: int, anchor_row: int, anchor_col: int, formula: str
    ) -> bool:
        """Evaluate a conditional-format formula at one cell without mutation."""
        h = self._require()
        with _ArgScope() as scope:
            formula_ptr = scope.cstr(formula)
            value_ptr = scope.alloc(fm_value_t_size)
            _check(
                LIB.fm_workbook_evaluate_cf_formula(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(row, "row"),
                    _uint(col, "col"),
                    _uint(anchor_row, "anchor_row"),
                    _uint(anchor_col, "anchor_col"),
                    formula_ptr,
                    value_ptr,
                ),
                "fm_workbook_evaluate_cf_formula",
            )
            return Value._from_wasm(value_ptr).boolean is True

    def evaluate_formula_array(self, sheet: int, row: int, col: int, formula: str) -> List[List[Value]]:
        """Evaluate ``formula`` as if entered at ``(sheet, row, col)`` and
        return the whole multi-cell result, without mutating the workbook.

        Unlike a scalar evaluation (which reduces an array to its top-left
        element), a dynamic-array formula such as ``=SEQUENCE(2,3)`` yields
        the full ``rows x cols`` grid as a nested list in row-major order
        (``result[r][c]``); a scalar result such as ``=1+2`` is returned as
        a ``1 x 1`` grid (``[[Value(...)]]``).

        The evaluation is read-only: no cell value is written and no spill
        is committed. Cell-level Excel errors surface as
        :class:`Value` entries with ``kind == ValueKind.ERROR``; only
        host-side failures (NULL handle, out-of-range sheet) raise
        :class:`FormulonError`.

        Args:
          sheet: 0-based sheet index the formula is anchored on.
          row: 0-based anchor row (drives ``ROW()`` and relative refs).
          col: 0-based anchor column (drives ``COLUMN()``).
          formula: the formula text, with or without a leading ``=``.

        Returns:
          A ``rows x cols`` nested list of :class:`Value`.
        """
        h = self._require()
        rows, cols = self._stash_formula_array(sheet, row, col, formula)

        # Second step: read each stashed cell back by its row-major index.
        # The stash on the handle stays valid until the next array
        # evaluation or mutation, so it survives the loop below.
        grid: List[List[Value]] = []
        with _ArgScope() as scope:
            value_ptr = scope.alloc(fm_value_t_size)
            for r in range(rows):
                out_row: List[Value] = []
                for c in range(cols):
                    index = r * cols + c
                    status = LIB.fm_workbook_evaluate_formula_array_cell(h, _uint(index, "index"), value_ptr)
                    _check(status, "fm_workbook_evaluate_formula_array_cell")
                    out_row.append(Value._from_wasm(value_ptr))
                grid.append(out_row)
        return grid

    def _evaluate_formula_top_left(self, sheet: int, row: int, col: int, formula: str) -> Value:
        """Evaluate as :meth:`evaluate_formula_array` and read back only the top-left cell."""
        h = self._require()
        self._stash_formula_array(sheet, row, col, formula)
        with _ArgScope() as scope:
            value_ptr = scope.alloc(fm_value_t_size)
            _check(
                LIB.fm_workbook_evaluate_formula_array_cell(h, 0, value_ptr),
                "fm_workbook_evaluate_formula_array_cell",
            )
            return Value._from_wasm(value_ptr)

    def _stash_formula_array(self, sheet: int, row: int, col: int, formula: str) -> Tuple[int, int]:
        """Evaluate ``formula`` into the handle's array stash; return its ``(rows, cols)``."""
        h = self._require()
        with _ArgScope() as scope:
            formula_ptr = scope.cstr(formula)
            rows_ptr = scope.out_ptr()
            cols_ptr = scope.out_ptr()
            status = LIB.fm_workbook_evaluate_formula_array(
                h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), formula_ptr, rows_ptr, cols_ptr
            )
            _check(status, "fm_workbook_evaluate_formula_array")
            return LIB.read_u32(rows_ptr), LIB.read_u32(cols_ptr)

    # -- Recalc ------------------------------------------------------------
    def recalc(self) -> None:
        """Drive a full incremental recalc.

        This no-pthread WASM wheel intentionally exposes only the serial
        recalc contract. Thread-capable native surfaces may opt in to the
        parallel scheduler, but this method always runs serially.
        """
        h = self._require()
        status = LIB.fm_workbook_recalc(h)
        _check(status, "fm_workbook_recalc")

    def set_iterative(self, enabled: bool, max_iterations: int, max_change: float) -> None:
        """Configure iterative calculation."""
        h = self._require()
        status = LIB.fm_workbook_set_iterative(
            h, 1 if enabled else 0, _sint(max_iterations, "max_iterations"), float(max_change)
        )
        _check(status, "fm_workbook_set_iterative")

    def set_iterative_enabled(self, enabled: bool) -> None:
        """Toggle iterative calculation, keeping the cap and threshold.

        The counterpart of Excel's enable checkbox, which is separate from
        its advanced iterative-calculation settings; :meth:`set_iterative`
        writes all three at once.
        """
        h = self._require()
        _check(
            LIB.fm_workbook_set_iterative_enabled(h, 1 if enabled else 0),
            "fm_workbook_set_iterative_enabled",
        )

    def get_iterative(self) -> IterativeSettings:
        """Read back the iterative-calculation settings.

        The counterpart of :meth:`set_iterative`; the cap and threshold are
        the stored values even when ``enabled`` is ``False``.
        """
        h = self._require()
        with _ArgScope() as scope:
            enabled_ptr = scope.out_ptr()
            iterations_ptr = scope.out_ptr()
            change_ptr = scope.alloc(8)
            LIB.write_bytes(change_ptr, b"\x00" * 8)
            _check(
                LIB.fm_workbook_get_iterative(h, enabled_ptr, iterations_ptr, change_ptr),
                "fm_workbook_get_iterative",
            )
            return IterativeSettings(
                enabled=bool(LIB.read_i32(enabled_ptr)),
                max_iterations=LIB.read_u32(iterations_ptr),
                max_change=LIB.read_f64(change_ptr),
            )

    # -- Save --------------------------------------------------------------
    def save(self) -> bytes:
        """Serialise the workbook to an in-memory ``.xlsx`` byte stream.

        The returned bytes are an independent copy; the underlying WASM
        buffer is freed before this method returns.
        """
        h = self._require()
        return _read_owned_buffer(LIB.fm_workbook_save, h, default_op="fm_workbook_save")

    def save_as(self, fmt: "WorkbookFormat | int") -> bytes:
        """Serialise the workbook to an in-memory byte stream in ``fmt``.

        ``WorkbookFormat.XLSX`` produces the same bytes as :meth:`save`;
        ``WorkbookFormat.XLSB`` produces an MS-XLSB package via the
        ``.xlsb`` writer. The returned bytes are an independent copy;
        the underlying WASM buffer is freed before this method returns.
        """
        h = self._require()
        return _read_owned_buffer(
            LIB.fm_workbook_save_as,
            h,
            _sint(fmt, "format"),
            default_op="fm_workbook_save_as",
        )

    def save_with_diagnostics(self, fmt: "WorkbookFormat | int") -> SaveDiagnostics:
        """Serialise the workbook and return what the save cost.

        The returned bytes are an independent copy and the underlying
        WASM allocation is released before this method returns.
        """
        h = self._require()
        with _ArgScope() as scope:
            out_ptr_ptr = scope.out_ptr()
            out_len_ptr = scope.out_ptr()
            diag_ptr = scope.struct(S.SAVE_DIAGNOSTICS)
            status = LIB.fm_workbook_save_with_diagnostics(h, _sint(fmt, "format"), out_ptr_ptr, out_len_ptr, diag_ptr)
            _check(status, "fm_workbook_save_with_diagnostics")
            data_ptr = LIB.read_u32(out_ptr_ptr)
            data_len = LIB.read_u32(out_len_ptr)
            try:
                data = b"" if data_len == 0 or data_ptr == 0 else LIB.read_bytes(data_ptr, data_len)
            finally:
                if data_ptr:
                    LIB.fm_buffer_free(data_ptr)
            d = S.SAVE_DIAGNOSTICS.unpack(LIB, diag_ptr)
            return SaveDiagnostics(
                bytes=data,
                downgraded_formula_count=d["downgraded_formula_count"],
                deferred_feature_count=d["deferred_feature_count"],
                dropped_part_count=d["dropped_part_count"],
                dropped_relationship_count=d["dropped_relationship_count"],
                renumbered_part_count=d["renumbered_part_count"],
            )

    def read_diagnostics(self) -> ReadDiagnostics:
        """Return the loss counters captured when this workbook was loaded."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.READ_DIAGNOSTICS)
            _check(LIB.fm_workbook_read_diagnostics(h, ptr), "fm_workbook_read_diagnostics")
            d = S.READ_DIAGNOSTICS.unpack(LIB, ptr)
            return ReadDiagnostics(
                undecoded_formula_count=d["undecoded_formula_count"],
                undecoded_defined_name_count=d["undecoded_defined_name_count"],
                undecoded_part_count=d["undecoded_part_count"],
                skipped_feature_count=d["skipped_feature_count"],
                unknown_content_type_count=d["unknown_content_type_count"],
            )

    # -- Iteration ---------------------------------------------------------
    def iter_cells(self, sheet: int) -> Iterator[Cell]:
        """Iterate over every written coordinate on ``sheet``.

        Yields each cell set by a value, formula or format setter (clearing
        keeps the slot) and each spill phantom, sorted by ``(row, col)``
        ascending; columns that were never written are skipped. Borrowed
        text pointers are decoded eagerly per yielded item. Do not mutate
        the workbook while consuming this iterator: the C ABI invalidates
        a cell enumeration after a workbook mutation.
        """
        h = self._require()
        n = _read_count(LIB.fm_workbook_cell_count, h, _uint(sheet, "sheet_index"))
        # Scratch: row(4) + col(4) + formula_ptr(4) + value(16) = 28 bytes.
        # Allocate them as separate slots so the ABI's
        # individual out-parameter contract is respected.
        with _ArgScope() as scope:
            row_ptr = scope.alloc(4)
            col_ptr = scope.alloc(4)
            formula_ptr = scope.alloc(4)
            value_ptr = scope.alloc(fm_value_t_size)
            LIB.write_bytes(row_ptr, b"\x00\x00\x00\x00")
            LIB.write_bytes(col_ptr, b"\x00\x00\x00\x00")
            LIB.write_bytes(formula_ptr, b"\x00\x00\x00\x00")
            for i in range(n):
                h = self._check_live()
                status = LIB.fm_workbook_cell_at(
                    h, _uint(sheet, "sheet_index"), _uint(i, "idx"), row_ptr, col_ptr, formula_ptr, value_ptr
                )
                _check(status, "fm_workbook_cell_at")
                row = LIB.read_u32(row_ptr)
                col = LIB.read_u32(col_ptr)
                formula_addr = LIB.read_u32(formula_ptr)
                formula = LIB.read_cstr(formula_addr) if formula_addr else None
                value = Value._from_wasm(value_ptr)
                yield Cell(row=row, col=col, formula=formula, value=value)

    def iter_defined_names(self) -> Iterator[DefinedName]:
        """Iterate over every defined name in declaration order."""
        h = self._require()
        n = int(LIB.fm_workbook_defined_name_count(h))
        # Scratch is hoisted out of the loop (as in iter_cells): each
        # LIB.alloc/free is a locked WASM call, so per-item slots would
        # make the walk cost O(n) allocator round-trips on top of the
        # unavoidable O(n) ABI reads.
        with _ArgScope() as scope:
            name_ptr = scope.out_ptr()
            formula_ptr = scope.out_ptr()
            local_sheet_ptr = scope.out_ptr()
            comment_ptr = scope.out_ptr()
            hidden_ptr = scope.out_ptr()
            for i in range(n):
                h = self._check_live()
                status = LIB.fm_workbook_defined_name_at(h, _uint(i, "idx"), name_ptr, formula_ptr, local_sheet_ptr)
                _check(status, "fm_workbook_defined_name_at")
                _check(
                    LIB.fm_workbook_defined_name_attrs_at(h, _uint(i, "idx"), comment_ptr, hidden_ptr),
                    "fm_workbook_defined_name_attrs_at",
                )
                name = LIB.read_cstr(LIB.read_u32(name_ptr))
                formula = LIB.read_cstr(LIB.read_u32(formula_ptr))
                local_sheet_id = LIB.read_i32(local_sheet_ptr)
                yield DefinedName(
                    name=name,
                    formula=formula,
                    local_sheet_id=local_sheet_id,
                    comment=LIB.read_cstr(LIB.read_u32(comment_ptr)) or "",
                    hidden=bool(LIB.read_i32(hidden_ptr)),
                )

    def iter_tables(self) -> Iterator[Table]:
        """Iterate over every table in declaration order."""
        h = self._require()
        n = int(LIB.fm_workbook_table_count(h))
        # Scratch hoisted out of the loop; see iter_defined_names.
        with _ArgScope() as scope:
            name_ptr = scope.out_ptr()
            display_ptr = scope.out_ptr()
            ref_ptr = scope.out_ptr()
            sheet_ptr = scope.out_ptr()
            info_ptr = scope.struct(S.TABLE_INFO)
            column_ptr = scope.struct(S.TABLE_COLUMN_INFO)
            for i in range(n):
                h = self._check_live()
                status = LIB.fm_workbook_table_at(h, _uint(i, "idx"), name_ptr, display_ptr, ref_ptr, sheet_ptr)
                _check(status, "fm_workbook_table_at")
                name = LIB.read_cstr(LIB.read_u32(name_ptr))
                display = LIB.read_cstr(LIB.read_u32(display_ptr))
                ref = LIB.read_cstr(LIB.read_u32(ref_ptr))
                sheet = LIB.read_u32(sheet_ptr)
                S.zero_struct(LIB, S.TABLE_INFO, info_ptr)
                _check(LIB.fm_workbook_table_get_info(h, _uint(i, "index"), info_ptr), "fm_workbook_table_get_info")
                info = S.TABLE_INFO.unpack(LIB, info_ptr)
                columns = []
                for c in range(info["column_count"]):
                    S.zero_struct(LIB, S.TABLE_COLUMN_INFO, column_ptr)
                    _check(
                        LIB.fm_workbook_table_get_column(h, _uint(i, "index"), _uint(c, "column"), column_ptr),
                        "fm_workbook_table_get_column",
                    )
                    col = S.TABLE_COLUMN_INFO.unpack(LIB, column_ptr)
                    columns.append(
                        TableColumn(
                            name=LIB.read_cstr(col["name"]),
                            totals_row_function=LIB.read_cstr(col["totals_row_function"]),
                            totals_row_label=LIB.read_cstr(col["totals_row_label"]),
                            totals_row_formula=LIB.read_cstr(col["totals_row_formula"]),
                        )
                    )
                yield Table(
                    name=name,
                    display_name=display,
                    ref=ref,
                    sheet_index=sheet,
                    style_name=LIB.read_cstr(info["style_name"]),
                    has_style_info=info["style_present"] != 0,
                    show_first_column=info["show_first_column"] != 0,
                    show_last_column=info["show_last_column"] != 0,
                    show_row_stripes=info["show_row_stripes"] != 0,
                    show_column_stripes=info["show_column_stripes"] != 0,
                    header_row_count=info["header_row_count"],
                    totals_row_count=info["totals_row_count"],
                    columns=tuple(columns),
                )

    def table_create(
        self,
        sheet: int,
        ref: str,
        name: str,
        display_name: str,
        column_names: Sequence[str],
        style_name: str = "",
        header_row: bool = True,
        totals_row: bool = False,
        *,
        show_first_column: Optional[bool] = None,
        show_last_column: Optional[bool] = None,
        show_row_stripes: Optional[bool] = None,
        show_column_stripes: Optional[bool] = None,
    ) -> int:
        """Create a worksheet table and return its index.

        ``column_names`` must hold one non-empty, table-unique header per
        column in ``ref``, and its length must equal the width of ``ref``.
        An empty ``style_name`` omits ``<tableStyleInfo>``; a styled table
        starts with row stripes on and the other toggles off, and a supplied
        ``show_*`` overrides that (without a style name it writes an unnamed
        style element). With ``header_row`` set, the caller still owns the
        header cells: Excel expects the first row of ``ref`` to hold exactly
        these names.
        """
        h = self._require()
        with _ArgScope() as scope:
            ref_ptr = scope.cstr(ref)
            name_ptr = scope.nonempty_cstr(name)
            display_ptr = scope.nonempty_cstr(display_name)
            style_ptr = scope.nonempty_cstr(style_name)
            names = [str(column) for column in column_names]
            name_ptrs = [scope.nonempty_cstr(column) for column in names]
            array_ptr = scope.alloc(4 * len(name_ptrs)) if name_ptrs else 0
            if array_ptr:
                LIB.write_bytes(array_ptr, b"".join(struct.pack("<I", p) for p in name_ptrs))
            out = scope.out_ptr()
            _check(
                LIB.fm_workbook_table_create(
                    h,
                    _uint(sheet, "sheet_index"),
                    ref_ptr,
                    name_ptr,
                    display_ptr,
                    array_ptr,
                    _uint(len(name_ptrs), "column_count"),
                    style_ptr,
                    1 if header_row else 0,
                    1 if totals_row else 0,
                    out,
                ),
                "fm_workbook_table_create",
            )
            index = LIB.read_u32(out)
        toggles = (show_first_column, show_last_column, show_row_stripes, show_column_stripes)
        if any(t is not None for t in toggles):
            try:
                self._table_apply_style_toggles(index, toggles)
            except BaseException:
                self.table_remove(index)
                raise
        return index

    def _table_apply_style_toggles(self, index: int, toggles: Sequence[Optional[bool]]) -> None:
        """Set the supplied ``show_*`` toggles over the table's current ones."""
        current = next(t for i, t in enumerate(self.iter_tables()) if i == index)
        existing = (
            current.show_first_column,
            current.show_last_column,
            current.show_row_stripes if current.has_style_info else True,
            current.show_column_stripes,
        )
        merged = [existing[i] if t is None else t for i, t in enumerate(toggles)]
        self.table_set_style_info(index, current.style_name, *merged)

    def table_set_style_info(
        self,
        index: int,
        style_name: Optional[str],
        show_first_column: bool = False,
        show_last_column: bool = False,
        show_row_stripes: bool = True,
        show_column_stripes: bool = False,
    ) -> None:
        """Set the table's style name and toggles, making the style element present.

        ``None`` or an empty ``style_name`` writes the element without a
        style name, keeping the toggles.
        """
        h = self._require()
        with _ArgScope() as scope:
            _check(
                LIB.fm_workbook_table_set_style_info(
                    h,
                    _uint(index, "index"),
                    scope.nonempty_cstr(style_name),
                    1 if show_first_column else 0,
                    1 if show_last_column else 0,
                    1 if show_row_stripes else 0,
                    1 if show_column_stripes else 0,
                ),
                "fm_workbook_table_set_style_info",
            )

    def table_rename(self, index: int, name: str, display_name: Optional[str] = None) -> None:
        """Rename table ``index``; ``display_name=None`` uses ``name`` for both.

        Names must be non-empty and unique case-insensitively across tables.
        Structured references to the old name are rewritten in cell,
        defined-name, conditional-format, validation and chart formulas; a
        bare table name used as a reference is not rewritten.
        """
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            display_ptr = scope.opt_cstr(display_name)
            _check(
                LIB.fm_workbook_table_rename(h, _uint(index, "index"), name_ptr, display_ptr),
                "fm_workbook_table_rename",
            )

    def table_set_column_totals(
        self,
        index: int,
        column: int,
        function: Optional[str] = None,
        label: Optional[str] = None,
        formula: Optional[str] = None,
    ) -> None:
        """Set column ``column``'s totals-row function and label.

        ``function`` is an ``ST_TotalsRowFunction`` token (``None`` means
        ``"none"``); ``formula`` is required for ``"custom"``. While the
        totals row is shown its cell follows: ``SUBTOTAL(109,Table[Column])``
        and the other 1xx codes for a built-in function, the formula for
        ``"custom"``, else the label as text, else nothing.
        """
        h = self._require()
        with _ArgScope() as scope:
            _check(
                LIB.fm_workbook_table_set_column_totals(
                    h,
                    _uint(index, "index"),
                    _uint(column, "column"),
                    scope.nonempty_cstr(function),
                    scope.nonempty_cstr(label),
                    scope.nonempty_cstr(formula),
                ),
                "fm_workbook_table_set_column_totals",
            )

    def table_update(
        self,
        index: int,
        ref: str,
        style_name: Optional[str] = None,
        header_row: Optional[bool] = None,
        totals_row: Optional[bool] = None,
        *,
        name: Optional[str] = None,
        display_name: Optional[str] = None,
        show_first_column: Optional[bool] = None,
        show_last_column: Optional[bool] = None,
        show_row_stripes: Optional[bool] = None,
        show_column_stripes: Optional[bool] = None,
    ) -> None:
        """Replace a table's range and optional visual style.

        ``ref`` is required and must keep the width the table's column
        list already describes. ``style_name=None`` preserves the existing
        style; a new name keeps the four toggles, and an empty string removes
        ``<tableStyleInfo>`` -- unless a ``show_*`` toggle is also given, which
        writes the element back without a style name, as
        :meth:`table_set_style_info` does. ``header_row=None`` / ``totals_row=None``
        preserve those flags; turning the totals row on writes each column's
        totals cell. ``name`` / ``display_name`` rename the table as
        :meth:`table_rename` does (``display_name`` follows ``name`` unless
        given). The update is all-or-nothing.
        """
        renaming = name is not None or display_name is not None
        if renaming:
            current = next(t for i, t in enumerate(self.iter_tables()) if i == index)
            next_name = name if name is not None else current.name
            if display_name is not None:
                next_display = display_name
            else:
                next_display = name if name is not None else current.display_name
            self.table_rename(index, next_name, next_display)
        try:
            self._table_update(index, ref, style_name, header_row, totals_row)
            toggles = (show_first_column, show_last_column, show_row_stripes, show_column_stripes)
            if any(t is not None for t in toggles):
                self._table_apply_style_toggles(index, toggles)
        except BaseException:
            if renaming:
                self.table_rename(index, current.name, current.display_name)
            raise

    def _table_update(
        self,
        index: int,
        ref: str,
        style_name: Optional[str],
        header_row: Optional[bool],
        totals_row: Optional[bool],
    ) -> None:
        h = self._require()
        with _ArgScope() as scope:
            ref_ptr = scope.cstr(ref)
            style_ptr = scope.opt_cstr(style_name)
            _check(
                LIB.fm_workbook_table_update(
                    h,
                    _uint(index, "index"),
                    ref_ptr,
                    style_ptr,
                    _sint(_tristate(header_row), "header_row"),
                    _sint(_tristate(totals_row), "totals_row"),
                ),
                "fm_workbook_table_update",
            )

    def table_remove(self, index: int) -> None:
        """Remove the table at ``index``."""
        h = self._require()
        _check(LIB.fm_workbook_table_remove(h, _uint(index, "index")), "fm_workbook_table_remove")

    def iter_passthrough(self) -> Iterator[PassthroughPart]:
        """Iterate over passthrough OOXML part paths."""
        h = self._require()
        n = int(LIB.fm_workbook_passthrough_count(h))
        # Scratch hoisted out of the loop; see iter_defined_names.
        with _ArgScope() as scope:
            path_ptr = scope.out_ptr()
            for i in range(n):
                h = self._check_live()
                status = LIB.fm_workbook_passthrough_at(h, _uint(i, "idx"), path_ptr)
                _check(status, "fm_workbook_passthrough_at")
                path = LIB.read_cstr(LIB.read_u32(path_ptr))
                yield PassthroughPart(path=path)

    # -- Sheet structure ---------------------------------------------------
    def move_sheet(self, from_index: int, to_index: int) -> None:
        """Move the sheet at ``from_index`` to ``to_index`` (post-removal)."""
        h = self._require()
        _check(
            LIB.fm_workbook_move_sheet(h, _uint(from_index, "from_index"), _uint(to_index, "to_index")),
            "fm_workbook_move_sheet",
        )

    def remove_sheet(self, index: int) -> None:
        """Remove the sheet at ``index``.

        Raises:
          FormulonError: with ``kCannotRemoveLastSheet`` when it is the
            workbook's only sheet, and with ``kInvalidArgument`` when it is
            the only visible one; a workbook keeps at least one visible sheet.
        """
        h = self._require()
        _check(LIB.fm_workbook_remove_sheet(h, _uint(index, "index")), "fm_workbook_remove_sheet")

    def rename_sheet(self, index: int, new_name: str) -> None:
        """Rename the sheet at ``index`` to ``new_name``."""
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(new_name)
            _check(
                LIB.fm_workbook_rename_sheet(h, _uint(index, "index"), name_ptr),
                "fm_workbook_rename_sheet",
            )

    # -- Defined names -----------------------------------------------------
    def set_defined_name(self, name: str, formula: str) -> None:
        """Set, append, or remove a workbook-scoped defined name.

        An empty ``formula`` removes the entry.
        """
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            formula_ptr = scope.cstr(formula)
            _check(
                LIB.fm_workbook_set_defined_name(h, name_ptr, formula_ptr),
                "fm_workbook_set_defined_name",
            )

    def set_defined_name_scoped(self, name: str, formula: str, local_sheet_id: int) -> None:
        """Set, append, or remove a defined name in workbook or sheet scope.

        Use ``local_sheet_id=-1`` for workbook scope, or a 0-based sheet
        index for sheet-local scope. An empty ``formula`` removes the
        matching entry in that scope.
        """
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            formula_ptr = scope.cstr(formula)
            _check(
                LIB.fm_workbook_set_defined_name_scoped(
                    h, name_ptr, formula_ptr, _sint(local_sheet_id, "local_sheet_id")
                ),
                "fm_workbook_set_defined_name_scoped",
            )

    def set_defined_name_attrs(
        self,
        name: str,
        local_sheet_id: int = -1,
        *,
        comment: Optional[str] = None,
        hidden: Optional[bool] = None,
    ) -> None:
        """Set the ``comment`` and / or ``hidden`` attribute of an existing defined name.

        ``None`` leaves that attribute unchanged and an empty ``comment``
        clears it. Replacing the name's formula keeps both attributes.
        """
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            comment_ptr = scope.opt_cstr(comment)
            _check(
                LIB.fm_workbook_set_defined_name_attrs(
                    h,
                    name_ptr,
                    _sint(local_sheet_id, "local_sheet_id"),
                    comment_ptr,
                    _sint(-1 if hidden is None else int(bool(hidden)), "hidden"),
                ),
                "fm_workbook_set_defined_name_attrs",
            )

    # -- Row / column structural edits -------------------------------------
    #
    # The four edits below move every structure the engine models: cells,
    # formulas, merges, conditional-format ranges, validations, hyperlinks,
    # tables, print areas, manual breaks and the auto-filter range. The
    # ranges and formulas inside the worksheet ``<extLst>`` (the ``x14``
    # conditional-formatting block, sparkline groups, ``x14`` validations)
    # move with them, as Excel moves them, and so do the cells named by the
    # other worksheet content kept verbatim for a lossless save: protected
    # ranges, scenarios, a sheet sort state, cell watches, ignored-error
    # ranges and web-publish ranges.
    #
    # They do not move the anchor of an embedded OLE object or form control,
    # also kept verbatim: it keeps its pre-edit cell, and nothing reports it.
    # An insert also does not copy the formatting of the row or column before
    # it onto the new one, which Excel does -- a sparkline included.
    def insert_rows(self, sheet: int, row: int, count: int) -> None:
        """Insert ``count`` rows at ``row`` on ``sheet``.

        The anchor of an embedded OLE object or form control is not
        remapped; see the note above this method group.

        Raises:
          FormulonError: with ``kPreconditionFailed`` when the edit cuts into
            a data table, legacy array block or PivotTable, or would push one
            of them or a table past the sheet bound; the workbook is unchanged.
        """
        h = self._require()
        _check(
            LIB.fm_workbook_insert_rows(h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(count, "count")),
            "fm_workbook_insert_rows",
        )

    def delete_rows(self, sheet: int, row: int, count: int) -> None:
        """Delete ``count`` rows starting at ``row`` on ``sheet``.

        The anchor of an embedded OLE object or form control is not
        remapped; see the note above this method group.

        Raises:
          FormulonError: with ``kPreconditionFailed`` when the edit cuts into
            a data table, legacy array block or PivotTable, or would push one
            of them or a table past the sheet bound; the workbook is unchanged.
        """
        h = self._require()
        _check(
            LIB.fm_workbook_delete_rows(h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(count, "count")),
            "fm_workbook_delete_rows",
        )

    def insert_cols(self, sheet: int, col: int, count: int) -> None:
        """Insert ``count`` columns at ``col`` on ``sheet``.

        The anchor of an embedded OLE object or form control is not
        remapped; see the note above this method group.

        Raises:
          FormulonError: with ``kPreconditionFailed`` when the edit cuts into
            a data table, legacy array block or PivotTable, or would push one
            of them or a table past the sheet bound; the workbook is unchanged.
        """
        h = self._require()
        _check(
            LIB.fm_workbook_insert_cols(h, _uint(sheet, "sheet"), _uint(col, "col"), _uint(count, "count")),
            "fm_workbook_insert_cols",
        )

    def delete_cols(self, sheet: int, col: int, count: int) -> None:
        """Delete ``count`` columns starting at ``col`` on ``sheet``.

        The anchor of an embedded OLE object or form control is not
        remapped; see the note above this method group.

        Raises:
          FormulonError: with ``kPreconditionFailed`` when the edit cuts into
            a data table, legacy array block or PivotTable, or would push one
            of them or a table past the sheet bound; the workbook is unchanged.
        """
        h = self._require()
        _check(
            LIB.fm_workbook_delete_cols(h, _uint(sheet, "sheet"), _uint(col, "col"), _uint(count, "count")),
            "fm_workbook_delete_cols",
        )

    # -- Calc policy / behaviour profile -----------------------------------
    def calc_mode(self) -> CalcMode:
        """Return the workbook's calc mode (round-trip metadata)."""
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            _check(LIB.fm_workbook_calc_mode(h, out), "fm_workbook_calc_mode")
            return CalcMode(LIB.read_i32(out))

    def set_calc_mode(self, mode: "CalcMode | int") -> None:
        """Set the workbook's calc mode."""
        h = self._require()
        _check(LIB.fm_workbook_set_calc_mode(h, _sint(mode, "mode")), "fm_workbook_set_calc_mode")

    def _read_flag(self, fn, op: str) -> bool:
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            _check(fn(h, out), op)
            return bool(LIB.read_i32(out))

    def full_precision(self) -> bool:
        """Return ``<calcPr fullPrecision>``; false is "set precision as displayed" (metadata only)."""
        return self._read_flag(LIB.fm_workbook_full_precision, "fm_workbook_full_precision")

    def set_full_precision(self, full_precision: bool) -> None:
        """Set ``<calcPr fullPrecision>``."""
        h = self._require()
        _check(
            LIB.fm_workbook_set_full_precision(h, 1 if full_precision else 0),
            "fm_workbook_set_full_precision",
        )

    def calc_on_save(self) -> bool:
        """Return ``<calcPr calcOnSave>`` (default true)."""
        return self._read_flag(LIB.fm_workbook_calc_on_save, "fm_workbook_calc_on_save")

    def set_calc_on_save(self, calc_on_save: bool) -> None:
        """Set ``<calcPr calcOnSave>``."""
        h = self._require()
        _check(LIB.fm_workbook_set_calc_on_save(h, 1 if calc_on_save else 0), "fm_workbook_set_calc_on_save")

    def ref_mode(self) -> RefMode:
        """Return ``<calcPr refMode>``: the reference notation formulas are shown in."""
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            _check(LIB.fm_workbook_ref_mode(h, out), "fm_workbook_ref_mode")
            return RefMode(LIB.read_i32(out))

    def set_ref_mode(self, mode: "RefMode | int") -> None:
        """Set ``<calcPr refMode>``."""
        h = self._require()
        _check(LIB.fm_workbook_set_ref_mode(h, _sint(mode, "mode")), "fm_workbook_set_ref_mode")

    def date1904(self) -> bool:
        """Return whether the workbook uses the 1904 date system."""
        return self._read_flag(LIB.fm_workbook_date1904, "fm_workbook_date1904")

    def set_date1904(self, date1904: bool) -> None:
        """Switch the date system. Stored serials keep their numbers, so every date shifts by 1462 days."""
        h = self._require()
        _check(LIB.fm_workbook_set_date1904(h, 1 if date1904 else 0), "fm_workbook_set_date1904")

    def pinned_now(self) -> "CivilTime | None":
        """Return the pinned wall-clock reading, or ``None`` when the
        workbook follows the host clock (the default)."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.CIVIL_TIME)
            flag = scope.out_ptr()
            _check(LIB.fm_workbook_pinned_now(h, ptr, flag), "fm_workbook_pinned_now")
            if LIB.read_i32(flag) == 0:
                return None
            d = S.CIVIL_TIME.unpack(LIB, ptr)
            return CivilTime(
                year=d["year"],
                month=d["month"],
                day=d["day"],
                hour=d["hour"],
                minute=d["minute"],
                second=d["second"],
            )

    def set_pinned_now(
        self,
        year: int,
        month: int,
        day: int,
        hour: int = 0,
        minute: int = 0,
        second: int = 0,
    ) -> None:
        """Pin every clock-dependent result to one instant.

        ``NOW()``, ``TODAY()`` and the pivot relative-period filters ("this
        month", "year to date", ...) otherwise each read the clock
        independently, which makes a recalc internally inconsistent across a
        midnight boundary and makes any such result untestable.

        This is model state, not file state: nothing in the OOXML package
        records it, so :meth:`save` drops it. Existing formula cells keep
        their cached values until the next :meth:`recalc`.

        Raises:
          FormulonError: with ``kInvalidArgument`` unless ``year`` is in
            ``[1900, 9999]``, ``month`` in ``[1, 12]``, ``day`` within that
            month's real length, ``hour`` in ``[0, 23]``, and ``minute`` /
            ``second`` in ``[0, 59]``. The pin is a calendar instant, not a
            normalising constructor: a month of 13 is rejected rather than
            rolled into the next year.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.CIVIL_TIME)
            S.CIVIL_TIME.pack(
                LIB,
                ptr,
                {
                    "year": _sint(year, "year"),
                    "month": _sint(month, "month"),
                    "day": _sint(day, "day"),
                    "hour": _sint(hour, "hour"),
                    "minute": _sint(minute, "minute"),
                    "second": _sint(second, "second"),
                },
            )
            _check(LIB.fm_workbook_set_pinned_now(h, ptr), "fm_workbook_set_pinned_now")

    def clear_pinned_now(self) -> None:
        """Release the pin so clock-dependent results follow the host clock
        again. Clearing an unpinned workbook does nothing."""
        h = self._require()
        _check(LIB.fm_workbook_clear_pinned_now(h), "fm_workbook_clear_pinned_now")

    def excel_profile_id(
        self,
    ) -> ExcelProfileId:
        """Return the active Excel formula profile id.

        New workbooks default to ``win-365-en_US``. Select another host or
        locale with :meth:`set_excel_profile_id`.
        """
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            _check(
                LIB.fm_workbook_excel_profile_id(h, out),
                "fm_workbook_excel_profile_id",
            )
            return cast(
                ExcelProfileId,
                LIB.read_cstr(LIB.read_u32(out)),
            )

    def set_excel_profile_id(
        self,
        profile_id: ExcelProfileId,
    ) -> None:
        """Set the workbook's Excel formula profile by id.

        New workbooks use ``win-365-en_US`` by default. Ids have the form
        ``{mac,win}-365-{ja_JP,en_US,de_DE,fr_FR,zh_CN,ko_KR,th_TH,es_ES,es_MX,pt_BR,ru_RU,zh_TW,it_IT,nl_NL}``.
        """
        h = self._require()
        with _ArgScope() as scope:
            pid_ptr = scope.cstr(profile_id)
            _check(
                LIB.fm_workbook_set_excel_profile_id(h, pid_ptr),
                "fm_workbook_set_excel_profile_id",
            )

    # -- Partial recalc ----------------------------------------------------
    #
    # Note: ``fm_workbook_set_iterative_progress`` (the per-sweep callback)
    # is intentionally NOT bound -- it takes a C function pointer that the
    # wasmtime-py host cannot synthesise into the module's function table.
    def partial_recalc(
        self,
        sheet: int,
        first_row: int,
        last_row: int,
        first_col: int,
        last_col: int,
    ) -> int:
        """Recalc the dependency closure for a viewport; return cell count."""
        h = self._require()
        with _ArgScope() as scope:
            vp = scope.struct(S.VIEWPORT)
            out = scope.out_ptr()
            S.VIEWPORT.pack(
                LIB,
                vp,
                {
                    "sheet": _uint(sheet, "sheet"),
                    "first_row": _uint(first_row, "first_row"),
                    "last_row": _uint(last_row, "last_row"),
                    "first_col": _uint(first_col, "first_col"),
                    "last_col": _uint(last_col, "last_col"),
                },
            )
            _check(
                LIB.fm_workbook_partial_recalc(h, vp, out),
                "fm_workbook_partial_recalc",
            )
            return LIB.read_u32(out)

    # -- Lambda text -------------------------------------------------------
    def lambda_text_at(self, sheet: int, row: int, col: int) -> str:
        """Render the lambda cached at ``(sheet, row, col)`` as text."""
        h = self._require()
        return _read_cstr_out(
            LIB.fm_workbook_lambda_text_at,
            h,
            _uint(sheet, "sheet_index"),
            _uint(row, "row"),
            _uint(col, "col"),
            default_op="fm_workbook_lambda_text_at",
        )

    # -- Merges ------------------------------------------------------------
    def add_merge(self, sheet: int, merge: MergeRange) -> None:
        """Append a merge range to ``sheet``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = _pack_merge_array([merge], scope)
            _check(LIB.fm_sheet_add_merge(h, _uint(sheet, "sheet"), ptr), "fm_sheet_add_merge")

    def remove_merge(self, sheet: int, merge: MergeRange) -> None:
        """Remove every merge on ``sheet`` overlapping ``merge``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = _pack_merge_array([merge], scope)
            _check(
                LIB.fm_sheet_remove_merge(h, _uint(sheet, "sheet"), ptr),
                "fm_sheet_remove_merge",
            )

    def remove_merge_at(self, sheet: int, index: int) -> None:
        """Remove the merge at ``index`` on ``sheet``."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_merge_at(h, _uint(sheet, "sheet"), _uint(index, "index")),
            "fm_sheet_remove_merge_at",
        )

    def clear_merges(self, sheet: int) -> None:
        """Drop every merge range on ``sheet``."""
        h = self._require()
        _check(LIB.fm_sheet_clear_merges(h, _uint(sheet, "sheet")), "fm_sheet_clear_merges")

    def merge_count(self, sheet: int) -> int:
        """Return the number of merge ranges on ``sheet``."""
        h = self._require()
        return _read_count(LIB.fm_sheet_get_merge_count, h, _uint(sheet, "sheet"))

    def get_merges(self, sheet: int) -> List[MergeRange]:
        """Return every merge range on ``sheet``."""
        h = self._require()
        n = self.merge_count(sheet)
        out: List[MergeRange] = []
        # One scratch block for the whole walk; see iter_defined_names.
        with _ArgScope() as scope:
            ptr = scope.struct(S.MERGE_RANGE)
            for i in range(n):
                S.zero_struct(LIB, S.MERGE_RANGE, ptr)
                _check(
                    LIB.fm_sheet_get_merge_at(h, _uint(sheet, "sheet"), _uint(i, "index"), ptr),
                    "fm_sheet_get_merge_at",
                )
                out.append(_decode_merge_at(ptr))
        return out

    # -- Hyperlinks --------------------------------------------------------
    def add_hyperlink(
        self,
        sheet: int,
        row: int,
        col: int,
        target: str,
        display: str = "",
        tooltip: str = "",
        location: str = "",
    ) -> None:
        """Append a hyperlink to ``sheet``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.HYPERLINK)
            S.HYPERLINK.pack(
                LIB,
                ptr,
                {
                    "row": _uint(row, "row"),
                    "col": _uint(col, "col"),
                    "last_row": _uint(row, "row"),
                    "last_col": _uint(col, "col"),
                },
            )
            S.write_str_field(LIB, ptr, S.HYPERLINK, "target", target, scope)
            S.write_str_field(LIB, ptr, S.HYPERLINK, "location", location, scope)
            S.write_str_field(LIB, ptr, S.HYPERLINK, "display", display, scope)
            S.write_str_field(LIB, ptr, S.HYPERLINK, "tooltip", tooltip, scope)
            _check(LIB.fm_sheet_add_hyperlink(h, _uint(sheet, "sheet"), ptr), "fm_sheet_add_hyperlink")

    def add_hyperlink_range(
        self,
        sheet: int,
        row: int,
        col: int,
        last_row: int,
        last_col: int,
        target: str,
        display: str = "",
        tooltip: str = "",
        location: str = "",
    ) -> None:
        """Append a hyperlink covering the inclusive cell rectangle."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.HYPERLINK)
            S.HYPERLINK.pack(
                LIB,
                ptr,
                {
                    "row": _uint(row, "row"),
                    "col": _uint(col, "col"),
                    "last_row": _uint(last_row, "last_row"),
                    "last_col": _uint(last_col, "last_col"),
                },
            )
            S.write_str_field(LIB, ptr, S.HYPERLINK, "target", target, scope)
            S.write_str_field(LIB, ptr, S.HYPERLINK, "location", location, scope)
            S.write_str_field(LIB, ptr, S.HYPERLINK, "display", display, scope)
            S.write_str_field(LIB, ptr, S.HYPERLINK, "tooltip", tooltip, scope)
            _check(LIB.fm_sheet_add_hyperlink(h, _uint(sheet, "sheet"), ptr), "fm_sheet_add_hyperlink")

    def remove_hyperlink(self, sheet: int, row: int, col: int) -> None:
        """Remove every hyperlink anchored at ``(row, col)`` on ``sheet``."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_hyperlink(h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(col, "col")),
            "fm_sheet_remove_hyperlink",
        )

    def remove_hyperlink_at(self, sheet: int, index: int) -> None:
        """Remove the hyperlink at ``index`` on ``sheet``."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_hyperlink_at(h, _uint(sheet, "sheet"), _uint(index, "index")),
            "fm_sheet_remove_hyperlink_at",
        )

    def clear_hyperlinks(self, sheet: int) -> None:
        """Drop every hyperlink on ``sheet``."""
        h = self._require()
        _check(LIB.fm_sheet_clear_hyperlinks(h, _uint(sheet, "sheet")), "fm_sheet_clear_hyperlinks")

    def hyperlink_count(self, sheet: int) -> int:
        """Return the number of hyperlinks on ``sheet``."""
        h = self._require()
        return _read_count(LIB.fm_sheet_get_hyperlink_count, h, _uint(sheet, "sheet"))

    def get_hyperlinks(self, sheet: int) -> List[Hyperlink]:
        """Return every hyperlink on ``sheet``."""
        h = self._require()
        n = self.hyperlink_count(sheet)
        out: List[Hyperlink] = []
        # One scratch block for the whole walk; see iter_defined_names.
        with _ArgScope() as scope:
            ptr = scope.struct(S.HYPERLINK)
            for i in range(n):
                S.zero_struct(LIB, S.HYPERLINK, ptr)
                _check(
                    LIB.fm_sheet_get_hyperlink_at(h, _uint(sheet, "sheet"), _uint(i, "index"), ptr),
                    "fm_sheet_get_hyperlink_at",
                )
                d = S.HYPERLINK.unpack(LIB, ptr)
                out.append(
                    Hyperlink(
                        row=d["row"],
                        col=d["col"],
                        last_row=d["last_row"],
                        last_col=d["last_col"],
                        target=LIB.read_cstr(d["target"]),
                        location=LIB.read_cstr(d["location"]),
                        display=LIB.read_cstr(d["display"]),
                        tooltip=LIB.read_cstr(d["tooltip"]),
                    )
                )
        return out

    # -- Comments ----------------------------------------------------------
    def get_comment(self, sheet: int, row: int, col: int) -> Optional[Comment]:
        """Return the comment at ``(sheet, row, col)`` or ``None`` if absent."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.COMMENT)
            status = LIB.fm_sheet_get_comment_at(h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(col, "col"), ptr)
            if status == _STATUS_NOT_FOUND:
                return None
            _check(status, "fm_sheet_get_comment_at")
            d = S.COMMENT.unpack(LIB, ptr)
            return Comment(
                author=LIB.read_cstr(d["author"]),
                text=LIB.read_cstr(d["text"]),
            )

    def set_comment(self, sheet: int, row: int, col: int, author: str, text: str) -> None:
        """Set, replace, or (empty ``text``) remove a cell comment."""
        h = self._require()
        with _ArgScope() as scope:
            author_ptr = scope.nonempty_cstr(author)
            text_ptr = scope.nonempty_cstr(text)
            _check(
                LIB.fm_sheet_set_comment(
                    h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(col, "col"), author_ptr, text_ptr
                ),
                "fm_sheet_set_comment",
            )

    def comment_count(self, sheet: int) -> int:
        """Return the number of comments on ``sheet``."""
        h = self._require()
        return _read_count(LIB.fm_sheet_get_comment_count, h, _uint(sheet, "sheet"))

    def get_comments(self, sheet: int) -> List[CommentEntry]:
        """Return every comment on ``sheet`` in storage order.

        Unlike :meth:`get_comment`, this discovers comments on otherwise
        empty cells without requiring callers to scan worksheet coordinates.
        """
        h = self._require()
        out: List[CommentEntry] = []
        # One scratch block for the whole walk; see iter_defined_names.
        with _ArgScope() as scope:
            ptr = scope.struct(S.COMMENT)
            for index in range(self.comment_count(sheet)):
                S.zero_struct(LIB, S.COMMENT, ptr)
                _check(
                    LIB.fm_sheet_get_comment_at_index(h, _uint(sheet, "sheet"), _uint(index, "index"), ptr),
                    "fm_sheet_get_comment_at_index",
                )
                d = S.COMMENT.unpack(LIB, ptr)
                out.append(CommentEntry(d["row"], d["col"], LIB.read_cstr(d["author"]), LIB.read_cstr(d["text"])))
        return out

    def get_comment_visible(self, sheet: int, row: int, col: int) -> Optional[bool]:
        """Return whether the note at the cell is shown without hovering, or ``None`` if absent."""
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            status = LIB.fm_sheet_get_comment_visible(
                h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(col, "col"), out
            )
            if status == _STATUS_NOT_FOUND:
                return None
            _check(status, "fm_sheet_get_comment_visible")
            return LIB.read_u32(out) != 0

    def set_comment_visible(self, sheet: int, row: int, col: int, visible: bool) -> None:
        """Show or hide the note at the cell; its box geometry is kept."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_comment_visible(
                h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(col, "col"), 1 if visible else 0
            ),
            "fm_sheet_set_comment_visible",
        )

    # -- Protection records ------------------------------------------------
    _WORKBOOK_PROTECTION_TEXT = (
        "workbook_password",
        "workbook_algorithm_name",
        "workbook_hash_value",
        "workbook_salt_value",
        "revisions_password",
        "revisions_algorithm_name",
        "revisions_hash_value",
        "revisions_salt_value",
    )
    _PROTECTED_RANGE_TEXT = (
        "name",
        "sqref",
        "password",
        "algorithm_name",
        "hash_value",
        "salt_value",
        "security_descriptor",
    )

    def get_workbook_protection(self) -> WorkbookProtection:
        """Read the workbook's ``<workbookProtection>``; every field is false, empty or zero when absent."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.WORKBOOK_PROTECTION)
            _check(LIB.fm_workbook_get_protection(h, ptr), "fm_workbook_get_protection")
            d = S.WORKBOOK_PROTECTION.unpack(LIB, ptr)
            prot = WorkbookProtection(
                lock_structure=bool(d["lock_structure"]),
                lock_windows=bool(d["lock_windows"]),
                lock_revision=bool(d["lock_revision"]),
                workbook_spin_count=d["workbook_spin_count"],
                revisions_spin_count=d["revisions_spin_count"],
            )
            for fld in self._WORKBOOK_PROTECTION_TEXT:
                setattr(prot, fld, LIB.read_cstr(d[fld]))
            return prot

    def set_workbook_protection(self, protection: WorkbookProtection) -> None:
        """Replace the modelled ``<workbookProtection>`` attributes; an all-empty record removes the element."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.WORKBOOK_PROTECTION)
            S.WORKBOOK_PROTECTION.pack(
                LIB,
                ptr,
                {
                    "lock_structure": 1 if protection.lock_structure else 0,
                    "lock_windows": 1 if protection.lock_windows else 0,
                    "lock_revision": 1 if protection.lock_revision else 0,
                    "workbook_spin_count": _uint(protection.workbook_spin_count, "workbook_spin_count"),
                    "revisions_spin_count": _uint(protection.revisions_spin_count, "revisions_spin_count"),
                },
            )
            for fld in self._WORKBOOK_PROTECTION_TEXT:
                S.write_str_field(LIB, ptr, S.WORKBOOK_PROTECTION, fld, getattr(protection, fld), scope)
            _check(LIB.fm_workbook_set_protection(h, ptr), "fm_workbook_set_protection")

    def protected_range_count(self, sheet: int) -> int:
        """Return the number of protected ranges on ``sheet``."""
        h = self._require()
        return _read_count(LIB.fm_sheet_protected_range_count, h, _uint(sheet, "sheet"))

    def get_protected_ranges(self, sheet: int) -> List[ProtectedRange]:
        """Return the protected ranges of ``sheet`` in file order."""
        h = self._require()
        out: List[ProtectedRange] = []
        with _ArgScope() as scope:
            ptr = scope.struct(S.PROTECTED_RANGE)
            for index in range(self.protected_range_count(sheet)):
                S.zero_struct(LIB, S.PROTECTED_RANGE, ptr)
                _check(
                    LIB.fm_sheet_get_protected_range(h, _uint(sheet, "sheet"), _uint(index, "index"), ptr),
                    "fm_sheet_get_protected_range",
                )
                d = S.PROTECTED_RANGE.unpack(LIB, ptr)
                out.append(
                    ProtectedRange(
                        spin_count=d["spin_count"],
                        **{fld: LIB.read_cstr(d[fld]) for fld in self._PROTECTED_RANGE_TEXT},
                    )
                )
        return out

    def _protected_range_call(self, fn, name: str, leading: tuple, protected: ProtectedRange) -> None:
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PROTECTED_RANGE)
            S.PROTECTED_RANGE.pack(LIB, ptr, {"spin_count": _uint(protected.spin_count, "spin_count")})
            for fld in self._PROTECTED_RANGE_TEXT:
                S.write_str_field(LIB, ptr, S.PROTECTED_RANGE, fld, getattr(protected, fld), scope)
            _check(fn(h, *leading, ptr), name)

    def add_protected_range(self, sheet: int, protected: ProtectedRange) -> None:
        """Append a protected range; ``name`` must be non-empty and unique on the sheet."""
        self._protected_range_call(
            LIB.fm_sheet_add_protected_range, "fm_sheet_add_protected_range", (_uint(sheet, "sheet"),), protected
        )

    def update_protected_range(self, sheet: int, index: int, protected: ProtectedRange) -> None:
        """Replace the ``index``-th protected range of ``sheet``."""
        self._protected_range_call(
            LIB.fm_sheet_update_protected_range,
            "fm_sheet_update_protected_range",
            (_uint(sheet, "sheet"), _uint(index, "index")),
            protected,
        )

    def remove_protected_range(self, sheet: int, index: int) -> None:
        """Remove the ``index``-th protected range of ``sheet``."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_protected_range(h, _uint(sheet, "sheet"), _uint(index, "index")),
            "fm_sheet_remove_protected_range",
        )

    # -- Data validations --------------------------------------------------
    def validation_count(self, sheet: int) -> int:
        """Return the number of data-validation rules on ``sheet``."""
        h = self._require()
        return _read_count(LIB.fm_sheet_get_validation_count, h, _uint(sheet, "sheet"))

    def get_validation_at(self, sheet: int, index: int) -> DataValidation:
        """Read the ``index``-th data-validation rule on ``sheet``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.DATA_VALIDATION)
            _check(
                LIB.fm_sheet_get_validation_at(h, _uint(sheet, "sheet"), _uint(index, "index"), ptr),
                "fm_sheet_get_validation_at",
            )
            return self._decode_validation(ptr)

    def get_validations(self, sheet: int) -> List[DataValidation]:
        """Return every data-validation rule on ``sheet``."""
        n = self.validation_count(sheet)
        return [self.get_validation_at(sheet, i) for i in range(n)]

    @staticmethod
    def _decode_validation(ptr: int) -> DataValidation:
        d = S.DATA_VALIDATION.unpack(LIB, ptr)
        ranges: List[MergeRange] = []
        base = d["ranges"]
        rsize = S.MERGE_RANGE.size
        for i in range(d["range_count"]):
            ranges.append(_decode_merge_at(base + i * rsize))
        return DataValidation(
            ranges=ranges,
            type=d["type"],
            op=d["op"],
            error_style=d["error_style"],
            allow_blank=bool(d["allow_blank"]),
            show_input_message=bool(d["show_input_message"]),
            show_error_message=bool(d["show_error_message"]),
            show_dropdown=bool(d["show_dropdown"]),
            formula1=LIB.read_cstr(d["formula1"]),
            formula2=LIB.read_cstr(d["formula2"]),
            error_title=LIB.read_cstr(d["error_title"]),
            error_message=LIB.read_cstr(d["error_message"]),
            prompt_title=LIB.read_cstr(d["prompt_title"]),
            prompt_message=LIB.read_cstr(d["prompt_message"]),
        )

    def add_validation(self, sheet: int, validation: DataValidationInput) -> None:
        """Append a data-validation rule to ``sheet``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.DATA_VALIDATION)
            S.DATA_VALIDATION.pack(
                LIB,
                ptr,
                {
                    "type": _uint(validation.type, "type", 8),
                    "op": _uint(validation.op, "op", 8),
                    "error_style": _uint(validation.error_style, "error_style", 8),
                    "allow_blank": 1 if validation.allow_blank else 0,
                    "show_input_message": 1 if validation.show_input_message else 0,
                    "show_error_message": 1 if validation.show_error_message else 0,
                    "show_dropdown": 1 if validation.show_dropdown else 0,
                },
            )
            ranges_ptr = _pack_merge_array(validation.ranges, scope)
            ro = S.DATA_VALIDATION.offsets
            LIB.write_bytes(ptr + ro["ranges"][1], struct.pack("<I", ranges_ptr))
            LIB.write_bytes(
                ptr + ro["range_count"][1],
                struct.pack("<I", len(validation.ranges)),
            )
            for fld in (
                "formula1",
                "formula2",
                "error_title",
                "error_message",
                "prompt_title",
                "prompt_message",
            ):
                S.write_str_field(LIB, ptr, S.DATA_VALIDATION, fld, getattr(validation, fld), scope)
            _check(
                LIB.fm_sheet_add_validation(h, _uint(sheet, "sheet"), ptr),
                "fm_sheet_add_validation",
            )

    def remove_validation_at(self, sheet: int, index: int) -> None:
        """Remove the validation rule at ``index`` on ``sheet``."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_validation_at(h, _uint(sheet, "sheet"), _uint(index, "index")),
            "fm_sheet_remove_validation_at",
        )

    def clear_validations(self, sheet: int) -> None:
        """Drop every validation rule on ``sheet``."""
        h = self._require()
        _check(
            LIB.fm_sheet_clear_validations(h, _uint(sheet, "sheet")),
            "fm_sheet_clear_validations",
        )

    # -- Sheet protection --------------------------------------------------
    _PROTECT_FLAGS = (
        "sheet",
        "objects",
        "scenarios",
        "format_cells",
        "format_columns",
        "format_rows",
        "insert_columns",
        "insert_rows",
        "insert_hyperlinks",
        "delete_columns",
        "delete_rows",
        "select_locked_cells",
        "select_unlocked_cells",
        "sort",
        "auto_filter",
        "pivot_tables",
    )

    def get_sheet_protection(self, sheet: int) -> SheetProtection:
        """Read the sheet's ``<sheetProtection>`` flags."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.SHEET_PROTECTION)
            _check(
                LIB.fm_sheet_get_protection(h, _uint(sheet, "sheet_index"), ptr),
                "fm_sheet_get_protection",
            )
            d = S.SHEET_PROTECTION.unpack(LIB, ptr)
            prot = SheetProtection(
                enabled=bool(d["enabled"]),
                algorithm_name=LIB.read_cstr(d["algorithm_name"]),
                hash_value=LIB.read_cstr(d["hash_value"]),
                salt_value=LIB.read_cstr(d["salt_value"]),
                spin_count=d["spin_count"],
                legacy_password=LIB.read_cstr(d["legacy_password"]),
            )
            for flag in self._PROTECT_FLAGS:
                setattr(prot, flag, bool(d[flag]))
            return prot

    def set_sheet_protection(self, sheet: int, protection: SheetProtection) -> None:
        """Replace the sheet's ``<sheetProtection>`` flags wholesale."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.SHEET_PROTECTION)
            values: Dict[str, int] = {
                "enabled": 1 if protection.enabled else 0,
                "spin_count": _uint(protection.spin_count, "spin_count"),
            }
            for flag in self._PROTECT_FLAGS:
                values[flag] = 1 if getattr(protection, flag) else 0
            S.SHEET_PROTECTION.pack(LIB, ptr, values)
            for fld in ("algorithm_name", "hash_value", "salt_value", "legacy_password"):
                S.write_str_field(LIB, ptr, S.SHEET_PROTECTION, fld, getattr(protection, fld), scope)
            _check(
                LIB.fm_sheet_set_protection(h, _uint(sheet, "sheet_index"), ptr),
                "fm_sheet_set_protection",
            )

    # -- Geometry / display ------------------------------------------------
    def clear_row_height(self, sheet: int, row: int) -> None:
        """Remove the height override at ``row`` (back to the sheet default)."""
        h = self._require()
        _check(
            LIB.fm_sheet_clear_row_height(h, _uint(sheet, "sheet_index"), _uint(row, "row")),
            "fm_sheet_clear_row_height",
        )

    def clear_column_width(self, sheet: int, first: int, last: int) -> None:
        """Remove the width override on ``[first, last]`` (back to the sheet default)."""
        h = self._require()
        _check(
            LIB.fm_sheet_clear_column_width(h, _uint(sheet, "sheet_index"), _uint(first, "first"), _uint(last, "last")),
            "fm_sheet_clear_column_width",
        )

    def get_sheet_format_defaults(self, sheet: int) -> SheetFormatDefaults:
        """Read the sheet's default column / row metrics (``<sheetFormatPr>``)."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.SHEET_FORMAT_DEFAULTS)
            _check(
                LIB.fm_sheet_get_format_defaults(h, _uint(sheet, "sheet_index"), ptr),
                "fm_sheet_get_format_defaults",
            )
            d = S.SHEET_FORMAT_DEFAULTS.unpack(LIB, ptr)
            return SheetFormatDefaults(
                default_col_width=d["default_col_width"],
                default_row_height=d["default_row_height"],
                base_col_width=d["base_col_width"],
                has_default_col_width=bool(d["has_default_col_width"]),
                has_default_row_height=bool(d["has_default_row_height"]),
                custom_height=bool(d["custom_height"]),
                zero_height=bool(d["zero_height"]),
                effective_default_col_width=d["effective_default_col_width"],
                effective_default_row_height=d["effective_default_row_height"],
            )

    def set_sheet_format_defaults(self, sheet: int, defaults: SheetFormatDefaults) -> None:
        """Replace the sheet's default column / row metrics; a ``None`` flag keeps the stored one."""
        h = self._require()
        if defaults.custom_height is None or defaults.zero_height is None:
            stored = self.get_sheet_format_defaults(sheet)
            custom_height = stored.custom_height if defaults.custom_height is None else defaults.custom_height
            zero_height = stored.zero_height if defaults.zero_height is None else defaults.zero_height
        else:
            custom_height, zero_height = defaults.custom_height, defaults.zero_height
        with _ArgScope() as scope:
            ptr = scope.struct(S.SHEET_FORMAT_DEFAULTS)
            S.SHEET_FORMAT_DEFAULTS.pack(
                LIB,
                ptr,
                {
                    "default_col_width": float(defaults.default_col_width),
                    "default_row_height": float(defaults.default_row_height),
                    "base_col_width": float(defaults.base_col_width),
                    "has_default_col_width": 1 if defaults.has_default_col_width else 0,
                    "has_default_row_height": 1 if defaults.has_default_row_height else 0,
                    "custom_height": 1 if custom_height else 0,
                    "zero_height": 1 if zero_height else 0,
                },
            )
            _check(
                LIB.fm_sheet_set_format_defaults(h, _uint(sheet, "sheet_index"), ptr),
                "fm_sheet_set_format_defaults",
            )

    def _read_f64_out(self, fn, *args) -> float:
        """Call a ``(..., double* out)`` ABI function and return the double."""
        with _ArgScope() as scope:
            out = scope.alloc(8)
            _check(fn(*args, out), getattr(fn, "__name__", "geometry"))
            return LIB.read_f64(out)

    def get_cell_rect_pt(
        self, sheet: int, cell_range: MergeRange, mode: Union[GeometryMode, int] = GeometryMode.DISPLAY
    ) -> RectPt:
        """Return the rectangle covering ``cell_range`` in points from the top-left of A1."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.RECT_PT)
            _check(
                LIB.fm_sheet_cell_rect_pt(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(cell_range.first_row, "first_row"),
                    _uint(cell_range.first_col, "first_col"),
                    _uint(cell_range.last_row, "last_row"),
                    _uint(cell_range.last_col, "last_col"),
                    _sint(mode, "mode"),
                    ptr,
                ),
                "fm_sheet_cell_rect_pt",
            )
            return RectPt(**S.RECT_PT.unpack(LIB, ptr))

    def get_column_width_pt(self, sheet: int, col: int, mode: Union[GeometryMode, int] = GeometryMode.DISPLAY) -> float:
        """Return the effective width of ``col`` in points (0 when hidden)."""
        h = self._require()
        return self._read_f64_out(
            LIB.fm_sheet_column_width_pt, h, _uint(sheet, "sheet_index"), _uint(col, "col"), _sint(mode, "mode")
        )

    def get_row_height_pt(self, sheet: int, row: int) -> float:
        """Return the effective height of ``row`` in points (0 when hidden)."""
        h = self._require()
        return self._read_f64_out(LIB.fm_sheet_row_height_pt, h, _uint(sheet, "sheet_index"), _uint(row, "row"))

    def get_width_model(self, sheet: int, mode: Union[GeometryMode, int] = GeometryMode.DISPLAY) -> WidthModel:
        """Return the character-unit to point conversion model in ``mode``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.WIDTH_MODEL)
            _check(
                LIB.fm_sheet_width_model(h, _uint(sheet, "sheet_index"), _sint(mode, "mode"), ptr),
                "fm_sheet_width_model",
            )
            d = S.WIDTH_MODEL.unpack(LIB, ptr)
            return WidthModel(
                points_per_char=d["points_per_char"],
                padding_pt=d["padding_pt"],
                normal_font_size=d["normal_font_size"],
                calibrated=bool(d["calibrated"]),
                normal_font_name=LIB.read_cstr(d["normal_font_name"]),
                platform=LIB.read_cstr(d["platform"]),
            )

    def column_chars_to_pt(
        self, sheet: int, chars: float, mode: Union[GeometryMode, int] = GeometryMode.DISPLAY
    ) -> float:
        """Convert a stored column width (padding included) to points, snapped to whole screen pixels."""
        h = self._require()
        return self._read_f64_out(
            LIB.fm_sheet_column_chars_to_pt, h, _uint(sheet, "sheet_index"), _sint(mode, "mode"), float(chars)
        )

    def column_pt_to_chars(self, sheet: int, pt: float, mode: Union[GeometryMode, int] = GeometryMode.DISPLAY) -> float:
        """Convert points to the stored column width Excel writes for that column."""
        h = self._require()
        return self._read_f64_out(
            LIB.fm_sheet_column_pt_to_chars, h, _uint(sheet, "sheet_index"), _sint(mode, "mode"), float(pt)
        )

    def _read_formula_text(self, fn, op: str, sheet: int, row: int, col: int) -> Optional[str]:
        h = self._require()
        text = _read_cstr_out(
            fn,
            h,
            _uint(sheet, "sheet_index"),
            _uint(row, "row"),
            _uint(col, "col"),
            default_op=op,
        )
        return text or None

    def get_formula(self, sheet: int, row: int, col: int) -> Optional[str]:
        """Return the stored A1 formula (leading ``=`` included), or ``None`` for a non-formula cell."""
        return self._read_formula_text(LIB.fm_workbook_get_formula, "fm_workbook_get_formula", sheet, row, col)

    def get_formula_r1c1(self, sheet: int, row: int, col: int) -> Optional[str]:
        """Return the formula in R1C1 notation relative to the cell, or ``None`` for a non-formula cell."""
        return self._read_formula_text(
            LIB.fm_workbook_get_formula_r1c1, "fm_workbook_get_formula_r1c1", sheet, row, col
        )

    def get_cells_in_range(
        self,
        sheet: int,
        cell_range: MergeRange,
        cursor: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> "tuple[List[Cell], Optional[int]]":
        """Return one page of the populated cells in ``cell_range`` (row-major).

        Pass the returned cursor back to fetch the next page; it is ``None``
        when the rectangle holds no further populated cell. ``limit`` of
        ``None`` or ``0`` means the engine maximum.
        """
        h = self._require()
        return self._read_cell_range_page(
            "fm_sheet_cells_in_range",
            LIB.fm_sheet_cells_in_range,
            h,
            _uint(sheet, "sheet_index"),
            _uint(cell_range.first_row, "first_row"),
            _uint(cell_range.first_col, "first_col"),
            _uint(cell_range.last_row, "last_row"),
            _uint(cell_range.last_col, "last_col"),
            _uint(cursor or 0, "cursor", 64),
            _uint(limit or 0, "limit"),
        )

    @staticmethod
    def _read_cell_range_page(op: str, fn, *args) -> "tuple[List[Cell], Optional[int]]":
        """Call a ``(..., fm_cell_range_t** out)`` ABI function and drain its page."""
        with _ArgScope() as scope:
            out = scope.out_ptr()
            _check(fn(*args, out), op)
            handle = LIB.read_u32(out)
        if handle == 0:
            raise FormulonError(
                _STATUS_BINDING_NULL_POINTER,
                op=op,
                _diagnostic_override=("returned kOk with a null cell-range handle", ""),
            )
        try:
            count = _read_count(LIB.fm_cell_range_count, handle)
            with _ArgScope() as scope:
                row_ptr = scope.out_ptr()
                col_ptr = scope.out_ptr()
                formula_ptr = scope.out_ptr()
                cursor_ptr = scope.out_u64()
                value_ptr = scope.alloc(fm_value_t_size)
                cells: List[Cell] = []
                for i in range(count):
                    LIB.write_bytes(formula_ptr, b"\x00\x00\x00\x00")
                    _check(
                        LIB.fm_cell_range_at(handle, _uint(i, "idx"), row_ptr, col_ptr, formula_ptr, value_ptr),
                        "fm_cell_range_at",
                    )
                    formula_addr = LIB.read_u32(formula_ptr)
                    cells.append(
                        Cell(
                            row=LIB.read_u32(row_ptr),
                            col=LIB.read_u32(col_ptr),
                            formula=LIB.read_cstr(formula_addr) if formula_addr else None,
                            value=Value._from_wasm(value_ptr),
                        )
                    )
                _check(LIB.fm_cell_range_next_cursor(handle, cursor_ptr), "fm_cell_range_next_cursor")
                next_cursor = struct.unpack("<Q", LIB.read_bytes(cursor_ptr, 8))[0]
        finally:
            LIB.fm_cell_range_destroy(handle)
        return cells, (None if next_cursor == _CELL_RANGE_NO_CURSOR else next_cursor)

    # -- AutoFilter ----------------------------------------------------------
    def _read_auto_filter(self, fn, index: int, op: str, index_name: str) -> Optional[AutoFilter]:
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.AUTO_FILTER)
            present = scope.out_ptr()
            _check(fn(h, _uint(index, index_name), ptr, present), op)
            if LIB.read_u32(present) == 0:
                return None
            return _decode_auto_filter(ptr)

    def _write_auto_filter(self, fn, index: int, auto_filter: AutoFilter, op: str, index_name: str) -> None:
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.AUTO_FILTER, 1)
            _pack_auto_filter(ptr, auto_filter, scope)
            _check(fn(h, _uint(index, index_name), ptr), op)

    def _evaluate_auto_filter(self, fn, index: int, op: str, index_name: str) -> "tuple[int, List[bool]]":
        h = self._require()
        with _ArgScope() as scope:
            len_ptr = scope.out_ptr()
            first_ptr = scope.out_ptr()
            buf = 0
            # Size the buffer first, then fetch.
            _check(fn(h, _uint(index, index_name), 0, 0, len_ptr, first_ptr), op)
            total = LIB.read_u32(len_ptr)
            if total == 0:
                return LIB.read_u32(first_ptr), []
            buf = scope.alloc(total)
            _check(fn(h, _uint(index, index_name), buf, total, len_ptr, first_ptr), op)
            flags = LIB.read_bytes(buf, total)
            return LIB.read_u32(first_ptr), [b != 0 for b in flags]

    def get_auto_filter(self, sheet: int) -> Optional[AutoFilter]:
        """Return the sheet AutoFilter, or ``None`` when the sheet has none."""
        return self._read_auto_filter(LIB.fm_sheet_get_auto_filter, sheet, "fm_sheet_get_auto_filter", "sheet_index")

    def set_auto_filter(self, sheet: int, auto_filter: AutoFilter) -> None:
        """Replace the sheet AutoFilter. Row visibility is unchanged; see :meth:`apply_auto_filter`."""
        self._write_auto_filter(
            LIB.fm_sheet_set_auto_filter, sheet, auto_filter, "fm_sheet_set_auto_filter", "sheet_index"
        )

    def remove_auto_filter(self, sheet: int) -> None:
        """Remove the sheet AutoFilter (no-op when absent). Row visibility is unchanged."""
        h = self._require()
        _check(LIB.fm_sheet_remove_auto_filter(h, _uint(sheet, "sheet_index")), "fm_sheet_remove_auto_filter")

    def apply_auto_filter(self, sheet: int) -> None:
        """Hide the body rows the sheet AutoFilter excludes and show the rest."""
        h = self._require()
        _check(LIB.fm_sheet_apply_auto_filter(h, _uint(sheet, "sheet_index")), "fm_sheet_apply_auto_filter")

    def clear_auto_filter(self, sheet: int) -> None:
        """Drop every column criterion of the sheet AutoFilter and show all its body rows."""
        h = self._require()
        _check(LIB.fm_sheet_clear_auto_filter(h, _uint(sheet, "sheet_index")), "fm_sheet_clear_auto_filter")

    def evaluate_auto_filter(self, sheet: int) -> "tuple[int, List[bool]]":
        """Evaluate the sheet AutoFilter without changing the sheet.

        Returns ``(first_row, match)``: body row ``first_row + i`` matches when
        ``match[i]`` is true.
        """
        return self._evaluate_auto_filter(
            LIB.fm_sheet_evaluate_auto_filter, sheet, "fm_sheet_evaluate_auto_filter", "sheet_index"
        )

    def get_table_auto_filter(self, table_index: int) -> Optional[AutoFilter]:
        """Return the AutoFilter of table ``table_index``, or ``None`` when it has none."""
        return self._read_auto_filter(
            LIB.fm_table_get_auto_filter, table_index, "fm_table_get_auto_filter", "table_index"
        )

    def set_table_auto_filter(self, table_index: int, auto_filter: AutoFilter) -> None:
        """Replace the AutoFilter of table ``table_index``."""
        self._write_auto_filter(
            LIB.fm_table_set_auto_filter, table_index, auto_filter, "fm_table_set_auto_filter", "table_index"
        )

    def remove_table_auto_filter(self, table_index: int) -> None:
        """Remove the AutoFilter of table ``table_index`` (no-op when absent)."""
        h = self._require()
        _check(LIB.fm_table_remove_auto_filter(h, _uint(table_index, "table_index")), "fm_table_remove_auto_filter")

    def apply_table_auto_filter(self, table_index: int) -> None:
        """Hide the body rows the table AutoFilter excludes and show the rest."""
        h = self._require()
        _check(LIB.fm_table_apply_auto_filter(h, _uint(table_index, "table_index")), "fm_table_apply_auto_filter")

    def clear_table_auto_filter(self, table_index: int) -> None:
        """Drop every column criterion of the table AutoFilter and show all its body rows."""
        h = self._require()
        _check(LIB.fm_table_clear_auto_filter(h, _uint(table_index, "table_index")), "fm_table_clear_auto_filter")

    def evaluate_table_auto_filter(self, table_index: int) -> "tuple[int, List[bool]]":
        """Evaluate the table AutoFilter; returns ``(first_row, match)`` as :meth:`evaluate_auto_filter`."""
        return self._evaluate_auto_filter(
            LIB.fm_table_evaluate_auto_filter, table_index, "fm_table_evaluate_auto_filter", "table_index"
        )

    # -- Validation checks -----------------------------------------------------
    def validate_value(self, sheet: int, row: int, col: int, value: Value) -> ValidationOutcome:
        """Check ``value`` against the data-validation rule covering ``(row, col)`` without storing it."""
        h = self._require()
        _check_value(value)
        with _ArgScope() as scope:
            value_ptr = scope.alloc(fm_value_t_size)
            ptr = scope.struct(S.VALIDATION_OUTCOME)
            _write_value_input(value, value_ptr, scope)
            _check(
                LIB.fm_sheet_validate_value(
                    h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), value_ptr, ptr
                ),
                "fm_sheet_validate_value",
            )
            d = S.VALIDATION_OUTCOME.unpack(LIB, ptr)
        return ValidationOutcome(
            has_rule=bool(d["has_rule"]),
            valid=bool(d["valid"]),
            rule_index=d["rule_index"],
            error_style=d["error_style"],
        )

    def list_invalid_cells(
        self, sheet: int, cursor: Optional[int] = None, limit: Optional[int] = None
    ) -> "tuple[List[Cell], Optional[int]]":
        """Return one page of the populated cells failing their data-validation rule (row-major).

        Paging follows :meth:`get_cells_in_range`: pass the returned cursor back
        for the next page; it is ``None`` once no further invalid cell exists.
        """
        h = self._require()
        return self._read_cell_range_page(
            "fm_sheet_list_invalid_cells",
            LIB.fm_sheet_list_invalid_cells,
            h,
            _uint(sheet, "sheet_index"),
            _uint(cursor or 0, "cursor", 64),
            _uint(limit or 0, "limit"),
        )

    # -- Threaded comments and persons -------------------------------------------
    def get_threaded_comments(self, sheet: int) -> List[ThreadedComment]:
        """Return the sheet's threaded comments in file order (openers followed by their replies)."""
        h = self._require()
        n = _read_count(LIB.fm_sheet_threaded_comment_count, h, _uint(sheet, "sheet_index"))
        with _ArgScope() as scope:
            ptr = scope.struct(S.THREADED_COMMENT)
            out: List[ThreadedComment] = []
            for i in range(n):
                S.zero_struct(LIB, S.THREADED_COMMENT, ptr)
                _check(
                    LIB.fm_sheet_threaded_comment_at(h, _uint(sheet, "sheet_index"), _uint(i, "idx"), ptr),
                    "fm_sheet_threaded_comment_at",
                )
                d = S.THREADED_COMMENT.unpack(LIB, ptr)
                out.append(
                    ThreadedComment(
                        id=LIB.read_cstr(d["id"]),
                        row=d["row"],
                        col=d["col"],
                        person_id=LIB.read_cstr(d["person_id"]),
                        created=LIB.read_cstr(d["created"]),
                        text=LIB.read_cstr(d["text"]),
                        parent_id=LIB.read_cstr(d["parent_id"]),
                        done=bool(d["done"]),
                        mentions=_decode_mentions(d["mentions"], d["mention_count"]),
                    )
                )
        return out

    def add_threaded_comment(self, sheet: int, comment: ThreadedComment) -> None:
        """Add a threaded comment: a new thread when ``parent_id`` is empty, else a reply."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.THREADED_COMMENT, 1)
            S.THREADED_COMMENT.pack(
                LIB,
                ptr,
                {
                    "row": _uint(comment.row, "row"),
                    "col": _uint(comment.col, "col"),
                    "done": 1 if comment.done else 0,
                },
            )
            for fld in ("id", "person_id", "created", "text", "parent_id"):
                S.write_str_field(LIB, ptr, S.THREADED_COMMENT, fld, getattr(comment, fld), scope)
            _write_mentions(ptr, S.THREADED_COMMENT, comment.mentions, scope)
            _check(
                LIB.fm_sheet_add_threaded_comment(h, _uint(sheet, "sheet_index"), ptr),
                "fm_sheet_add_threaded_comment",
            )

    def edit_threaded_comment(self, sheet: int, comment_id: str, text: str, mentions: Sequence[Mention] = ()) -> None:
        """Replace the text and mentions of the comment ``comment_id``."""
        h = self._require()
        with _ArgScope() as scope:
            id_ptr = scope.cstr(comment_id)
            text_ptr = scope.cstr(text)
            mentions_ptr = _pack_mentions(mentions, scope)
            _check(
                LIB.fm_sheet_edit_threaded_comment(
                    h, _uint(sheet, "sheet_index"), id_ptr, text_ptr, mentions_ptr, _uint(len(mentions), "count")
                ),
                "fm_sheet_edit_threaded_comment",
            )

    def set_thread_resolved(self, sheet: int, thread_id: str, done: bool) -> None:
        """Set the resolved state of the thread opened by ``thread_id``."""
        h = self._require()
        with _ArgScope() as scope:
            id_ptr = scope.cstr(thread_id)
            _check(
                LIB.fm_sheet_set_thread_resolved(h, _uint(sheet, "sheet_index"), id_ptr, 1 if done else 0),
                "fm_sheet_set_thread_resolved",
            )

    def remove_threaded_comment(self, sheet: int, comment_id: str) -> None:
        """Remove the comment ``comment_id``; removing a thread opener removes its whole thread."""
        h = self._require()
        with _ArgScope() as scope:
            id_ptr = scope.cstr(comment_id)
            _check(
                LIB.fm_sheet_remove_threaded_comment(h, _uint(sheet, "sheet_index"), id_ptr),
                "fm_sheet_remove_threaded_comment",
            )

    # -- Drawing images ------------------------------------------------------
    def probe_image(self, data: Union[bytes, bytearray, memoryview]) -> ImageInfo:
        """Sniff the format and pixel size of PNG, JPEG, GIF or BMP bytes without touching the workbook."""
        h = self._require()
        raw = bytes(data)
        with _ArgScope() as scope:
            buf = scope.buffer(raw)
            info = scope.struct(S.IMAGE_INFO)
            _check(LIB.fm_workbook_probe_image(h, buf, _uint(len(raw), "len"), info), "fm_workbook_probe_image")
            return _read_image_info(info)

    def list_drawing_objects(self, sheet: int) -> List[DrawingObject]:
        """Return the anchored objects of the sheet's drawing in document order."""
        h = self._require()
        n = _read_count(LIB.fm_sheet_drawing_object_count, h, _uint(sheet, "sheet_index"))
        with _ArgScope() as scope:
            ptr = scope.struct(S.DRAWING_OBJECT)
            out: List[DrawingObject] = []
            for i in range(n):
                S.zero_struct(LIB, S.DRAWING_OBJECT, ptr)
                _check(
                    LIB.fm_sheet_drawing_object_at(h, _uint(sheet, "sheet_index"), _uint(i, "idx"), ptr),
                    "fm_sheet_drawing_object_at",
                )
                d = S.DRAWING_OBJECT.unpack(LIB, ptr)
                out.append(
                    DrawingObject(
                        object_id=d["object_id"],
                        kind=d["kind"],
                        anchor_kind=d["anchor_kind"],
                        edit_as=d["edit_as"],
                        from_row=d["from_row"],
                        from_col=d["from_col"],
                        from_row_off=d["from_row_off"],
                        from_col_off=d["from_col_off"],
                        to_row=d["to_row"],
                        to_col=d["to_col"],
                        to_row_off=d["to_row_off"],
                        to_col_off=d["to_col_off"],
                        cx=d["cx"],
                        cy=d["cy"],
                        image_format=d["image_format"],
                        name=LIB.read_cstr(d["name"]),
                        descr=LIB.read_cstr(d["descr"]),
                        media_path=LIB.read_cstr(d["media_path"]),
                    )
                )
        return out

    def get_image(self, sheet: int, object_id: int) -> bytes:
        """Return the bytes of the picture ``object_id`` (copied out of WASM memory)."""
        h = self._require()
        with _ArgScope() as scope:
            bytes_ptr = scope.out_ptr()
            len_ptr = scope.out_ptr()
            info = scope.struct(S.IMAGE_INFO)
            _check(
                LIB.fm_sheet_get_image(
                    h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"), bytes_ptr, len_ptr, info
                ),
                "fm_sheet_get_image",
            )
            return LIB.read_bytes(LIB.read_u32(bytes_ptr), LIB.read_u32(len_ptr))

    def insert_image(
        self,
        sheet: int,
        data: Union[bytes, bytearray, memoryview],
        *,
        name: str = "",
        descr: str = "",
        anchor_kind: Union[AnchorKind, int] = AnchorKind.ONE_CELL,
        edit_as: Union[AnchorEditAs, int] = AnchorEditAs.TWO_CELL,
        row: int = 0,
        col: int = 0,
        row_off_emu: int = 0,
        col_off_emu: int = 0,
        width_emu: int = 0,
        height_emu: int = 0,
    ) -> int:
        """Insert an image anchored at ``(row, col)`` and return its object id.

        A ``width_emu`` or ``height_emu`` of ``0`` means the image's pixel size
        times 9525. ``edit_as`` is honoured for a two-cell anchor only.
        """
        h = self._require()
        raw = bytes(data)
        with _ArgScope() as scope:
            out = scope.out_ptr()
            buf = scope.buffer(raw)
            ptr = scope.struct_array(S.IMAGE_INSERT, 1)
            S.IMAGE_INSERT.pack(
                LIB,
                ptr,
                _image_anchor_fields(
                    anchor_kind,
                    edit_as,
                    row,
                    col,
                    row_off_emu,
                    col_off_emu,
                    width_emu,
                    height_emu,
                ),
            )
            S.write_str_field(LIB, ptr, S.IMAGE_INSERT, "name", name, scope)
            S.write_str_field(LIB, ptr, S.IMAGE_INSERT, "descr", descr, scope)
            _check(
                LIB.fm_sheet_insert_image(h, _uint(sheet, "sheet_index"), buf, _uint(len(raw), "len"), ptr, out),
                "fm_sheet_insert_image",
            )
            return LIB.read_u32(out)

    def remove_drawing(self, sheet: int, object_id: int) -> None:
        """Remove the picture or chart ``object_id`` and the parts only it reaches; other drawing content is kept."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_drawing(h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id")),
            "fm_sheet_remove_drawing",
        )

    def set_drawing_anchor(
        self,
        sheet: int,
        object_id: int,
        *,
        anchor_kind: Union[AnchorKind, int] = AnchorKind.ONE_CELL,
        edit_as: Union[AnchorEditAs, int] = AnchorEditAs.TWO_CELL,
        row: int = 0,
        col: int = 0,
        row_off_emu: int = 0,
        col_off_emu: int = 0,
        width_emu: int = 0,
        height_emu: int = 0,
    ) -> None:
        """Move and resize the picture or chart ``object_id``, keeping its id and every other element.

        The placement is in the quantities :meth:`list_drawing_objects`
        reports: ``(row, col)`` and the offsets are the top-left marker of the
        anchor box, ``width_emu`` and ``height_emu`` the object's own unrotated
        size (``cx`` and ``cy``); ``0`` keeps the current size. ``edit_as`` is
        honoured for a two-cell anchor only.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.DRAWING_ANCHOR, 1)
            S.DRAWING_ANCHOR.pack(
                LIB,
                ptr,
                _image_anchor_fields(
                    anchor_kind,
                    edit_as,
                    row,
                    col,
                    row_off_emu,
                    col_off_emu,
                    width_emu,
                    height_emu,
                ),
            )
            _check(
                LIB.fm_sheet_set_drawing_anchor(h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"), ptr),
                "fm_sheet_set_drawing_anchor",
            )

    def set_drawing_z_order(self, sheet: int, object_id: int, index: int) -> None:
        """Make the picture or chart ``object_id`` item ``index`` of :meth:`list_drawing_objects` (``0`` is the back)."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_drawing_z_order(
                h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"), _uint(index, "index")
            ),
            "fm_sheet_set_drawing_z_order",
        )

    def snapshot_drawing(self, sheet: int, object_id: int) -> bytes:
        """Capture the picture or chart ``object_id`` as opaque bytes for :meth:`restore_drawing`.

        The capture holds the object's list position, element and every part it reaches.
        """
        h = self._require()
        with _ArgScope() as scope:
            bytes_ptr = scope.out_ptr()
            len_ptr = scope.out_ptr()
            data_ptr = 0
            try:
                _check(
                    LIB.fm_sheet_snapshot_drawing(
                        h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"), bytes_ptr, len_ptr
                    ),
                    "fm_sheet_snapshot_drawing",
                )
                data_ptr = LIB.read_u32(bytes_ptr)
                return LIB.read_bytes(data_ptr, LIB.read_u32(len_ptr))
            finally:
                if data_ptr:
                    LIB.fm_buffer_free(data_ptr)

    def restore_drawing(self, sheet: int, data: Union[bytes, bytearray, memoryview], *, new_id: bool = False) -> int:
        """Put a :meth:`snapshot_drawing` capture back and return the object's id.

        An object with the same id is replaced and the capture returns to its
        recorded list position. With ``new_id`` it is added on top as a copy
        with a fresh id.
        """
        h = self._require()
        raw = bytes(data)
        with _ArgScope() as scope:
            buf = scope.buffer(raw)
            out = scope.out_ptr()
            _check(
                LIB.fm_sheet_restore_drawing(
                    h, _uint(sheet, "sheet_index"), buf, _uint(len(raw), "len"), 1 if new_id else 0, out
                ),
                "fm_sheet_restore_drawing",
            )
            return LIB.read_u32(out)

    def list_shapes(self, sheet: int) -> List[Shape]:
        """Return the shapes, connectors and groups of the sheet's drawing in z-order (back first).

        Children of a group are not listed.
        """
        h = self._require()
        n = _read_count(LIB.fm_sheet_shape_count, h, _uint(sheet, "sheet_index"))
        with _ArgScope() as scope:
            ptr = scope.struct(S.SHAPE)
            out: List[Shape] = []
            for i in range(n):
                S.zero_struct(LIB, S.SHAPE, ptr)
                _check(LIB.fm_sheet_shape_at(h, _uint(sheet, "sheet_index"), _uint(i, "idx"), ptr), "fm_sheet_shape_at")
                d = S.SHAPE.unpack(LIB, ptr)
                out.append(
                    Shape(
                        object_id=d["object_id"],
                        kind=d["kind"],
                        anchor_kind=d["anchor_kind"],
                        edit_as=d["edit_as"],
                        from_row=d["from_row"],
                        from_col=d["from_col"],
                        from_row_off=d["from_row_off"],
                        from_col_off=d["from_col_off"],
                        to_row=d["to_row"],
                        to_col=d["to_col"],
                        to_row_off=d["to_row_off"],
                        to_col_off=d["to_col_off"],
                        cx=d["cx"],
                        cy=d["cy"],
                        name=LIB.read_cstr(d["name"]),
                        prst=LIB.read_cstr(d["prst"]),
                        text=LIB.read_cstr(d["text"]),
                        text_box=bool(d["text_box"]),
                        fill_kind=d["fill_kind"],
                        fill_rgb=d["fill_rgb"],
                        line_kind=d["line_kind"],
                        line_rgb=d["line_rgb"],
                        line_width_emu=d["line_width_emu"],
                        rotation=d["rotation"],
                        hidden=bool(d["hidden"]),
                    )
                )
        return out

    def insert_shape(
        self,
        sheet: int,
        *,
        anchor_kind: Union[AnchorKind, int],
        edit_as: Union[AnchorEditAs, int] = AnchorEditAs.TWO_CELL,
        from_row: int = 0,
        from_col: int = 0,
        from_row_off: int = 0,
        from_col_off: int = 0,
        to_row: int = 0,
        to_col: int = 0,
        to_row_off: int = 0,
        to_col_off: int = 0,
        cx: int = 0,
        cy: int = 0,
        name: Optional[str] = None,
        prst: Optional[str] = None,
        text: Optional[str] = None,
        text_box: Optional[bool] = None,
        fill_kind: Optional[Union[ShapePaint, int]] = None,
        fill_rgb: int = 0,
        line_kind: Optional[Union[ShapePaint, int]] = None,
        line_rgb: int = 0,
        line_width_emu: Optional[int] = None,
        rotation: Optional[int] = None,
        hidden: Optional[bool] = None,
    ) -> int:
        """Append a shape on top of the sheet's drawing and return its object id.

        A ``None`` argument is not applied. ``prst`` defaults to ``rect`` and
        ``name`` to ``Shape <id>``; a ``prst`` naming a line or connector
        geometry makes a connector, which holds no text. A two-cell anchor's
        size is its box (``cx`` / ``cy`` are ignored); an absolute anchor's
        position is ``from_col_off`` (x) and ``from_row_off`` (y). ``fill_kind``
        and ``line_kind`` must be ``SOLID`` (with the rgb) or ``NONE``.
        """
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            ptr = _pack_shape(
                scope, name, prst, text, text_box, anchor_kind, edit_as, from_row, from_col, from_row_off,
                from_col_off, to_row, to_col, to_row_off, to_col_off, cx, cy, fill_kind, fill_rgb, line_kind,
                line_rgb, line_width_emu, rotation, hidden,
            )  # fmt: skip
            _check(LIB.fm_sheet_insert_shape(h, _uint(sheet, "sheet_index"), ptr, out), "fm_sheet_insert_shape")
            return LIB.read_u32(out)

    def update_shape(
        self,
        sheet: int,
        object_id: int,
        *,
        anchor_kind: Optional[Union[AnchorKind, int]] = None,
        edit_as: Union[AnchorEditAs, int] = AnchorEditAs.TWO_CELL,
        from_row: int = 0,
        from_col: int = 0,
        from_row_off: int = 0,
        from_col_off: int = 0,
        to_row: int = 0,
        to_col: int = 0,
        to_row_off: int = 0,
        to_col_off: int = 0,
        cx: int = 0,
        cy: int = 0,
        name: Optional[str] = None,
        prst: Optional[str] = None,
        text: Optional[str] = None,
        text_box: Optional[bool] = None,
        fill_kind: Optional[Union[ShapePaint, int]] = None,
        fill_rgb: int = 0,
        line_kind: Optional[Union[ShapePaint, int]] = None,
        line_rgb: int = 0,
        line_width_emu: Optional[int] = None,
        rotation: Optional[int] = None,
        hidden: Optional[bool] = None,
    ) -> None:
        """Apply the arguments that are not ``None`` to the shape ``object_id``; the rest of its XML is kept.

        The anchor is applied as a whole when ``anchor_kind`` is given, and its
        kind cannot change. Text applies to a shape only and keeps the first
        paragraph's properties and first run's formatting.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = _pack_shape(
                scope, name, prst, text, text_box, anchor_kind, edit_as, from_row, from_col, from_row_off,
                from_col_off, to_row, to_col, to_row_off, to_col_off, cx, cy, fill_kind, fill_rgb, line_kind,
                line_rgb, line_width_emu, rotation, hidden,
            )  # fmt: skip
            _check(
                LIB.fm_sheet_update_shape(h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"), ptr),
                "fm_sheet_update_shape",
            )

    def remove_shape(self, sheet: int, object_id: int) -> None:
        """Remove the shape, connector or group ``object_id`` with its children."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_shape(h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id")),
            "fm_sheet_remove_shape",
        )

    def list_slicers(self, sheet: int) -> List[Slicer]:
        """Return the table slicers hosted by the sheet; slicers over a pivot cache are not listed."""
        h = self._require()
        n = _read_count(LIB.fm_sheet_slicer_count, h, _uint(sheet, "sheet_index"))
        with _ArgScope() as scope:
            ptr = scope.struct(S.SLICER)
            out: List[Slicer] = []
            for i in range(n):
                S.zero_struct(LIB, S.SLICER, ptr)
                _check(
                    LIB.fm_sheet_slicer_at(h, _uint(sheet, "sheet_index"), _uint(i, "idx"), ptr), "fm_sheet_slicer_at"
                )
                d = S.SLICER.unpack(LIB, ptr)
                out.append(
                    Slicer(
                        object_id=d["object_id"],
                        name=LIB.read_cstr(d["name"]),
                        caption=LIB.read_cstr(d["caption"]),
                        cache_name=LIB.read_cstr(d["cache_name"]),
                        table_name=LIB.read_cstr(d["table_name"]),
                        column_name=LIB.read_cstr(d["column_name"]),
                        style=LIB.read_cstr(d["style"]),
                        column_count=d["column_count"],
                        row_height=d["row_height"],
                        sort_order=d["sort_order"],
                        cross_filter=d["cross_filter"],
                        anchor_kind=d["anchor_kind"],
                        from_row=d["from_row"],
                        from_col=d["from_col"],
                        from_row_off=d["from_row_off"],
                        from_col_off=d["from_col_off"],
                        to_row=d["to_row"],
                        to_col=d["to_col"],
                        to_row_off=d["to_row_off"],
                        to_col_off=d["to_col_off"],
                    )
                )
        return out

    def add_slicer(
        self,
        sheet: int,
        table: int,
        column: int,
        *,
        anchor: Sequence[int],
        name: Optional[str] = None,
        caption: Optional[str] = None,
        style: Optional[str] = None,
        column_count: Optional[int] = None,
        row_height: Optional[int] = None,
        sort_order: Optional[Union[SlicerSortOrder, int]] = None,
        cross_filter: Optional[Union[SlicerCrossFilter, int]] = None,
    ) -> int:
        """Add a slicer over column ``column`` of table ``table`` and return its frame's object id.

        ``anchor`` is ``(from_row, from_col, to_row, to_col)`` (0-based cells), optionally followed by the four
        EMU offsets ``(from_row_off, from_col_off, to_row_off, to_col_off)``. The name and caption default to
        the column name (the name is made unique), ``row_height`` to 241300 EMU and ``column_count`` to 1. The
        table may live on another sheet.
        """
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            ptr = _pack_slicer(scope, name, caption, style, column_count, row_height, anchor, sort_order, cross_filter)
            _check(
                LIB.fm_sheet_add_slicer(
                    h, _uint(sheet, "sheet_index"), _uint(table, "table_index"), _uint(column, "column_index"), ptr, out
                ),
                "fm_sheet_add_slicer",
            )
            return LIB.read_u32(out)

    def update_slicer(
        self,
        sheet: int,
        index: int,
        *,
        anchor: Optional[Sequence[int]] = None,
        caption: Optional[str] = None,
        style: Optional[str] = None,
        column_count: Optional[int] = None,
        row_height: Optional[int] = None,
        sort_order: Optional[Union[SlicerSortOrder, int]] = None,
        cross_filter: Optional[Union[SlicerCrossFilter, int]] = None,
    ) -> None:
        """Apply the arguments that are not ``None`` to slicer ``index``; the rest of its XML is kept.

        An empty ``style`` removes the style. ``anchor`` moves the slicer's two-cell frame (see :meth:`add_slicer`).
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = _pack_slicer(scope, None, caption, style, column_count, row_height, anchor, sort_order, cross_filter)
            _check(
                LIB.fm_sheet_update_slicer(h, _uint(sheet, "sheet_index"), _uint(index, "idx"), ptr),
                "fm_sheet_update_slicer",
            )

    def remove_slicer(self, sheet: int, index: int) -> None:
        """Remove slicer ``index`` with its drawing frame, and its cache when no other slicer uses it."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_slicer(h, _uint(sheet, "sheet_index"), _uint(index, "idx")),
            "fm_sheet_remove_slicer",
        )

    def add_data_table(
        self,
        sheet: int,
        first_row: int,
        first_col: int,
        last_row: int,
        last_col: int,
        *,
        row_input: Optional[Tuple[int, int]] = None,
        col_input: Optional[Tuple[int, int]] = None,
    ) -> None:
        """Create a data table whose result range is ``first_row``..``last_col`` (0-based, inclusive).

        The formulas sit in the row above the range and the substitution values in the column left of it (a
        one-variable table), or the other way round; ``row_input`` / ``col_input`` are the ``(row, col)`` input
        cells that receive the values of the row above / the column left. Give one for a one-variable table, both
        for a two-variable one. The result cells read 0 until the next recalc and refuse writes until the table
        is removed.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.DATA_TABLE, 1)
            values: Dict[str, int] = {
                "first_row": _uint(first_row, "first_row"),
                "first_col": _uint(first_col, "first_col"),
                "last_row": _uint(last_row, "last_row"),
                "last_col": _uint(last_col, "last_col"),
            }
            for prefix, cell in (("row_input", row_input), ("col_input", col_input)):
                if cell is not None:
                    values["has_" + prefix] = 1
                    values[prefix + "_row"] = _uint(cell[0], prefix + "_row")
                    values[prefix + "_col"] = _uint(cell[1], prefix + "_col")
            S.DATA_TABLE.pack(LIB, ptr, values)
            _check(LIB.fm_sheet_add_data_table(h, _uint(sheet, "sheet_index"), ptr), "fm_sheet_add_data_table")

    def get_data_table(self, sheet: int, row: int, col: int) -> Optional[DataTable]:
        """Return the data table whose result range contains ``(row, col)``, or ``None``."""
        h = self._require()
        with _ArgScope() as scope:
            present = scope.out_ptr()
            ptr = scope.struct(S.DATA_TABLE)
            _check(
                LIB.fm_sheet_data_table_at(
                    h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), present, ptr
                ),
                "fm_sheet_data_table_at",
            )
            if not LIB.read_u32(present):
                return None
            d = S.DATA_TABLE.unpack(LIB, ptr)

        def _input(prefix: str) -> Optional[DataTableInput]:
            if not d["has_" + prefix]:
                return None
            return DataTableInput(d[prefix + "_row"], d[prefix + "_col"], bool(d[prefix + "_deleted"]))

        return DataTable(
            first_row=d["first_row"],
            first_col=d["first_col"],
            last_row=d["last_row"],
            last_col=d["last_col"],
            two_dimensional=bool(d["two_dimensional"]),
            row_oriented=bool(d["row_oriented"]),
            row_input=_input("row_input"),
            col_input=_input("col_input"),
        )

    def remove_data_table(self, sheet: int, row: int, col: int) -> None:
        """Remove the data table containing ``(row, col)`` and blank its result cells."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_data_table(h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col")),
            "fm_sheet_remove_data_table",
        )

    def recalc_data_tables(self) -> None:
        """Recompute every data table now, whatever the calc mode (the explicit calculation of ``AUTO_NO_TABLE``)."""
        _check(LIB.fm_workbook_recalc_data_tables(self._require()), "fm_workbook_recalc_data_tables")

    def list_sparkline_groups(self, sheet: int) -> List[SparklineGroup]:
        """Return the sheet's sparkline groups in document order, each with its sparklines."""
        h = self._require()
        n = _read_count(LIB.fm_sheet_sparkline_group_count, h, _uint(sheet, "sheet_index"))
        with _ArgScope() as scope:
            group_ptr = scope.struct(S.SPARKLINE_GROUP)
            item_ptr = scope.struct(S.SPARKLINE)
            out: List[SparklineGroup] = []
            for i in range(n):
                S.zero_struct(LIB, S.SPARKLINE_GROUP, group_ptr)
                _check(
                    LIB.fm_sheet_sparkline_group_at(h, _uint(sheet, "sheet_index"), _uint(i, "idx"), group_ptr),
                    "fm_sheet_sparkline_group_at",
                )
                d = S.SPARKLINE_GROUP.unpack(LIB, group_ptr)
                group = SparklineGroup(
                    type=d["type"],
                    color_series=_decode_color(group_ptr + S.SPARKLINE_GROUP.offsets["color_series"][1]),
                    color_negative=_decode_color(group_ptr + S.SPARKLINE_GROUP.offsets["color_negative"][1]),
                    color_axis=_decode_color(group_ptr + S.SPARKLINE_GROUP.offsets["color_axis"][1]),
                    color_markers=_decode_color(group_ptr + S.SPARKLINE_GROUP.offsets["color_markers"][1]),
                    color_first=_decode_color(group_ptr + S.SPARKLINE_GROUP.offsets["color_first"][1]),
                    color_last=_decode_color(group_ptr + S.SPARKLINE_GROUP.offsets["color_last"][1]),
                    color_high=_decode_color(group_ptr + S.SPARKLINE_GROUP.offsets["color_high"][1]),
                    color_low=_decode_color(group_ptr + S.SPARKLINE_GROUP.offsets["color_low"][1]),
                    markers=bool(d["markers"]),
                    high=bool(d["high"]),
                    low=bool(d["low"]),
                    first=bool(d["first"]),
                    last=bool(d["last"]),
                    negative=bool(d["negative"]),
                    display_x_axis=bool(d["display_x_axis"]),
                    display_hidden=bool(d["display_hidden"]),
                    min_axis_type=d["min_axis_type"],
                    max_axis_type=d["max_axis_type"],
                    manual_min=d["manual_min"] if d["has_manual_min"] else None,
                    manual_max=d["manual_max"] if d["has_manual_max"] else None,
                    date_axis=bool(d["date_axis"]),
                    date_axis_ref=LIB.read_cstr(d["date_axis_ref"]),
                    line_weight=d["line_weight"],
                    empty_cells_as=d["empty_cells_as"],
                )
                for k in range(d["sparkline_count"]):
                    S.zero_struct(LIB, S.SPARKLINE, item_ptr)
                    _check(
                        LIB.fm_sheet_sparkline_at(
                            h, _uint(sheet, "sheet_index"), _uint(i, "idx"), _uint(k, "idx"), item_ptr
                        ),
                        "fm_sheet_sparkline_at",
                    )
                    item = S.SPARKLINE.unpack(LIB, item_ptr)
                    group.sparklines.append(
                        Sparkline(formula=LIB.read_cstr(item["formula"]), location=LIB.read_cstr(item["location"]))
                    )
                out.append(group)
        return out

    def add_sparkline_group(self, sheet: int, group: SparklineGroup) -> None:
        """Append ``group`` with its ``sparklines`` (at least one) to the sheet's worksheet extension list."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = _pack_sparkline_group(scope, group)
            items = _pack_sparklines(scope, group.sparklines)
            _check(
                LIB.fm_sheet_add_sparkline_group(
                    h, _uint(sheet, "sheet_index"), ptr, items, _uint(len(group.sparklines), "count")
                ),
                "fm_sheet_add_sparkline_group",
            )

    def update_sparkline_group(self, sheet: int, index: int, group: SparklineGroup) -> None:
        """Rewrite the modelled attributes, colours and date range of group ``index`` from ``group``.

        Its sparklines (``group.sparklines`` is ignored) and every attribute or
        child outside the model are kept; read, modify and write back.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = _pack_sparkline_group(scope, group)
            _check(
                LIB.fm_sheet_update_sparkline_group(h, _uint(sheet, "sheet_index"), _uint(index, "idx"), ptr),
                "fm_sheet_update_sparkline_group",
            )

    def set_sparkline_group_sparklines(self, sheet: int, index: int, sparklines: Sequence[Sparkline]) -> None:
        """Replace the sparklines of group ``index`` with ``sparklines`` (at least one)."""
        h = self._require()
        with _ArgScope() as scope:
            items = _pack_sparklines(scope, sparklines)
            _check(
                LIB.fm_sheet_set_sparkline_group_sparklines(
                    h, _uint(sheet, "sheet_index"), _uint(index, "idx"), items, _uint(len(sparklines), "count")
                ),
                "fm_sheet_set_sparkline_group_sparklines",
            )

    def remove_sparkline_group(self, sheet: int, index: int) -> None:
        """Remove sparkline group ``index``."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_sparkline_group(h, _uint(sheet, "sheet_index"), _uint(index, "idx")),
            "fm_sheet_remove_sparkline_group",
        )

    def get_chart(self, sheet: int, object_id: int) -> ChartInfo:
        """Return the typed view of the chart ``object_id``: plots, series, axes, legend and source.

        Raises :class:`FormulonError` when the sheet has no chart with that id
        or the chart part does not parse.
        """
        h = self._require()
        chart = _read_count(LIB.fm_sheet_chart_open, h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"))
        try:
            return _read_chart(chart)
        finally:
            LIB.fm_chart_destroy(chart)

    def get_chart_data(self, sheet: int, object_id: int) -> ChartData:
        """Resolve the chart's series against the current cell values by Excel's rules."""
        h = self._require()
        data = _read_count(LIB.fm_sheet_chart_data_open, h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"))
        try:
            return _read_chart_data(data)
        finally:
            LIB.fm_chart_data_destroy(data)

    def preview_chart_data(
        self, sheet: int, object_id: int, overrides: Optional[ChartPreviewOverrides] = None
    ) -> ChartData:
        """Resolve the data of a copy of the chart with ``overrides`` applied; the workbook is unchanged.

        Series are rebuilt as :meth:`set_chart_source` does: over the
        overridden ``source`` (an unset direction or header is auto), else over
        the chart's derived range.
        """
        h = self._require()
        overrides = overrides or {}
        with _ArgScope() as scope:
            fields = _encode_patch(_PREVIEW_OVERRIDE_SPEC, overrides, ("source",), "preview override", scope)
            if "source" in overrides:
                fields["source"] = scope.cstr(overrides["source"])
            ptr = scope.struct(S.CHART_PREVIEW_OVERRIDES)
            S.CHART_PREVIEW_OVERRIDES.pack(LIB, ptr, fields)
            data = _read_count(
                LIB.fm_sheet_chart_preview_open,
                h,
                _uint(sheet, "sheet_index"),
                _uint(object_id, "object_id"),
                ptr,
            )
        try:
            return _read_chart_data(data)
        finally:
            if data:
                LIB.fm_chart_data_destroy(data)

    def insert_chart(
        self,
        sheet: int,
        kind: Union[ChartInsertKind, int],
        source: str,
        *,
        grouping: Union[ChartGrouping, int] = ChartGrouping.CLUSTERED,
        direction: Union[ChartSeriesDirection, int] = ChartSeriesDirection.AUTO,
        header_row: Optional[bool] = None,
        header_column: Optional[bool] = None,
        title: Optional[str] = None,
        legend: Union[ChartLegendPosition, int] = ChartLegendPosition.BOTTOM,
        name: str = "",
        description: str = "",
        anchor_kind: Union[AnchorKind, int] = AnchorKind.TWO_CELL,
        edit_as: Union[AnchorEditAs, int] = AnchorEditAs.TWO_CELL,
        row: int = 0,
        col: int = 0,
        row_off_emu: int = 0,
        col_off_emu: int = 0,
        width_emu: int = 0,
        height_emu: int = 0,
    ) -> int:
        """Create a chart over the A1 rectangle ``source`` and return its object id.

        ``source`` is sheet-qualified or on ``sheet``. ``grouping`` applies to
        column, bar, line and area charts. ``header_row`` / ``header_column``
        ``None`` follow Excel's detection. ``title`` is ``None`` for Excel's
        automatic title, ``""`` for none, else the text. The placement reads as
        for :meth:`insert_image` (an empty ``name`` becomes ``Chart <id>``),
        except that a zero ``width_emu`` or ``height_emu`` means Excel's default
        360 x 216 pt frame and the anchor defaults to two-cell.
        """
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            ptr = scope.struct_array(S.CHART_INSERT, 1)
            placement = _image_anchor_fields(
                anchor_kind, edit_as, row, col, row_off_emu, col_off_emu, width_emu, height_emu
            )
            placement["name"] = scope.nonempty_cstr(name)
            placement["descr"] = scope.nonempty_cstr(description)
            S.CHART_INSERT.pack(
                LIB,
                ptr,
                {
                    "kind": _sint(kind, "kind"),
                    "grouping": _sint(grouping, "grouping"),
                    "source": scope.cstr(source),
                    "direction": _sint(direction, "direction"),
                    "header_row": _sint(_header_mode(header_row), "header_row"),
                    "header_column": _sint(_header_mode(header_column), "header_column"),
                    "title": scope.opt_cstr(title),
                    "legend": _sint(legend, "legend"),
                    "placement": placement,
                },
            )
            _check(LIB.fm_sheet_insert_chart(h, _uint(sheet, "sheet_index"), ptr, out), "fm_sheet_insert_chart")
            return LIB.read_u32(out)

    def set_chart_type(
        self,
        sheet: int,
        object_id: int,
        plot: int,
        kind: Union[ChartInsertKind, int],
        grouping: Union[ChartGrouping, int] = ChartGrouping.CLUSTERED,
    ) -> None:
        """Replace plot group ``plot`` with ``kind``, keeping each series' references, idx, order and explicit colors."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_chart_type(
                h,
                _uint(sheet, "sheet_index"),
                _uint(object_id, "object_id"),
                _uint(plot, "plot"),
                _sint(kind, "kind"),
                _sint(grouping, "grouping"),
            ),
            "fm_sheet_set_chart_type",
        )

    def set_chart_title(self, sheet: int, object_id: int, title: Union[str, None, ChartTitleInfo]) -> None:
        """Set the chart title to ``title``; ``None`` removes it.

        A :class:`ChartTitleInfo` sets that kind, so ``ChartTitleInfo(ChartTitleKind.AUTO, "", "")``
        returns the title to Excel's automatic one.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.CHART_TITLE, 1)
            fields = {"kind": 0} if title is None else _title_fields(title, scope)
            S.CHART_TITLE.pack(LIB, ptr, fields)
            _check(
                LIB.fm_sheet_set_chart_title(h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"), ptr),
                "fm_sheet_set_chart_title",
            )

    def set_chart_legend(
        self,
        sheet: int,
        object_id: int,
        position: Union[ChartLegendPosition, int],
        overlay: bool = False,
        *,
        hidden_series: Optional[Sequence[int]] = None,
    ) -> None:
        """Set the legend position (``NONE`` removes it) and overlay.

        ``hidden_series`` replaces the hidden legend entries (series ``c:idx``
        values); ``None`` leaves them alone.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.CHART_LEGEND_PATCH, 1)
            fields: Dict[str, object] = {"position": _sint(position, "position"), "overlay": 1 if overlay else 0}
            if hidden_series is not None:
                fields["hidden_series_op"] = 2
                fields["hidden_series"] = _id_array(hidden_series, "hidden_series", scope)
                fields["hidden_series_count"] = _uint(len(hidden_series), "hidden_series_count")
            S.CHART_LEGEND_PATCH.pack(LIB, ptr, fields)
            _check(
                LIB.fm_sheet_set_chart_legend(h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"), ptr),
                "fm_sheet_set_chart_legend",
            )

    def set_chart_axis(self, sheet: int, object_id: int, axis_id: int, patch: ChartAxisPatch) -> None:
        """Patch axis ``axis_id``: an omitted key is kept, ``None`` removes the element."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.CHART_AXIS_PATCH, 1)
            fields = _encode_axis_patch(patch, scope)
            S.CHART_AXIS_PATCH.pack(LIB, ptr, fields)
            _check(
                LIB.fm_sheet_set_chart_axis(
                    h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"), _uint(axis_id, "axis_id"), ptr
                ),
                "fm_sheet_set_chart_axis",
            )

    def set_chart_display(
        self,
        sheet: int,
        object_id: int,
        blanks_as: Union[ChartBlanksAs, int],
        plot_visible_only: Optional[bool],
    ) -> None:
        """Write how blanks plot and whether hidden cells are skipped; ``ABSENT`` / ``None`` remove the element."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_chart_display(
                h,
                _uint(sheet, "sheet_index"),
                _uint(object_id, "object_id"),
                _sint(blanks_as, "blanks_as"),
                _sint(_tri_flag(plot_visible_only), "plot_vis_only"),
            ),
            "fm_sheet_set_chart_display",
        )

    def set_chart_series(self, sheet: int, object_id: int, plot: int, series_idx: int, patch: ChartSeriesPatch) -> None:
        """Patch the series with ``c:idx`` ``series_idx`` of plot group ``plot``; a changed reference refreshes its cache."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.CHART_SERIES_PATCH, 1)
            fields = _encode_series_patch(patch, scope)
            S.CHART_SERIES_PATCH.pack(LIB, ptr, fields)
            _check(
                LIB.fm_sheet_set_chart_series(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(object_id, "object_id"),
                    _uint(plot, "plot"),
                    _uint(series_idx, "series_idx"),
                    ptr,
                ),
                "fm_sheet_set_chart_series",
            )

    def set_chart_point(
        self,
        sheet: int,
        object_id: int,
        plot: int,
        series_idx: int,
        point_idx: int,
        patch: Optional[ChartPointPatch],
    ) -> None:
        """Patch point ``point_idx`` of a series; ``None`` (or an empty patch) removes the point's formatting."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.CHART_POINT_PATCH, 1)
            fields = _encode_point_patch(patch, scope)
            S.CHART_POINT_PATCH.pack(LIB, ptr, fields)
            _check(
                LIB.fm_sheet_set_chart_point(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(object_id, "object_id"),
                    _uint(plot, "plot"),
                    _uint(series_idx, "series_idx"),
                    _uint(point_idx, "point_idx"),
                    ptr,
                ),
                "fm_sheet_set_chart_point",
            )

    def set_chart_plot(self, sheet: int, object_id: int, plot: int, patch: ChartPlotPatch) -> None:
        """Patch plot group ``plot``; a field the plot type does not have is rejected."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.CHART_PLOT_PATCH, 1)
            fields = _encode_patch(_PLOT_PATCH_SPEC, patch, (), "plot patch", scope)
            S.CHART_PLOT_PATCH.pack(LIB, ptr, fields)
            _check(
                LIB.fm_sheet_set_chart_plot(
                    h, _uint(sheet, "sheet_index"), _uint(object_id, "object_id"), _uint(plot, "plot"), ptr
                ),
                "fm_sheet_set_chart_plot",
            )

    def set_chart_filter(
        self,
        sheet: int,
        object_id: int,
        hidden_series: Sequence[int],
        hidden_categories: Sequence[int],
    ) -> None:
        """Replace the chart filter: the listed series (by ``c:idx``) and category positions are hidden."""
        h = self._require()
        with _ArgScope() as scope:
            _check(
                LIB.fm_sheet_set_chart_filter(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(object_id, "object_id"),
                    _id_array(hidden_series, "hidden_series", scope),
                    _uint(len(hidden_series), "hidden_series_count"),
                    _id_array(hidden_categories, "hidden_categories", scope),
                    _uint(len(hidden_categories), "hidden_category_count"),
                ),
                "fm_sheet_set_chart_filter",
            )

    def add_chart_series(self, sheet: int, object_id: int, plot: int, patch: ChartSeriesPatch) -> int:
        """Append a series to plot group ``plot`` and return its ``c:idx``.

        ``patch`` must set ``values`` (``y`` for a scatter plot).
        """
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            ptr = scope.struct_array(S.CHART_SERIES_PATCH, 1)
            fields = _encode_series_patch(patch, scope)
            S.CHART_SERIES_PATCH.pack(LIB, ptr, fields)
            _check(
                LIB.fm_sheet_add_chart_series(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(object_id, "object_id"),
                    _uint(plot, "plot"),
                    ptr,
                    out,
                ),
                "fm_sheet_add_chart_series",
            )
            return LIB.read_u32(out)

    def remove_chart_series(self, sheet: int, object_id: int, plot: int, series_idx: int) -> None:
        """Remove the series with ``c:idx`` ``series_idx`` from plot group ``plot``."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_chart_series(
                h,
                _uint(sheet, "sheet_index"),
                _uint(object_id, "object_id"),
                _uint(plot, "plot"),
                _uint(series_idx, "series_idx"),
            ),
            "fm_sheet_remove_chart_series",
        )

    def set_chart_source(
        self,
        sheet: int,
        object_id: int,
        source: str,
        direction: Union[ChartSeriesDirection, int] = ChartSeriesDirection.AUTO,
        header_row: Optional[bool] = None,
        header_column: Optional[bool] = None,
    ) -> None:
        """Rebuild every series from ``source`` by the insert splitting rules.

        The chart kind and each series' formatting (by idx) are kept and the
        filter is cleared. ``header_row`` / ``header_column`` ``None`` follow
        Excel's detection.
        """
        h = self._require()
        with _ArgScope() as scope:
            _check(
                LIB.fm_sheet_set_chart_source(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(object_id, "object_id"),
                    scope.cstr(source),
                    _sint(direction, "direction"),
                    _sint(_header_mode(header_row), "header_row"),
                    _sint(_header_mode(header_column), "header_column"),
                ),
                "fm_sheet_set_chart_source",
            )

    def get_persons(self) -> List[Person]:
        """Return the workbook's person list in file order."""
        h = self._require()
        n = _read_count(LIB.fm_workbook_person_count, h)
        with _ArgScope() as scope:
            ptr = scope.struct(S.PERSON)
            out: List[Person] = []
            for i in range(n):
                S.zero_struct(LIB, S.PERSON, ptr)
                _check(LIB.fm_workbook_person_at(h, _uint(i, "idx"), ptr), "fm_workbook_person_at")
                d = S.PERSON.unpack(LIB, ptr)
                out.append(
                    Person(
                        id=LIB.read_cstr(d["id"]),
                        display_name=LIB.read_cstr(d["display_name"]),
                        user_id=LIB.read_cstr(d["user_id"]),
                        provider_id=LIB.read_cstr(d["provider_id"]),
                    )
                )
        return out

    def add_person(self, person: Person) -> None:
        """Append a person to the workbook's person list."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct_array(S.PERSON, 1)
            for fld in ("id", "display_name", "user_id", "provider_id"):
                S.write_str_field(LIB, ptr, S.PERSON, fld, getattr(person, fld), scope)
            _check(LIB.fm_workbook_add_person(h, ptr), "fm_workbook_add_person")

    def remove_person(self, person_id: str) -> None:
        """Remove the person ``person_id`` (refused while a comment or mention still names them)."""
        h = self._require()
        with _ArgScope() as scope:
            id_ptr = scope.cstr(person_id)
            _check(LIB.fm_workbook_remove_person(h, id_ptr), "fm_workbook_remove_person")

    def get_merges_in_range(self, sheet: int, cell_range: MergeRange) -> List[MergeRange]:
        """Return every merge range on ``sheet`` that intersects ``cell_range``."""
        h = self._require()
        with _ArgScope() as scope:
            range_ptr = _pack_merge_array([cell_range], scope)
            count_ptr = scope.out_ptr()
            # Size the buffer first, then fetch.
            _check(
                LIB.fm_sheet_merges_in_range(h, _uint(sheet, "sheet_index"), range_ptr, 0, 0, count_ptr),
                "fm_sheet_merges_in_range",
            )
            total = LIB.read_u32(count_ptr)
            if total == 0:
                return []
            size = S.MERGE_RANGE.size
            buf = scope.struct_array(S.MERGE_RANGE, total)
            _check(
                LIB.fm_sheet_merges_in_range(
                    h, _uint(sheet, "sheet_index"), range_ptr, buf, _uint(total, "capacity"), count_ptr
                ),
                "fm_sheet_merges_in_range",
            )
            out: List[MergeRange] = []
            for i in range(min(total, LIB.read_u32(count_ptr))):
                out.append(_decode_merge_at(buf + i * size))
            return out

    def get_display_text(self, sheet: int, row: int, col: int) -> "tuple[str, DisplayStatus]":
        """Return the text Excel displays for the cell and the rendering outcome."""
        h = self._require()
        with _ArgScope() as scope:
            text_ptr = scope.out_ptr()
            status_ptr = scope.out_ptr()
            _check(
                LIB.fm_workbook_get_display_text(
                    h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), text_ptr, status_ptr
                ),
                "fm_workbook_get_display_text",
            )
            return LIB.read_cstr(LIB.read_u32(text_ptr)), DisplayStatus(LIB.read_i32(status_ptr))

    def format_value(self, value: Value, format_code: str = "") -> "tuple[str, DisplayStatus]":
        """Render ``value`` under the number format ``format_code`` (empty means General)."""
        h = self._require()
        _check_value(value)
        with _ArgScope() as scope:
            value_ptr = scope.alloc(fm_value_t_size)
            text_ptr = scope.out_ptr()
            status_ptr = scope.out_ptr()
            _write_value_input(value, value_ptr, scope)
            fmt_ptr = scope.cstr(format_code)
            _check(
                LIB.fm_workbook_format_value(h, value_ptr, fmt_ptr, text_ptr, status_ptr),
                "fm_workbook_format_value",
            )
            return LIB.read_cstr(LIB.read_u32(text_ptr)), DisplayStatus(LIB.read_i32(status_ptr))

    # -- Sheet view / layout -----------------------------------------------
    def paginate(self, sheet: int) -> PaginationResult:
        """Resolve the worksheet's print area, page breaks, and page count.

        The result is a snapshot: later workbook or layout changes do not
        mutate the returned lists.
        """
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            _check(LIB.fm_workbook_paginate(h, _uint(sheet, "sheet_index"), out), "fm_workbook_paginate")
            pagination = LIB.read_u32(out)
            if pagination == 0:
                raise FormulonError(
                    _STATUS_BINDING_NULL_POINTER,
                    op="fm_workbook_paginate",
                    _diagnostic_override=("returned kOk with a null pagination handle", ""),
                )
            try:
                page_count = int(LIB.fm_pagination_page_count(pagination))
                range_count = int(LIB.fm_pagination_print_area_count(pagination))
                break_count = int(LIB.fm_pagination_horizontal_break_count(pagination))
                vertical_break_count = int(LIB.fm_pagination_vertical_break_count(pagination))
                range_ptr = scope.alloc(16)
                value_ptr = scope.out_ptr()
                scale_ptr = scope.alloc(8)
                # Sized for the largest pagination detail struct (fm_page_layout).
                struct_ptr = scope.struct(S.PAGE_LAYOUT)
                print_area = []
                for i in range(range_count):
                    _check(
                        LIB.fm_pagination_print_area_at(pagination, _uint(i, "index"), range_ptr),
                        "fm_pagination_print_area_at",
                    )
                    print_area.append(struct.unpack("<IIII", LIB.read_bytes(range_ptr, 16)))
                horizontal_breaks = []
                for i in range(break_count):
                    _check(
                        LIB.fm_pagination_horizontal_break_at(pagination, _uint(i, "index"), value_ptr),
                        "fm_pagination_horizontal_break_at",
                    )
                    horizontal_breaks.append(LIB.read_u32(value_ptr))
                vertical_breaks = []
                for i in range(vertical_break_count):
                    _check(
                        LIB.fm_pagination_vertical_break_at(pagination, _uint(i, "index"), value_ptr),
                        "fm_pagination_vertical_break_at",
                    )
                    vertical_breaks.append(LIB.read_u32(value_ptr))
                horizontal_break_manual = []
                for i in range(break_count):
                    _check(
                        LIB.fm_pagination_horizontal_break_is_manual(pagination, _uint(i, "index"), value_ptr),
                        "fm_pagination_horizontal_break_is_manual",
                    )
                    horizontal_break_manual.append(bool(LIB.read_i32(value_ptr)))
                vertical_break_manual = []
                for i in range(vertical_break_count):
                    _check(
                        LIB.fm_pagination_vertical_break_is_manual(pagination, _uint(i, "index"), value_ptr),
                        "fm_pagination_vertical_break_is_manual",
                    )
                    vertical_break_manual.append(bool(LIB.read_i32(value_ptr)))
                _check(LIB.fm_pagination_scale(pagination, scale_ptr), "fm_pagination_scale")
                scale = LIB.read_f64(scale_ptr)
                _check(LIB.fm_pagination_page_order(pagination, value_ptr), "fm_pagination_page_order")
                page_order = LIB.read_i32(value_ptr)

                def read_struct(layout: S.Struct, fn, op: str) -> Dict[str, int]:
                    S.zero_struct(LIB, layout, struct_ptr)
                    _check(fn(pagination, struct_ptr), op)
                    return layout.unpack(LIB, struct_ptr)

                d = read_struct(S.PAPER_INFO, LIB.fm_pagination_paper, "fm_pagination_paper")
                paper = PaperInfo(d["width_pt"], d["height_pt"], bool(d["landscape"]), bool(d["known"]))
                margins = MarginsPt(**read_struct(S.MARGINS_PT, LIB.fm_pagination_margins, "fm_pagination_margins"))
                printable = RectPt(**read_struct(S.RECT_PT, LIB.fm_pagination_printable, "fm_pagination_printable"))
                d = read_struct(S.PRINT_TITLES, LIB.fm_pagination_print_titles, "fm_pagination_print_titles")
                print_titles = PrintTitles(
                    has_rows=bool(d["has_rows"]),
                    first_row=d["first_row"],
                    last_row=d["last_row"],
                    has_cols=bool(d["has_cols"]),
                    first_col=d["first_col"],
                    last_col=d["last_col"],
                )
                pages = []
                for i in range(page_count):
                    S.zero_struct(LIB, S.PAGE_LAYOUT, struct_ptr)
                    _check(
                        LIB.fm_pagination_page_at(pagination, _uint(i, "index"), struct_ptr),
                        "fm_pagination_page_at",
                    )
                    pages.append(PageLayout(**S.PAGE_LAYOUT.unpack(LIB, struct_ptr)))
                return PaginationResult(
                    page_count,
                    print_area,
                    horizontal_breaks,
                    vertical_breaks,
                    paper,
                    margins,
                    printable,
                    scale,
                    page_order,
                    print_titles,
                    pages,
                    horizontal_break_manual,
                    vertical_break_manual,
                )
            finally:
                LIB.fm_pagination_destroy(pagination)

    def get_sheet_view(self, sheet: int) -> SheetView:
        """Read the full per-sheet view (zoom, freeze, tab-hidden, and the
        display / orientation flags)."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.SHEET_VIEW)
            _check(LIB.fm_sheet_get_view(h, _uint(sheet, "sheet_index"), ptr), "fm_sheet_get_view")
            d = S.SHEET_VIEW.unpack(LIB, ptr)
            return SheetView(
                zoom_scale=d["zoom_scale"],
                freeze_rows=d["freeze_rows"],
                freeze_cols=d["freeze_cols"],
                tab_hidden=bool(d["tab_hidden"]),
                visibility=SheetVisibility(d["visibility"]),
                show_grid_lines=bool(d["show_grid_lines"]),
                show_row_col_headers=bool(d["show_row_col_headers"]),
                show_zeros=bool(d["show_zeros"]),
                right_to_left=bool(d["right_to_left"]),
                tab_selected=bool(d["tab_selected"]),
                view_mode=LIB.read_cstr(d["view_mode"]) or "",
                top_left_row=d["top_left_row"],
                top_left_col=d["top_left_col"],
                pane_top_left_row=d["pane_top_left_row"],
                pane_top_left_col=d["pane_top_left_col"],
                split_x=d["split_x"],
                split_y=d["split_y"],
                show_formulas=bool(d["show_formulas"]),
                show_outline_symbols=bool(d["show_outline_symbols"]),
            )

    def set_sheet_zoom(self, sheet: int, zoom_scale: int) -> None:
        """Set the sheet zoom percentage (clamped to ``[10, 400]``)."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_zoom(h, _uint(sheet, "sheet_index"), _uint(zoom_scale, "zoom_scale")), "fm_sheet_set_zoom"
        )

    def set_sheet_freeze(self, sheet: int, freeze_rows: int, freeze_cols: int) -> None:
        """Set the frozen pane in ``(rows, cols)``."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_freeze(
                h, _uint(sheet, "sheet_index"), _uint(freeze_rows, "freeze_rows"), _uint(freeze_cols, "freeze_cols")
            ),
            "fm_sheet_set_freeze",
        )

    def set_sheet_tab_hidden(self, sheet: int, hidden: bool) -> None:
        """Set the sheet tab's hidden flag.

        The two-state view of :meth:`set_sheet_visibility`. ``True`` on an
        already very-hidden sheet leaves it very-hidden rather than
        demoting it, since "hidden" says nothing that sheet does not
        already satisfy; ``False`` shows it from either hidden state.

        Raises:
          FormulonError: with ``kInvalidArgument`` when hiding the only
            visible sheet.
        """
        h = self._require()
        _check(
            LIB.fm_sheet_set_tab_hidden(h, _uint(sheet, "sheet_index"), 1 if hidden else 0),
            "fm_sheet_set_tab_hidden",
        )

    def set_sheet_visibility(self, sheet: int, visibility: "SheetVisibility | int") -> None:
        """Set the sheet tab's visibility to one of the three states.

        The only way to newly state :attr:`SheetVisibility.VERY_HIDDEN`, and
        the only way to demote a very-hidden sheet to plain hidden;
        :meth:`set_sheet_tab_hidden` can express neither.

        Raises:
          FormulonError: with ``kInvalidArgument`` for an unknown state or
            when hiding the only visible sheet.
        """
        h = self._require()
        _check(
            LIB.fm_sheet_set_visibility(h, _uint(sheet, "sheet_index"), _sint(visibility, "visibility")),
            "fm_sheet_set_visibility",
        )

    def set_sheet_show_grid_lines(self, sheet: int, show: bool) -> None:
        """Set the sheet's ``showGridLines`` flag."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_show_grid_lines(h, _uint(sheet, "sheet_index"), 1 if show else 0),
            "fm_sheet_set_show_grid_lines",
        )

    def set_sheet_show_row_col_headers(self, sheet: int, show: bool) -> None:
        """Set the sheet's ``showRowColHeaders`` flag."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_show_row_col_headers(h, _uint(sheet, "sheet_index"), 1 if show else 0),
            "fm_sheet_set_show_row_col_headers",
        )

    def set_sheet_show_zeros(self, sheet: int, show: bool) -> None:
        """Set the sheet's ``showZeros`` flag."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_show_zeros(h, _uint(sheet, "sheet_index"), 1 if show else 0),
            "fm_sheet_set_show_zeros",
        )

    def set_sheet_show_formulas(self, sheet: int, show: bool) -> None:
        """Set the sheet's ``showFormulas`` flag."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_show_formulas(h, _uint(sheet, "sheet_index"), 1 if show else 0),
            "fm_sheet_set_show_formulas",
        )

    def set_sheet_show_outline_symbols(self, sheet: int, show: bool) -> None:
        """Set the sheet's ``showOutlineSymbols`` flag."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_show_outline_symbols(h, _uint(sheet, "sheet_index"), 1 if show else 0),
            "fm_sheet_set_show_outline_symbols",
        )

    def set_sheet_right_to_left(self, sheet: int, right_to_left: bool) -> None:
        """Set the sheet's ``rightToLeft`` flag."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_right_to_left(h, _uint(sheet, "sheet_index"), 1 if right_to_left else 0),
            "fm_sheet_set_right_to_left",
        )

    def set_sheet_top_left(self, sheet: int, row: int, col: int) -> None:
        """Set the sheet view's scroll origin (``topLeftCell``)."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_top_left(h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col")),
            "fm_sheet_set_top_left",
        )

    def set_sheet_pane_top_left(self, sheet: int, row: int, col: int) -> None:
        """Set the first visible cell of a frozen or split view's lower-right pane.

        The cell must lie past any frozen rows and columns, and the sheet must
        be frozen or split. Changing the freeze resets it to the first unfrozen
        cell.
        """
        h = self._require()
        _check(
            LIB.fm_sheet_set_pane_top_left(h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col")),
            "fm_sheet_set_pane_top_left",
        )

    def set_sheet_split(self, sheet: int, x_twips: float, y_twips: float) -> None:
        """Split the view at ``x_twips`` / ``y_twips`` (0 for none on that axis).

        ``(0, 0)`` removes the split. A split replaces any freeze, as
        :meth:`set_sheet_freeze` replaces a split. Negative or non-finite
        values raise and leave the view unchanged.
        """
        h = self._require()
        _check(
            LIB.fm_sheet_set_split(h, _uint(sheet, "sheet_index"), float(x_twips), float(y_twips)),
            "fm_sheet_set_split",
        )

    def get_sheet_selection(self, sheet: int) -> Tuple[Tuple[int, int], List[MergeRange]]:
        """Return ``((active_row, active_col), ranges)`` of the active pane's selection.

        The selection reads as it is saved: a pane that stores none reports A1
        with the single range A1 (the pane's top-left cell for a frozen or split
        view's active pane), and an active cell outside every range moves to the
        first range's top-left.
        """
        h = self._require()
        with _ArgScope() as scope:
            row_ptr = scope.out_ptr()
            col_ptr = scope.out_ptr()
            total_ptr = scope.out_ptr()
            array_ptr = 0
            # Size the buffer first, then fetch.
            _check(
                LIB.fm_sheet_get_selection(h, _uint(sheet, "sheet_index"), row_ptr, col_ptr, 0, 0, total_ptr),
                "fm_sheet_get_selection",
            )
            total = LIB.read_u32(total_ptr)
            array_ptr = scope.struct_array(S.MERGE_RANGE, total)
            _check(
                LIB.fm_sheet_get_selection(
                    h, _uint(sheet, "sheet_index"), row_ptr, col_ptr, array_ptr, _uint(total, "capacity"), total_ptr
                ),
                "fm_sheet_get_selection",
            )
            size = S.MERGE_RANGE.size
            ranges = [_decode_merge_at(array_ptr + i * size) for i in range(total)]
            return (LIB.read_u32(row_ptr), LIB.read_u32(col_ptr)), ranges

    def set_sheet_selection(
        self, sheet: int, active_row: int, active_col: int, ranges: Sequence[MergeRange] = ()
    ) -> None:
        """Replace the active pane's selection; no ``ranges`` selects the active cell alone."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = _pack_merge_array(list(ranges), scope)
            _check(
                LIB.fm_sheet_set_selection(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(active_row, "active_row"),
                    _uint(active_col, "active_col"),
                    ptr,
                    _uint(len(ranges), "count"),
                ),
                "fm_sheet_set_selection",
            )

    def set_sheet_tab_selected(self, sheet: int, selected: bool) -> None:
        """Set the sheet's ``tabSelected`` flag."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_tab_selected(h, _uint(sheet, "sheet_index"), 1 if selected else 0),
            "fm_sheet_set_tab_selected",
        )

    def set_sheet_view_mode(self, sheet: int, mode: str) -> None:
        """Set the sheet's ``<sheetView view="...">`` mode: ``""``,
        ``"pageBreakPreview"``, or ``"pageLayout"``. Stored verbatim.

        Unlike most string setters in this module, an empty ``mode`` is a
        meaningful value here (the OOXML-default "normal" view), not a
        request to pass ``NULL`` -- ``fm_sheet_set_view_mode`` rejects a
        `NULL` pointer outright, so this always allocates a real buffer.
        """
        h = self._require()
        with _ArgScope() as scope:
            mode_ptr = scope.cstr(mode)
            _check(
                LIB.fm_sheet_set_view_mode(h, _uint(sheet, "sheet_index"), mode_ptr),
                "fm_sheet_set_view_mode",
            )

    def get_auto_filter_xml(self, sheet: int) -> str:
        """Return the sheet's ``<autoFilter>`` XML fragment, or ``""``.

        The fragment carries the filter-column criteria, sort state and
        extension payload verbatim, so a host can preserve definitions it
        does not interpret.
        """
        h = self._require()
        return _read_cstr_out(
            LIB.fm_sheet_get_auto_filter_xml,
            h,
            _uint(sheet, "sheet_index"),
            default_op="fm_sheet_get_auto_filter_xml",
        )

    def set_auto_filter_xml(self, sheet: int, xml: str) -> None:
        """Replace the sheet's ``<autoFilter>`` XML fragment.

        An empty ``xml`` removes the AutoFilter. Non-empty input must be a
        complete ``<autoFilter ...>`` fragment; the engine preserves filter
        extensions verbatim rather than validating them in detail.
        """
        h = self._require()
        with _ArgScope() as scope:
            xml_ptr = scope.cstr(xml)
            _check(
                LIB.fm_sheet_set_auto_filter_xml(h, _uint(sheet, "sheet_index"), xml_ptr),
                "fm_sheet_set_auto_filter_xml",
            )

    # -- Print settings: raw XML -------------------------------------------
    #
    # The five worksheet print elements are stored verbatim and re-emitted
    # on save, so these getters return what the file says rather than a
    # re-serialisation of a partial model. An absent element reads as "".
    #
    # Setting the empty string removes the element and restores the
    # structured defaults it fed; any non-empty value must be exactly one
    # well-formed element with the matching root name.

    def _get_print_xml(self, sheet: int, export: str) -> str:
        h = self._require()
        return _read_cstr_out(
            getattr(LIB, export),
            h,
            _uint(sheet, "sheet_index"),
            default_op=export,
        )

    def _set_print_xml(self, sheet: int, export: str, xml: str) -> None:
        h = self._require()
        with _ArgScope() as scope:
            xml_ptr = scope.cstr(xml)
            _check(getattr(LIB, export)(h, _uint(sheet, "sheet_index"), xml_ptr), export)

    def get_page_setup_xml(self, sheet: int) -> str:
        """Return the sheet's ``<pageSetup>`` fragment, or ``""``."""
        return self._get_print_xml(sheet, "fm_sheet_get_page_setup_xml")

    def set_page_setup_xml(self, sheet: int, xml: str) -> None:
        """Replace the sheet's ``<pageSetup>`` fragment.

        Note that ``fitToPage`` is not a ``<pageSetup>`` attribute -- use
        :meth:`set_fit_to_page`. A fragment carrying ``r:id`` is rejected
        unless the sheet already has a printerSettings part, because the
        reference would otherwise dangle and Excel would repair the file.
        """
        self._set_print_xml(sheet, "fm_sheet_set_page_setup_xml", xml)

    def get_page_margins_xml(self, sheet: int) -> str:
        """Return the sheet's ``<pageMargins>`` fragment, or ``""``."""
        return self._get_print_xml(sheet, "fm_sheet_get_page_margins_xml")

    def set_page_margins_xml(self, sheet: int, xml: str) -> None:
        """Replace the sheet's ``<pageMargins>`` fragment."""
        self._set_print_xml(sheet, "fm_sheet_set_page_margins_xml", xml)

    def get_print_options_xml(self, sheet: int) -> str:
        """Return the sheet's ``<printOptions>`` fragment, or ``""``."""
        return self._get_print_xml(sheet, "fm_sheet_get_print_options_xml")

    def set_print_options_xml(self, sheet: int, xml: str) -> None:
        """Replace the sheet's ``<printOptions>`` fragment."""
        self._set_print_xml(sheet, "fm_sheet_set_print_options_xml", xml)

    def get_header_footer_xml(self, sheet: int) -> str:
        """Return the sheet's ``<headerFooter>`` fragment, or ``""``."""
        return self._get_print_xml(sheet, "fm_sheet_get_header_footer_xml")

    def set_header_footer_xml(self, sheet: int, xml: str) -> None:
        """Replace the sheet's ``<headerFooter>`` fragment.

        Header and footer codes are introduced by ``&``, which lives in XML
        element text and so must arrive escaped: Excel writes
        ``<oddHeader>&amp;C...</oddHeader>``. Pass decoded text to
        :meth:`set_header_footer` instead to let the engine escape it.
        """
        self._set_print_xml(sheet, "fm_sheet_set_header_footer_xml", xml)

    def get_sheet_pr_xml(self, sheet: int) -> str:
        """Return the sheet's ``<sheetPr>`` fragment, or ``""``.

        ``<sheetPr>`` is not print-only: it also carries the tab colour and
        the VBA code name, which is why toggling fit-to-page has its own
        entry point rather than going through this setter.
        """
        return self._get_print_xml(sheet, "fm_sheet_get_sheet_pr_xml")

    def set_sheet_pr_xml(self, sheet: int, xml: str) -> None:
        """Replace the sheet's ``<sheetPr>`` fragment."""
        self._set_print_xml(sheet, "fm_sheet_set_sheet_pr_xml", xml)

    def set_fit_to_page(self, sheet: int, enabled: bool) -> None:
        """Set or clear ``<sheetPr><pageSetUpPr fitToPage>``.

        Leaves every other ``<sheetPr>`` child and attribute alone.
        ``fitToPage`` only selects the mode; state the target with
        ``fit_to_width`` / ``fit_to_height`` on :meth:`set_page_setup`.
        """
        h = self._require()
        _check(
            LIB.fm_sheet_set_fit_to_page(h, _uint(sheet, "sheet_index"), 1 if enabled else 0),
            "fm_sheet_set_fit_to_page",
        )

    # -- Print settings: area and titles -----------------------------------

    def get_print_area(self, sheet: int) -> str:
        """Return the print area as comma-separated A1 ranges, or ``""``.

        A whole-axis area reads back expanded to explicit corners (``"A:D"``
        becomes ``"A1:D1048576"``), because this reports the rectangles the
        paginator resolves rather than the authored shape.
        """
        h = self._require()
        return _read_cstr_out(
            LIB.fm_sheet_get_print_area,
            h,
            _uint(sheet, "sheet_index"),
            default_op="fm_sheet_get_print_area",
        )

    def set_print_area(self, sheet: int, ranges_a1: str) -> None:
        """Write ``_xlnm.Print_Area`` from one or more A1 ranges.

        Accepts ``"A1:F8"``, ``"A1:B10,D5:E20"``, ``"A:D"`` or ``"1:50"``,
        with or without ``$``. Corners are absolutised and each area is
        qualified with this sheet's name. An empty string removes the name.
        """
        h = self._require()
        with _ArgScope() as scope:
            ranges_ptr = scope.cstr(ranges_a1)
            _check(
                LIB.fm_sheet_set_print_area(h, _uint(sheet, "sheet_index"), ranges_ptr),
                "fm_sheet_set_print_area",
            )

    def get_print_titles(self, sheet: int) -> tuple[str, str]:
        """Return ``(repeat_rows, repeat_cols)`` as ``"1:2"`` / ``"A:A"``.

        Either is ``""`` when that axis is unset.
        """
        h = self._require()
        with _ArgScope() as scope:
            rows_out = scope.out_ptr()
            cols_out = scope.out_ptr()
            _check(
                LIB.fm_sheet_get_print_titles(h, _uint(sheet, "sheet_index"), rows_out, cols_out),
                "fm_sheet_get_print_titles",
            )
            return (LIB.read_cstr(LIB.read_u32(rows_out)), LIB.read_cstr(LIB.read_u32(cols_out)))

    def set_print_titles(self, sheet: int, repeat_rows: str = "", repeat_cols: str = "") -> None:
        """Write ``_xlnm.Print_Titles`` from a row span and a column span.

        ``repeat_rows`` is a whole-row span (``"1:2"``), ``repeat_cols`` a
        whole-column span (``"A:A"``). Both empty removes the defined name.
        """
        h = self._require()
        with _ArgScope() as scope:
            rows_ptr = scope.cstr(repeat_rows)
            cols_ptr = scope.cstr(repeat_cols)
            _check(
                LIB.fm_sheet_set_print_titles(h, _uint(sheet, "sheet_index"), rows_ptr, cols_ptr),
                "fm_sheet_set_print_titles",
            )

    # -- Print settings: manual page breaks --------------------------------

    def add_row_break(self, sheet: int, row: int, manual: bool = True) -> None:
        """Upsert a row break before ``row``, spanning the whole sheet."""
        h = self._require()
        _check(
            LIB.fm_sheet_add_row_break(h, _uint(sheet, "sheet_index"), _uint(row, "row"), 1 if manual else 0),
            "fm_sheet_add_row_break",
        )

    def add_col_break(self, sheet: int, col: int, manual: bool = True) -> None:
        """Upsert a column break before ``col``, spanning the whole sheet."""
        h = self._require()
        _check(
            LIB.fm_sheet_add_col_break(h, _uint(sheet, "sheet_index"), _uint(col, "col"), 1 if manual else 0),
            "fm_sheet_add_col_break",
        )

    def remove_row_break(self, sheet: int, row: int) -> None:
        """Remove the row break at ``row``. An absent break is a no-op."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_row_break(h, _uint(sheet, "sheet_index"), _uint(row, "row")),
            "fm_sheet_remove_row_break",
        )

    def remove_col_break(self, sheet: int, col: int) -> None:
        """Remove the column break at ``col``. An absent break is a no-op."""
        h = self._require()
        _check(
            LIB.fm_sheet_remove_col_break(h, _uint(sheet, "sheet_index"), _uint(col, "col")),
            "fm_sheet_remove_col_break",
        )

    def clear_breaks(self, sheet: int) -> None:
        """Remove every manual break on both axes."""
        h = self._require()
        _check(LIB.fm_sheet_clear_breaks(h, _uint(sheet, "sheet_index")), "fm_sheet_clear_breaks")

    def _read_breaks(self, sheet: int, count_export: str, at_export: str) -> List[PageBreak]:
        h = self._require()
        count = int(getattr(LIB, count_export)(h, _uint(sheet, "sheet_index")))
        out: List[PageBreak] = []
        with _ArgScope() as scope:
            ptr = scope.struct(S.PAGE_BREAK)
            for i in range(count):
                _check(getattr(LIB, at_export)(h, _uint(sheet, "sheet_index"), _uint(i, "index"), ptr), at_export)
                d = S.PAGE_BREAK.unpack(LIB, ptr)
                out.append(PageBreak(id=d["id"], min=d["min"], max=d["max"], manual=bool(d["manual"])))
        return out

    def get_row_breaks(self, sheet: int) -> List[PageBreak]:
        """Return the row breaks, ascending by row."""
        return self._read_breaks(sheet, "fm_sheet_row_break_count", "fm_sheet_row_break_at")

    def get_col_breaks(self, sheet: int) -> List[PageBreak]:
        """Return the column breaks, ascending by column."""
        return self._read_breaks(sheet, "fm_sheet_col_break_count", "fm_sheet_col_break_at")

    # -- Print settings: typed patch setters -------------------------------
    #
    # Each keyword defaults to ``None`` meaning "leave this attribute as the
    # file has it". That is how the C ``*_engaged`` flags are expressed in
    # Python: a caller states the two or three attributes it cares about and
    # every other one, including attributes the engine does not model, stays
    # exactly where the file put it.

    def set_page_setup(
        self,
        sheet: int,
        *,
        orientation: Optional[int] = None,
        paper_size: Optional[int] = None,
        scale: Optional[int] = None,
        fit_to_width: Optional[int] = None,
        fit_to_height: Optional[int] = None,
        fit_to_page: Optional[bool] = None,
    ) -> None:
        """Apply a partial ``<pageSetup>`` update.

        ``orientation`` is 0 (default) / 1 (portrait) / 2 (landscape);
        ``paper_size`` is the OOXML code (9 = A4). ``scale`` outside
        ``[10, 400]`` is rejected rather than clamped -- a mis-stated print
        scale lands on paper, so rounding it silently would hide the error.
        ``fit_to_page`` is routed to ``<sheetPr><pageSetUpPr>``.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PAGE_SETUP)
            S.PAGE_SETUP.pack(
                LIB,
                ptr,
                {
                    "orientation_engaged": 0 if orientation is None else 1,
                    "orientation": _uint(orientation or 0, "orientation"),
                    "paper_size_engaged": 0 if paper_size is None else 1,
                    "paper_size": _uint(paper_size or 0, "paper_size"),
                    "scale_engaged": 0 if scale is None else 1,
                    "scale": _uint(scale or 0, "scale"),
                    "fit_to_width_engaged": 0 if fit_to_width is None else 1,
                    "fit_to_width": _uint(fit_to_width or 0, "fit_to_width"),
                    "fit_to_height_engaged": 0 if fit_to_height is None else 1,
                    "fit_to_height": _uint(fit_to_height or 0, "fit_to_height"),
                    "fit_to_page_engaged": 0 if fit_to_page is None else 1,
                    "fit_to_page": 1 if fit_to_page else 0,
                },
            )
            _check(LIB.fm_sheet_set_page_setup(h, _uint(sheet, "sheet_index"), ptr), "fm_sheet_set_page_setup")

    def set_page_margins(
        self,
        sheet: int,
        *,
        left: Optional[float] = None,
        right: Optional[float] = None,
        top: Optional[float] = None,
        bottom: Optional[float] = None,
        header: Optional[float] = None,
        footer: Optional[float] = None,
    ) -> None:
        """Apply a partial ``<pageMargins>`` update, in inches.

        A negative, infinite or NaN margin is rejected: the paginator
        subtracts these from the paper, so such a value does not describe a
        printable body.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PAGE_MARGINS)
            values: Dict[str, object] = {}
            for name, value in (
                ("left", left),
                ("right", right),
                ("top", top),
                ("bottom", bottom),
                ("header", header),
                ("footer", footer),
            ):
                values[f"{name}_engaged"] = 0 if value is None else 1
                values[name] = 0.0 if value is None else float(value)
            S.PAGE_MARGINS.pack(LIB, ptr, values)
            _check(LIB.fm_sheet_set_page_margins(h, _uint(sheet, "sheet_index"), ptr), "fm_sheet_set_page_margins")

    def set_print_options(
        self,
        sheet: int,
        *,
        grid_lines: Optional[bool] = None,
        headings: Optional[bool] = None,
        horizontal_centered: Optional[bool] = None,
        vertical_centered: Optional[bool] = None,
    ) -> None:
        """Apply a partial ``<printOptions>`` update."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PRINT_OPTIONS)
            values: Dict[str, object] = {}
            for name, value in (
                ("grid_lines", grid_lines),
                ("headings", headings),
                ("horizontal_centered", horizontal_centered),
                ("vertical_centered", vertical_centered),
            ):
                values[f"{name}_engaged"] = 0 if value is None else 1
                values[name] = 1 if value else 0
            S.PRINT_OPTIONS.pack(LIB, ptr, values)
            _check(LIB.fm_sheet_set_print_options(h, _uint(sheet, "sheet_index"), ptr), "fm_sheet_set_print_options")

    def set_header_footer(
        self,
        sheet: int,
        *,
        odd_header: Optional[str] = None,
        odd_footer: Optional[str] = None,
        even_header: Optional[str] = None,
        even_footer: Optional[str] = None,
        first_header: Optional[str] = None,
        first_footer: Optional[str] = None,
        different_odd_even: Optional[bool] = None,
        different_first: Optional[bool] = None,
        scale_with_doc: Optional[bool] = None,
        align_with_margins: Optional[bool] = None,
    ) -> None:
        """Apply a partial ``<headerFooter>`` update.

        Each section is tri-state: ``None`` leaves it untouched, ``""``
        clears it, anything else replaces it. Pass decoded text -- Excel's
        formatting codes go in plainly (``"&C&\\"MS Gothic\\"Report &P/&N"``)
        and the engine applies the XML escaping.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.HEADER_FOOTER)
            values: Dict[str, object] = {}
            for name, value in (
                ("different_odd_even", different_odd_even),
                ("different_first", different_first),
                ("scale_with_doc", scale_with_doc),
                ("align_with_margins", align_with_margins),
            ):
                values[f"{name}_engaged"] = 0 if value is None else 1
                values[name] = 1 if value else 0
            S.HEADER_FOOTER.pack(LIB, ptr, values)
            # Written after `pack`, which zeroes the whole block: a NULL
            # pointer is the "leave this section alone" signal, and an
            # empty string still needs a real (empty) buffer to mean
            # "clear it".
            for field, value in (
                ("odd_header", odd_header),
                ("odd_footer", odd_footer),
                ("even_header", even_header),
                ("even_footer", even_footer),
                ("first_header", first_header),
                ("first_footer", first_footer),
            ):
                text_ptr = scope.opt_cstr(value)
                if text_ptr:
                    _, off = S.HEADER_FOOTER.offsets[field]
                    LIB.write_bytes(ptr + off, struct.pack("<I", text_ptr))
            _check(LIB.fm_sheet_set_header_footer(h, _uint(sheet, "sheet_index"), ptr), "fm_sheet_set_header_footer")

    def get_page_setup(self, sheet: int) -> PageSetup:
        """Read the effective page setup and which attributes state it."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PAGE_SETUP)
            _check(LIB.fm_sheet_get_page_setup(h, _uint(sheet, "sheet_index"), ptr), "fm_sheet_get_page_setup")
            d = S.PAGE_SETUP.unpack(LIB, ptr)
            return PageSetup(
                orientation=d["orientation"],
                paper_size=d["paper_size"],
                scale=d["scale"],
                fit_to_width=d["fit_to_width"],
                fit_to_height=d["fit_to_height"],
                fit_to_page=bool(d["fit_to_page"]),
                orientation_stated=bool(d["orientation_engaged"]),
                paper_size_stated=bool(d["paper_size_engaged"]),
                scale_stated=bool(d["scale_engaged"]),
                fit_to_width_stated=bool(d["fit_to_width_engaged"]),
                fit_to_height_stated=bool(d["fit_to_height_engaged"]),
                fit_to_page_stated=bool(d["fit_to_page_engaged"]),
            )

    def get_page_margins(self, sheet: int) -> PageMargins:
        """Read the effective page margins in inches, with presence flags."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PAGE_MARGINS)
            _check(LIB.fm_sheet_get_page_margins(h, _uint(sheet, "sheet_index"), ptr), "fm_sheet_get_page_margins")
            d = S.PAGE_MARGINS.unpack(LIB, ptr)
            return PageMargins(
                left=d["left"],
                right=d["right"],
                top=d["top"],
                bottom=d["bottom"],
                header=d["header"],
                footer=d["footer"],
                left_stated=bool(d["left_engaged"]),
                right_stated=bool(d["right_engaged"]),
                top_stated=bool(d["top_engaged"]),
                bottom_stated=bool(d["bottom_engaged"]),
                header_stated=bool(d["header_engaged"]),
                footer_stated=bool(d["footer_engaged"]),
            )

    def get_sheet_columns(self, sheet: int) -> List[ColumnLayout]:
        """Return the column-layout overrides on ``sheet``."""
        h = self._require()
        n = _read_count(LIB.fm_sheet_get_column_count, h, _uint(sheet, "sheet_index"))
        out: List[ColumnLayout] = []
        # One scratch block for the whole walk; see iter_defined_names.
        with _ArgScope() as scope:
            ptr = scope.struct(S.COLUMN_LAYOUT)
            for i in range(n):
                S.zero_struct(LIB, S.COLUMN_LAYOUT, ptr)
                _check(
                    LIB.fm_sheet_get_column(h, _uint(sheet, "sheet_index"), _uint(i, "idx"), ptr),
                    "fm_sheet_get_column",
                )
                d = S.COLUMN_LAYOUT.unpack(LIB, ptr)
                out.append(
                    ColumnLayout(
                        first=d["first"],
                        last=d["last"],
                        width=d["width"],
                        hidden=bool(d["hidden"]),
                        outline_level=d["outline_level"],
                        collapsed=bool(d["collapsed"]),
                        has_width=bool(d["has_width"]),
                        has_style=bool(d["has_style"]),
                        style_xf=d["style_xf"],
                    )
                )
        return out

    def set_column_width(self, sheet: int, first: int, last: int, width: float) -> None:
        """Set the column width override on ``[first, last]``.

        ``width`` is a stored width: characters with the column padding
        included, as ``<col width>`` holds it.
        """
        h = self._require()
        _check(
            LIB.fm_sheet_set_column_width(
                h, _uint(sheet, "sheet_index"), _uint(first, "first"), _uint(last, "last"), float(width)
            ),
            "fm_sheet_set_column_width",
        )

    def set_column_hidden(self, sheet: int, first: int, last: int, hidden: bool) -> None:
        """Set the column hidden flag on ``[first, last]``."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_column_hidden(
                h, _uint(sheet, "sheet_index"), _uint(first, "first"), _uint(last, "last"), 1 if hidden else 0
            ),
            "fm_sheet_set_column_hidden",
        )

    def set_column_outline(self, sheet: int, first: int, last: int, level: int) -> None:
        """Set the column outline level (0-7) on ``[first, last]``.

        Raises:
          FormulonError: with ``kInvalidArgument`` when ``level`` exceeds 7.
        """
        h = self._require()
        _check(
            LIB.fm_sheet_set_column_outline(
                h, _uint(sheet, "sheet_index"), _uint(first, "first"), _uint(last, "last"), _uint(level, "level", 8)
            ),
            "fm_sheet_set_column_outline",
        )

    def set_column_collapsed(self, sheet: int, first: int, last: int, collapsed: bool) -> None:
        """Set or clear the ``collapsed`` flag on the columns ``[first, last]``."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_column_collapsed(
                h, _uint(sheet, "sheet_index"), _uint(first, "first"), _uint(last, "last"), 1 if collapsed else 0
            ),
            "fm_sheet_set_column_collapsed",
        )

    def set_column_style(self, sheet: int, first: int, last: int, xf_index: int) -> None:
        """Set the cell-style XF on ``[first, last]``, keeping the other column attributes."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_column_style(
                h, _uint(sheet, "sheet_index"), _uint(first, "first"), _uint(last, "last"), _uint(xf_index, "xf_index")
            ),
            "fm_sheet_set_column_style",
        )

    def clear_column_style(self, sheet: int, first: int, last: int) -> None:
        """Remove the cell-style XF on ``[first, last]``, keeping the other column attributes."""
        h = self._require()
        _check(
            LIB.fm_sheet_clear_column_style(h, _uint(sheet, "sheet_index"), _uint(first, "first"), _uint(last, "last")),
            "fm_sheet_clear_column_style",
        )

    def get_sheet_row_overrides(self, sheet: int) -> List[RowLayout]:
        """Return the row-layout overrides on ``sheet``."""
        h = self._require()
        n = _read_count(LIB.fm_sheet_get_row_override_count, h, _uint(sheet, "sheet_index"))
        out: List[RowLayout] = []
        # One scratch block for the whole walk; see iter_defined_names.
        with _ArgScope() as scope:
            ptr = scope.struct(S.ROW_LAYOUT)
            for i in range(n):
                S.zero_struct(LIB, S.ROW_LAYOUT, ptr)
                _check(
                    LIB.fm_sheet_get_row_override(h, _uint(sheet, "sheet_index"), _uint(i, "idx"), ptr),
                    "fm_sheet_get_row_override",
                )
                d = S.ROW_LAYOUT.unpack(LIB, ptr)
                out.append(
                    RowLayout(
                        row=d["row"],
                        height=d["height"],
                        hidden=bool(d["hidden"]),
                        outline_level=d["outline_level"],
                        collapsed=bool(d["collapsed"]),
                        has_style=bool(d["has_style"]),
                        style_xf=d["style_xf"],
                        has_height=bool(d["has_height"]),
                        custom_height=bool(d["custom_height"]),
                    )
                )
        return out

    def set_row_height(self, sheet: int, row: int, height: float) -> None:
        """Set the row height override at ``row``."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_row_height(h, _uint(sheet, "sheet_index"), _uint(row, "row"), float(height)),
            "fm_sheet_set_row_height",
        )

    def set_row_hidden(self, sheet: int, row: int, hidden: bool) -> None:
        """Set the row hidden flag at ``row``."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_row_hidden(h, _uint(sheet, "sheet_index"), _uint(row, "row"), 1 if hidden else 0),
            "fm_sheet_set_row_hidden",
        )

    def set_row_outline(self, sheet: int, row: int, level: int) -> None:
        """Set the row outline level (0-7) at ``row``.

        Raises:
          FormulonError: with ``kInvalidArgument`` when ``level`` exceeds 7.
        """
        h = self._require()
        _check(
            LIB.fm_sheet_set_row_outline(h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(level, "level", 8)),
            "fm_sheet_set_row_outline",
        )

    def set_row_collapsed(self, sheet: int, row: int, collapsed: bool) -> None:
        """Set or clear the ``collapsed`` flag at ``row``."""
        h = self._require()
        _check(
            LIB.fm_sheet_set_row_collapsed(h, _uint(sheet, "sheet_index"), _uint(row, "row"), 1 if collapsed else 0),
            "fm_sheet_set_row_collapsed",
        )

    def set_row_style(self, sheet: int, first: int, last: int, xf_index: int) -> None:
        """Set the cell-style XF on the inclusive row span ``first..last``, keeping the other row attributes.

        Every row of the span gets an override. The span and ``xf_index`` are
        validated before anything changes.
        """
        h = self._require()
        _check(
            LIB.fm_sheet_set_row_style(
                h, _uint(sheet, "sheet_index"), _uint(first, "first"), _uint(last, "last"), _uint(xf_index, "xf_index")
            ),
            "fm_sheet_set_row_style",
        )

    def clear_row_style(self, sheet: int, first: int, last: int) -> None:
        """Remove the cell-style XF on the inclusive row span ``first..last``, keeping the other row attributes."""
        h = self._require()
        _check(
            LIB.fm_sheet_clear_row_style(h, _uint(sheet, "sheet_index"), _uint(first, "first"), _uint(last, "last")),
            "fm_sheet_clear_row_style",
        )

    def range_style_bases(self, sheet: int, first_row: int, first_col: int, last_row: int, last_col: int) -> List[int]:
        """List, ascending, every cell XF some cell of the selection resolves to.

        The rectangle is a selection: full height is a column selection, full
        width a row selection, both the whole sheet, neither a cell range. It
        is the first step of an attribute patch (for example a font size over a selection): read the
        bases, build a patched XF for each with :meth:`add_font` /
        :meth:`add_cell_xf`, then apply them with :meth:`remap_range_style`.
        """
        h = self._require()
        with _ArgScope() as scope:
            len_ptr = scope.out_ptr()
            buf = 0
            # Size the buffer first, then fetch.
            _check(
                LIB.fm_sheet_range_style_bases(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(first_row, "first_row"),
                    _uint(first_col, "first_col"),
                    _uint(last_row, "last_row"),
                    _uint(last_col, "last_col"),
                    0,
                    0,
                    len_ptr,
                ),
                "fm_sheet_range_style_bases",
            )
            total = LIB.read_u32(len_ptr)
            if total == 0:
                return []
            buf = scope.alloc(4 * total)
            _check(
                LIB.fm_sheet_range_style_bases(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(first_row, "first_row"),
                    _uint(first_col, "first_col"),
                    _uint(last_row, "last_row"),
                    _uint(last_col, "last_col"),
                    buf,
                    _uint(total, "cap"),
                    len_ptr,
                ),
                "fm_sheet_range_style_bases",
            )
            n = min(total, LIB.read_u32(len_ptr))
            return list(struct.unpack("<%dI" % n, LIB.read_bytes(buf, 4 * n)))

    def remap_range_style(
        self, sheet: int, first_row: int, first_col: int, last_row: int, last_col: int, mapping: Dict[int, int]
    ) -> None:
        """Remap the XFs of a selection: a cell resolving to key ``k`` ends at ``mapping[k]``.

        An XF absent from ``mapping`` is kept. Each target must be a valid cell
        XF, else :class:`FormulonError` and nothing changes. Patch an attribute
        by reading :meth:`range_style_bases`, adding a patched XF for each base
        and passing ``{base: patched}``. Undo with :meth:`snapshot_range_style`
        taken beforehand and :meth:`restore_range_style`.
        """
        h = self._require()
        pairs = list(mapping.items())
        count = len(pairs)
        from_buf = to_buf = 0
        with _ArgScope() as scope:
            if count:
                from_buf = scope.buffer(b"".join(struct.pack("<I", _uint(k, "from_xf")) for k, _ in pairs))
                to_buf = scope.buffer(b"".join(struct.pack("<I", _uint(v, "to_xf")) for _, v in pairs))
            _check(
                LIB.fm_sheet_remap_range_style(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(first_row, "first_row"),
                    _uint(first_col, "first_col"),
                    _uint(last_row, "last_row"),
                    _uint(last_col, "last_col"),
                    from_buf,
                    to_buf,
                    _uint(count, "count"),
                ),
                "fm_sheet_remap_range_style",
            )

    def snapshot_range_style(self, sheet: int, first_row: int, first_col: int, last_row: int, last_col: int) -> bytes:
        """Capture the style state of a selection as opaque bytes for :meth:`restore_range_style`.

        The capture holds the covered column styles (column selection), row
        styles (row selection) and every stored cell's XF and explicit mark.
        Take it before :meth:`remap_range_style` to be able to undo the edit.
        """
        h = self._require()
        with _ArgScope() as scope:
            bytes_ptr = scope.out_ptr()
            len_ptr = scope.out_ptr()
            data_ptr = 0
            try:
                _check(
                    LIB.fm_sheet_snapshot_range_style(
                        h,
                        _uint(sheet, "sheet_index"),
                        _uint(first_row, "first_row"),
                        _uint(first_col, "first_col"),
                        _uint(last_row, "last_row"),
                        _uint(last_col, "last_col"),
                        bytes_ptr,
                        len_ptr,
                    ),
                    "fm_sheet_snapshot_range_style",
                )
                data_ptr = LIB.read_u32(bytes_ptr)
                return LIB.read_bytes(data_ptr, LIB.read_u32(len_ptr))
            finally:
                if data_ptr:
                    LIB.fm_buffer_free(data_ptr)

    def restore_range_style(self, sheet: int, data: Union[bytes, bytearray, memoryview]) -> None:
        """Put a :meth:`snapshot_range_style` capture back on ``sheet``.

        Captured axis styles and cell XFs are restored exactly; a stored cell of
        the captured rectangle that was not captured loses its style. Values and
        formulas are untouched. An invalid capture raises :class:`FormulonError`
        and changes nothing.
        """
        h = self._require()
        raw = bytes(data)
        with _ArgScope() as scope:
            buf = scope.buffer(raw) if raw else 0
            _check(
                LIB.fm_sheet_restore_range_style(h, _uint(sheet, "sheet_index"), buf, _uint(len(raw), "len")),
                "fm_sheet_restore_range_style",
            )

    # -- Conditional formatting --------------------------------------------
    @staticmethod
    def _decode_cf_color(d: Dict[str, int], prefix: str) -> tuple:
        return (
            d[prefix + "r"],
            d[prefix + "g"],
            d[prefix + "b"],
            d[prefix + "a"],
        )

    def evaluate_cf_range(
        self,
        sheet: int,
        first_row: int,
        first_col: int,
        last_row: int,
        last_col: int,
        today_serial: float = float("nan"),
    ) -> List[CfCellResult]:
        """Evaluate every CF block on ``sheet`` against an inclusive range.

        Args:
          sheet: 0-based sheet index.
          first_row: 0-based inclusive first row.
          first_col: 0-based inclusive first column.
          last_row: 0-based inclusive last row.
          last_col: 0-based inclusive last column.
          today_serial: date basis pinned for ``timePeriod`` rules, as an
            Excel serial date. The default ``float("nan")`` disables them:
            no ``timePeriod`` rule can match, so pass a serial date to use
            them. ``0.0`` is *not* a disabling value -- it is the valid
            serial for 1899-12-30 and would evaluate those rules against
            that date.
        """
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            results = 0
            try:
                _check(
                    LIB.fm_workbook_cf_evaluate_range(
                        h,
                        _uint(sheet, "sheet_index"),
                        _uint(first_row, "first_row"),
                        _uint(first_col, "first_col"),
                        _uint(last_row, "last_row"),
                        _uint(last_col, "last_col"),
                        float(today_serial),
                        out,
                    ),
                    "fm_workbook_cf_evaluate_range",
                )
                results = LIB.read_u32(out)
                cells: List[CfCellResult] = []
                n = LIB.fm_cf_results_cell_count(results)
                # One fixed set of out slots for the whole walk: allocating
                # per cell would put a locked WASM malloc/free pair on every
                # item, which dominates the cost of a viewport-sized range.
                rp = scope.out_ptr()
                cp = scope.out_ptr()
                mcp = scope.out_ptr()
                mptr = scope.struct(S.CF_MATCH)
                for ci in range(n):
                    _check(
                        LIB.fm_cf_results_cell_at(results, _uint(ci, "cell_idx"), rp, cp, mcp),
                        "fm_cf_results_cell_at",
                    )
                    row = LIB.read_u32(rp)
                    col = LIB.read_u32(cp)
                    mcount = LIB.read_u32(mcp)
                    matches: List[CfMatch] = []
                    for mi in range(mcount):
                        S.zero_struct(LIB, S.CF_MATCH, mptr)
                        _check(
                            LIB.fm_cf_results_match_at(results, _uint(ci, "cell_idx"), _uint(mi, "match_idx"), mptr),
                            "fm_cf_results_match_at",
                        )
                        d = S.CF_MATCH.unpack(LIB, mptr)
                        matches.append(
                            CfMatch(
                                kind=d["kind"],
                                priority=d["priority"],
                                dxf_id_engaged=bool(d["dxf_id_engaged"]),
                                dxf_id=d["dxf_id"],
                                color=self._decode_cf_color(d, "color_"),
                                bar_length_pct=d["bar_length_pct"],
                                bar_axis_position_pct=d["bar_axis_position_pct"],
                                bar_is_negative=bool(d["bar_is_negative"]),
                                bar_fill=self._decode_cf_color(d, "bar_fill_"),
                                bar_border_engaged=bool(d["bar_border_engaged"]),
                                bar_border=self._decode_cf_color(d, "bar_border_"),
                                bar_gradient=bool(d["bar_gradient"]),
                                icon_set_name=d["icon_set_name"],
                                icon_index=d["icon_index"],
                                bar_direction=d["bar_direction"],
                            )
                        )
                    cells.append(CfCellResult(row=row, col=col, matches=matches))
                return cells
            finally:
                if results:
                    LIB.fm_cf_results_destroy(results)

    def cf_count(self, sheet: int) -> int:
        """Return the number of CF rules on ``sheet`` (flattened)."""
        h = self._require()
        return _read_count(
            LIB.fm_sheet_cf_count,
            h,
            _uint(sheet, "sheet_index"),
            default_op="fm_sheet_cf_count",
        )

    @staticmethod
    def _decode_cfvo(ptr: int) -> CfValueObject:
        d = S.CFVO.unpack(LIB, ptr)
        return CfValueObject(
            type=d["type"], value=LIB.read_cstr(d["value"]) if d["value"] else None, gte=bool(d["gte"])
        )

    @staticmethod
    def _decode_cf_color_at(ptr: int) -> CfColor:
        d = S.CF_COLOR.unpack(LIB, ptr)
        return CfColor(d["r"], d["g"], d["b"], d["a"])

    @staticmethod
    def _write_cfvo(ptr: int, value: CfValueObject, scope: _ArgScope) -> None:
        S.CFVO.pack(LIB, ptr, {"type": _uint(value.type, "type", 8), "gte": 1 if value.gte else 0})
        if value.value is not None:
            S.write_str_field(LIB, ptr, S.CFVO, "value", value.value, scope)

    @staticmethod
    def _write_cf_color(ptr: int, color: CfColor) -> None:
        S.CF_COLOR.pack(
            LIB,
            ptr,
            {
                "r": _uint(color.r, "r", 8),
                "g": _uint(color.g, "g", 8),
                "b": _uint(color.b, "b", 8),
                "a": _uint(color.a, "a", 8),
            },
        )

    def get_conditional_format_at(self, sheet: int, index: int) -> ConditionalFormat:
        """Read the ``index``-th CF rule on ``sheet`` (flattened order)."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.CF_RULE)
            _check(
                LIB.fm_sheet_cf_get_at(h, _uint(sheet, "sheet_index"), _uint(index, "idx"), ptr),
                "fm_sheet_cf_get_at",
            )
            d = S.CF_RULE.unpack(LIB, ptr)
            sqref: List[MergeRange] = []
            base = d["sqref"]
            rsize = S.CF_CELL_RANGE.size
            for i in range(d["sqref_count"]):
                rd = S.CF_CELL_RANGE.unpack(LIB, base + i * rsize)
                sqref.append(
                    MergeRange(
                        first_row=rd["first_row"],
                        first_col=rd["first_col"],
                        last_row=rd["last_row"],
                        last_col=rd["last_col"],
                    )
                )
            color_scale = None
            if d["color_scale_count"]:
                thresholds = [
                    self._decode_cfvo(d["color_scale_thresholds"] + i * S.CFVO.size)
                    for i in range(d["color_scale_count"])
                ]
                colors = [
                    self._decode_cf_color_at(d["color_scale_colors"] + i * S.CF_COLOR.size)
                    for i in range(d["color_scale_count"])
                ]
                color_scale = ColorScale(thresholds, colors)
            offsets = S.CF_RULE.offsets
            data_bar = None
            if d["data_bar_engaged"]:
                data_bar = DataBar(
                    self._decode_cfvo(ptr + offsets["data_bar_min"][1]),
                    self._decode_cfvo(ptr + offsets["data_bar_max"][1]),
                    self._decode_cf_color_at(ptr + offsets["data_bar_fill"][1]),
                    bool(d["data_bar_show_value"]),
                    d["data_bar_min_length_pct"],
                    d["data_bar_max_length_pct"],
                    # x14 extension. Each field is decoded only when the C
                    # ABI reports its `*_engaged` flag, so `None` keeps its
                    # "no override" meaning on the way back in.
                    bool(d["data_bar_gradient"]) if d["data_bar_gradient_engaged"] else None,
                    d["data_bar_axis_position"] if d["data_bar_axis_position_engaged"] else None,
                    self._decode_cf_color_at(ptr + offsets["data_bar_negative_fill"][1])
                    if d["data_bar_negative_fill_engaged"]
                    else None,
                    self._decode_cf_color_at(ptr + offsets["data_bar_border"][1])
                    if d["data_bar_border_engaged"]
                    else None,
                    self._decode_cf_color_at(ptr + offsets["data_bar_negative_border"][1])
                    if d["data_bar_negative_border_engaged"]
                    else None,
                    self._decode_cf_color_at(ptr + offsets["data_bar_axis_color"][1])
                    if d["data_bar_axis_color_engaged"]
                    else None,
                    d["data_bar_direction"],
                )
            icon_set = None
            if d["icon_set_engaged"]:
                icon_set = IconSet(
                    d["icon_set_name"],
                    [
                        self._decode_cfvo(d["icon_set_thresholds"] + i * S.CFVO.size)
                        for i in range(d["icon_set_threshold_count"])
                    ],
                    bool(d["icon_set_reverse"]),
                    bool(d["icon_set_show_value"]),
                    bool(d["icon_set_percent"]),
                    self._decode_cfvo(ptr + offsets["icon_set_floor"][1]) if d["icon_set_floor_engaged"] else None,
                    [
                        CfIcon(
                            LIB.read_cstr(LIB.read_u32(d["icon_set_icons"] + i * S.CF_ICON.size)),
                            LIB.read_i32(d["icon_set_icons"] + i * S.CF_ICON.size + S.CF_ICON.offsets["icon_id"][1]),
                        )
                        for i in range(d["icon_set_icon_count"])
                    ],
                )
            return ConditionalFormat(
                id=LIB.read_cstr(d["id"]),
                type=d["type"],
                priority=d["priority"],
                stop_if_true=bool(d["stop_if_true"]),
                sqref=sqref,
                dxf_id=d["dxf_id"] if d["dxf_id_engaged"] else None,
                formula1=LIB.read_cstr(d["formula1"]),
                formula2=LIB.read_cstr(d["formula2"]),
                op=d["op"] if d["op_engaged"] else None,
                rank=d["rank"] if d["rank_engaged"] else None,
                percent=bool(d["percent"]),
                bottom=bool(d["bottom"]),
                above_average=bool(d["above_average"]),
                equal_average=bool(d["equal_average"]),
                std_dev=d["std_dev"] if d["std_dev_engaged"] else None,
                text=LIB.read_cstr(d["text"]),
                time_period=d["time_period"] if d["time_period_engaged"] else None,
                color_scale=color_scale,
                data_bar=data_bar,
                icon_set=icon_set,
            )

    def get_conditional_formats(self, sheet: int) -> List[ConditionalFormat]:
        """Return every CF rule on ``sheet`` in flattened priority order."""
        n = self.cf_count(sheet)
        return [self.get_conditional_format_at(sheet, i) for i in range(n)]

    def add_conditional_format(self, sheet: int, rule: ConditionalFormatInput) -> int:
        """Append a CF rule to ``sheet``; return its index.

        Every rule type is accepted, the visual ones included: a color scale,
        data bar or icon set rule carries its payload in ``rule.color_scale``,
        ``rule.data_bar`` or ``rule.icon_set``.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.CF_RULE)
            out = scope.out_ptr()
            S.CF_RULE.pack(
                LIB,
                ptr,
                {
                    "type": _uint(rule.type, "type", 8),
                    "op": _uint(rule.op or 0, "op", 8),
                    "time_period": _uint(rule.time_period or 0, "time_period", 8),
                    "priority": _sint(rule.priority, "priority"),
                    "stop_if_true": 1 if rule.stop_if_true else 0,
                    "dxf_id_engaged": 1 if rule.dxf_id is not None else 0,
                    "dxf_id": _uint(rule.dxf_id or 0, "dxf_id"),
                    "op_engaged": 1 if rule.op is not None else 0,
                    "rank_engaged": 1 if rule.rank is not None else 0,
                    "rank": _sint(rule.rank or 0, "rank"),
                    "percent": 1 if rule.percent else 0,
                    "bottom": 1 if rule.bottom else 0,
                    "above_average": 1 if rule.above_average else 0,
                    "equal_average": 1 if rule.equal_average else 0,
                    "std_dev_engaged": 1 if rule.std_dev is not None else 0,
                    "std_dev": float(rule.std_dev or 0.0),
                    "time_period_engaged": 1 if rule.time_period is not None else 0,
                },
            )
            sqref_ptr = 0
            if rule.sqref:
                rsize = S.CF_CELL_RANGE.size
                sqref_ptr = scope.alloc(rsize * len(rule.sqref))
                for i, r in enumerate(rule.sqref):
                    S.CF_CELL_RANGE.pack(
                        LIB,
                        sqref_ptr + i * rsize,
                        {
                            "first_row": _uint(r.first_row, "first_row"),
                            "first_col": _uint(r.first_col, "first_col"),
                            "last_row": _uint(r.last_row, "last_row"),
                            "last_col": _uint(r.last_col, "last_col"),
                        },
                    )
            ro = S.CF_RULE.offsets
            LIB.write_bytes(ptr + ro["sqref"][1], struct.pack("<I", sqref_ptr))
            LIB.write_bytes(ptr + ro["sqref_count"][1], struct.pack("<I", len(rule.sqref)))
            S.write_str_field(LIB, ptr, S.CF_RULE, "id", rule.id, scope)
            S.write_str_field(LIB, ptr, S.CF_RULE, "formula1", rule.formula1, scope)
            S.write_str_field(LIB, ptr, S.CF_RULE, "formula2", rule.formula2, scope)
            S.write_str_field(LIB, ptr, S.CF_RULE, "text", rule.text, scope)
            if rule.color_scale is not None:
                count = len(rule.color_scale.thresholds)
                if count != len(rule.color_scale.colors):
                    raise ValueError("color_scale thresholds and colors must have equal length")
                thresholds = scope.alloc(count * S.CFVO.size)
                colors = scope.alloc(count * S.CF_COLOR.size)
                for i, value in enumerate(rule.color_scale.thresholds):
                    self._write_cfvo(thresholds + i * S.CFVO.size, value, scope)
                for i, color in enumerate(rule.color_scale.colors):
                    self._write_cf_color(colors + i * S.CF_COLOR.size, color)
                LIB.write_bytes(ptr + ro["color_scale_thresholds"][1], struct.pack("<I", thresholds))
                LIB.write_bytes(ptr + ro["color_scale_colors"][1], struct.pack("<I", colors))
                LIB.write_bytes(ptr + ro["color_scale_count"][1], struct.pack("<I", count))
            if rule.data_bar is not None:
                data_bar = rule.data_bar
                self._write_cfvo(ptr + ro["data_bar_min"][1], data_bar.minimum, scope)
                self._write_cfvo(ptr + ro["data_bar_max"][1], data_bar.maximum, scope)
                self._write_cf_color(ptr + ro["data_bar_fill"][1], data_bar.fill)
                LIB.write_bytes(ptr + ro["data_bar_engaged"][1], struct.pack("<i", 1))
                LIB.write_bytes(ptr + ro["data_bar_show_value"][1], struct.pack("<i", 1 if data_bar.show_value else 0))
                LIB.write_bytes(
                    ptr + ro["data_bar_min_length_pct"][1],
                    struct.pack("<B", _uint(data_bar.min_length_pct, "min_length_pct", 8)),
                )
                LIB.write_bytes(
                    ptr + ro["data_bar_max_length_pct"][1],
                    struct.pack("<B", _uint(data_bar.max_length_pct, "max_length_pct", 8)),
                )
                # x14 extension. A `None` leaves the `*_engaged` flag clear,
                # which the C ABI reads as "keep the model default".
                if data_bar.gradient is not None:
                    LIB.write_bytes(ptr + ro["data_bar_gradient_engaged"][1], struct.pack("<i", 1))
                    LIB.write_bytes(ptr + ro["data_bar_gradient"][1], struct.pack("<i", 1 if data_bar.gradient else 0))
                if data_bar.axis_position is not None:
                    LIB.write_bytes(ptr + ro["data_bar_axis_position_engaged"][1], struct.pack("<i", 1))
                    LIB.write_bytes(
                        ptr + ro["data_bar_axis_position"][1],
                        struct.pack("<B", _uint(data_bar.axis_position, "axis_position", 8)),
                    )
                for field, color in (
                    ("negative_fill", data_bar.negative_fill),
                    ("border", data_bar.border),
                    ("negative_border", data_bar.negative_border),
                    ("axis_color", data_bar.axis_color),
                ):
                    if color is not None:
                        LIB.write_bytes(ptr + ro[f"data_bar_{field}_engaged"][1], struct.pack("<i", 1))
                        self._write_cf_color(ptr + ro[f"data_bar_{field}"][1], color)
                LIB.write_bytes(
                    ptr + ro["data_bar_direction"][1], struct.pack("<B", _uint(data_bar.direction, "direction", 8))
                )
            if rule.icon_set is not None:
                icon_set = rule.icon_set
                count = len(icon_set.thresholds)
                thresholds = scope.alloc(count * S.CFVO.size)
                for i, value in enumerate(icon_set.thresholds):
                    self._write_cfvo(thresholds + i * S.CFVO.size, value, scope)
                LIB.write_bytes(ptr + ro["icon_set_thresholds"][1], struct.pack("<I", thresholds))
                LIB.write_bytes(ptr + ro["icon_set_engaged"][1], struct.pack("<i", 1))
                LIB.write_bytes(ptr + ro["icon_set_name"][1], struct.pack("<B", _uint(icon_set.name, "icon_set", 8)))
                LIB.write_bytes(ptr + ro["icon_set_threshold_count"][1], struct.pack("<I", count))
                LIB.write_bytes(ptr + ro["icon_set_reverse"][1], struct.pack("<i", 1 if icon_set.reverse else 0))
                LIB.write_bytes(ptr + ro["icon_set_show_value"][1], struct.pack("<i", 1 if icon_set.show_value else 0))
                LIB.write_bytes(ptr + ro["icon_set_percent"][1], struct.pack("<i", 1 if icon_set.percent else 0))
                if icon_set.floor is not None:
                    LIB.write_bytes(ptr + ro["icon_set_floor_engaged"][1], struct.pack("<i", 1))
                    self._write_cfvo(ptr + ro["icon_set_floor"][1], icon_set.floor, scope)
                if icon_set.icons:
                    icons_ptr = scope.alloc(len(icon_set.icons) * S.CF_ICON.size)
                    for i, icon in enumerate(icon_set.icons):
                        name_ptr = scope.cstr(icon.icon_set)
                        S.CF_ICON.pack(
                            LIB,
                            icons_ptr + i * S.CF_ICON.size,
                            {"icon_set": name_ptr, "icon_id": _sint(icon.icon_id, "icon_id")},
                        )
                    LIB.write_bytes(ptr + ro["icon_set_icons"][1], struct.pack("<I", icons_ptr))
                    LIB.write_bytes(ptr + ro["icon_set_icon_count"][1], struct.pack("<I", len(icon_set.icons)))
            _check(
                LIB.fm_sheet_cf_add_rule(h, _uint(sheet, "sheet_index"), ptr, out),
                "fm_sheet_cf_add_rule",
            )
            return LIB.read_u32(out)

    def remove_conditional_format_at(self, sheet: int, index: int) -> None:
        """Remove the CF rule at ``index`` on ``sheet`` (flattened order)."""
        h = self._require()
        _check(
            LIB.fm_sheet_cf_remove_at(h, _uint(sheet, "sheet_index"), _uint(index, "idx")),
            "fm_sheet_cf_remove_at",
        )

    def clear_conditional_formats(self, sheet: int) -> None:
        """Drop every CF block on ``sheet``."""
        h = self._require()
        _check(LIB.fm_sheet_cf_clear(h, _uint(sheet, "sheet_index")), "fm_sheet_cf_clear")

    # -- Styles ------------------------------------------------------------
    def get_cell_xf_index(self, sheet: int, row: int, col: int) -> int:
        """Return the xf (style record) index attached to a cell."""
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            _check(
                LIB.fm_cell_get_xf_index(h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(col, "col"), out),
                "fm_cell_get_xf_index",
            )
            return LIB.read_u32(out)

    def set_cell_xf_index(self, sheet: int, row: int, col: int, xf_index: int) -> None:
        """Store ``xf_index`` on the cell at ``(row, col)``.

        Raises:
          FormulonError: with ``kInvalidArgument`` when ``xf_index`` is not
            below the workbook's cell-XF count.
        """
        h = self._require()
        _check(
            LIB.fm_cell_set_xf_index(
                h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(col, "col"), _uint(xf_index, "xf_index")
            ),
            "fm_cell_set_xf_index",
        )

    def clear_cell_xf_index(self, sheet: int, row: int, col: int) -> None:
        """Remove the direct style assignment from the cell at ``(row, col)``.

        A blank cell inherits the row / column style again; value, formula and
        comments are kept. An absent cell is a no-op. A non-blank cell keeps
        owning the default xf. Use the ``source`` of :meth:`get_effective_style`
        to tell an unassigned cell from one directly assigned the Normal xf.
        """
        h = self._require()
        _check(
            LIB.fm_cell_clear_xf_index(h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(col, "col")),
            "fm_cell_clear_xf_index",
        )

    def set_range_xf_index(
        self, sheet: int, first_row: int, first_col: int, last_row: int, last_col: int, xf_index: int
    ) -> None:
        """Store ``xf_index`` on every cell in the inclusive rectangle.

        Cells that do not exist yet are materialised as blanks carrying only
        the style, so an empty ruled box renders. Ruling a report this way
        costs one call instead of one per cell.
        """
        h = self._require()
        _check(
            LIB.fm_sheet_set_range_xf_index(
                h,
                _uint(sheet, "sheet"),
                _uint(first_row, "first_row"),
                _uint(first_col, "first_col"),
                _uint(last_row, "last_row"),
                _uint(last_col, "last_col"),
                _uint(xf_index, "xf_index"),
            ),
            "fm_sheet_set_range_xf_index",
        )

    @staticmethod
    def _decode_cell_xf(ptr: int) -> CellXf:
        d = S.CELL_XF.unpack(LIB, ptr)
        return CellXf(
            font_index=d["font_index"],
            fill_index=d["fill_index"],
            border_index=d["border_index"],
            num_fmt_id=d["num_fmt_id"],
            horizontal_align=d["horizontal_align"],
            vertical_align=d["vertical_align"],
            wrap_text=bool(d["wrap_text"]),
            has_alignment=bool(d["has_alignment"]),
            justify_last_line=bool(d["justify_last_line"]),
            xf_id=d["xf_id"],
            text_rotation=d["text_rotation"] if d["has_text_rotation"] else None,
            indent=d["indent"] if d["has_indent"] else None,
            relative_indent=d["relative_indent"] if d["has_relative_indent"] else None,
            shrink_to_fit=bool(d["shrink_to_fit"]) if d["has_shrink_to_fit"] else None,
            reading_order=d["reading_order"] if d["has_reading_order"] else None,
            has_horizontal_align=bool(d["has_horizontal_align"]),
            has_vertical_align=bool(d["has_vertical_align"]),
            has_wrap_text=bool(d["has_wrap_text"]),
            has_justify_last_line=bool(d["has_justify_last_line"]),
            apply_number_format=bool(d["apply_number_format"]),
            apply_font=bool(d["apply_font"]),
            apply_fill=bool(d["apply_fill"]),
            apply_border=bool(d["apply_border"]),
            apply_alignment=bool(d["apply_alignment"]),
            apply_protection=bool(d["apply_protection"]),
            quote_prefix=bool(d["quote_prefix"]),
            has_protection=bool(d["has_protection"]),
            locked=bool(d["locked"]),
            hidden=bool(d["hidden"]),
        )

    def _get_style_record(self, fn, layout: S.Struct, index: int, index_field: str, decode, op: str):
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(layout)
            _check(fn(h, _uint(index, index_field), ptr), op)
            return decode(ptr)

    def get_cell_xf(self, xf_index: int) -> CellXf:
        """Return the resolved ``<xf>`` record at ``xf_index``."""
        return self._get_style_record(
            LIB.fm_styles_get_cell_xf, S.CELL_XF, xf_index, "xf_index", self._decode_cell_xf, "fm_styles_get_cell_xf"
        )

    def get_font(self, font_index: int) -> FontRecord:
        """Return the font record at ``font_index``."""
        return self._get_style_record(
            LIB.fm_styles_get_font, S.FONT_RECORD, font_index, "font_index", _decode_font, "fm_styles_get_font"
        )

    def get_fill(self, fill_index: int) -> FillRecord:
        """Return the fill record at ``fill_index``."""
        return self._get_style_record(
            LIB.fm_styles_get_fill, S.FILL_RECORD, fill_index, "fill_index", _decode_fill, "fm_styles_get_fill"
        )

    def get_border(self, border_index: int) -> Dict[str, object]:
        """Return the border record at ``border_index``.

        Each side is a ``{"style", "color_argb", "color"}`` dict, where
        ``color`` is the round-trip :class:`ColorSpec`; the result also
        carries ``diagonal_up`` / ``diagonal_down`` booleans.
        """
        return self._get_style_record(
            LIB.fm_styles_get_border,
            S.BORDER_RECORD,
            border_index,
            "border_index",
            _decode_border_record,
            "fm_styles_get_border",
        )

    def get_dxf(self, dxf_index: int) -> DifferentialFormat:
        """Read one differential format by its conditional-format ``dxfId``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.DXF_RECORD)
            _check(LIB.fm_styles_get_dxf(h, _uint(dxf_index, "dxf_index"), ptr), "fm_styles_get_dxf")
            d = S.DXF_RECORD.unpack(LIB, ptr)
            offsets = S.DXF_RECORD.offsets
            font = _decode_font(ptr + offsets["font"][1]) if d["font_engaged"] else None
            fill = _decode_fill(ptr + offsets["fill"][1]) if d["fill_engaged"] else None
            return DifferentialFormat(
                font=font,
                fill=fill,
                border=_decode_border_record(ptr + offsets["border"][1]) if d["border_engaged"] else None,
                num_fmt_id=d["num_fmt_id"] if d["num_fmt_engaged"] else None,
                num_fmt_code=LIB.read_cstr(d["num_fmt_code"]) if d["num_fmt_engaged"] else "",
                alignment_xml=LIB.read_cstr(d["alignment_xml"]),
                protection_xml=LIB.read_cstr(d["protection_xml"]),
            )

    def get_num_fmt(self, num_fmt_id: int) -> str:
        """Return the format code registered for ``num_fmt_id``."""
        h = self._require()
        return _read_cstr_out(
            LIB.fm_styles_get_num_fmt_string,
            h,
            _uint(num_fmt_id, "num_fmt_id", 16),
            default_op="fm_styles_get_num_fmt_string",
        )

    def font_count(self) -> int:
        """Return the number of font records registered."""
        return self._style_count(LIB.fm_styles_get_font_count)

    def fill_count(self) -> int:
        """Return the number of fill records registered."""
        return self._style_count(LIB.fm_styles_get_fill_count)

    def border_count(self) -> int:
        """Return the number of border records registered."""
        return self._style_count(LIB.fm_styles_get_border_count)

    def cell_xf_count(self) -> int:
        """Return the number of ``<xf>`` records registered."""
        return self._style_count(LIB.fm_styles_get_cell_xf_count)

    def cell_style_count(self) -> int:
        """Return the number of named cell styles."""
        return self._style_count(LIB.fm_styles_get_cell_style_count)

    def cell_style_xf_count(self) -> int:
        """Return the number of ``<cellStyleXfs>`` records."""
        return self._style_count(LIB.fm_styles_get_cell_style_xf_count)

    def dxf_count(self) -> int:
        """Return the number of differential formats available to CF rules."""
        return self._style_count(LIB.fm_styles_get_dxf_count)

    def _style_count(self, fn) -> int:
        h = self._require()
        return _read_count(fn, h, default_op="style_count")

    def add_font(self, record: FontRecord) -> int:
        """Add (dedup) a font record; return its index."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.FONT_RECORD)
            out = scope.out_ptr()
            _pack_font(ptr, record, scope)
            _check(LIB.fm_styles_add_font(h, ptr, out), "fm_styles_add_font")
            return LIB.read_u32(out)

    def set_font(self, font_index: int, record: FontRecord) -> None:
        """Overwrite an existing font slot in place.

        Every ``<xf>`` naming ``font_index`` restyles at once, so this is a
        bulk change rather than a local edit; :meth:`add_font` is the way to
        introduce a new appearance. The index must already exist.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.FONT_RECORD)
            _pack_font(ptr, record, scope)
            _check(
                LIB.fm_styles_set_font(h, _uint(font_index, "font_index"), ptr),
                "fm_styles_set_font",
            )

    def set_default_font(self, record: FontRecord) -> None:
        """Declare the workbook's default font (font 0).

        Font 0 is what an unstyled cell resolves to. A new workbook seeds it
        with Excel's Calibri 11, and :meth:`add_font` can only append beside
        it, so this is the way a ja-JP host declares e.g. ``游ゴシック`` for
        the cells it never styles explicitly. Read it back with
        ``get_font(0)``.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.FONT_RECORD)
            _pack_font(ptr, record, scope)
            _check(LIB.fm_workbook_set_default_font(h, ptr), "fm_workbook_set_default_font")

    def add_fill(self, record: FillRecord) -> int:
        """Add (dedup) a fill record; return its index."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.FILL_RECORD)
            out = scope.out_ptr()
            _pack_fill(ptr, record, scope)
            _check(LIB.fm_styles_add_fill(h, ptr, out), "fm_styles_add_fill")
            return LIB.read_u32(out)

    def add_border(self, sides: Dict[str, object]) -> int:
        """Add (dedup) a border record; return its index.

        ``sides`` mirrors :meth:`get_border`'s shape: a dict with
        ``left`` / ``right`` / ``top`` / ``bottom`` / ``diagonal`` entries
        (each ``{"style", "color_argb"}`` plus an optional ``color``
        :class:`ColorSpec`) plus optional ``diagonal_up`` /
        ``diagonal_down`` booleans.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.BORDER_RECORD)
            out = scope.out_ptr()
            _pack_border_record(ptr, sides)
            _check(LIB.fm_styles_add_border(h, ptr, out), "fm_styles_add_border")
            return LIB.read_u32(out)

    def add_num_fmt(self, format_code: str) -> int:
        """Add (dedup) a number-format code; return its resolved id."""
        h = self._require()
        with _ArgScope() as scope:
            code_ptr = scope.cstr(format_code)
            out = scope.out_ptr()
            _check(LIB.fm_styles_add_num_fmt(h, code_ptr, out), "fm_styles_add_num_fmt")
            return struct.unpack("<H", LIB.read_bytes(out, 2))[0]

    def add_cell_xf(self, record: CellXf) -> int:
        """Add (dedup) an ``<xf>`` record; return its index."""
        return self._add_xf_record(record, LIB.fm_styles_add_cell_xf, "fm_styles_add_cell_xf")

    def add_cell_style_xf(self, record: CellXf) -> int:
        """Add (dedup) a named-style ``<xf>``; return its ``<cellStyleXfs>`` id.

        The counterpart of :meth:`get_cell_style_xf`. Named-style xfs are
        the records a ``<cellStyle>`` points at; :meth:`add_cell_xf` writes
        the per-cell ``<cellXfs>`` pool instead.
        """
        return self._add_xf_record(record, LIB.fm_styles_add_cell_style_xf, "fm_styles_add_cell_style_xf")

    def _add_xf_record(self, record: CellXf, fn, op: str) -> int:
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.CELL_XF)
            out = scope.out_ptr()
            S.CELL_XF.pack(LIB, ptr, _cell_xf_fields(record))
            _check(fn(h, ptr, out), op)
            return LIB.read_u32(out)

    def add_batch(
        self,
        *,
        fonts: Optional[Sequence[FontRecord]] = None,
        fills: Optional[Sequence[FillRecord]] = None,
        borders: Optional[Sequence[Dict[str, object]]] = None,
        num_fmts: Optional[Sequence[str]] = None,
        cell_xfs: Optional[Sequence[CellXf]] = None,
    ) -> StyleBatchIndices:
        """Add (dedup) whole style tables in one call.

        The per-record :meth:`add_font` / :meth:`add_fill` / :meth:`add_border`
        / :meth:`add_num_fmt` / :meth:`add_cell_xf` methods each rescan their
        table, so building thousands of formats one at a time is quadratic.
        This routes the same work through a single ABI call that dedups every
        table in linear time.

        Fonts, fills, borders and number formats are installed before the
        xfs, so a ``cell_xfs`` entry may reference an index this same call
        assigns. ``borders`` entries take :meth:`add_border`'s dict shape.

        The call is one transaction: on failure the workbook is unchanged
        and :class:`FormulonError` is raised.
        """
        h = self._require()
        font_list = list(fonts or ())
        fill_list = list(fills or ())
        border_list = list(borders or ())
        num_fmt_list = list(num_fmts or ())
        xf_list = list(cell_xfs or ())

        with _ArgScope() as scope:
            batch = scope.struct(S.STYLES_BATCH)
            fields: Dict[str, object] = {}

            font_indices = 0
            if font_list:
                records = scope.alloc(S.FONT_RECORD.size * len(font_list))
                font_indices = scope.alloc(4 * len(font_list))
                for i, record in enumerate(font_list):
                    _pack_font(records + i * S.FONT_RECORD.size, record, scope)
                fields.update(fonts=records, font_count=len(font_list), font_indices=font_indices)

            fill_indices = 0
            if fill_list:
                records = scope.alloc(S.FILL_RECORD.size * len(fill_list))
                fill_indices = scope.alloc(4 * len(fill_list))
                for i, record in enumerate(fill_list):
                    _pack_fill(records + i * S.FILL_RECORD.size, record, scope)
                fields.update(fills=records, fill_count=len(fill_list), fill_indices=fill_indices)

            border_indices = 0
            if border_list:
                records = scope.alloc(S.BORDER_RECORD.size * len(border_list))
                border_indices = scope.alloc(4 * len(border_list))
                for i, sides in enumerate(border_list):
                    _pack_border_record(records + i * S.BORDER_RECORD.size, sides)
                fields.update(borders=records, border_count=len(border_list), border_indices=border_indices)

            xf_indices = 0
            if xf_list:
                records = scope.alloc(S.CELL_XF.size * len(xf_list))
                xf_indices = scope.alloc(4 * len(xf_list))
                for i, record in enumerate(xf_list):
                    S.CELL_XF.pack(LIB, records + i * S.CELL_XF.size, _cell_xf_fields(record))
                fields.update(cell_xfs=records, cell_xf_count=len(xf_list), cell_xf_indices=xf_indices)

            num_fmt_ids = 0
            if num_fmt_list:
                # An array of `const char*`: one 4-byte pointer slot per code.
                codes = scope.alloc(4 * len(num_fmt_list))
                num_fmt_ids = scope.alloc(2 * len(num_fmt_list))
                for i, code in enumerate(num_fmt_list):
                    code_ptr = scope.cstr(code)
                    LIB.write_bytes(codes + i * 4, struct.pack("<I", code_ptr))
                fields.update(num_fmt_codes=codes, num_fmt_count=len(num_fmt_list), num_fmt_ids=num_fmt_ids)

            S.STYLES_BATCH.pack(LIB, batch, fields)
            _check(LIB.fm_styles_add_batch(h, batch), "fm_styles_add_batch")

            def read_u32_array(ptr: int, count: int) -> List[int]:
                if count == 0:
                    return []
                raw = LIB.read_bytes(ptr, 4 * count)
                return [struct.unpack_from("<I", raw, 4 * i)[0] for i in range(count)]

            def read_u16_array(ptr: int, count: int) -> List[int]:
                if count == 0:
                    return []
                raw = LIB.read_bytes(ptr, 2 * count)
                return [struct.unpack_from("<H", raw, 2 * i)[0] for i in range(count)]

            return StyleBatchIndices(
                fonts=read_u32_array(font_indices, len(font_list)),
                fills=read_u32_array(fill_indices, len(fill_list)),
                borders=read_u32_array(border_indices, len(border_list)),
                cell_xfs=read_u32_array(xf_indices, len(xf_list)),
                num_fmts=read_u16_array(num_fmt_ids, len(num_fmt_list)),
            )

    def add_dxf(self, record: DifferentialFormat) -> int:
        """Add (dedup) a differential format and return its ``dxfId``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.DXF_RECORD)
            out = scope.out_ptr()
            S.DXF_RECORD.pack(
                LIB,
                ptr,
                {
                    "font_engaged": 1 if record.font is not None else 0,
                    "fill_engaged": 1 if record.fill is not None else 0,
                    "border_engaged": 1 if record.border is not None else 0,
                    "num_fmt_engaged": 1 if record.num_fmt_id is not None else 0,
                    "num_fmt_id": _uint(record.num_fmt_id or 0, "num_fmt_id", 16),
                },
            )
            offsets = S.DXF_RECORD.offsets
            if record.font is not None:
                _pack_font(ptr + offsets["font"][1], record.font, scope)
            if record.fill is not None:
                _pack_fill(ptr + offsets["fill"][1], record.fill, scope)
            if record.border is not None:
                _pack_border_record(ptr + offsets["border"][1], record.border)
            S.write_str_field(LIB, ptr, S.DXF_RECORD, "num_fmt_code", record.num_fmt_code, scope)
            S.write_str_field(LIB, ptr, S.DXF_RECORD, "alignment_xml", record.alignment_xml, scope)
            S.write_str_field(LIB, ptr, S.DXF_RECORD, "protection_xml", record.protection_xml, scope)
            _check(LIB.fm_styles_add_dxf(h, ptr, out), "fm_styles_add_dxf")
            return LIB.read_u32(out)

    def set_cell_style(self, record: CellStyle) -> None:
        """Add or replace the named ``<cellStyle>`` record ``record.name``.

        ``record.xf_id`` must reference an existing named-style xf -- register
        one with :meth:`add_cell_style_xf` first. ``builtin_id`` is an Excel
        built-in style ordinal (0..53); leave it at
        ``CELL_STYLE_BUILTIN_ID_NONE`` for a custom style.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.CELL_STYLE_RECORD)
            S.CELL_STYLE_RECORD.pack(
                LIB,
                ptr,
                {
                    "xf_id": _uint(record.xf_id, "xf_id"),
                    "builtin_id": _uint(record.builtin_id, "builtin_id"),
                    "i_level": _uint(record.i_level, "i_level"),
                    "hidden": 1 if record.hidden else 0,
                    "custom_builtin": 1 if record.custom_builtin else 0,
                },
            )
            S.write_str_field(LIB, ptr, S.CELL_STYLE_RECORD, "name", record.name, scope, allow_empty=True)
            _check(LIB.fm_styles_set_cell_style(h, ptr), "fm_styles_set_cell_style")

    def remove_cell_style(self, name: str) -> None:
        """Remove the named cell style ``name``.

        Cell xfs inheriting from it are repointed at Normal; no xf index
        shifts. The Normal style and unknown names raise ``FormulonError``.
        """
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            _check(LIB.fm_styles_remove_cell_style(h, name_ptr), "fm_styles_remove_cell_style")

    def table_style_count(self) -> int:
        """Return the number of custom table / PivotTable styles."""
        return self._style_count(LIB.fm_styles_get_table_style_count)

    def get_table_style(self, index: int) -> TableStyle:
        """Return the custom table style at ``index``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.TABLE_STYLE)
            _check(LIB.fm_styles_get_table_style(h, _uint(index, "index"), ptr), "fm_styles_get_table_style")
            d = S.TABLE_STYLE.unpack(LIB, ptr)
            elements = []
            for i in range(d["element_count"]):
                e = S.TABLE_STYLE_ELEMENT.unpack(LIB, d["elements"] + i * S.TABLE_STYLE_ELEMENT.size)
                elements.append(
                    TableStyleElement(
                        type=LIB.read_cstr(e["type"]),
                        size=e["size"],
                        dxf_id=e["dxf_id"] if e["has_dxf_id"] else None,
                    )
                )
            return TableStyle(
                name=LIB.read_cstr(d["name"]),
                pivot=d["pivot"] != 0,
                table=d["table"] != 0,
                elements=tuple(elements),
            )

    def set_table_style(self, style: TableStyle) -> None:
        """Add a custom table style, or replace the one with the same name.

        The name may not be a built-in style name; each element type may
        appear once, ``size`` must be at least 1 and ``dxf_id`` must name an
        existing differential format (:meth:`add_dxf`).
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.TABLE_STYLE)
            elements_ptr = 0
            if style.elements:
                elements_ptr = scope.struct_array(S.TABLE_STYLE_ELEMENT, len(style.elements))
                for i, element in enumerate(style.elements):
                    type_ptr = scope.cstr(element.type)
                    S.TABLE_STYLE_ELEMENT.pack(
                        LIB,
                        elements_ptr + i * S.TABLE_STYLE_ELEMENT.size,
                        {
                            "type": type_ptr,
                            "size": _uint(element.size, "size"),
                            "has_dxf_id": 0 if element.dxf_id is None else 1,
                            "dxf_id": _uint(0 if element.dxf_id is None else element.dxf_id, "dxf_id"),
                        },
                    )
            name_ptr = scope.cstr(style.name)
            S.TABLE_STYLE.pack(
                LIB,
                ptr,
                {
                    "name": name_ptr,
                    "pivot": 1 if style.pivot else 0,
                    "table": 1 if style.table else 0,
                    "elements": elements_ptr,
                    "element_count": _uint(len(style.elements), "element_count"),
                },
            )
            _check(LIB.fm_styles_set_table_style(h, ptr), "fm_styles_set_table_style")

    def remove_table_style(self, name: str) -> None:
        """Remove the custom table style ``name``.

        A default naming it reverts to the built-in default; tables and
        pivots naming it keep the name.
        """
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            _check(LIB.fm_styles_remove_table_style(h, name_ptr), "fm_styles_remove_table_style")

    def table_style_defaults(self) -> Tuple[str, str]:
        """Return the default ``(table_style, pivot_style)`` names; empty when unset."""
        h = self._require()
        with _ArgScope() as scope:
            table_ptr = scope.out_ptr()
            pivot_ptr = scope.out_ptr()
            _check(
                LIB.fm_styles_get_table_style_defaults(h, table_ptr, pivot_ptr),
                "fm_styles_get_table_style_defaults",
            )
            return LIB.read_cstr(LIB.read_u32(table_ptr)), LIB.read_cstr(LIB.read_u32(pivot_ptr))

    def set_table_style_defaults(self, table_style: Optional[str] = None, pivot_style: Optional[str] = None) -> None:
        """Set the default style names; ``None`` keeps one, ``""`` removes it."""
        h = self._require()
        with _ArgScope() as scope:
            ptrs = [scope.opt_cstr(value) for value in (table_style, pivot_style)]
            _check(
                LIB.fm_styles_set_table_style_defaults(h, ptrs[0], ptrs[1]),
                "fm_styles_set_table_style_defaults",
            )

    def get_theme(self) -> Theme:
        """Read the theme's 12 scheme colours and typefaces.

        The default theme is reported when the part is absent or unparseable;
        ``Theme.source`` tells the cases apart.
        """
        h = self._require()
        with _ArgScope() as scope:
            colors_ptr = scope.struct(S.THEME_COLORS)
            fonts_ptr = scope.struct(S.THEME_FONTS)
            source_ptr = scope.out_ptr()
            _check(LIB.fm_workbook_get_theme_colors(h, colors_ptr, source_ptr), "fm_workbook_get_theme_colors")
            source = LIB.read_i32(source_ptr)
            colors = list(struct.unpack("<12I", LIB.read_bytes(colors_ptr, S.THEME_COLORS.size)))
            _check(LIB.fm_workbook_get_theme_fonts(h, fonts_ptr), "fm_workbook_get_theme_fonts")
            f = S.THEME_FONTS.unpack(LIB, fonts_ptr)
            fonts = ThemeFonts(
                major_latin=LIB.read_cstr(f["major_latin"]),
                major_east_asian=LIB.read_cstr(f["major_east_asian"]),
                minor_latin=LIB.read_cstr(f["minor_latin"]),
                minor_east_asian=LIB.read_cstr(f["minor_east_asian"]),
            )
            return Theme(
                source=ThemeSource(source),
                colors=colors,
                fonts=fonts,
                major_scripts=self._read_theme_script_fonts(h, True),
                minor_scripts=self._read_theme_script_fonts(h, False),
            )

    @staticmethod
    def _read_theme_script_fonts(h: int, major: bool) -> Tuple[ThemeScriptFont, ...]:
        """Read one theme font set; each pair is decoded before the next call (read-scratch strings)."""
        flag = 1 if major else 0
        count = _read_count(LIB.fm_workbook_theme_script_font_count, h, _sint(flag, "major"))
        with _ArgScope() as scope:
            script_out = scope.out_ptr()
            face_out = scope.out_ptr()
            result: List[ThemeScriptFont] = []
            for idx in range(count):
                _check(
                    LIB.fm_workbook_theme_script_font_at(
                        h, _sint(flag, "major"), _uint(idx, "idx"), script_out, face_out
                    ),
                    "fm_workbook_theme_script_font_at",
                )
                result.append(
                    ThemeScriptFont(
                        script=LIB.read_cstr(LIB.read_u32(script_out)),
                        typeface=LIB.read_cstr(LIB.read_u32(face_out)),
                    )
                )
            return tuple(result)

    def set_theme_colors(self, colors: Sequence[int]) -> None:
        """Replace the theme's 12 scheme colours (``a:clrScheme`` order; alpha ignored)."""
        h = self._require()
        values = [_uint(c, "colors") for c in colors]
        if len(values) != 12:
            raise ValueError(f"formulon: colors must hold 12 entries, got {len(values)}")
        with _ArgScope() as scope:
            ptr = scope.struct(S.THEME_COLORS)
            LIB.write_bytes(ptr, struct.pack("<12I", *values))
            _check(LIB.fm_workbook_set_theme_colors(h, ptr), "fm_workbook_set_theme_colors")

    def set_theme_fonts(self, fonts: ThemeFonts) -> None:
        """Replace the theme's major and minor typefaces."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.THEME_FONTS)
            for fname in ("major_latin", "major_east_asian", "minor_latin", "minor_east_asian"):
                S.write_str_field(LIB, ptr, S.THEME_FONTS, fname, getattr(fonts, fname), scope, allow_empty=True)
            _check(LIB.fm_workbook_set_theme_fonts(h, ptr), "fm_workbook_set_theme_fonts")

    def set_theme_script_font(self, major: bool, script: str, typeface: str) -> None:
        """Set the typeface of one script in the major (heading) or minor (body) font set.

        ``script`` is an ISO 15924 code of exactly four ASCII letters
        (``Jpan``, ``Hang``); ``typeface`` must be non-empty. Other scripts are
        unchanged and an unlisted script is appended. Setting ``Jpan`` also
        changes ``ThemeFonts.*_east_asian``. A workbook without a theme part
        first gets one carrying the full default set. Invalid arguments raise
        ``FormulonError``.
        """
        h = self._require()
        with _ArgScope() as scope:
            script_ptr = scope.cstr(script)
            face_ptr = scope.cstr(typeface)
            _check(
                LIB.fm_workbook_set_theme_script_font(h, 1 if major else 0, script_ptr, face_ptr),
                "fm_workbook_set_theme_script_font",
            )

    def reset_theme(self) -> None:
        """Remove the theme part so the workbook reports the default theme.

        :meth:`get_theme` then reports ``ThemeSource.DEFAULT``. Excel adds a
        theme part again when it saves the file.
        """
        h = self._require()
        _check(LIB.fm_workbook_reset_theme(h), "fm_workbook_reset_theme")

    def resolve_color(self, spec: ColorSpec, context: Union[ColorContext, int] = ColorContext.FONT) -> ResolvedColor:
        """Resolve ``spec`` to the ``0xAARRGGBB`` Excel renders.

        ``context`` decides what an automatic or absent colour means (black
        for font and border, white for fills).
        """
        h = self._require()
        with _ArgScope() as scope:
            spec_ptr = scope.struct(S.COLOR_SPEC)
            argb_ptr = scope.out_ptr()
            res_ptr = scope.out_ptr()
            _pack_color(spec_ptr, spec)
            _check(
                LIB.fm_workbook_resolve_color(h, spec_ptr, _sint(context, "context"), argb_ptr, res_ptr),
                "fm_workbook_resolve_color",
            )
            return ResolvedColor(LIB.read_u32(argb_ptr), ColorResolution(LIB.read_i32(res_ptr)))

    def get_effective_style(self, sheet: int, row: int, col: int) -> EffectiveStyle:
        """Read the effective style of the cell at ``(row, col)``; the cell need not exist."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.EFFECTIVE_STYLE)
            _check(
                LIB.fm_sheet_get_effective_style(
                    h, _uint(sheet, "sheet_index"), _uint(row, "row"), _uint(col, "col"), ptr
                ),
                "fm_sheet_get_effective_style",
            )
            d = S.EFFECTIVE_STYLE.unpack(LIB, ptr)
            offsets = S.EFFECTIVE_STYLE.offsets
            border_argb = struct.unpack("<5I", LIB.read_bytes(ptr + offsets["border_argb"][1], 20))
            border_res = struct.unpack("<5i", LIB.read_bytes(ptr + offsets["border_resolution"][1], 20))
            return EffectiveStyle(
                xf_index=d["xf_index"],
                source=EffectiveStyleSource(d["source"]),
                font_index=d["font_index"],
                fill_index=d["fill_index"],
                border_index=d["border_index"],
                font=ResolvedColor(d["font_argb"], ColorResolution(d["font_resolution"])),
                fill_foreground=ResolvedColor(d["fill_fg_argb"], ColorResolution(d["fill_fg_resolution"])),
                fill_background=ResolvedColor(d["fill_bg_argb"], ColorResolution(d["fill_bg_resolution"])),
                borders=[ResolvedColor(a, ColorResolution(r)) for a, r in zip(border_argb, border_res)],
                locked=bool(d["locked"]),
                hidden=bool(d["hidden"]),
                num_fmt_code=LIB.read_cstr(d["num_fmt_code"]),
            )

    def get_cell_style(self, index: int) -> CellStyle:
        """Return the named cell style at ``index``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.CELL_STYLE_RECORD)
            _check(
                LIB.fm_styles_get_cell_style(h, _uint(index, "index"), ptr),
                "fm_styles_get_cell_style",
            )
            d = S.CELL_STYLE_RECORD.unpack(LIB, ptr)
            return CellStyle(
                name=LIB.read_cstr(d["name"]),
                xf_id=d["xf_id"],
                builtin_id=d["builtin_id"],
                i_level=d["i_level"],
                hidden=bool(d["hidden"]),
                custom_builtin=bool(d["custom_builtin"]),
            )

    def get_cell_style_xf(self, index: int) -> CellXf:
        """Return the named-style xf record at ``index``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.CELL_XF)
            _check(
                LIB.fm_styles_get_cell_style_xf(h, _uint(index, "index"), ptr),
                "fm_styles_get_cell_style_xf",
            )
            return self._decode_cell_xf(ptr)

    # -- Pivot layout projection -------------------------------------------
    def pivot_count(self, sheet: int) -> int:
        """Return the number of PivotTables anchored on ``sheet``."""
        h = self._require()
        return _read_count(
            LIB.fm_workbook_pivot_count,
            h,
            _uint(sheet, "sheet_index"),
            default_op="fm_workbook_pivot_count",
        )

    def pivot_layout(self, sheet: int, pivot_index: int) -> PivotLayout:
        """Evaluate and project a PivotTable into concrete grid cells."""
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            handle = 0
            try:
                _check(
                    LIB.fm_workbook_pivot_layout(
                        h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), out
                    ),
                    "fm_workbook_pivot_layout",
                )
                handle = LIB.read_u32(out)
                top_p = scope.out_ptr()
                left_p = scope.out_ptr()
                rows_p = scope.out_ptr()
                cols_p = scope.out_ptr()
                _check(
                    LIB.fm_pivot_cells_bounds(handle, top_p, left_p, rows_p, cols_p),
                    "fm_pivot_cells_bounds",
                )
                top = LIB.read_u32(top_p)
                left = LIB.read_u32(left_p)
                rows = LIB.read_u32(rows_p)
                cols = LIB.read_u32(cols_p)
                cells: List[PivotCell] = []
                n = LIB.fm_pivot_cells_count(handle)
                # One scratch block for the whole walk; see iter_defined_names.
                cptr = scope.struct(S.PIVOT_CELL)
                for i in range(n):
                    S.zero_struct(LIB, S.PIVOT_CELL, cptr)
                    _check(
                        LIB.fm_pivot_cells_at(handle, _uint(i, "idx"), cptr),
                        "fm_pivot_cells_at",
                    )
                    d = S.PIVOT_CELL.unpack(LIB, cptr)
                    value = Value._from_wasm(cptr + S.PIVOT_CELL_VALUE_OFFSET)
                    cells.append(
                        PivotCell(
                            row=d["row"],
                            col=d["col"],
                            value=value,
                            kind=PivotCellKind(d["kind"]),
                            depth=d["depth"],
                            field_name=LIB.read_cstr(d["field_name"]),
                            number_format=LIB.read_cstr(d["number_format"]),
                        )
                    )
                return PivotLayout(top=top, left=left, rows=rows, cols=cols, cells=cells)
            finally:
                if handle:
                    LIB.fm_pivot_cells_destroy(handle)

    # -- Pivot caches ------------------------------------------------------
    def pivot_cache_count(self) -> int:
        """Return the number of pivot caches owned by the workbook."""
        h = self._require()
        return _read_count(LIB.fm_workbook_pivot_cache_count, h, default_op="fm_workbook_pivot_cache_count")

    def pivot_cache_id_at(self, index: int) -> int:
        """Return the cache id at flat ``index``."""
        h = self._require()
        return _read_count(
            LIB.fm_workbook_pivot_cache_id_at,
            h,
            _uint(index, "idx"),
            default_op="fm_workbook_pivot_cache_id_at",
        )

    def pivot_cache_create(self, requested_id: int = 0) -> int:
        """Create a new empty pivot cache; return its assigned id."""
        h = self._require()
        return _read_count(
            LIB.fm_workbook_pivot_cache_create,
            h,
            _uint(requested_id, "requested_id"),
            default_op="fm_workbook_pivot_cache_create",
        )

    def get_pivot_cache_worksheet_source(self, cache_id: int) -> Optional[PivotWorksheetSource]:
        """Return a cache's worksheet-source metadata, or ``None`` when absent."""
        h = self._require()
        with _ArgScope() as scope:
            present = scope.out_ptr()
            out_ref = scope.out_ptr()
            out_sheet = scope.out_ptr()
            out_name = scope.out_ptr()
            _check(
                LIB.fm_workbook_pivot_cache_get_worksheet_source(
                    h, _uint(cache_id, "cache_id"), present, out_ref, out_sheet, out_name
                ),
                "fm_workbook_pivot_cache_get_worksheet_source",
            )
            if not LIB.read_i32(present):
                return None
            return PivotWorksheetSource(
                LIB.read_cstr(LIB.read_u32(out_ref)) if LIB.read_u32(out_ref) else None,
                LIB.read_cstr(LIB.read_u32(out_sheet)) if LIB.read_u32(out_sheet) else None,
                LIB.read_cstr(LIB.read_u32(out_name)) if LIB.read_u32(out_name) else None,
            )

    def set_pivot_cache_worksheet_source(self, cache_id: int, source: Optional[PivotWorksheetSource]) -> None:
        """Set cache worksheet-source metadata; pass ``None`` to clear it."""
        h = self._require()
        with _ArgScope() as scope:
            values = () if source is None else (source.ref, source.sheet, source.name)
            pointers = [scope.opt_cstr(value) for value in values] if source is not None else [0, 0, 0]
            _check(
                LIB.fm_workbook_pivot_cache_set_worksheet_source(
                    h, _uint(cache_id, "cache_id"), 0 if source is None else 1, *pointers
                ),
                "fm_workbook_pivot_cache_set_worksheet_source",
            )

    def pivot_cache_remove(self, cache_id: int) -> None:
        """Remove the pivot cache with id ``cache_id``."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_remove(h, _uint(cache_id, "cache_id")),
            "fm_workbook_pivot_cache_remove",
        )

    def pivot_cache_field_count(self, cache_id: int) -> int:
        """Return the number of fields on the cache."""
        h = self._require()
        return _read_count(LIB.fm_workbook_pivot_cache_field_count, h, _uint(cache_id, "cache_id"))

    def pivot_cache_field_name(self, cache_id: int, field_idx: int) -> str:
        """Read the name of cache field ``field_idx``."""
        h = self._require()
        return _read_cstr_out(
            LIB.fm_workbook_pivot_cache_field_name,
            h,
            _uint(cache_id, "cache_id"),
            _uint(field_idx, "field_idx"),
            default_op="fm_workbook_pivot_cache_field_name",
        )

    def pivot_cache_field_add(self, cache_id: int, name: str) -> int:
        """Append a field to the cache; return its index."""
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            out = scope.out_ptr()
            _check(
                LIB.fm_workbook_pivot_cache_field_add(h, _uint(cache_id, "cache_id"), name_ptr, out),
                "fm_workbook_pivot_cache_field_add",
            )
            return LIB.read_u32(out)

    def pivot_cache_field_clear(self, cache_id: int) -> None:
        """Drop every field (and record) from the cache."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_field_clear(h, _uint(cache_id, "cache_id")),
            "fm_workbook_pivot_cache_field_clear",
        )

    def pivot_cache_field_shared_item_count(self, cache_id: int, field_idx: int) -> int:
        """Return the shared-item count on cache field ``field_idx``."""
        h = self._require()
        return _read_count(
            LIB.fm_workbook_pivot_cache_field_shared_item_count,
            h,
            _uint(cache_id, "cache_id"),
            _uint(field_idx, "field_idx"),
        )

    def pivot_cache_field_add_shared_item_number(self, cache_id: int, field_idx: int, value: float) -> None:
        """Append a numeric shared item to a cache field."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_field_add_shared_item_number(
                h, _uint(cache_id, "cache_id"), _uint(field_idx, "field_idx"), float(value)
            ),
            "fm_workbook_pivot_cache_field_add_shared_item_number",
        )

    def pivot_cache_field_add_shared_item_text(self, cache_id: int, field_idx: int, value: str) -> None:
        """Append a text shared item to a cache field."""
        h = self._require()
        with _ArgScope() as scope:
            vp = scope.cstr(value)
            _check(
                LIB.fm_workbook_pivot_cache_field_add_shared_item_text(
                    h, _uint(cache_id, "cache_id"), _uint(field_idx, "field_idx"), vp
                ),
                "fm_workbook_pivot_cache_field_add_shared_item_text",
            )

    def pivot_cache_field_add_shared_item_bool(self, cache_id: int, field_idx: int, value: bool) -> None:
        """Append a boolean shared item to a cache field."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_field_add_shared_item_bool(
                h, _uint(cache_id, "cache_id"), _uint(field_idx, "field_idx"), 1 if value else 0
            ),
            "fm_workbook_pivot_cache_field_add_shared_item_bool",
        )

    def pivot_cache_field_add_shared_item_blank(self, cache_id: int, field_idx: int) -> None:
        """Append a blank shared item to a cache field."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_field_add_shared_item_blank(
                h, _uint(cache_id, "cache_id"), _uint(field_idx, "field_idx")
            ),
            "fm_workbook_pivot_cache_field_add_shared_item_blank",
        )

    def pivot_cache_field_add_shared_item_error(self, cache_id: int, field_idx: int, error_code: int) -> None:
        """Append an Excel error shared item to a cache field."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_field_add_shared_item_error(
                h, _uint(cache_id, "cache_id"), _uint(field_idx, "field_idx"), _sint(error_code, "error")
            ),
            "fm_workbook_pivot_cache_field_add_shared_item_error",
        )

    def pivot_cache_field_clear_shared_items(self, cache_id: int, field_idx: int) -> None:
        """Drop every shared item from a cache field."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_field_clear_shared_items(
                h, _uint(cache_id, "cache_id"), _uint(field_idx, "field_idx")
            ),
            "fm_workbook_pivot_cache_field_clear_shared_items",
        )

    def pivot_cache_record_count(self, cache_id: int) -> int:
        """Return the number of records on the cache."""
        h = self._require()
        return _read_count(LIB.fm_workbook_pivot_cache_record_count, h, _uint(cache_id, "cache_id"))

    def pivot_cache_record_add(self, cache_id: int) -> int:
        """Append an empty record to the cache; return its index."""
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            _check(
                LIB.fm_workbook_pivot_cache_record_add(h, _uint(cache_id, "cache_id"), out),
                "fm_workbook_pivot_cache_record_add",
            )
            return LIB.read_u32(out)

    def pivot_cache_record_clear(self, cache_id: int) -> None:
        """Drop every record from the cache."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_record_clear(h, _uint(cache_id, "cache_id")),
            "fm_workbook_pivot_cache_record_clear",
        )

    def pivot_cache_record_set_number(self, cache_id: int, record_idx: int, field_idx: int, value: float) -> None:
        """Set cache cell ``(record_idx, field_idx)`` to a number."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_record_set_number(
                h,
                _uint(cache_id, "cache_id"),
                _uint(record_idx, "record_idx"),
                _uint(field_idx, "field_idx"),
                float(value),
            ),
            "fm_workbook_pivot_cache_record_set_number",
        )

    def pivot_cache_record_set_text(self, cache_id: int, record_idx: int, field_idx: int, value: str) -> None:
        """Set cache cell ``(record_idx, field_idx)`` to text."""
        h = self._require()
        with _ArgScope() as scope:
            vp = scope.cstr(value)
            _check(
                LIB.fm_workbook_pivot_cache_record_set_text(
                    h, _uint(cache_id, "cache_id"), _uint(record_idx, "record_idx"), _uint(field_idx, "field_idx"), vp
                ),
                "fm_workbook_pivot_cache_record_set_text",
            )

    def pivot_cache_record_set_bool(self, cache_id: int, record_idx: int, field_idx: int, value: bool) -> None:
        """Set cache cell ``(record_idx, field_idx)`` to a boolean."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_record_set_bool(
                h,
                _uint(cache_id, "cache_id"),
                _uint(record_idx, "record_idx"),
                _uint(field_idx, "field_idx"),
                1 if value else 0,
            ),
            "fm_workbook_pivot_cache_record_set_bool",
        )

    def pivot_cache_record_set_blank(self, cache_id: int, record_idx: int, field_idx: int) -> None:
        """Set cache cell ``(record_idx, field_idx)`` to blank."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_record_set_blank(
                h, _uint(cache_id, "cache_id"), _uint(record_idx, "record_idx"), _uint(field_idx, "field_idx")
            ),
            "fm_workbook_pivot_cache_record_set_blank",
        )

    def pivot_cache_record_set_error(self, cache_id: int, record_idx: int, field_idx: int, error_code: int) -> None:
        """Set cache cell ``(record_idx, field_idx)`` to an Excel error."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_cache_record_set_error(
                h,
                _uint(cache_id, "cache_id"),
                _uint(record_idx, "record_idx"),
                _uint(field_idx, "field_idx"),
                _sint(error_code, "error"),
            ),
            "fm_workbook_pivot_cache_record_set_error",
        )

    # -- Pivot tables ------------------------------------------------------
    def pivot_create(self, sheet: int, name: str, cache_id: int, anchor_row: int, anchor_col: int) -> int:
        """Create a new empty pivot table; return its flat index."""
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            out = scope.out_ptr()
            _check(
                LIB.fm_workbook_pivot_create(
                    h,
                    _uint(sheet, "sheet_index"),
                    name_ptr,
                    _uint(cache_id, "cache_id"),
                    _uint(anchor_row, "anchor_row"),
                    _uint(anchor_col, "anchor_col"),
                    out,
                ),
                "fm_workbook_pivot_create",
            )
            return LIB.read_u32(out)

    def get_pivot_report_layout(self, sheet: int, pivot_index: int) -> PivotReportLayout:
        """Return the pivot's compact, tabular, or outline report layout."""
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            _check(
                LIB.fm_workbook_pivot_get_layout(
                    h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), out
                ),
                "fm_workbook_pivot_get_layout",
            )
            return PivotReportLayout(LIB.read_i32(out))

    def set_pivot_report_layout(self, sheet: int, pivot_index: int, layout: "PivotReportLayout | int") -> None:
        """Set the pivot's compact, tabular, or outline report layout."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_set_layout(
                h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), _sint(layout, "layout")
            ),
            "fm_workbook_pivot_set_layout",
        )

    def pivot_remove(self, sheet: int, pivot_index: int) -> None:
        """Remove the pivot table at ``pivot_index``."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_remove(h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index")),
            "fm_workbook_pivot_remove",
        )

    def pivot_set_name(self, sheet: int, pivot_index: int, name: str) -> None:
        """Rename the pivot table."""
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            _check(
                LIB.fm_workbook_pivot_set_name(
                    h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), name_ptr
                ),
                "fm_workbook_pivot_set_name",
            )

    def pivot_set_anchor(
        self,
        sheet: int,
        pivot_index: int,
        anchor_row: int,
        anchor_col: int,
        span_rows: int,
        span_cols: int,
    ) -> None:
        """Update the pivot's anchor cell and span."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_set_anchor(
                h,
                _uint(sheet, "sheet_index"),
                _uint(pivot_index, "pivot_index"),
                _uint(anchor_row, "anchor_row"),
                _uint(anchor_col, "anchor_col"),
                _uint(span_rows, "span_rows"),
                _uint(span_cols, "span_cols"),
            ),
            "fm_workbook_pivot_set_anchor",
        )

    def pivot_set_grand_totals(self, sheet: int, pivot_index: int, rows_enabled: bool, cols_enabled: bool) -> None:
        """Toggle the row / column grand-total bands."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_set_grand_totals(
                h,
                _uint(sheet, "sheet_index"),
                _uint(pivot_index, "pivot_index"),
                1 if rows_enabled else 0,
                1 if cols_enabled else 0,
            ),
            "fm_workbook_pivot_set_grand_totals",
        )

    def pivot_set_style_info(
        self,
        sheet: int,
        pivot_index: int,
        name: Optional[str] = None,
        *,
        show_row_headers: bool = False,
        show_col_headers: bool = False,
        show_row_stripes: bool = False,
        show_col_stripes: bool = False,
        show_last_column: bool = False,
    ) -> None:
        """Set the pivot's table style and toggles, making the style element present.

        ``None`` or an empty ``name`` writes the element without a style name.
        """
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.nonempty_cstr(name)
            _check(
                LIB.fm_workbook_pivot_set_style_info(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(pivot_index, "pivot_index"),
                    name_ptr,
                    1 if show_row_headers else 0,
                    1 if show_col_headers else 0,
                    1 if show_row_stripes else 0,
                    1 if show_col_stripes else 0,
                    1 if show_last_column else 0,
                ),
                "fm_workbook_pivot_set_style_info",
            )

    def pivot_cache_id(self, sheet: int, pivot_index: int) -> int:
        """Return the ``cache_id`` of the pivot cache the pivot draws from."""
        h = self._require()
        return _read_count(
            LIB.fm_workbook_pivot_get_cache_id, h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index")
        )

    def pivot_name(self, sheet: int, pivot_index: int) -> str:
        """Return the pivot's name."""
        h = self._require()
        return _read_cstr_out(
            LIB.fm_workbook_pivot_get_name, h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index")
        )

    def pivot_grand_totals(self, sheet: int, pivot_index: int) -> Tuple[bool, bool]:
        """Return ``(rows, cols)``, the flags :meth:`pivot_set_grand_totals` writes."""
        h = self._require()
        with _ArgScope() as scope:
            rows = scope.out_ptr()
            cols = scope.out_ptr()
            _check(
                LIB.fm_workbook_pivot_get_grand_totals(
                    h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), rows, cols
                ),
                "fm_workbook_pivot_get_grand_totals",
            )
            return LIB.read_i32(rows) != 0, LIB.read_i32(cols) != 0

    def pivot_style_info(self, sheet: int, pivot_index: int) -> PivotStyleInfo:
        """Return the table style :meth:`pivot_set_style_info` writes."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PIVOT_STYLE_INFO)
            _check(
                LIB.fm_workbook_pivot_get_style_info(
                    h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), ptr
                ),
                "fm_workbook_pivot_get_style_info",
            )
            d = S.PIVOT_STYLE_INFO.unpack(LIB, ptr)
            return PivotStyleInfo(
                present=d["present"] != 0,
                name=LIB.read_cstr(d["name"]),
                show_row_headers=d["show_row_headers"] != 0,
                show_col_headers=d["show_col_headers"] != 0,
                show_row_stripes=d["show_row_stripes"] != 0,
                show_col_stripes=d["show_col_stripes"] != 0,
                show_last_column=d["show_last_column"] != 0,
            )

    def _pivot_get_field_order(self, fn, sheet: int, pivot_index: int) -> List[int]:
        h = self._require()
        with _ArgScope() as scope:
            out_ptr = scope.out_ptr()
            out_count = scope.out_ptr()
            _check(
                fn(h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), out_ptr, out_count),
                getattr(fn, "__name__", "pivot_get_field_order"),
            )
            count = LIB.read_u32(out_count)
            if count == 0:
                return []
            raw = LIB.read_bytes(LIB.read_u32(out_ptr), 4 * count)
            return list(struct.unpack("<%dI" % count, raw))

    def pivot_row_field_order(self, sheet: int, pivot_index: int) -> List[int]:
        """Return the row-axis field order (the list :meth:`pivot_set_row_field_order` takes)."""
        return self._pivot_get_field_order(LIB.fm_workbook_pivot_get_row_field_order, sheet, pivot_index)

    def pivot_col_field_order(self, sheet: int, pivot_index: int) -> List[int]:
        """Return the column-axis field order. Same contract as rows."""
        return self._pivot_get_field_order(LIB.fm_workbook_pivot_get_col_field_order, sheet, pivot_index)

    def pivot_field_at(self, sheet: int, pivot_index: int, field_idx: int) -> PivotFieldInfo:
        """Read the definition of pivot field ``field_idx``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PIVOT_FIELD_INFO)
            _check(
                LIB.fm_workbook_pivot_field_at(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(pivot_index, "pivot_index"),
                    _uint(field_idx, "field_idx"),
                    ptr,
                ),
                "fm_workbook_pivot_field_at",
            )
            d = S.PIVOT_FIELD_INFO.unpack(LIB, ptr)
            return PivotFieldInfo(
                source_name=LIB.read_cstr(d["source_name"]),
                custom_name=LIB.read_cstr(d["custom_name"]),
                axis=PivotAxis(d["axis"]) if d["axis"] >= 0 else None,
                subtotal_top=d["subtotal_top"] != 0,
                number_format=LIB.read_cstr(d["number_format"]),
                cache_field_index=d["cache_field_index"],
                sort_order=PivotSortOrder(d["sort_order"]),
                sort_by_field=LIB.read_cstr(d["sort_by_field"]),
                has_date_group=d["has_date_group"] != 0,
                date_granularity=PivotDateGrouping(d["date_granularity"]),
                date_calendar=PivotCalendar(d["date_calendar"]),
                date_start_year=d["date_start_year"],
                date_end_year=d["date_end_year"],
                date_interval_days=d["date_interval_days"],
                date_start_serial=d["date_start_serial"],
                date_end_serial=d["date_end_serial"],
                default_subtotal=d["default_subtotal"] != 0,
                subtotal_fns=tuple(agg for agg in PivotAggregation if d["subtotal_fns"] & (1 << int(agg))),
            )

    def pivot_field_item_count(self, sheet: int, pivot_index: int, field_idx: int) -> int:
        """Return the number of items in pivot field ``field_idx``'s item list."""
        h = self._require()
        return _read_count(
            LIB.fm_workbook_pivot_field_item_count,
            h,
            _uint(sheet, "sheet_index"),
            _uint(pivot_index, "pivot_index"),
            _uint(field_idx, "field_idx"),
        )

    def pivot_field_item_at(self, sheet: int, pivot_index: int, field_idx: int, item_idx: int) -> PivotItemInfo:
        """Read item ``item_idx`` of pivot field ``field_idx``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PIVOT_ITEM_INFO)
            _check(
                LIB.fm_workbook_pivot_field_item_at(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(pivot_index, "pivot_index"),
                    _uint(field_idx, "field_idx"),
                    _uint(item_idx, "item_idx"),
                    ptr,
                ),
                "fm_workbook_pivot_field_item_at",
            )
            d = S.PIVOT_ITEM_INFO.unpack(LIB, ptr)
            return PivotItemInfo(
                name=LIB.read_cstr(d["name"]),
                cache_index=d["cache_index"],
                visible=d["visible"] != 0,
            )

    def pivot_data_field_at(self, sheet: int, pivot_index: int, data_field_idx: int) -> PivotDataFieldSpec:
        """Read data field ``data_field_idx`` in the shape ``pivot_data_field_add`` accepts."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PIVOT_DATA_FIELD_SPEC)
            _check(
                LIB.fm_workbook_pivot_data_field_at(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(pivot_index, "pivot_index"),
                    _uint(data_field_idx, "data_field_idx"),
                    ptr,
                ),
                "fm_workbook_pivot_data_field_at",
            )
            d = S.PIVOT_DATA_FIELD_SPEC.unpack(LIB, ptr)
            return PivotDataFieldSpec(
                name=LIB.read_cstr(d["name"]),
                field_index=d["field_index"],
                aggregation=PivotAggregation(d["aggregation"]),
                number_format=LIB.read_cstr(d["number_format"]),
                show_as=PivotShowValuesAs(d["show_as"]),
                show_as_base_field=d["show_as_base_field"],
                show_as_base_item=d["show_as_base_item"],
            )

    def pivot_field_count(self, sheet: int, pivot_index: int) -> int:
        """Return the number of fields configured on the pivot."""
        h = self._require()
        return _read_count(
            LIB.fm_workbook_pivot_field_count, h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index")
        )

    def pivot_field_add(self, sheet: int, pivot_index: int, spec: PivotFieldSpec) -> int:
        """Place a field on the pivot; return its index.

        A pivot's fields are positional over its cache's fields (field ``i``
        is cache field ``i``). When ``source_name`` names a cache field the
        pivot first gets one bare, axis-less field per cache field and the
        named one is configured in place, so the index is that cache field's
        position and adding it again updates it. A name the cache lacks
        appends a field. A field added on the row or column axis is appended
        to that axis's field order.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PIVOT_FIELD_SPEC)
            out = scope.out_ptr()
            S.PIVOT_FIELD_SPEC.pack(
                LIB,
                ptr,
                {
                    "axis": _sint(spec.axis, "axis"),
                    "subtotal_top": 1 if spec.subtotal_top else 0,
                },
            )
            S.write_str_field(LIB, ptr, S.PIVOT_FIELD_SPEC, "source_name", spec.source_name, scope)
            S.write_str_field(LIB, ptr, S.PIVOT_FIELD_SPEC, "custom_name", spec.custom_name, scope)
            S.write_str_field(
                LIB,
                ptr,
                S.PIVOT_FIELD_SPEC,
                "number_format",
                spec.number_format,
                scope,
            )
            _check(
                LIB.fm_workbook_pivot_field_add(
                    h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), ptr, out
                ),
                "fm_workbook_pivot_field_add",
            )
            return LIB.read_u32(out)

    def pivot_field_clear(self, sheet: int, pivot_index: int) -> None:
        """Drop every field from the pivot."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_field_clear(h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index")),
            "fm_workbook_pivot_field_clear",
        )

    def pivot_field_set_axis(self, sheet: int, pivot_index: int, field_idx: int, axis: "PivotAxis | int") -> None:
        """Set the axis of pivot field ``field_idx``.

        Moving onto the row or column axis appends the field to that axis's
        order; moving off removes it from the order it was in. ``-1`` takes
        the field off every axis: its data fields are removed (later
        data-field indices shift down), as are filters naming it and
        value filters scoring a removed data field.
        """
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_field_set_axis(
                h,
                _uint(sheet, "sheet_index"),
                _uint(pivot_index, "pivot_index"),
                _uint(field_idx, "field_idx"),
                _sint(axis, "axis"),
            ),
            "fm_workbook_pivot_field_set_axis",
        )

    def pivot_field_set_sort(
        self,
        sheet: int,
        pivot_index: int,
        field_idx: int,
        order: "PivotSortOrder | int",
        by_field: str = "",
    ) -> None:
        """Set the sibling order of pivot field ``field_idx``.

        ``PivotSortOrder.MANUAL`` rejects a non-empty ``by_field``.
        """
        h = self._require()
        with _ArgScope() as scope:
            by_ptr = scope.nonempty_cstr(by_field)
            _check(
                LIB.fm_workbook_pivot_field_set_sort(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(pivot_index, "pivot_index"),
                    _uint(field_idx, "field_idx"),
                    _sint(order, "order"),
                    by_ptr,
                ),
                "fm_workbook_pivot_field_set_sort",
            )

    def pivot_field_set_subtotal_top(self, sheet: int, pivot_index: int, field_idx: int, top: bool) -> None:
        """Set the ``subtotal_top`` flag on pivot field ``field_idx``."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_field_set_subtotal_top(
                h,
                _uint(sheet, "sheet_index"),
                _uint(pivot_index, "pivot_index"),
                _uint(field_idx, "field_idx"),
                1 if top else 0,
            ),
            "fm_workbook_pivot_field_set_subtotal_top",
        )

    def pivot_field_add_item(self, sheet: int, pivot_index: int, field_idx: int, name: str, visible: bool) -> None:
        """Append a manual-filter item addressed by its label.

        The item carries no cache binding, so records are matched by
        comparing their rendered label against ``name``. The blank item has
        no label of its own; build it with
        :meth:`pivot_field_add_item_at` instead.
        """
        h = self._require()
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            _check(
                LIB.fm_workbook_pivot_field_add_item(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(pivot_index, "pivot_index"),
                    _uint(field_idx, "field_idx"),
                    name_ptr,
                    1 if visible else 0,
                ),
                "fm_workbook_pivot_field_add_item",
            )

    def pivot_field_add_item_at(
        self, sheet: int, pivot_index: int, field_idx: int, cache_index: int, visible: bool
    ) -> None:
        """Append a manual-filter item addressed by its cache shared-item index.

        ``cache_index`` selects ``shared_items[cache_index]`` of the bound
        cache field, the same index space as OOXML ``<item x="N">``. The
        label is resolved from that shared item, so a shared item that
        renders to nothing produces the blank item.
        """
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_field_add_item_at(
                h,
                _uint(sheet, "sheet_index"),
                _uint(pivot_index, "pivot_index"),
                _uint(field_idx, "field_idx"),
                _uint(cache_index, "cache_index"),
                1 if visible else 0,
            ),
            "fm_workbook_pivot_field_add_item_at",
        )

    def pivot_field_clear_items(self, sheet: int, pivot_index: int, field_idx: int) -> None:
        """Drop every manual-filter item from pivot field ``field_idx``."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_field_clear_items(
                h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), _uint(field_idx, "field_idx")
            ),
            "fm_workbook_pivot_field_clear_items",
        )

    def pivot_field_set_item_visible(
        self,
        sheet: int,
        pivot_index: int,
        field_idx: int,
        item_idx: int,
        visible: bool,
    ) -> None:
        """Toggle the visibility of item ``item_idx`` on field ``field_idx``."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_field_set_item_visible(
                h,
                _uint(sheet, "sheet_index"),
                _uint(pivot_index, "pivot_index"),
                _uint(field_idx, "field_idx"),
                _uint(item_idx, "item_idx"),
                1 if visible else 0,
            ),
            "fm_workbook_pivot_field_set_item_visible",
        )

    def pivot_field_add_subtotal_fn(
        self, sheet: int, pivot_index: int, field_idx: int, agg: "PivotAggregation | int"
    ) -> None:
        """Append a subtotal-fn entry to pivot field ``field_idx``."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_field_add_subtotal_fn(
                h,
                _uint(sheet, "sheet_index"),
                _uint(pivot_index, "pivot_index"),
                _uint(field_idx, "field_idx"),
                _sint(agg, "agg"),
            ),
            "fm_workbook_pivot_field_add_subtotal_fn",
        )

    def pivot_field_clear_subtotal_fns(self, sheet: int, pivot_index: int, field_idx: int) -> None:
        """Drop every subtotal-fn entry from pivot field ``field_idx``."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_field_clear_subtotal_fns(
                h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), _uint(field_idx, "field_idx")
            ),
            "fm_workbook_pivot_field_clear_subtotal_fns",
        )

    def pivot_field_set_date_group(
        self,
        sheet: int,
        pivot_index: int,
        field_idx: int,
        granularity: "PivotDateGrouping | int",
        calendar: "PivotCalendar | int",
        start_year: int = -1,
        end_year: int = -1,
        interval_days: int = 1,
        start_serial: float = -1.0,
        end_serial: float = -1.0,
    ) -> None:
        """Configure date-grouping on pivot field ``field_idx``.

        ``interval_days`` is the ``PivotDateGrouping.DAYS``-only bucket
        width in whole days; leave it at ``1`` for every other
        granularity. ``start_serial`` / ``end_serial`` are the
        ``DAYS``-only Start/End window, as Excel date serials -- leave
        either at ``-1`` to keep it auto (Start = the field's data
        minimum, End = the data maximum plus one day); both are ignored
        for every other granularity. With ``DAYS``, a zero
        ``interval_days`` or a start after the end raises
        ``FormulonError``.
        """
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_field_set_date_group(
                h,
                _uint(sheet, "sheet_index"),
                _uint(pivot_index, "pivot_index"),
                _uint(field_idx, "field_idx"),
                _sint(granularity, "granularity"),
                _sint(calendar, "calendar"),
                _sint(start_year, "start_year_or_neg1"),
                _sint(end_year, "end_year_or_neg1"),
                _uint(interval_days, "interval_days"),
                float(start_serial),
                float(end_serial),
            ),
            "fm_workbook_pivot_field_set_date_group",
        )

    def pivot_field_clear_date_group(self, sheet: int, pivot_index: int, field_idx: int) -> None:
        """Remove the date-grouping config from pivot field ``field_idx``."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_field_clear_date_group(
                h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), _uint(field_idx, "field_idx")
            ),
            "fm_workbook_pivot_field_clear_date_group",
        )

    def pivot_field_set_number_format(self, sheet: int, pivot_index: int, field_idx: int, fmt: str) -> None:
        """Set the ``numFmtId`` of pivot field ``field_idx``.

        ``fmt`` is a decimal id string naming a built-in format or one returned
        by :meth:`add_num_fmt`; the empty string clears it.
        """
        h = self._require()
        with _ArgScope() as scope:
            fmt_ptr = scope.cstr(fmt)
            _check(
                LIB.fm_workbook_pivot_field_set_number_format(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(pivot_index, "pivot_index"),
                    _uint(field_idx, "field_idx"),
                    fmt_ptr,
                ),
                "fm_workbook_pivot_field_set_number_format",
            )

    def pivot_set_row_field_order(self, sheet: int, pivot_index: int, indices: Sequence[int]) -> None:
        """Replace the row-axis field order with ``indices``.

        The list is the axis's whole membership: listed fields move onto the
        row axis, and fields left out come off it. Each index may appear once.
        """
        self._pivot_set_field_order(
            LIB.fm_workbook_pivot_set_row_field_order,
            _uint(sheet, "sheet_index"),
            _uint(pivot_index, "pivot_index"),
            indices,
        )

    def pivot_set_col_field_order(self, sheet: int, pivot_index: int, indices: Sequence[int]) -> None:
        """Replace the column-axis field order with ``indices``.

        Same contract as :meth:`pivot_set_row_field_order`.
        """
        self._pivot_set_field_order(
            LIB.fm_workbook_pivot_set_col_field_order,
            _uint(sheet, "sheet_index"),
            _uint(pivot_index, "pivot_index"),
            indices,
        )

    def _pivot_set_field_order(self, fn, sheet: int, pivot_index: int, indices: Sequence[int]) -> None:
        h = self._require()
        arr_ptr = 0
        with _ArgScope() as scope:
            if indices:
                arr_ptr = scope.alloc(4 * len(indices))
                buf = b"".join(struct.pack("<I", _uint(i, "index")) for i in indices)
                LIB.write_bytes(arr_ptr, buf)
            _check(
                fn(h, sheet, pivot_index, arr_ptr, _uint(len(indices), "count")),
                getattr(fn, "__name__", "pivot_set_field_order"),
            )

    def pivot_data_field_count(self, sheet: int, pivot_index: int) -> int:
        """Return the number of ``<dataField>`` entries on the pivot."""
        h = self._require()
        return _read_count(
            LIB.fm_workbook_pivot_data_field_count, h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index")
        )

    def pivot_data_field_add(self, sheet: int, pivot_index: int, spec: PivotDataFieldSpec) -> int:
        """Append a data-field entry; return its index."""
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            ptr = self._pack_data_field_spec(spec, scope)
            _check(
                LIB.fm_workbook_pivot_data_field_add(
                    h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), ptr, out
                ),
                "fm_workbook_pivot_data_field_add",
            )
            return LIB.read_u32(out)

    def pivot_data_field_set(
        self,
        sheet: int,
        pivot_index: int,
        data_field_idx: int,
        spec: PivotDataFieldSpec,
    ) -> None:
        """Replace the data-field entry at ``data_field_idx`` in place."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = self._pack_data_field_spec(spec, scope)
            _check(
                LIB.fm_workbook_pivot_data_field_set(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(pivot_index, "pivot_index"),
                    _uint(data_field_idx, "data_field_idx"),
                    ptr,
                ),
                "fm_workbook_pivot_data_field_set",
            )

    @staticmethod
    def _pack_data_field_spec(spec: PivotDataFieldSpec, scope: _ArgScope) -> int:
        ptr = scope.struct(S.PIVOT_DATA_FIELD_SPEC)
        S.PIVOT_DATA_FIELD_SPEC.pack(
            LIB,
            ptr,
            {
                "field_index": _uint(spec.field_index, "field_index"),
                "aggregation": _sint(spec.aggregation, "aggregation"),
                "show_as": _sint(spec.show_as, "show_as"),
                "show_as_base_field": _sint(spec.show_as_base_field, "show_as_base_field"),
                "show_as_base_item": _sint(spec.show_as_base_item, "show_as_base_item"),
            },
        )
        S.write_str_field(LIB, ptr, S.PIVOT_DATA_FIELD_SPEC, "name", spec.name, scope)
        S.write_str_field(
            LIB,
            ptr,
            S.PIVOT_DATA_FIELD_SPEC,
            "number_format",
            spec.number_format,
            scope,
        )
        return ptr

    def pivot_data_field_clear(self, sheet: int, pivot_index: int) -> None:
        """Drop every data-field entry from the pivot."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_data_field_clear(h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index")),
            "fm_workbook_pivot_data_field_clear",
        )

    def pivot_filter_count(self, sheet: int, pivot_index: int) -> int:
        """Return the number of filters on the pivot; see :meth:`pivot_filter_at`."""
        h = self._require()
        return _read_count(
            LIB.fm_workbook_pivot_filter_count, h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index")
        )

    def pivot_filter_at(self, sheet: int, pivot_index: int, filter_idx: int) -> PivotFilterSpec:
        """Read the filter at ``filter_idx`` without mutating it.

        The filter list is saved as the definition's ``<filters>`` block. A
        loaded file's caption contains / begins-with, top-N count, value
        greater-than / between and date-between entries appear here, naming
        their field by source name. Its other entries are not listed, still
        filter, survive :meth:`pivot_filter_clear` /
        :meth:`pivot_filter_remove_at`, and are saved verbatim.
        """
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PIVOT_FILTER_SPEC)
            _check(
                LIB.fm_workbook_pivot_filter_at(
                    h,
                    _uint(sheet, "sheet_index"),
                    _uint(pivot_index, "pivot_index"),
                    _uint(filter_idx, "filter_idx"),
                    ptr,
                ),
                "fm_workbook_pivot_filter_at",
            )
            d = S.PIVOT_FILTER_SPEC.unpack(LIB, ptr)
            return PivotFilterSpec(
                axis=PivotAxis(d["axis"]),
                field_name=LIB.read_cstr(d["field_name"]),
                type=PivotFilterType(d["type"]),
                value_kind=PivotFilterValueKind(d["value_kind"]),
                value_int=d["value_int"],
                value_double=d["value_double"],
                value_text=LIB.read_cstr(d["value_text"]),
                value_high_kind=PivotFilterValueKind(d["value_high_kind"]),
                value_high_int=d["value_high_int"],
                value_high_double=d["value_high_double"],
                data_field_index=d["data_field_index"],
            )

    def pivot_filter_add(self, sheet: int, pivot_index: int, spec: PivotFilterSpec) -> None:
        """Append a filter to the pivot; it is saved with it. See :meth:`pivot_filter_at`."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.PIVOT_FILTER_SPEC)
            S.PIVOT_FILTER_SPEC.pack(
                LIB,
                ptr,
                {
                    "axis": _sint(spec.axis, "axis"),
                    "type": _sint(spec.type, "type"),
                    "data_field_index": _uint(spec.data_field_index, "data_field_index"),
                    "value_kind": _sint(spec.value_kind, "value_kind"),
                    "value_int": _sint(spec.value_int, "value_int"),
                    "value_double": float(spec.value_double),
                    "value_high_kind": _sint(spec.value_high_kind, "value_high_kind"),
                    "value_high_int": _sint(spec.value_high_int, "value_high_int"),
                    "value_high_double": float(spec.value_high_double),
                },
            )
            S.write_str_field(LIB, ptr, S.PIVOT_FILTER_SPEC, "field_name", spec.field_name, scope)
            S.write_str_field(LIB, ptr, S.PIVOT_FILTER_SPEC, "value_text", spec.value_text, scope)
            _check(
                LIB.fm_workbook_pivot_filter_add(
                    h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), ptr
                ),
                "fm_workbook_pivot_filter_add",
            )

    def pivot_filter_clear(self, sheet: int, pivot_index: int) -> None:
        """Drop every listed filter from the pivot."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_filter_clear(h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index")),
            "fm_workbook_pivot_filter_clear",
        )

    def pivot_filter_remove_at(self, sheet: int, pivot_index: int, filter_idx: int) -> None:
        """Remove the filter at ``filter_idx``."""
        h = self._require()
        _check(
            LIB.fm_workbook_pivot_filter_remove_at(
                h, _uint(sheet, "sheet_index"), _uint(pivot_index, "pivot_index"), _uint(filter_idx, "filter_idx")
            ),
            "fm_workbook_pivot_filter_remove_at",
        )

    # -- Dependency-graph trace --------------------------------------------
    def precedents(self, sheet: int, row: int, col: int, depth: int = 1) -> List[CellNode]:
        """Return the cells ``(sheet, row, col)`` reads (up to ``depth``)."""
        return self._trace(
            LIB.fm_workbook_precedents,
            _uint(sheet, "sheet"),
            _uint(row, "row"),
            _uint(col, "col"),
            _uint(depth, "depth"),
        )

    def dependents(self, sheet: int, row: int, col: int, depth: int = 1) -> List[CellNode]:
        """Return the cells that read ``(sheet, row, col)`` (up to ``depth``)."""
        return self._trace(
            LIB.fm_workbook_dependents,
            _uint(sheet, "sheet"),
            _uint(row, "row"),
            _uint(col, "col"),
            _uint(depth, "depth"),
        )

    def _trace(self, fn, sheet: int, row: int, col: int, depth: int) -> List[CellNode]:
        h = self._require()
        with _ArgScope() as scope:
            out = scope.out_ptr()
            handle = 0
            try:
                _check(
                    fn(h, sheet, row, col, depth, out),
                    getattr(fn, "__name__", "trace"),
                )
                handle = LIB.read_u32(out)
                nodes: List[CellNode] = []
                n = LIB.fm_cell_nodes_count(handle)
                # One scratch block for the whole walk; see iter_defined_names.
                nptr = scope.struct(S.CELL_NODE)
                for i in range(n):
                    S.zero_struct(LIB, S.CELL_NODE, nptr)
                    _check(LIB.fm_cell_nodes_at(handle, _uint(i, "idx"), nptr), "fm_cell_nodes_at")
                    d = S.CELL_NODE.unpack(LIB, nptr)
                    nodes.append(CellNode(sheet=d["sheet"], row=d["row"], col=d["col"]))
                return nodes
            finally:
                if handle:
                    LIB.fm_cell_nodes_destroy(handle)

    # -- Dynamic-array spill -----------------------------------------------
    def spill_info(self, sheet: int, row: int, col: int) -> SpillInfo:
        """Return dynamic-array spill info for ``(sheet, row, col)``."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.SPILL_INFO)
            _check(
                LIB.fm_workbook_spill_info(h, _uint(sheet, "sheet"), _uint(row, "row"), _uint(col, "col"), ptr),
                "fm_workbook_spill_info",
            )
            d = S.SPILL_INFO.unpack(LIB, ptr)
            return SpillInfo(
                engaged=bool(d["engaged"]),
                anchor_row=d["anchor_row"],
                anchor_col=d["anchor_col"],
                rows=d["rows"],
                cols=d["cols"],
            )

    # -- Function catalog (workbook-independent) ---------------------------
    @staticmethod
    def function_count() -> int:
        """Return the total number of registered Formulon functions."""
        return int(LIB.fm_function_count())

    @staticmethod
    def function_name_at(index: int) -> str:
        """Return the canonical name of the ``index``-th function."""
        return _read_cstr_out(
            LIB.fm_function_name_at,
            _uint(index, "idx"),
            default_op="fm_function_name_at",
        )

    @staticmethod
    def function_metadata(name: str) -> Optional[FunctionMetadata]:
        """Return metadata for ``name`` or ``None`` when unknown.

        The metadata is locale-invariant.

        Args:
          name: canonical function name, matched case-insensitively.

        Returns:
          The metadata, or ``None`` when ``name`` matches no registered
          function.
        """
        with _ArgScope() as scope:
            name_ptr = scope.cstr(name)
            ptr = scope.struct(S.FUNCTION_METADATA)
            status = LIB.fm_function_metadata(name_ptr, ptr)
            if status != 0:
                return None
            d = S.FUNCTION_METADATA.unpack(LIB, ptr)
            sig = LIB.read_cstr(d["signature_template"]) if d["signature_template"] else None
            desc = LIB.read_cstr(d["description"]) if d["description"] else None
            # 0xFFFFFFFF is the unbounded / unknown-arity sentinel; expose it
            # as None so callers do not treat it as a concrete upper bound.
            raw_max = d["max_arity"]
            max_arity = None if raw_max == 0xFFFFFFFF else raw_max
            return FunctionMetadata(
                name=LIB.read_cstr(d["canonical_name"]),
                min_arity=d["min_arity"],
                max_arity=max_arity,
                availability=d["availability"],
                signature_template=sig,
                description=desc,
            )

    @staticmethod
    def _map_profile_text(fn_name: str, text: str, profile_id: str) -> str:
        """Call a ``(text, profile_id) -> text`` catalog entry point."""
        with _ArgScope() as scope:
            text_ptr = scope.cstr(text)
            pid_ptr = scope.cstr(profile_id)
            return _read_cstr_out(getattr(LIB, fn_name), text_ptr, pid_ptr, default_op=fn_name)

    @staticmethod
    def localize_function_name(canonical_name: str, profile_id: ExcelProfileId) -> str:
        """Return the display name of ``canonical_name`` under ``profile_id``."""
        return Workbook._map_profile_text("fm_function_localize", canonical_name, profile_id)

    @staticmethod
    def canonicalize_function_name(localized_name: str, profile_id: ExcelProfileId) -> str:
        """Return the canonical English name for ``localized_name`` under ``profile_id``."""
        return Workbook._map_profile_text("fm_function_canonicalize", localized_name, profile_id)

    @staticmethod
    def localize_formula(formula: str, profile_id: ExcelProfileId) -> str:
        """Rewrite stored (en-invariant) formula text into ``profile_id``'s spelling.

        Function names, list / array separators, decimal points, booleans
        and error names take the locale form; strings, quoted sheet names,
        external qualifiers and structured-reference brackets are kept
        verbatim. A pure text rewrite: the grammar is not validated.
        """
        return Workbook._map_profile_text("fm_formula_localize", formula, profile_id)

    @staticmethod
    def canonicalize_formula(formula: str, profile_id: ExcelProfileId) -> str:
        """Rewrite ``profile_id``-spelled formula text into the en-invariant form."""
        return Workbook._map_profile_text("fm_formula_canonicalize", formula, profile_id)

    @staticmethod
    def locale_facts(profile_id: ExcelProfileId) -> LocaleFacts:
        """Return the locale facts (separators, names, currency, error names) of ``profile_id``.

        Raises:
          FormulonError: when ``profile_id`` is not a documented profile.
        """
        with _ArgScope() as scope:
            pid_ptr = scope.cstr(profile_id)
            ptr = scope.struct(S.LOCALE_FACTS)
            canonical_out = scope.out_ptr()
            localized_out = scope.out_ptr()
            measured_out = scope.out_ptr()
            _check(LIB.fm_locale_facts(pid_ptr, ptr), "fm_locale_facts")
            d = S.LOCALE_FACTS.unpack(LIB, ptr)
            errors = []
            for index in range(int(LIB.fm_locale_error_name_count())):
                _check(
                    LIB.fm_locale_error_name(
                        pid_ptr, _uint(index, "error_index"), canonical_out, localized_out, measured_out
                    ),
                    "fm_locale_error_name",
                )
                errors.append(
                    ErrorName(
                        canonical=LIB.read_cstr(LIB.read_u32(canonical_out)),
                        localized=LIB.read_cstr(LIB.read_u32(localized_out)),
                        measured=LIB.read_u32(measured_out) != 0,
                    )
                )
            return LocaleFacts(
                decimal_separator=LIB.read_cstr(d["decimal_separator"]),
                group_separator=LIB.read_cstr(d["group_separator"]),
                list_separator=LIB.read_cstr(d["list_separator"]),
                array_column_separator=LIB.read_cstr(d["array_column_separator"]),
                array_row_separator=LIB.read_cstr(d["array_row_separator"]),
                true_name=LIB.read_cstr(d["true_name"]),
                false_name=LIB.read_cstr(d["false_name"]),
                date_order=_DATE_ORDERS[d["date_order"]],
                currency_symbol=LIB.read_cstr(d["currency_symbol"]),
                currency_suffix=d["currency_suffix"] != 0,
                currency_space=d["currency_space"] != 0,
                currency_default_decimals=d["currency_default_decimals"],
                measured=d["measured"] != 0,
                collation_measured=d["collation_measured"] != 0,
                error_names=tuple(errors),
            )

    @staticmethod
    def compare_text(a: str, b: str, strength: CollationStrength, profile_id: ExcelProfileId) -> int:
        """Compare two texts under the collation of ``profile_id``.

        Returns -1, 0 or 1. This is the text fold only, not ``=`` on two
        cells. ``strength`` selects which fold applies.

        Raises:
          FormulonError: on an unknown ``profile_id`` or an out-of-range ``strength``.
        """
        with _ArgScope() as scope:
            a_ptr = scope.cstr(a)
            b_ptr = scope.cstr(b)
            pid_ptr = scope.cstr(profile_id)
            out = scope.out_ptr()
            _check(
                LIB.fm_text_compare(a_ptr, b_ptr, pid_ptr, _sint(strength, "strength"), out),
                "fm_text_compare",
            )
            return struct.unpack("<i", LIB.read_bytes(out, 4))[0]

    @staticmethod
    def collation_classes(
        values: Sequence[Value], strength: CollationStrength, profile_id: ExcelProfileId
    ) -> CollationClasses:
        """Classify ``values`` into collation-ordered equivalence classes.

        Two values share an id only when they have the same kind and compare
        equal under the ``strength`` text fold (``-0`` equals ``0``; blanks
        are always equal). Ids are dense from 0 in ascending SORT order:
        numbers < text < booleans < errors < blanks. ``strength`` selects the
        text fold only; type boundaries never depend on it.

        Ids are valid only within one call. Usage:

        * Dedup or checklist order: take the first position of each id and
          order by id.
        * Sort: stable-sort by id; reverse for descending, keeping blanks last.
        * Re-applying a saved selection: classify the saved values plus the
          column values in one call and select the matching ids.

        Raises:
          FormulonError: on an unknown ``profile_id``, an out-of-range
            ``strength``, a non-finite number or an out-of-range error code.
        """
        values = [_check_value(v) for v in values]
        n = len(values)
        with _ArgScope() as scope:
            pid_ptr = scope.cstr(profile_id)
            count_out = scope.alloc(4)
            base = scope.value_array(n)
            for i, v in enumerate(values):
                _write_value_input(v, base + i * fm_value_t_size, scope)
            ids = 0
            if n:
                ids = scope.alloc(4 * n)
            _check(
                LIB.fm_collation_classes(base, _uint(n, "count"), pid_ptr, _sint(strength, "strength"), ids, count_out),
                "fm_collation_classes",
            )
            class_ids = list(struct.unpack(f"<{n}I", LIB.read_bytes(ids, 4 * n))) if n else []
            return CollationClasses(class_ids=class_ids, class_count=LIB.read_u32(count_out))

    # -- External links ----------------------------------------------------
    def external_link_count(self) -> int:
        """Return the number of external-link records on the workbook."""
        h = self._require()
        return _read_count(
            LIB.fm_workbook_external_link_count,
            h,
            default_op="fm_workbook_external_link_count",
        )

    def get_external_link_at(self, index: int) -> ExternalLink:
        """Read the ``index``-th external-link record."""
        h = self._require()
        with _ArgScope() as scope:
            ptr = scope.struct(S.EXTERNAL_LINK_RECORD)
            _check(
                LIB.fm_workbook_external_link_at(h, _uint(index, "index"), ptr),
                "fm_workbook_external_link_at",
            )
            d = S.EXTERNAL_LINK_RECORD.unpack(LIB, ptr)
            return ExternalLink(
                index=d["index"],
                rel_id=LIB.read_cstr(d["rel_id"]),
                part_path=LIB.read_cstr(d["part_path"]),
                target=LIB.read_cstr(d["target"]),
                target_external=bool(d["target_external"]),
                kind=ExternalLinkKind(d["kind"]),
            )

    def get_external_links(self) -> List[ExternalLink]:
        """Return every external-link record in document order."""
        n = self.external_link_count()
        return [self.get_external_link_at(i) for i in range(n)]


def _lock_workbook_method(method):
    """Serialize one complete public operation on the shared WASM store.

    A normal method can make several ABI calls while it copies borrowed
    pointers into Python objects.  Locking only those individual calls leaves
    the handle and borrowed memory exposed between calls.  Generators need a
    slightly different shape: hold the lock through one ``next`` call so the
    item is decoded before it is yielded, then release it while the consumer
    examines the item.  Closing the underlying generator is also serialized
    so its scratch buffers are released before another operation starts.
    """

    if isgeneratorfunction(method):

        @wraps(method)
        def locked_generator(*args, **kwargs):
            iterator = method(*args, **kwargs)
            try:
                while True:
                    with LIB.call_lock:
                        try:
                            item = next(iterator)
                        except StopIteration:
                            return
                    yield item
            finally:
                with LIB.call_lock:
                    close = getattr(iterator, "close", None)
                    if close is not None:
                        close()

        return locked_generator

    if getattr(method, "__name__", None) == "__del__":

        @wraps(method)
        def locked_finalizer(*args, **kwargs):
            # Keep the destructor's no-raise contract even when interpreter
            # teardown has already cleared LIB. During normal execution the
            # same RLock also covers the nested close() call.
            try:
                with LIB.call_lock:
                    return method(*args, **kwargs)
            except Exception:  # noqa: BLE001 - finalizers must not raise
                return None

        return locked_finalizer

    @wraps(method)
    def locked(*args, **kwargs):
        with LIB.call_lock:
            return method(*args, **kwargs)

    return locked


def _install_workbook_locks() -> None:
    """Wrap every Workbook operation while preserving its descriptors."""

    for name, descriptor in list(Workbook.__dict__.items()):
        if isinstance(descriptor, property):
            setattr(
                Workbook,
                name,
                property(
                    _lock_workbook_method(descriptor.fget) if descriptor.fget is not None else None,
                    _lock_workbook_method(descriptor.fset) if descriptor.fset is not None else None,
                    _lock_workbook_method(descriptor.fdel) if descriptor.fdel is not None else None,
                    descriptor.__doc__,
                ),
            )
        elif isinstance(descriptor, classmethod):
            setattr(Workbook, name, classmethod(_lock_workbook_method(descriptor.__func__)))
        elif isinstance(descriptor, staticmethod):
            setattr(Workbook, name, staticmethod(_lock_workbook_method(descriptor.__func__)))
        elif callable(descriptor):
            setattr(Workbook, name, _lock_workbook_method(descriptor))


_install_workbook_locks()
