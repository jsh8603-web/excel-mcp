"""
Compound File Binary (CFB / OLE2) parser.

Implements a subset of [MS-CFB] sufficient to locate and extract
VBA project streams from vbaProject.bin.

Structure overview
------------------
Offset 0       : 512-byte header
  - Magic bytes (8)
  - Sector size (power-of-two exponent, usually 9 -> 512 bytes)
  - Mini-stream cutoff size
  - Number of FAT sectors, root entry start sector, ...
Sectors        : fixed-size blocks that follow the header
  - FAT (File Allocation Table) chains describe how data spans sectors
  - Mini-FAT chains describe how small streams span mini-sectors
  - Directory entries (128 bytes each) live in the directory sector chain
"""

from __future__ import annotations

import struct
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import BinaryIO

from pyopenvba.exceptions import CFBError

# ---------------------------------------------------------------------------
# Constants from the MS-CFB specification
# ---------------------------------------------------------------------------

_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"

_FREESECT: int = 0xFFFF_FFFF   # unused sector
_ENDOFCHAIN: int = 0xFFFF_FFFE  # end of a FAT chain
_FATSECT: int = 0xFFFF_FFFD    # sector is part of the FAT
_DIFSECT: int = 0xFFFF_FFFC    # sector is part of the DIFAT
_NOSTREAM: int = 0xFFFF_FFFF   # no sibling / no child

# FAT sector numbers the header lists, and a 512-byte DIFAT sector's after it
# (the sector's last four bytes hold the next DIFAT sector's number).
_HEADER_DIFAT = 109
_DIFAT_PER_SECTOR = 127

# Directory entry object types
_OBJTYPE_EMPTY: int = 0
_OBJTYPE_STORAGE: int = 1
_OBJTYPE_STREAM: int = 2
_OBJTYPE_ROOT: int = 5

# Directory entry colours in a storage's red-black tree ([MS-CFB] 2.6.4)
_RED: int = 0
_BLACK: int = 1

# Spec field order: sig(8), CLSID(16), minorVer(2), majorVer(2), byteOrder(2),
# sectorShift(2), miniSectorShift(2), reserved(6), then nine DWORDs, then DIFAT(436)
_HEADER_FMT = "<8s16sHHHHH6sIIIIIIIII436s"
_HEADER_SIZE = struct.calcsize(_HEADER_FMT)  # == 512

# name(64), nameLen(2), type(1), color(1), left(4), right(4), child(4),
# CLSID(16), state(4), created(8), modified(8), startSector(4), sizeLow(4), sizeHigh(4)
_DIR_ENTRY_FMT = "<64sHBBIII16sIQQIII"
_DIR_ENTRY_SIZE = struct.calcsize(_DIR_ENTRY_FMT)  # == 128


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class DirEntry:
    name: str
    obj_type: int
    child_id: int
    left_sibling_id: int
    right_sibling_id: int
    start_sector: int
    size: int
    is_mini: bool = False  # True when size < mini-stream cutoff
    # Preserved verbatim for round-trip writes (CLSID, state, timestamps, etc.)
    raw: bytes = b""
    # Red or black in the parent storage's tree; a rebuilt tree recolours its entries.
    color: int = _BLACK


class CFB:
    """Parsed Compound File Binary."""

    # ------------------------------------------------------------------
    # Constructor: build via from_bytes() / from_file()
    # ------------------------------------------------------------------

    def __init__(self, data: bytes) -> None:
        self._data: bytes = data
        self.sector_size: int = 512
        self.mini_sector_size: int = 64
        self.mini_stream_cutoff: int = 4096
        self._fat: list[int] = []
        self._minifat: list[int] = []
        self._directory: list[DirEntry] = []
        self._mini_stream: bytes = b""
        # Pending overrides for write-back; key = directory index, value = new stream bytes.
        self._stream_overrides: dict[int, bytes] = {}

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_bytes(cls, data: bytes) -> CFB:
        cfb = cls(data)
        cfb._parse()
        return cfb

    @classmethod
    def from_file(cls, fh: BinaryIO) -> CFB:
        return cls.from_bytes(fh.read())

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def list_streams(self) -> list[str]:
        """Return the names of all stream entries (not storages)."""
        return [e.name for e in self._directory if e.obj_type == _OBJTYPE_STREAM]

    def get_stream(self, name: str) -> bytes:
        """Return the raw bytes of the first stream with a matching name
        anywhere in the directory (case-insensitive, directory order).

        Deliberately storage-agnostic: root-level project streams such as
        ``PROJECT`` sit at the CFB root in ``vbaProject.bin`` but nested
        inside ``_VBA_PROJECT_CUR`` in legacy ``.xls`` files, and this
        lookup finds them in either layout.  Use
        :meth:`get_stream_in_storage` when the parent storage matters.
        """
        needle = name.casefold()
        for entry in self._directory:
            if entry.obj_type == _OBJTYPE_STREAM and entry.name.casefold() == needle:
                return self._read_stream(entry)
        raise KeyError(f"Stream not found: {name!r}")

    def get_stream_in_storage(self, storage: str, name: str) -> bytes:
        """Return the raw bytes of a stream that is a direct child of the
        named storage.

        Both lookups are case-insensitive.  Only the storage's own child
        subtree is searched, so same-named streams in other storages (for
        example the ``o`` / ``f`` streams of two UserForms) can never
        shadow each other.  Raises ``KeyError`` if the storage or the
        child stream does not exist.
        """
        parent_idx = self._find_storage_index(storage)
        child_idx = self._find_child_stream_index(parent_idx, name)
        if child_idx is None:
            raise KeyError(f"Stream {name!r} not found in storage {storage!r}")
        return self._read_stream(self._directory[child_idx])

    def list_storages_at(self, path: Sequence[str] = ()) -> list[str]:
        """Return the storages directly inside the storage at ``path``.

        ``path`` is a sequence of storage names from the root, so nested
        storages that share a name -- a UserForm's ``i06`` and another
        form's ``i06`` -- stay distinct.  An empty path means the root.
        """
        parent_idx = self._resolve_path(path)
        return [
            self._directory[i].name
            for i in sorted(self._collect_subtree(self._directory[parent_idx].child_id))
            if self._directory[i].obj_type == _OBJTYPE_STORAGE
        ]

    def list_streams_at(self, path: Sequence[str] = ()) -> list[str]:
        """Return the streams directly inside the storage at ``path``."""
        parent_idx = self._resolve_path(path)
        return [
            self._directory[i].name
            for i in sorted(self._collect_subtree(self._directory[parent_idx].child_id))
            if self._directory[i].obj_type == _OBJTYPE_STREAM
        ]

    def get_stream_at(self, path: Sequence[str], name: str) -> bytes:
        """Return a stream that is a direct child of the storage at ``path``."""
        parent_idx = self._resolve_path(path)
        child_idx = self._find_child_stream_index(parent_idx, name)
        if child_idx is None:
            joined = "/".join(path)
            raise KeyError(f"Stream {name!r} not found in storage {joined!r}")
        return self._read_stream(self._directory[child_idx])

    def write_stream_at(self, path: Sequence[str], name: str, data: bytes) -> None:
        """Replace a stream that is a direct child of the storage at ``path``.

        The change is held in memory until :meth:`to_bytes`.
        """
        parent_idx = self._resolve_path(path)
        child_idx = self._find_child_stream_index(parent_idx, name)
        if child_idx is None:
            joined = "/".join(path)
            raise KeyError(f"Stream {name!r} not found in storage {joined!r}")
        self._stream_overrides[child_idx] = bytes(data)

    def list_storages(self) -> list[str]:
        """Return the names of all storage entries (excluding the root)."""
        return [
            e.name for e in self._directory
            if e.obj_type == _OBJTYPE_STORAGE
        ]

    def list_streams_in_storage(self, storage: str) -> list[str]:
        """Return the names of the streams that are direct children of the
        named storage (case-insensitive), in directory-entry order.

        Raises ``KeyError`` if the storage does not exist.  Streams that
        live in other storages, or at the root next to the storage, are
        not included.
        """
        parent_idx = self._find_storage_index(storage)
        children = sorted(
            self._collect_subtree(self._directory[parent_idx].child_id)
        )
        return [
            self._directory[i].name
            for i in children
            if self._directory[i].obj_type == _OBJTYPE_STREAM
        ]

    # ------------------------------------------------------------------
    # Internal parsing
    # ------------------------------------------------------------------

    def _parse(self) -> None:
        data = self._data
        if len(data) < _HEADER_SIZE:
            raise CFBError("File too small to be a valid CFB.")
        if data[:8] != _MAGIC:
            raise CFBError("Not a Compound File Binary (magic bytes mismatch).")

        (
            _magic,
            _clsid,
            _minor_ver,
            major_ver,
            _byte_order,
            sector_size_pow,
            mini_sector_size_pow,
            _reserved,
            _num_dir_sectors,
            _num_fat_sectors,
            root_dir_start,
            _sig,
            mini_cutoff,
            minifat_start,
            _num_minifat_sectors,
            difat_start,
            num_difat_sectors,
            difat_array_raw,
        ) = struct.unpack_from(_HEADER_FMT, data, 0)

        if major_ver not in (3, 4):
            raise CFBError(f"Unsupported CFB major version: {major_ver}")
        # [MS-CFB] 2.2: 512-byte sectors in version 3, 4096 in version 4, and
        # 64-byte mini sectors in both.
        if sector_size_pow != (9 if major_ver == 3 else 12) or mini_sector_size_pow != 6:
            raise CFBError(
                f"Unsupported CFB sector sizes: shift {sector_size_pow}, mini shift {mini_sector_size_pow}."
            )

        self.sector_size = 1 << sector_size_pow          # 512 or 4096
        self.mini_sector_size = 1 << mini_sector_size_pow  # 64
        self.mini_stream_cutoff = mini_cutoff             # usually 4096

        # Parse the initial DIFAT array from the header (up to 109 entries)
        difat: list[int] = [int(x) for x in struct.unpack_from("<109I", difat_array_raw)]

        # Follow DIFAT chain for large files (> 109 FAT sectors)
        if difat_start != _ENDOFCHAIN and num_difat_sectors > 0:
            # The header's count is only a claim: a file cannot hold more
            # sectors than its size allows, and a chain that returns to a
            # sector it has visited would otherwise loop for that count.
            if num_difat_sectors > max(0, len(self._data) // self.sector_size - 1):
                raise CFBError(f"The header claims {num_difat_sectors} DIFAT sectors; the file is too short.")
            sector = difat_start
            seen: set[int] = set()
            for _ in range(num_difat_sectors):
                if sector in (_ENDOFCHAIN, _FREESECT):
                    break
                if sector in seen:
                    raise CFBError(f"The DIFAT chain returns to sector {sector}.")
                seen.add(sector)
                sector_data = self._sector(sector)
                if len(sector_data) < self.sector_size:
                    raise CFBError(f"DIFAT sector {sector} lies past the end of the file.")
                entries_per_difat = (self.sector_size // 4) - 1
                extra = [int(x) for x in struct.unpack_from(f"<{entries_per_difat}I", sector_data)]
                difat.extend(extra)
                sector = struct.unpack_from("<I", sector_data, self.sector_size - 4)[0]

        # Build FAT from the sectors listed in the DIFAT
        fat_raw = bytearray()
        for sect in difat:
            if sect in (_FREESECT, _ENDOFCHAIN, _FATSECT, _DIFSECT):
                break
            fat_raw.extend(self._sector(sect))
        fat_count = len(fat_raw) // 4
        self._fat = [int(x) for x in struct.unpack_from(f"<{fat_count}I", fat_raw)]

        # Build mini-FAT
        if minifat_start != _ENDOFCHAIN:
            minifat_raw = bytearray()
            for sect in self._chain(minifat_start):
                minifat_raw.extend(self._sector(sect))
            mf_count = len(minifat_raw) // 4
            self._minifat = [int(x) for x in struct.unpack_from(f"<{mf_count}I", minifat_raw)]

        # Parse directory entries
        dir_raw = bytearray()
        for sect in self._chain(root_dir_start):
            dir_raw.extend(self._sector(sect))
        entries_count = len(dir_raw) // _DIR_ENTRY_SIZE
        self._directory = []
        for i in range(entries_count):
            self._directory.append(self._parse_dir_entry(dir_raw, i))

        # Build mini-stream from the root entry's stream data
        if self._directory:
            root = self._directory[0]
            if root.start_sector not in (_ENDOFCHAIN, _FREESECT):
                ms_raw = bytearray()
                for sect in self._chain(root.start_sector):
                    ms_raw.extend(self._sector(sect))
                self._mini_stream = bytes(ms_raw)

    def _sector(self, index: int) -> bytes:
        # The header takes the whole first sector: 512 bytes in version 3, and
        # 512 bytes padded to 4096 in version 4 ([MS-CFB] 2.2), so sector n
        # starts at (n + 1) * sector_size, not after the 512 header bytes.
        offset = (index + 1) * self.sector_size
        return self._data[offset: offset + self.sector_size]

    def _chain(self, start: int) -> list[int]:
        sectors: list[int] = []
        current = start
        seen: set[int] = set()
        while current not in (_ENDOFCHAIN, _FREESECT):
            if current in seen or current >= len(self._fat):
                raise CFBError(f"Cycle or out-of-range sector in FAT chain at {current}.")
            seen.add(current)
            sectors.append(current)
            current = self._fat[current]
        return sectors

    def _mini_chain(self, start: int) -> list[int]:
        sectors: list[int] = []
        current = start
        seen: set[int] = set()
        while current not in (_ENDOFCHAIN, _FREESECT):
            if current in seen or current >= len(self._minifat):
                raise CFBError(f"Cycle or out-of-range sector in mini-FAT chain at {current}.")
            seen.add(current)
            sectors.append(current)
            current = self._minifat[current]
        return sectors

    def _parse_dir_entry(self, raw: bytes | bytearray, index: int) -> DirEntry:
        offset = index * _DIR_ENTRY_SIZE
        entry_raw = bytes(raw[offset: offset + _DIR_ENTRY_SIZE])
        (
            name_raw,
            name_len,
            obj_type,
            color,
            left_id,
            right_id,
            child_id,
            _clsid,
            _state,
            _created,
            _modified,
            start_sector,
            size,
            _size_high,
        ) = struct.unpack_from(_DIR_ENTRY_FMT, raw, offset)

        # Name is UTF-16LE; name_len includes the null terminator
        name_bytes = name_raw[: max(0, name_len - 2)]
        name = name_bytes.decode("utf-16-le", errors="replace")

        return DirEntry(
            name=name,
            obj_type=obj_type,
            child_id=child_id,
            left_sibling_id=left_id,
            right_sibling_id=right_id,
            start_sector=start_sector,
            size=size,
            raw=entry_raw,
            color=color,
        )

    def _read_stream(self, entry: DirEntry) -> bytes:
        # Honor pending write-back overrides.
        for idx, e in enumerate(self._directory):
            if e is entry and idx in self._stream_overrides:
                return self._stream_overrides[idx]
        if entry.size < self.mini_stream_cutoff and entry.obj_type != _OBJTYPE_ROOT:
            # Read from mini-stream
            raw = bytearray()
            for sect in self._mini_chain(entry.start_sector):
                offset = sect * self.mini_sector_size
                raw.extend(self._mini_stream[offset: offset + self.mini_sector_size])
            return bytes(raw[: entry.size])
        # Read from regular stream
        raw = bytearray()
        for sect in self._chain(entry.start_sector):
            raw.extend(self._sector(sect))
        return bytes(raw[: entry.size])

    # ------------------------------------------------------------------
    # Mutation API
    # ------------------------------------------------------------------

    def write_stream(self, name: str, data: bytes) -> None:
        """
        Replace the bytes of the first stream with a matching name
        anywhere in the directory (case-insensitive, directory order).

        Storage-agnostic on purpose, mirroring :meth:`get_stream`; use
        :meth:`write_stream_in_storage` when the parent storage matters.
        The change is held in memory until :meth:`to_bytes` is called.
        """
        needle = name.casefold()
        for idx, entry in enumerate(self._directory):
            if entry.obj_type == _OBJTYPE_STREAM and entry.name.casefold() == needle:
                self._stream_overrides[idx] = bytes(data)
                return
        raise KeyError(f"Stream not found: {name!r}")

    def write_stream_in_storage(self, storage: str, name: str, data: bytes) -> None:
        """Replace the bytes of a stream that is a direct child of the
        named storage (both lookups case-insensitive).

        Only the storage's own child subtree is searched, mirroring
        :meth:`get_stream_in_storage`.  The change is held in memory
        until :meth:`to_bytes` is called.  Raises ``KeyError`` if the
        storage or the child stream does not exist.
        """
        parent_idx = self._find_storage_index(storage)
        child_idx = self._find_child_stream_index(parent_idx, name)
        if child_idx is None:
            raise KeyError(f"Stream {name!r} not found in storage {storage!r}")
        self._stream_overrides[child_idx] = bytes(data)

    def add_stream_at(self, path: Sequence[str], name: str, data: bytes) -> None:
        """Create a stream inside the storage at ``path``, seeded with ``data``.

        The path form of :meth:`add_stream_to_storage`, for storages whose
        name repeats -- a UserForm's containers all own an ``f``.
        """
        if not name:
            raise ValueError("stream name must be non-empty")
        parent_idx = self._resolve_path(path)
        if self._find_child_stream_index(parent_idx, name) is not None:
            joined = "/".join(path)
            raise ValueError(f"Stream {name!r} already exists in {joined!r}")
        self._attach_child(parent_idx, self._claim_slot(name, _OBJTYPE_STREAM))
        self._stream_overrides[self._find_child_stream_index(parent_idx, name) or 0] = (
            bytes(data)
        )

    def add_substorage_at(
        self, path: Sequence[str], name: str, clsid: bytes = b""
    ) -> None:
        """Create a storage inside the storage at ``path``.

        ``clsid`` is the 16-byte class id the entry carries.  It is not
        decoration: a UserForm container's storage is bound by its CLSID,
        and one written without it is silently not bound.
        """
        if not name:
            raise ValueError("storage name must be non-empty")
        if clsid and len(clsid) != 16:
            raise ValueError(f"CLSID must be 16 bytes, got {len(clsid)}")
        parent_idx = self._resolve_path(path)
        needle = name.casefold()
        for child_idx in self._collect_subtree(self._directory[parent_idx].child_id):
            sibling = self._directory[child_idx]
            if (
                sibling.obj_type == _OBJTYPE_STORAGE
                and sibling.name.casefold() == needle
            ):
                joined = "/".join(path)
                raise ValueError(f"Storage {name!r} already exists under {joined!r}")
        target_idx = self._claim_slot(name, _OBJTYPE_STORAGE)
        if clsid:
            entry = self._directory[target_idx]
            raw = bytearray(self._synth_dir_entry_bytes(entry))
            raw[80:96] = clsid
            entry.raw = bytes(raw)
        self._attach_child(parent_idx, target_idx)

    def remove_storage_at(self, path: Sequence[str], name: str) -> None:
        """Delete a storage inside ``path``, and everything under it.

        Recursive on purpose: a UserForm container's storage holds its
        children's storages, and leaving one behind orphans a whole
        subtree that the next read would refuse.
        """
        parent_idx = self._resolve_path(path)
        needle = name.casefold()
        target_idx = None
        for child_idx in self._collect_subtree(self._directory[parent_idx].child_id):
            entry = self._directory[child_idx]
            if entry.obj_type == _OBJTYPE_STORAGE and entry.name.casefold() == needle:
                target_idx = child_idx
                break
        if target_idx is None:
            joined = "/".join(path)
            raise KeyError(f"Storage {name!r} not found under {joined!r}")

        def clear(idx: int) -> None:
            entry = self._directory[idx]
            if entry.obj_type == _OBJTYPE_STORAGE:
                for grandchild in self._collect_subtree(entry.child_id):
                    clear(grandchild)
            self._stream_overrides.pop(idx, None)
            entry.name = ""
            entry.obj_type = _OBJTYPE_EMPTY
            entry.child_id = _NOSTREAM
            entry.left_sibling_id = _NOSTREAM
            entry.right_sibling_id = _NOSTREAM
            entry.start_sector = _FREESECT
            entry.size = 0
            entry.raw = b""

        siblings = [
            i
            for i in self._collect_subtree(self._directory[parent_idx].child_id)
            if i != target_idx
        ]
        clear(target_idx)
        self._directory[parent_idx].child_id = self._rebuild_balanced_subtree(siblings)

    def _claim_slot(self, name: str, obj_type: int) -> int:
        """Recycle an empty directory slot, or append a fresh entry."""
        for idx, entry in enumerate(self._directory):
            if entry.obj_type == _OBJTYPE_EMPTY:
                entry.name = name
                entry.obj_type = obj_type
                entry.child_id = _NOSTREAM
                entry.left_sibling_id = _NOSTREAM
                entry.right_sibling_id = _NOSTREAM
                entry.start_sector = _ENDOFCHAIN
                entry.size = 0
                entry.raw = b""
                return idx
        self._directory.append(DirEntry(
            name=name,
            obj_type=obj_type,
            child_id=_NOSTREAM,
            left_sibling_id=_NOSTREAM,
            right_sibling_id=_NOSTREAM,
            start_sector=_ENDOFCHAIN,
            size=0,
            raw=b"",
        ))
        return len(self._directory) - 1

    def _attach_child(self, parent_idx: int, child_idx: int) -> None:
        """Splice a new entry into a storage's child subtree and rebalance."""
        siblings = self._collect_subtree(self._directory[parent_idx].child_id)
        siblings.append(child_idx)
        self._directory[parent_idx].child_id = self._rebuild_balanced_subtree(siblings)

    def add_stream_to_storage(self, storage: str, name: str, data: bytes) -> None:
        """
        Create a new stream as a child of ``storage`` and seed it with ``data``.

        A new :class:`DirEntry` is appended to the directory (re-using an
        existing empty slot when one is available) and inserted into the
        storage's child subtree.  Raises ``KeyError`` if the storage does not
        exist and ``ValueError`` if a child stream of that name already exists.
        """
        if not name:
            raise ValueError("stream name must be non-empty")
        parent_idx = self._find_storage_index(storage)
        if self._find_child_stream_index(parent_idx, name) is not None:
            raise ValueError(
                f"Stream {name!r} already exists in storage {storage!r}"
            )
        # Prefer to recycle an existing EMPTY slot so the directory does not
        # grow unnecessarily; otherwise append a fresh entry.
        target_idx: int | None = None
        for i, e in enumerate(self._directory):
            if e.obj_type == _OBJTYPE_EMPTY:
                target_idx = i
                break
        if target_idx is None:
            self._directory.append(DirEntry(
                name=name,
                obj_type=_OBJTYPE_STREAM,
                child_id=_NOSTREAM,
                left_sibling_id=_NOSTREAM,
                right_sibling_id=_NOSTREAM,
                start_sector=_ENDOFCHAIN,
                size=0,
                raw=b"",
            ))
            target_idx = len(self._directory) - 1
        else:
            slot = self._directory[target_idx]
            slot.name = name
            slot.obj_type = _OBJTYPE_STREAM
            slot.child_id = _NOSTREAM
            slot.left_sibling_id = _NOSTREAM
            slot.right_sibling_id = _NOSTREAM
            slot.start_sector = _ENDOFCHAIN
            slot.size = 0
            slot.raw = b""
        self._stream_overrides[target_idx] = bytes(data)
        # Splice the new entry into the parent's child subtree and rebalance.
        siblings = self._collect_subtree(self._directory[parent_idx].child_id)
        siblings.append(target_idx)
        self._directory[parent_idx].child_id = self._rebuild_balanced_subtree(siblings)

    def add_substorage(self, parent: str, name: str) -> None:
        """
        Create a new storage as a child of ``parent``.

        Use :meth:`add_stream_to_storage` afterwards to place child streams
        inside the new sub-storage.  Raises ``KeyError`` if ``parent`` does
        not exist and ``ValueError`` if a sibling storage already uses ``name``.
        """
        if not name:
            raise ValueError("storage name must be non-empty")
        parent_idx = self._find_storage_index(parent)
        # Refuse duplicate sibling storages (case-insensitive).
        needle = name.casefold()
        for child_idx in self._collect_subtree(self._directory[parent_idx].child_id):
            sib = self._directory[child_idx]
            if sib.obj_type == _OBJTYPE_STORAGE and sib.name.casefold() == needle:
                raise ValueError(
                    f"Storage {name!r} already exists under {parent!r}"
                )
        target_idx: int | None = None
        for i, e in enumerate(self._directory):
            if e.obj_type == _OBJTYPE_EMPTY:
                target_idx = i
                break
        if target_idx is None:
            self._directory.append(DirEntry(
                name=name,
                obj_type=_OBJTYPE_STORAGE,
                child_id=_NOSTREAM,
                left_sibling_id=_NOSTREAM,
                right_sibling_id=_NOSTREAM,
                start_sector=_ENDOFCHAIN,
                size=0,
                raw=b"",
            ))
            target_idx = len(self._directory) - 1
        else:
            slot = self._directory[target_idx]
            slot.name = name
            slot.obj_type = _OBJTYPE_STORAGE
            slot.child_id = _NOSTREAM
            slot.left_sibling_id = _NOSTREAM
            slot.right_sibling_id = _NOSTREAM
            slot.start_sector = _ENDOFCHAIN
            slot.size = 0
            slot.raw = b""
        siblings = self._collect_subtree(self._directory[parent_idx].child_id)
        siblings.append(target_idx)
        self._directory[parent_idx].child_id = self._rebuild_balanced_subtree(siblings)

    # ------------------------------------------------------------------
    # Directory mutation (stream removal / drop)
    # ------------------------------------------------------------------

    def remove_stream_in_storage(self, storage: str, name: str) -> None:
        """
        Remove a stream from a named storage.

        The stream's directory entry is marked empty and unlinked from the
        storage's red-black sibling tree.  The change is held in memory until
        :meth:`to_bytes` is called.
        """
        parent_idx = self._find_storage_index(storage)
        target_idx = self._find_child_stream_index(parent_idx, name)
        if target_idx is None:
            raise KeyError(f"Stream {name!r} not found in storage {storage!r}")
        self._unlink_and_clear(parent_idx, target_idx)

    def remove_stream(self, name: str) -> None:
        """Remove a top-level stream (child of the root entry)."""
        target_idx = self._find_child_stream_index(0, name)
        if target_idx is None:
            raise KeyError(f"Stream not found: {name!r}")
        self._unlink_and_clear(0, target_idx)

    def rename_stream_in_storage(self, storage: str, old: str, new: str) -> None:
        """
        Rename a stream within a storage.

        The entry's name is replaced and the storage's child subtree is rebuilt
        to keep BST ordering ([MS-CFB] 2.6.4) valid.  Raises ``KeyError`` if
        the source stream is missing and ``ValueError`` if a sibling already
        uses ``new``.
        """
        if not new:
            raise ValueError("new stream name must be non-empty")
        if old.casefold() == new.casefold():
            # Same name (case-insensitive): just patch the displayed casing.
            parent_idx = self._find_storage_index(storage)
            target_idx = self._find_child_stream_index(parent_idx, old)
            if target_idx is None:
                raise KeyError(f"Stream {old!r} not found in storage {storage!r}")
            self._directory[target_idx].name = new
            return
        parent_idx = self._find_storage_index(storage)
        target_idx = self._find_child_stream_index(parent_idx, old)
        if target_idx is None:
            raise KeyError(f"Stream {old!r} not found in storage {storage!r}")
        if self._find_child_stream_index(parent_idx, new) is not None:
            raise ValueError(
                f"Stream {new!r} already exists in storage {storage!r}"
            )
        self._directory[target_idx].name = new
        # Rebuild the parent's subtree so BST ordering reflects the new name.
        siblings = self._collect_subtree(self._directory[parent_idx].child_id)
        self._directory[parent_idx].child_id = self._rebuild_balanced_subtree(siblings)

    def drop_streams_in_storage(
        self, storage: str, predicate: Callable[[str], bool]
    ) -> list[str]:
        """
        Remove every stream child of ``storage`` whose name satisfies ``predicate``.

        Returns the names of removed streams (in directory order).  Raises
        :class:`KeyError` if the storage does not exist.
        """
        parent_idx = self._find_storage_index(storage)
        children = self._collect_subtree(self._directory[parent_idx].child_id)
        removed: list[str] = []
        for child_idx in children:
            entry = self._directory[child_idx]
            if entry.obj_type == _OBJTYPE_STREAM and predicate(entry.name):
                removed.append(entry.name)
        for name in removed:
            self.remove_stream_in_storage(storage, name)
        return removed

    # ------------------------------------------------------------------
    # Directory tree helpers
    # ------------------------------------------------------------------

    def _resolve_path(self, path: Sequence[str]) -> int:
        """Resolve a root-relative sequence of storage names to its index.

        Each step searches only the previous storage's own children, which
        is what keeps two forms' identically named substorages apart.
        """
        idx = 0  # the root entry
        for step in path:
            needle = step.casefold()
            found = None
            for child_idx in self._collect_subtree(self._directory[idx].child_id):
                entry = self._directory[child_idx]
                if (
                    entry.obj_type == _OBJTYPE_STORAGE
                    and entry.name.casefold() == needle
                ):
                    found = child_idx
                    break
            if found is None:
                joined = "/".join(path)
                raise KeyError(f"Storage not found: {joined!r} (at {step!r})")
            idx = found
        return idx

    def _find_storage_index(self, storage: str) -> int:
        needle = storage.casefold()
        for idx, entry in enumerate(self._directory):
            if entry.obj_type == _OBJTYPE_STORAGE and entry.name.casefold() == needle:
                return idx
        raise KeyError(f"Storage not found: {storage!r}")

    def _find_child_stream_index(self, parent_idx: int, name: str) -> int | None:
        needle = name.casefold()
        for child_idx in self._collect_subtree(self._directory[parent_idx].child_id):
            entry = self._directory[child_idx]
            if entry.obj_type == _OBJTYPE_STREAM and entry.name.casefold() == needle:
                return child_idx
        return None

    def _collect_subtree(self, root_id: int) -> list[int]:
        """Walk the sibling subtree rooted at ``root_id`` and return all node indices."""
        out: list[int] = []
        seen: set[int] = set()
        stack: list[int] = []
        if root_id != _NOSTREAM and root_id < len(self._directory):
            stack.append(root_id)
        while stack:
            node = stack.pop()
            if node in seen or node == _NOSTREAM or node >= len(self._directory):
                continue
            seen.add(node)
            out.append(node)
            entry = self._directory[node]
            if entry.left_sibling_id != _NOSTREAM:
                stack.append(entry.left_sibling_id)
            if entry.right_sibling_id != _NOSTREAM:
                stack.append(entry.right_sibling_id)
        return out

    def _rebuild_balanced_subtree(self, indices: list[int]) -> int:
        """
        Build a balanced BST from ``indices`` sorted by ``([MS-CFB] 2.6.4)``
        ordering: ``(len(name), upper(name))``.  Returns the new root id, or
        ``_NOSTREAM`` if empty.  Side-effect: rewrites the participating
        entries' left/right sibling pointers and colours.

        The colours matter as much as the order.  Reading never notices them,
        but Windows' compound-file code inserts into the tree it reads and
        refuses with STG_E_DOCFILECORRUPT on runs of red entries: that is the
        "Device I/O error" Excel's editor gave adding a module to a project
        of 66 sheets this wrote, when every entry it placed was left red.
        """
        if not indices:
            return _NOSTREAM
        ordered = sorted(
            indices,
            key=lambda i: (len(self._directory[i].name), self._directory[i].name.upper()),
        )
        # Halving the sorted run fills every level but the deepest, so black
        # above it and red on it gives every path the same black count with
        # no red node above another.
        full_levels = (len(ordered) + 1).bit_length() - 1
        return self._build_from_sorted(ordered, 0, full_levels)

    def _build_from_sorted(self, ordered: list[int], depth: int, full_levels: int) -> int:
        if not ordered:
            return _NOSTREAM
        mid = len(ordered) // 2
        root = ordered[mid]
        entry = self._directory[root]
        entry.color = _RED if depth >= full_levels else _BLACK
        entry.left_sibling_id = self._build_from_sorted(ordered[:mid], depth + 1, full_levels)
        entry.right_sibling_id = self._build_from_sorted(ordered[mid + 1:], depth + 1, full_levels)
        return root

    def _red_under_red(self, root: int) -> bool:
        """Whether the tree under ``root`` holds a red entry under a red one.

        That is the fault Windows refuses to insert into, and the one this
        writer used to leave.  Measured with ole32 on balanced trees of up
        to 300 entries: all red, it refused at 226 sizes; all black, so
        that paths hold different numbers of black entries, or red only at
        the top, it refused none.  Word and PowerPoint write such all-black
        trees into .doc and .ppt files, and those are left as they are.
        """
        seen: set[int] = set()
        stack = [(root, False)]
        while stack:
            node, parent_red = stack.pop()
            if node == _NOSTREAM or node >= len(self._directory) or node in seen:
                continue
            seen.add(node)
            entry = self._directory[node]
            red = entry.color != _BLACK
            if red and parent_red:
                return True
            stack.append((entry.left_sibling_id, red))
            stack.append((entry.right_sibling_id, red))
        return False

    def _mend_trees(self) -> None:
        """Rebuild every storage's child tree that holds a red entry under a red one.

        Office never writes one, so its files pass through as they are.  This
        mends the trees earlier versions of this writer left red, the bundled
        blank templates among them.
        """
        for entry in self._directory:
            if entry.obj_type in (_OBJTYPE_STORAGE, _OBJTYPE_ROOT) and self._red_under_red(entry.child_id):
                entry.child_id = self._rebuild_balanced_subtree(self._collect_subtree(entry.child_id))

    def _unlink_and_clear(self, parent_idx: int, target_idx: int) -> None:
        parent = self._directory[parent_idx]
        siblings = [i for i in self._collect_subtree(parent.child_id) if i != target_idx]
        parent.child_id = self._rebuild_balanced_subtree(siblings)
        # Clear the removed entry so the serializer emits an empty slot.
        dead = self._directory[target_idx]
        dead.name = ""
        dead.obj_type = _OBJTYPE_EMPTY
        dead.left_sibling_id = _NOSTREAM
        dead.right_sibling_id = _NOSTREAM
        dead.child_id = _NOSTREAM
        dead.start_sector = _FREESECT
        dead.size = 0
        dead.raw = b""
        # Drop any pending override for the removed stream.
        self._stream_overrides.pop(target_idx, None)

    # ------------------------------------------------------------------
    # Serializer ([MS-CFB] write-path)
    # ------------------------------------------------------------------

    def to_bytes(self) -> bytes:
        """
        Serialize this CFB back to bytes, honoring any pending stream overrides.

        Output uses major version 3 (512-byte sectors, 64-byte mini-sectors,
        4096-byte mini-stream cutoff).  Preserves the original directory-tree
        topology and per-entry metadata (CLSID, state, color, timestamps),
        except that a storage whose tree holds a red entry under a red one
        gets a rebuilt one: Windows refuses to add a stream to it.

        Layout, in sector order:
            [mini-stream data] [regular stream data] [directory] [mini-FAT] [FAT] [DIFAT]

        The header lists the first 109 FAT sectors, which cover 109 x 128
        sectors of 512 bytes, about 7.1 MB.  A larger file lists the rest in
        DIFAT sectors ([MS-CFB] 2.5): 127 FAT sector numbers each, then the
        number of the next DIFAT sector, the last one ending the chain.
        """
        SECTOR = 512
        MINI = 64
        CUTOFF = 4096
        ENTRIES_PER_SECTOR = SECTOR // 4              # 128 FAT entries / sector
        DIR_ENTRIES_PER_SECTOR = SECTOR // _DIR_ENTRY_SIZE  # 4 dir entries / sector

        self._mend_trees()

        # ---- 1. Snapshot every directory entry's stream data ----
        stream_bytes: list[bytes] = []
        for i, entry in enumerate(self._directory):
            if entry.obj_type == _OBJTYPE_STREAM:
                if i in self._stream_overrides:
                    stream_bytes.append(self._stream_overrides[i])
                else:
                    stream_bytes.append(self._read_stream(entry))
            else:
                stream_bytes.append(b"")

        # ---- 2. Pack mini-eligible streams into the mini-stream + mini-FAT ----
        minifat: list[int] = []
        mini_stream = bytearray()
        mini_starts: dict[int, int] = {}   # dir_idx -> first mini-sector
        for i, entry in enumerate(self._directory):
            if entry.obj_type != _OBJTYPE_STREAM:
                continue
            data = stream_bytes[i]
            if len(data) == 0 or len(data) >= CUTOFF:
                continue
            n = (len(data) + MINI - 1) // MINI
            first = len(minifat)
            for k in range(n):
                minifat.append(first + k + 1 if k + 1 < n else _ENDOFCHAIN)
            mini_stream.extend(data)
            if len(data) % MINI != 0:
                mini_stream.extend(b"\x00" * (MINI - len(data) % MINI))
            mini_starts[i] = first

        mini_stream_used_bytes = len(minifat) * MINI  # logical length for Root.size

        # Pad mini-stream to a 512-byte sector boundary.
        if len(mini_stream) % SECTOR != 0:
            mini_stream.extend(b"\x00" * (SECTOR - len(mini_stream) % SECTOR))

        # Pad mini-FAT array to a full sector.
        while len(minifat) % ENTRIES_PER_SECTOR != 0:
            minifat.append(_FREESECT)

        # ---- 3. Assign sector indices ----
        sector_payloads: list[bytes] = []

        # 3a. Mini-stream sectors
        n_mini_stream_sectors = len(mini_stream) // SECTOR
        if n_mini_stream_sectors > 0:
            mini_stream_first = len(sector_payloads)
            for k in range(n_mini_stream_sectors):
                sector_payloads.append(bytes(mini_stream[k * SECTOR:(k + 1) * SECTOR]))
        else:
            mini_stream_first = _ENDOFCHAIN

        # 3b. Regular stream sectors
        reg_starts: dict[int, int] = {}
        for i, entry in enumerate(self._directory):
            if entry.obj_type != _OBJTYPE_STREAM:
                continue
            data = stream_bytes[i]
            if len(data) < CUTOFF:
                continue
            n = (len(data) + SECTOR - 1) // SECTOR
            first = len(sector_payloads)
            padded = data + b"\x00" * (n * SECTOR - len(data))
            for k in range(n):
                sector_payloads.append(padded[k * SECTOR:(k + 1) * SECTOR])
            reg_starts[i] = first

        # 3c. Directory sectors
        n_dir_entries = len(self._directory)
        n_dir_sectors = max(
            1,
            (n_dir_entries + DIR_ENTRIES_PER_SECTOR - 1) // DIR_ENTRIES_PER_SECTOR,
        )
        dir_buf = bytearray()
        for i, entry in enumerate(self._directory):
            dir_buf.extend(self._build_dir_entry_bytes(
                entry=entry,
                data_size=len(stream_bytes[i]),
                mini_starts=mini_starts,
                reg_starts=reg_starts,
                mini_stream_first=mini_stream_first,
                mini_stream_used_bytes=mini_stream_used_bytes,
                idx=i,
            ))
        # Pad remaining entries in the last dir sector with empty entries.
        empty_entry = self._empty_dir_entry_bytes()
        while len(dir_buf) < n_dir_sectors * SECTOR:
            dir_buf.extend(empty_entry)

        dir_first = len(sector_payloads)
        for k in range(n_dir_sectors):
            sector_payloads.append(bytes(dir_buf[k * SECTOR:(k + 1) * SECTOR]))

        # 3d. Mini-FAT sectors
        if minifat:
            minifat_first = len(sector_payloads)
            minifat_bytes = struct.pack(f"<{len(minifat)}I", *minifat)
            n_minifat_sectors = len(minifat_bytes) // SECTOR
            for k in range(n_minifat_sectors):
                sector_payloads.append(minifat_bytes[k * SECTOR:(k + 1) * SECTOR])
        else:
            minifat_first = _ENDOFCHAIN
            n_minifat_sectors = 0

        # ---- 4. Decide how many FAT and DIFAT sectors we need (fixed-point) ----
        # The FAT maps every sector, its own and the DIFAT's included, and the
        # DIFAT lists the FAT sectors the header has no room for.
        n_data = len(sector_payloads)
        n_fat = 1
        while True:
            n_difat = -(-max(0, n_fat - _HEADER_DIFAT) // _DIFAT_PER_SECTOR)
            needed = -(-(n_data + n_fat + n_difat) // ENTRIES_PER_SECTOR)
            if needed <= n_fat:
                break
            n_fat = needed

        fat_first = n_data
        fat_sector_ids = list(range(fat_first, fat_first + n_fat))
        difat_first = fat_first + n_fat
        difat_sector_ids = list(range(difat_first, difat_first + n_difat))

        # ---- 5. Build the FAT ----
        fat = [_FREESECT] * (n_fat * ENTRIES_PER_SECTOR)

        def chain(start: int, n: int) -> None:
            for k in range(n):
                fat[start + k] = (start + k + 1) if k + 1 < n else _ENDOFCHAIN

        if n_mini_stream_sectors > 0:
            chain(mini_stream_first, n_mini_stream_sectors)
        for i, entry in enumerate(self._directory):
            if entry.obj_type == _OBJTYPE_STREAM:
                data = stream_bytes[i]
                if len(data) >= CUTOFF:
                    n_s = (len(data) + SECTOR - 1) // SECTOR
                    chain(reg_starts[i], n_s)
        chain(dir_first, n_dir_sectors)
        if n_minifat_sectors > 0:
            chain(minifat_first, n_minifat_sectors)
        for s in fat_sector_ids:
            fat[s] = _FATSECT
        for s in difat_sector_ids:
            fat[s] = _DIFSECT

        fat_bytes = struct.pack(f"<{len(fat)}I", *fat)
        for k in range(n_fat):
            sector_payloads.append(fat_bytes[k * SECTOR:(k + 1) * SECTOR])

        # The FAT sectors past the header's 109, 127 to a DIFAT sector, each
        # sector ending with the next one's number.
        rest = fat_sector_ids[_HEADER_DIFAT:]
        for k in range(n_difat):
            listed = rest[k * _DIFAT_PER_SECTOR:(k + 1) * _DIFAT_PER_SECTOR]
            listed += [_FREESECT] * (_DIFAT_PER_SECTOR - len(listed))
            following = difat_sector_ids[k + 1] if k + 1 < n_difat else _ENDOFCHAIN
            sector_payloads.append(struct.pack(f"<{_DIFAT_PER_SECTOR + 1}I", *listed, following))

        # ---- 6. Build the header ----
        difat = fat_sector_ids[:_HEADER_DIFAT]
        difat += [_FREESECT] * (_HEADER_DIFAT - len(difat))
        difat_bytes = struct.pack(f"<{_HEADER_DIFAT}I", *difat)

        header = struct.pack(
            _HEADER_FMT,
            _MAGIC,
            b"\x00" * 16,         # CLSID — must be zero per spec
            0x003E,               # minor version
            3,                    # major version
            0xFFFE,               # byte-order mark (little-endian)
            9,                    # sector shift: 2^9 = 512
            6,                    # mini-sector shift: 2^6 = 64
            b"\x00" * 6,          # reserved
            0,                    # num_dir_sectors (must be 0 for v3)
            n_fat,                # num_fat_sectors
            dir_first,            # first_dir_sector
            0,                    # transaction signature
            CUTOFF,               # mini-stream cutoff size
            minifat_first,        # first mini-FAT sector
            n_minifat_sectors,    # num mini-FAT sectors
            difat_first if n_difat else _ENDOFCHAIN,  # first DIFAT sector
            n_difat,              # num DIFAT sectors
            difat_bytes,          # 436-byte DIFAT array
        )

        out = bytearray(header)
        for s in sector_payloads:
            out.extend(s)
        return bytes(out)

    # ------------------------------------------------------------------
    # Serializer helpers
    # ------------------------------------------------------------------

    def _build_dir_entry_bytes(
        self,
        entry: DirEntry,
        data_size: int,
        mini_starts: dict[int, int],
        reg_starts: dict[int, int],
        mini_stream_first: int,
        mini_stream_used_bytes: int,
        idx: int,
    ) -> bytes:
        """
        Re-emit a 128-byte directory entry, patching in updated start_sector,
        size and colour while preserving the original CLSID, state, and
        timestamps.
        """
        CUTOFF = 4096

        if entry.obj_type == _OBJTYPE_EMPTY:
            return self._empty_dir_entry_bytes()

        if entry.obj_type == _OBJTYPE_ROOT:
            start_sector = mini_stream_first
            size = mini_stream_used_bytes
        elif entry.obj_type == _OBJTYPE_STREAM:
            if data_size == 0:
                start_sector = _ENDOFCHAIN
                size = 0
            elif data_size < CUTOFF:
                start_sector = mini_starts[idx]
                size = data_size
            else:
                start_sector = reg_starts[idx]
                size = data_size
        else:
            # Storage entry: no stream data.
            start_sector = _ENDOFCHAIN
            size = 0

        # Start from the preserved raw entry (or a synthesised blank if missing).
        if len(entry.raw) == _DIR_ENTRY_SIZE:
            buf = bytearray(entry.raw)
        else:
            buf = bytearray(self._synth_dir_entry_bytes(entry))

        # Patch sibling/child pointers and name in case they have been edited.
        name_utf16 = entry.name.encode("utf-16-le") + b"\x00\x00"
        if len(name_utf16) > 64:
            raise CFBError(f"Directory entry name too long: {entry.name!r}")
        name_bytes = name_utf16 + b"\x00" * (64 - len(name_utf16))
        struct.pack_into("<64sHBB", buf, 0,
                         name_bytes, len(name_utf16), entry.obj_type, entry.color)
        struct.pack_into("<III", buf, 68,
                         entry.left_sibling_id,
                         entry.right_sibling_id,
                         entry.child_id)
        # start_sector at offset 116, size_low at 120, size_high at 124.
        struct.pack_into("<III", buf, 116,
                         start_sector & 0xFFFFFFFF,
                         size & 0xFFFFFFFF,
                         (size >> 32) & 0xFFFFFFFF)
        return bytes(buf)

    def _synth_dir_entry_bytes(self, entry: DirEntry) -> bytes:
        """Build a fresh directory entry from scratch when no preserved raw exists."""
        return struct.pack(
            _DIR_ENTRY_FMT,
            b"\x00" * 64,             # name (patched in by caller)
            0,                        # name_len
            entry.obj_type,
            entry.color,
            entry.left_sibling_id,
            entry.right_sibling_id,
            entry.child_id,
            b"\x00" * 16,             # CLSID
            0,                        # state
            0,                        # created
            0,                        # modified
            _ENDOFCHAIN,              # start_sector (patched in by caller)
            0,                        # size_low (patched in by caller)
            0,                        # size_high
        )

    def _empty_dir_entry_bytes(self) -> bytes:
        """A fully-empty directory entry slot ([MS-CFB] 2.6.4)."""
        return struct.pack(
            _DIR_ENTRY_FMT,
            b"\x00" * 64, 0, _OBJTYPE_EMPTY, 0,
            _NOSTREAM, _NOSTREAM, _NOSTREAM,
            b"\x00" * 16, 0, 0, 0,
            _FREESECT, 0, 0,
        )
