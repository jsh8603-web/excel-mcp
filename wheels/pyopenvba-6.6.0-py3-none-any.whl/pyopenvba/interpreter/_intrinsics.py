"""The VBA runtime library: the functions every project has without a reference.

The inventory is the one the VBA language reference lists.  A function
here either behaves as VBA's does or raises
:class:`~pyopenvba.exceptions.VBAUnsupportedError` saying what it would
have needed; nothing returns a plausible-looking wrong answer.

What is deliberately not implemented, and why:

* the file and folder verbs (Dir, FreeFile, GetAttr, Kill, ...) reach
  outside the model into the real machine;
* the registry verbs (GetSetting, SaveSetting) do the same;
* VarPtr, StrPtr and ObjPtr hand out addresses that mean nothing here;
* Shell, SendKeys and AppActivate start or drive other programs.

MsgBox and InputBox do not block.  A message goes into the dialog
transcript and the answer comes from the queue the caller primed, so a
macro that would have stopped for a prompt runs to the end and the
prompt is visible afterwards.
"""

from __future__ import annotations

import datetime as _dt
import math
import re
import struct
import time
from collections.abc import Callable
from decimal import Decimal, InvalidOperation
from typing import TYPE_CHECKING, Any, Final

from pyopenvba.exceptions import VBARuntimeError, VBAUnsupportedError
from pyopenvba.interpreter import _locale
from pyopenvba.interpreter._objects import VBAObject
from pyopenvba.interpreter._values import (
    EMPTY,
    ERROR_TEXT,
    ERR_INVALID_PROCEDURE_CALL,
    ERR_INVALID_USE_OF_NULL,
    ERR_SUBSCRIPT_OUT_OF_RANGE,
    ERR_TYPE_MISMATCH,
    MISSING,
    NOTHING,
    NULL,
    VBAArray,
    VBACurrency,
    VBADate,
    VBADecimal,
    VBAErrorValue,
    VBAInt,
    VBASingle,
    error,
    number_text,
    read_date_text,
    round_half_even,
    string_order,
    condition,
    decimal_of,
    to_bool,
    to_date,
    to_integer,
    to_number,
    to_text,
    type_name,
)

if TYPE_CHECKING:
    from pyopenvba.interpreter._runtime import Interpreter

Intrinsic = Callable[["Interpreter", list[object], dict[str, object]], object]

INTRINSICS: dict[str, Intrinsic] = {}

#: The names VBA defines that this does not implement, and the reason.
UNIMPLEMENTED: Final[dict[str, str]] = {
    "dir": "reads the real file system",
    "curdir": "reads the real file system",
    "filelen": "reads the real file system",
    "filedatetime": "reads the real file system",
    "getattr": "reads the real file system",
    "freefile": "opens real files",
    "eof": "reads real files",
    "lof": "reads real files",
    "loc": "reads real files",
    "seek": "reads real files",
    "fileattr": "reads real files",
    "getsetting": "reads the Windows registry",
    "savesetting": "writes the Windows registry",
    "deletesetting": "writes the Windows registry",
    "getallsettings": "reads the Windows registry",
    "varptr": "hands out a memory address",
    "strptr": "hands out a memory address",
    "objptr": "hands out a memory address",
    "shell": "starts another program",
    "sendkeys": "drives another program's window",
    "appactivate": "drives another program's window",
    "macscript": "runs AppleScript",
    "macid": "is a Mac file type",
    "imestatus": "reports the input method editor",
    "command": "reads the command line Office was started with",
    "environ": "reads the machine's environment",
    "doevents": "yields to a message pump this does not have",
    "getobject": "attaches to a running application",
    "qbcolor": "is not implemented yet",
    "partition": "is not implemented yet",
}


def intrinsic(name: str, *parameters: str, minimum: int = 0) -> Callable[..., Any]:
    """Register a VBA function under ``name`` with VBA's parameter names."""

    def register(function: Callable[..., object]) -> Callable[..., object]:
        def dispatch(interpreter: Interpreter, args: list[object], named: dict[str, object]) -> object:
            laid: list[object] = list(args) + [MISSING] * max(0, len(parameters) - len(args))
            if len(args) > len(parameters):
                raise error(450, f"{name} takes {len(parameters)} arguments")
            for key, value in named.items():
                for index, parameter in enumerate(parameters):
                    if parameter.lower() == key.lower():
                        laid[index] = value
                        break
                else:
                    raise error(448, f"{name} has no argument named {key}")
            # How many were written, not how many are non-Missing: an
            # argument whose value is Missing was still passed, which is
            # the whole point of IsMissing.
            supplied = len(args) + len(named)
            if supplied < minimum:
                raise error(449, f"{name} needs {minimum} argument{'s' if minimum != 1 else ''}")
            return function(interpreter, *laid[: len(parameters)])

        INTRINSICS[name.lower()] = dispatch
        return function

    return register


def _unimplemented(name: str, reason: str) -> Intrinsic:
    def refuse(interpreter: Interpreter, args: list[object], named: dict[str, object]) -> object:
        raise VBAUnsupportedError(f"{name} {reason}, so pyOpenVBA does not implement it")

    return refuse


for _name, _reason in UNIMPLEMENTED.items():
    INTRINSICS[_name] = _unimplemented(_name, _reason)


#: CallByName's CallType: VbMethod, VbGet, VbLet and VbSet, which may be added together.
_METHOD, _GET, _LET, _SET = 1, 2, 4, 8


def _call_by_name(interpreter: Interpreter, args: list[object], named: dict[str, object]) -> object:
    """CallByName(Object, ProcName, CallType, Args...): a member named at run time.

    Measured in live Excel (tests/fixtures/excel_model/probes.txt): a name
    found in any case; VbGet reads a property and passes the arguments,
    VbLet sets one to the last argument; VbMethod on a property of a
    host object is error 438, as VbSet with a value is, and so is a
    CallType with none of the four in it; Nothing is error 5.
    """
    if named:
        raise error(446, "CallByName takes no named arguments")
    if len(args) < 3:
        raise error(449, "CallByName needs an object, a name and a call type")
    target, name, kind = args[0], to_text(args[1]), int(to_integer(args[2], "Long"))
    rest = list(args[3:])
    if target is NOTHING:
        raise error(5, "Invalid procedure call or argument")
    if not isinstance(target, VBAObject):
        raise error(424, "Object required")
    spec = target.vba_member(name)
    if kind & (_LET | _SET):
        if not rest or (kind & _SET and not isinstance(rest[-1], VBAObject) and rest[-1] is not NOTHING):
            raise error(438, f"{target.vba_type_name} has no such member as {name}")
        return target.vba_call_by_name(name, rest, assignment=True, by_ref=bool(kind & _SET))
    if not kind & (_METHOD | _GET) or (kind == _METHOD and spec is not None and spec.kind != "method"):
        raise error(438, f"{target.vba_type_name} has no such member as {name}")
    strict = getattr(target, "vba_strict_call_types", False)
    if strict and kind == _GET and spec is not None and spec.kind == "method":
        raise error(438, f"{target.vba_type_name} has no such member as {name}")
    return target.vba_call_by_name(name, rest)


INTRINSICS["callbyname"] = _call_by_name


# --- conversion ---------------------------------------------------------------------


@intrinsic("CBool", "Expression", minimum=1)
def vba_cbool(interpreter: Interpreter, value: object) -> object:
    return to_bool(value)


def _convertible(value: object) -> object:
    """An Error as the number conversion functions read it: its number.

    CLng(CVErr(2042)) is 2042, and so are CInt, CByte, CSng, CDbl and CCur
    of it, measured in Excel's VBA; arithmetic on the same Variant, Int
    and Val are still a type mismatch.
    """
    return VBAInt(value.number, "Long") if isinstance(value, VBAErrorValue) else value


@intrinsic("CByte", "Expression", minimum=1)
def vba_cbyte(interpreter: Interpreter, value: object) -> object:
    return to_integer(_convertible(value), "Byte")


@intrinsic("CInt", "Expression", minimum=1)
def vba_cint(interpreter: Interpreter, value: object) -> object:
    return to_integer(_convertible(value), "Integer")


@intrinsic("CLng", "Expression", minimum=1)
def vba_clng(interpreter: Interpreter, value: object) -> object:
    return to_integer(_convertible(value), "Long")


@intrinsic("CLngLng", "Expression", minimum=1)
def vba_clnglng(interpreter: Interpreter, value: object) -> object:
    return to_integer(value, "LongLong")


@intrinsic("CSng", "Expression", minimum=1)
def vba_csng(interpreter: Interpreter, value: object) -> object:
    return VBASingle(float(to_number(_convertible(value))))


@intrinsic("CDbl", "Expression", minimum=1)
def vba_cdbl(interpreter: Interpreter, value: object) -> object:
    return float(to_number(_convertible(value)))


@intrinsic("CCur", "Expression", minimum=1)
def vba_ccur(interpreter: Interpreter, value: object) -> object:
    return VBACurrency(to_number(_convertible(value)))


@intrinsic("CDec", "Expression", minimum=1)
def vba_cdec(interpreter: Interpreter, value: object) -> object:
    """Text is read as a Decimal directly, all 29 digits of it, not through a
    Double (native probe: CDec("7.9228162514264337593543950335")). Its digits
    are ASCII, or full-width under ja-JP (live probes)."""
    if isinstance(value, str):
        text = _locale.fold_width(value) if _locale.current().folds_width else value
        plain = text.strip().replace(",", "")
        try:
            exact = Decimal(plain) if plain.isascii() else None
        except InvalidOperation:
            exact = None
        if exact is not None and exact.is_finite():
            return VBADecimal(exact)
    return VBADecimal(decimal_of(to_number(value)))


@intrinsic("CStr", "Expression", minimum=1)
def vba_cstr(interpreter: Interpreter, value: object) -> object:
    return to_text(value)


@intrinsic("CDate", "Date", minimum=1)
def vba_cdate(interpreter: Interpreter, value: object) -> object:
    return to_date(value)


@intrinsic("CVDate", "Expression", minimum=1)
def vba_cvdate(interpreter: Interpreter, value: object) -> object:
    return to_date(value)


@intrinsic("CVar", "Expression", minimum=1)
def vba_cvar(interpreter: Interpreter, value: object) -> object:
    return value


@intrinsic("CVErr", "ErrorNumber", minimum=1)
def vba_cverr(interpreter: Interpreter, value: object) -> object:
    return VBAErrorValue(int(to_integer(value, "Long")))


#: The number Val reads from the front of its text, spaces gone: a sign, ASCII digits and a point, and an exponent.
_VAL_NUMBER = re.compile(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eEdD][+-]?[0-9]+)?")


@intrinsic("Val", "String", minimum=1)
def vba_val(interpreter: Interpreter, value: object) -> object:
    """Val takes the leading number and stops, and always gives a Double."""
    if isinstance(value, VBAErrorValue):
        # CStr spells an Error as "Error 2042"; Val refuses one outright.
        raise error(ERR_TYPE_MISMATCH)
    text = to_text(value).replace(" ", "").replace("\t", "")
    if text[:2].lower() in ("&h", "&o"):
        # Read at a literal's width: up to &HFFFF an Integer, up to &HFFFFFFFF a
        # Long, so Val("&HFFFF") is -1 and Val("&H8000") -32768, while a trailing
        # & makes it a Long: Val("&HFFFF&") is 65535 (native probes).
        digits = re.match(r"[0-9a-f]*" if text[1] in "hH" else r"[0-7]*", text[2:], re.IGNORECASE)
        assert digits is not None
        if not digits.group():
            return 0.0
        raw = int(digits.group(), 16 if text[1] in "hH" else 8)
        bits = 16 if raw <= 0xFFFF and not text[2 + digits.end():].startswith("&") else 32
        if raw <= 0xFFFFFFFF and raw >= 1 << (bits - 1):
            raw -= 1 << bits
        return float(raw)
    # The leading number in ASCII digits, D as well as E before an exponent; full-width digits, inf, nan and _ end
    # it (tests/fixtures/locale_report.json).
    found = _VAL_NUMBER.match(text)
    return float(found.group().replace("d", "e").replace("D", "e")) if found else 0.0


@intrinsic("Str", "Number", minimum=1)
def vba_str(interpreter: Interpreter, value: object) -> object:
    """Str: a leading space where a number is not negative, and no zero before
    the point (" .5", "-.5"); True and dates as their text, Null as Null (native probes)."""
    if value is NULL:
        return NULL
    if isinstance(value, bool):
        return "True" if value else "False"
    if isinstance(value, VBADate):
        return to_text(value)
    text = number_text(to_number(value))
    if text.startswith("0."):
        text = text[1:]
    elif text.startswith("-0."):
        text = "-" + text[2:]
    return text if text.startswith("-") else f" {text}"


def _unsigned(value: object) -> int:
    """A negative number as the bits of its own width, which is what
    Hex and Oct print: Hex(-1) is FFFF for an Integer and FFFFFFFF for
    a Long."""
    whole = int(to_integer(value, "LongLong"))
    if whole >= 0:
        return whole
    width = {"Byte": 8, "Integer": 16, "Long": 32}.get(type_name(value), 0)
    if not width:
        width = 16 if -32768 <= whole else (32 if whole >= -(1 << 31) else 64)
    return whole + (1 << width)


@intrinsic("Hex", "Number", minimum=1)
def vba_hex(interpreter: Interpreter, value: object) -> object:
    if value is NULL:
        return NULL
    return format(_unsigned(value), "X")


@intrinsic("Oct", "Number", minimum=1)
def vba_oct(interpreter: Interpreter, value: object) -> object:
    if value is NULL:
        return NULL
    return format(_unsigned(value), "o")


# --- maths ----------------------------------------------------------------------------


def _same_kind(number: object, result: Decimal | float) -> object:
    """``result`` in ``number``'s type: Abs, Int, Fix and Round of a Currency are
    Currency, of a Single a Single, of a Decimal a Decimal (native probes)."""
    if isinstance(number, VBACurrency):
        return VBACurrency(result)
    if isinstance(number, VBADecimal):
        return VBADecimal(result)
    if isinstance(number, VBASingle):
        return VBASingle(float(result))
    if isinstance(number, Decimal):
        return VBADecimal(result)
    return float(result)


@intrinsic("Abs", "Number", minimum=1)
def vba_abs(interpreter: Interpreter, value: object) -> object:
    """Abs keeps the width it was given: Abs of an Integer is an Integer."""
    if value is NULL:
        return NULL
    number = to_number(value)
    if isinstance(number, float) and number == 0.0:
        return _same_kind(number, 0.0)
    if number >= 0:
        return number
    if isinstance(number, VBAInt):
        return VBAInt(-int(number), number.kind)
    return _same_kind(number, -number)


@intrinsic("Sgn", "Number", minimum=1)
def vba_sgn(interpreter: Interpreter, value: object) -> object:
    if value is NULL:
        return NULL
    number = to_number(value)
    return VBAInt((number > 0) - (number < 0), "Integer")


@intrinsic("Int", "Number", minimum=1)
def vba_int(interpreter: Interpreter, value: object) -> object:
    """Int rounds toward minus infinity; Fix rounds toward zero."""
    if value is NULL:
        return NULL
    number = to_number(value)
    if isinstance(number, int):
        return number
    if isinstance(number, Decimal):
        return _same_kind(number, Decimal(math.floor(number)))
    # Int and Fix keep a zero's sign: Fix(-0.5) is -0 (native probes).
    return _same_kind(number, math.copysign(math.floor(number), number))


@intrinsic("Fix", "Number", minimum=1)
def vba_fix(interpreter: Interpreter, value: object) -> object:
    if value is NULL:
        return NULL
    number = to_number(value)
    if isinstance(number, int):
        return number
    if isinstance(number, Decimal):
        return _same_kind(number, Decimal(int(number)))
    return _same_kind(number, math.copysign(int(number), number))


@intrinsic("Round", "Number", "NumDigitsAfterDecimal", minimum=1)
def vba_round(interpreter: Interpreter, value: object, digits: object) -> object:
    """Half to even, in the number's own type; negative digits are error 5 (native probes)."""
    if value is NULL:
        return NULL
    places = 0 if digits is MISSING else int(to_integer(digits, "Long"))
    if places < 0:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    number = to_number(value)
    if isinstance(number, int):
        return number
    return _same_kind(number, round_half_even(number, places))


@intrinsic("Sqr", "Number", minimum=1)
def vba_sqr(interpreter: Interpreter, value: object) -> object:
    number = float(to_number(value))
    if number < 0:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    return math.sqrt(number)


@intrinsic("Exp", "Number", minimum=1)
def vba_exp(interpreter: Interpreter, value: object) -> object:
    try:
        return math.exp(float(to_number(value)))
    except OverflowError:
        raise error(6) from None


@intrinsic("Log", "Number", minimum=1)
def vba_log(interpreter: Interpreter, value: object) -> object:
    number = float(to_number(value))
    if number <= 0:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    return math.log(number)


@intrinsic("Sin", "Number", minimum=1)
def vba_sin(interpreter: Interpreter, value: object) -> object:
    return math.sin(float(to_number(value)))


@intrinsic("Cos", "Number", minimum=1)
def vba_cos(interpreter: Interpreter, value: object) -> object:
    return math.cos(float(to_number(value)))


@intrinsic("Tan", "Number", minimum=1)
def vba_tan(interpreter: Interpreter, value: object) -> object:
    return math.tan(float(to_number(value)))


@intrinsic("Atn", "Number", minimum=1)
def vba_atn(interpreter: Interpreter, value: object) -> object:
    return math.atan(float(to_number(value)))


@intrinsic("Rnd", "Number")
def vba_rnd(interpreter: Interpreter, value: object) -> object:
    """VBA's own generator, so a seeded run gives Excel's numbers (native probes).

    A 24-bit linear congruence: seed * 0x43FD43FD + 0xC39EC3. A negative
    argument seeds it from the number's Single bits, the bits plus their top
    byte, then steps; 0 repeats the last number.
    """
    state = getattr(interpreter, "_rnd_state", 0x50000)
    if value is not MISSING:
        number = float(to_number(value))
        if number < 0:
            bits = struct.unpack("<I", struct.pack("<f", number))[0]
            state = (bits + (bits >> 24)) & 0xFFFFFF
        elif number == 0:
            return VBASingle(state / (1 << 24))
    state = (state * 0x43FD43FD + 0xC39EC3) & 0xFFFFFF
    interpreter._rnd_state = state  # type: ignore[attr-defined]
    return VBASingle(state / (1 << 24))


@intrinsic("Randomize", "Number")
def vba_randomize(interpreter: Interpreter, value: object) -> object:
    """Replace the seed's middle 16 bits with the high word of the number's
    Double, folded on itself; the outer bytes stay (native probes). With no
    number, the number is Timer."""
    number = time.time() % 86400 if value is MISSING else float(to_number(value))
    high = struct.unpack("<Q", struct.pack("<d", number))[0] >> 32
    middle = ((high & 0xFFFF) ^ (high >> 16)) << 8
    state = getattr(interpreter, "_rnd_state", 0x50000)
    interpreter._rnd_state = (state & 0xFF0000FF) | (middle & 0x00FFFF00)  # type: ignore[attr-defined]
    return EMPTY


# --- strings ----------------------------------------------------------------------------


@intrinsic("Len", "Expression", minimum=1)
def vba_len(interpreter: Interpreter, value: object) -> object:
    from pyopenvba.interpreter._runtime import UserTypeValue

    if isinstance(value, UserTypeValue):
        return VBAInt(value.record_layout(binary=False)[0], 'Long')
    if value is NULL:
        return NULL
    if isinstance(value, VBAObject):
        value = value.vba_value()
    if value is EMPTY:
        return VBAInt(0, "Long")
    body = to_text(value)
    return VBAInt(len(body) if body.isascii() else len(_string_bytes(body)) // 2, "Long")


def _string_bytes(value: object) -> bytes:
    return to_text(value).encode("utf-16-le", errors="surrogatepass")


def _bytes_string(data: bytes) -> str:
    """UTF-16LE bytes as text. VBA can hold an odd byte as half a character;
    here a trailing odd byte stands as a character of its own."""
    text = data[: len(data) // 2 * 2].decode("utf-16-le", errors="surrogatepass")
    return text + chr(data[-1]) if len(data) % 2 else text


@intrinsic("LeftB", "String", "Length", minimum=2)
def vba_leftb(interpreter: Interpreter, value: object, length: object) -> object:
    if value is NULL:
        return NULL
    count = int(to_integer(length, "Long"))
    if count < 0:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    return _bytes_string(_string_bytes(value)[:count])


@intrinsic("RightB", "String", "Length", minimum=2)
def vba_rightb(interpreter: Interpreter, value: object, length: object) -> object:
    if value is NULL:
        return NULL
    count = int(to_integer(length, "Long"))
    if count < 0:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    data = _string_bytes(value)
    return _bytes_string(data[max(0, len(data) - count):])


@intrinsic("MidB", "String", "Start", "Length", minimum=2)
def vba_midb(interpreter: Interpreter, value: object, start: object, length: object) -> object:
    if value is NULL:
        return NULL
    first = int(to_integer(start, "Long"))
    if first < 1:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    data = _string_bytes(value)[first - 1:]
    if length is not MISSING:
        count = int(to_integer(length, "Long"))
        if count < 0:
            raise error(ERR_INVALID_PROCEDURE_CALL)
        data = data[:count]
    return _bytes_string(data)


@intrinsic("AscB", "String", minimum=1)
def vba_ascb(interpreter: Interpreter, value: object) -> object:
    data = _string_bytes(value)
    if not data:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    return VBAInt(data[0], "Integer")


@intrinsic("InStrB", "Start", "String1", "String2", "Compare")
def vba_instrb(interpreter: Interpreter, first: object, second: object, third: object, compare: object) -> object:
    """InStr on the bytes: a 1-based byte position, a match at any byte (InStrB("abc", "b") is 3)."""
    if third is MISSING and compare is MISSING:
        start, haystack, needle = 1, first, second
    else:
        start, haystack, needle = int(to_integer(first, "Long")), second, third
    if haystack is NULL or needle is NULL:
        return NULL
    if start < 1:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    body, wanted = _string_bytes(haystack), _string_bytes(needle)
    if not body:
        return VBAInt(0, "Long")
    if not wanted:
        return VBAInt(start, "Long")
    return VBAInt(body.find(wanted, start - 1) + 1, "Long")


@intrinsic("LenB", "Expression", minimum=1)
def vba_lenb(interpreter: Interpreter, value: object) -> object:
    from pyopenvba.interpreter._runtime import UserTypeValue

    if isinstance(value, UserTypeValue):
        return VBAInt(value.record_layout(binary=True)[0], 'Long')
    if value is NULL:
        return NULL
    body = to_text(value)
    return VBAInt(len(body) * 2 if body.isascii() else len(_string_bytes(body)), "Long")


@intrinsic("Left", "String", "Length", minimum=2)
def vba_left(interpreter: Interpreter, text: object, length: object) -> object:
    if text is NULL:
        return NULL
    count = int(to_integer(length, "Long"))
    if count < 0:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    body = to_text(text)
    return body[:count] if body.isascii() else _bytes_string(_string_bytes(body)[:count * 2])


@intrinsic("Right", "String", "Length", minimum=2)
def vba_right(interpreter: Interpreter, text: object, length: object) -> object:
    if text is NULL:
        return NULL
    count = int(to_integer(length, "Long"))
    if count < 0:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    body = to_text(text)
    if body.isascii():
        return body[max(0, len(body) - count) :] if count else ""
    data = _string_bytes(body)
    return _bytes_string(data[max(0, len(data) - count * 2):]) if count else ""


@intrinsic("Mid", "String", "Start", "Length", minimum=2)
def vba_mid(interpreter: Interpreter, text: object, start: object, length: object) -> object:
    if text is NULL:
        return NULL
    body = to_text(text)
    first = int(to_integer(start, "Long"))
    if first < 1:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    if length is MISSING:
        return body[first - 1:] if body.isascii() else _bytes_string(_string_bytes(body)[(first - 1) * 2:])
    count = int(to_integer(length, "Long"))
    if count < 0:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    if body.isascii():
        return body[first - 1:first - 1 + count]
    return _bytes_string(_string_bytes(body)[(first - 1) * 2:(first - 1 + count) * 2])


@intrinsic("LTrim", "String", minimum=1)
def vba_ltrim(interpreter: Interpreter, text: object) -> object:
    return NULL if text is NULL else to_text(text).lstrip(" ")


@intrinsic("RTrim", "String", minimum=1)
def vba_rtrim(interpreter: Interpreter, text: object) -> object:
    return NULL if text is NULL else to_text(text).rstrip(" ")


@intrinsic("Trim", "String", minimum=1)
def vba_trim(interpreter: Interpreter, text: object) -> object:
    return NULL if text is NULL else to_text(text).strip(" ")


@intrinsic("UCase", "String", minimum=1)
def vba_ucase(interpreter: Interpreter, text: object) -> object:
    return NULL if text is NULL else to_text(text).upper()


@intrinsic("LCase", "String", minimum=1)
def vba_lcase(interpreter: Interpreter, text: object) -> object:
    return NULL if text is NULL else to_text(text).lower()


@intrinsic("Space", "Number", minimum=1)
def vba_space(interpreter: Interpreter, count: object) -> object:
    times = int(to_integer(count, "Long"))
    if times < 0:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    return " " * times


@intrinsic("String", "Number", "Character", minimum=2)
def vba_string(interpreter: Interpreter, count: object, character: object) -> object:
    times = int(to_integer(count, "Long"))
    if times < 0:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    if character is NULL:
        # A Null character makes a Null, where a Null count is error 94 (native probes).
        return NULL
    if isinstance(character, str):
        if not character:
            raise error(ERR_INVALID_PROCEDURE_CALL)
        return character[0] * times
    return chr(int(to_integer(character, "Long")) & 0xFF) * times


#: The characters after which StrConv's vbProperCase starts a word (native
#: probes: space, tab, NUL, LF, VT, FF and CR; no punctuation, digit or NBSP).
_WORD_BREAKS: Final = frozenset(" \t\x00\n\x0b\x0c\r")


def _proper_case(text: str) -> str:
    out: list[str] = []
    starts = True
    for char in text:
        changed = char.upper() if starts else char.lower()
        # VBA maps one character to one: a case that would grow (ß) stays.
        out.append(changed if len(changed) == 1 else char)
        starts = char in _WORD_BREAKS
    return "".join(out)


def _ansi_bytes(text: str) -> list[int]:
    """Text as Windows-1252 bytes, '?' for what the code page lacks (native probe)."""
    return list(text.encode("cp1252", errors="replace"))


def _ansi_text(data: list[int]) -> str:
    """Windows-1252 bytes as text; the five bytes it leaves undefined keep their value."""
    return "".join(bytes([byte]).decode("cp1252", errors="ignore") or chr(byte) for byte in data)


@intrinsic("StrConv", "String", "Conversion", "LocaleID", minimum=2)
def vba_strconv(interpreter: Interpreter, value: object, conversion: object, locale: object) -> object:
    """Case and byte conversions. A case flag with a byte flag, and the East
    Asian flags, are error 5 here, as on a Western Office (native probes)."""
    flags = int(to_integer(conversion, "Long"))
    case, unicode = flags & 3, flags & ~3
    if unicode not in (0, 64, 128) or (case and unicode):
        raise error(ERR_INVALID_PROCEDURE_CALL)
    if value is NULL:
        return NULL
    if unicode == 64:
        data = value.items if isinstance(value, VBAArray) else [ord(char) & 0xFF for char in to_text(value)]
        return _ansi_text([int(to_integer(byte, "Byte")) for byte in data])
    text = to_text(value)
    if unicode == 128:
        data = _ansi_bytes(text)
        return VBAArray([(0, len(data) - 1)], element_type="Byte", items=[VBAInt(byte, "Byte") for byte in data])
    if case == 1:
        return text.upper()
    if case == 2:
        return text.lower()
    if case == 3:
        return _proper_case(text)
    return text


@intrinsic("Erl")
def vba_erl(interpreter: Interpreter) -> object:
    """The last numbered line run in the procedure that handled the last error, 0 for none."""
    return VBAInt(interpreter.err.erl, "Long")


@intrinsic("Error", "ErrorNumber")
def vba_error(interpreter: Interpreter, number: object) -> object:
    """The text of an error number, or of the current error with no argument."""
    if number is MISSING:
        return interpreter.err.description
    code = int(to_integer(number, "Integer"))
    if code == 0:
        return ""
    return ERROR_TEXT.get(code, ERROR_TEXT[1004])


@intrinsic("StrReverse", "String", minimum=1)
def vba_strreverse(interpreter: Interpreter, text: object) -> object:
    return to_text(text)[::-1]


@intrinsic("Asc", "String", minimum=1)
def vba_asc(interpreter: Interpreter, text: object) -> object:
    """The first character's Windows-1252 code, 63 ("?") for one the code page lacks."""
    body = to_text(text)
    if not body:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    return VBAInt(_ansi_bytes(body[0])[0], "Integer")


@intrinsic("AscW", "String", minimum=1)
def vba_ascw(interpreter: Interpreter, text: object) -> object:
    body = to_text(text)
    if not body:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    # An Integer, so code points past 32767 come back negative: AscW(ChrW(&HFFFF)) is -1 (native probes).
    code = ord(body[0])
    if code > 0xFFFF:
        code = 0xD800 + ((code - 0x10000) >> 10)
    return VBAInt(code - 65536 if code > 32767 else code, "Integer")


@intrinsic("Chr", "CharCode", minimum=1)
def vba_chr(interpreter: Interpreter, code: object) -> object:
    """The Windows-1252 character with this code, 0 to 255; anything else is error 5 (native probes)."""
    number = int(to_integer(code, "Long"))
    if not 0 <= number <= 255:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    return _ansi_text([number])


@intrinsic("ChrW", "CharCode", minimum=1)
def vba_chrw(interpreter: Interpreter, code: object) -> object:
    """The UTF-16 unit -32768 to 65535, a negative one counted from 65536; else error 5 (native probes)."""
    number = int(to_integer(code, "Long"))
    if not -32768 <= number <= 65535:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    return chr(number & 0xFFFF if number < 0 else number)


@intrinsic("InStr", "Start", "String1", "String2", "Compare")
def vba_instr(
    interpreter: Interpreter, first: object, second: object, third: object, compare: object
) -> object:
    """InStr's first argument is the start only when three are given."""
    if third is MISSING and compare is MISSING:
        start, haystack, needle, mode = 1, first, second, MISSING
    else:
        start, haystack, needle, mode = int(to_integer(first, "Long")), second, third, compare
    if haystack is NULL or needle is NULL:
        return NULL
    if start < 1:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    body = "" if haystack is EMPTY or haystack is MISSING else to_text(haystack)
    wanted = "" if needle is EMPTY or needle is MISSING else to_text(needle)
    if vba_text_mode(interpreter, mode):
        body, wanted = body.lower(), wanted.lower()
    # Empty text is 0; an empty search is the start, past the end too (native probes).
    if not body:
        return VBAInt(0, "Long")
    if not wanted:
        return VBAInt(start, "Long")
    if start > len(body):
        return VBAInt(0, "Long")
    return VBAInt(body.find(wanted, int(start) - 1) + 1, "Long")


@intrinsic("InStrRev", "StringCheck", "StringMatch", "Start", "Compare", minimum=2)
def vba_instrrev(
    interpreter: Interpreter, haystack: object, needle: object, start: object, compare: object
) -> object:
    if haystack is NULL:
        # Unlike InStr, InStrRev refuses a Null to search (native probe).
        raise error(ERR_INVALID_USE_OF_NULL)
    if needle is NULL:
        return NULL
    body = to_text(haystack)
    wanted = to_text(needle)
    if vba_text_mode(interpreter, compare):
        body, wanted = body.lower(), wanted.lower()
    # Start -1 is the end; 0 or below -1 is error 5; past the end finds nothing;
    # an empty search is the start (native probes).
    end = -1 if start is MISSING else int(to_integer(start, "Long"))
    if end == 0 or end < -1:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    if end == -1:
        end = len(body)
    if not body or end > len(body):
        return VBAInt(0, "Long")
    if not wanted:
        return VBAInt(end, "Long")
    return VBAInt(body.rfind(wanted, 0, end) + 1, "Long")


def vba_text_mode(interpreter: Interpreter, compare: object) -> bool:
    if compare is MISSING:
        return interpreter.option_compare_text
    return int(to_integer(compare, "Long")) == 1


@intrinsic("StrComp", "String1", "String2", "Compare", minimum=2)
def vba_strcomp(interpreter: Interpreter, first: object, second: object, compare: object) -> object:
    if first is NULL or second is NULL:
        return NULL
    return VBAInt(string_order(to_text(first), to_text(second),
                              text_compare=vba_text_mode(interpreter, compare)), "Integer")


@intrinsic("Replace", "Expression", "Find", "Replace", "Start", "Count", "Compare", minimum=3)
def vba_replace(
    interpreter: Interpreter,
    text: object,
    find: object,
    put: object,
    start: object,
    count: object,
    compare: object,
) -> object:
    if text is NULL:
        # Replace returns a String, so Null has nowhere to go (native probe).
        raise error(ERR_INVALID_USE_OF_NULL)
    body = to_text(text)
    wanted = to_text(find)
    replacement = to_text(put)
    first = 1 if start is MISSING else int(to_integer(start, "Long"))
    limit = -1 if count is MISSING else int(to_integer(count, "Long"))
    if first < 1 or limit < -1:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    body = body[first - 1 :]
    if not wanted:
        return body
    if vba_text_mode(interpreter, compare):
        out: list[str] = []
        low = body.lower()
        target = wanted.lower()
        at = 0
        made = 0
        while limit == -1 or made < limit:
            found = low.find(target, at)
            if found < 0:
                break
            out.append(body[at:found])
            out.append(replacement)
            at = found + len(wanted)
            made += 1
        out.append(body[at:])
        return "".join(out)
    return body.replace(wanted, replacement) if limit == -1 else body.replace(wanted, replacement, limit)


@intrinsic("Split", "Expression", "Delimiter", "Limit", "Compare", minimum=1)
def vba_split(
    interpreter: Interpreter, text: object, delimiter: object, limit: object, compare: object
) -> object:
    body = to_text(text)
    separator = " " if delimiter is MISSING else to_text(delimiter)
    count = -1 if limit is MISSING else int(to_integer(limit, "Long"))
    if not body:
        # Splitting nothing gives an array with no elements at all,
        # whose UBound is -1.
        pieces = []
    elif not separator:
        pieces = [body]
    elif count == 0:
        pieces = []
    else:
        # vbTextCompare matches the delimiter in any case (native probe).
        flags = re.IGNORECASE if vba_text_mode(interpreter, compare) else 0
        pieces = re.split(re.escape(separator), body, maxsplit=max(0, count - 1), flags=flags)
    # A String array, as TypeName(Split(...)) says (native probe).
    return VBAArray([(0, len(pieces) - 1)] if pieces else [(0, -1)], element_type="String", items=list(pieces))


@intrinsic("Join", "SourceArray", "Delimiter", minimum=1)
def vba_join(interpreter: Interpreter, source: object, delimiter: object) -> object:
    if not isinstance(source, VBAArray):
        raise error(ERR_TYPE_MISMATCH, "Join needs an array")
    separator = " " if delimiter is MISSING else to_text(delimiter)
    return separator.join(to_text(item) for item in source.elements())


@intrinsic("Filter", "SourceArray", "Match", "Include", "Compare", minimum=2)
def vba_filter(
    interpreter: Interpreter, source: object, match: object, include: object, compare: object
) -> object:
    if not isinstance(source, VBAArray):
        raise error(ERR_TYPE_MISMATCH, "Filter needs an array")
    wanted = to_text(match)
    keep = True if include is MISSING else to_bool(include)
    text_mode = vba_text_mode(interpreter, compare)
    found: list[object] = []
    for item in source.elements():
        body = to_text(item)
        hit = (wanted.lower() in body.lower()) if text_mode else (wanted in body)
        if hit == keep:
            found.append(item)
    return VBAArray([(0, len(found) - 1)] if found else [(0, -1)], element_type="String",
                    items=[to_text(item) for item in found])


@intrinsic("Format", "Expression", "Format", "FirstDayOfWeek", "FirstWeekOfYear", minimum=1)
def vba_format(
    interpreter: Interpreter, value: object, pattern: object, first_day: object, first_week: object
) -> object:
    """VBA's own Format (pyopenvba.interpreter._format), not Access's field formats."""
    from pyopenvba.interpreter._format import vba_format as format_value

    day = 1 if first_day is MISSING else int(to_integer(first_day, "Integer")) or 1
    week = 1 if first_week is MISSING else int(to_integer(first_week, "Integer")) or 1
    return format_value(value, pattern, day, week)


def _tristate(value: object, default: bool) -> bool:
    """A vbTriState argument: missing or vbUseDefault (-2) takes the locale's choice."""
    if value is MISSING or int(to_integer(value, "Long")) == -2:
        return default
    return to_bool(value)


def _format_numeric(interpreter: Interpreter, value: object, digits: object, leading: object, parens: object,
                    group: object, *, prefix: str = "", suffix: str = "", parens_default: bool = False) -> object:
    """FormatNumber, FormatCurrency and FormatPercent as a Format pattern: -1
    digits is the locale's 2, False leading digit drops the 0 before the
    point, parentheses wrap a negative and False grouping drops the
    thousands separator. Only the currency format puts negatives in
    parentheses by default (native probes, en-US); ja-JP's currency has no
    decimals and a minus sign, as ¥1,235 and -¥1,235 (live probe)."""
    locale = _locale.current()
    default_places = locale.currency_digits if prefix else 2
    places = default_places if digits is MISSING else int(to_integer(digits, "Long"))
    if places == -1:
        places = default_places
    whole = "0" if _tristate(leading, True) else "#"
    body = prefix + ("#,##" + whole if _tristate(group, True) else whole) + ("." + "0" * places if places else "") + suffix
    pattern = f"{body};({body})" if _tristate(parens, parens_default) else body
    return vba_format(interpreter, value, pattern, MISSING, MISSING)


@intrinsic("FormatNumber", "Expression", "NumDigitsAfterDecimal", "IncludeLeadingDigit",
           "UseParensForNegativeNumbers", "GroupDigits", minimum=1)
def vba_format_number(interpreter: Interpreter, value: object, digits: object, leading: object, parens: object,
                      group: object) -> object:
    return _format_numeric(interpreter, value, digits, leading, parens, group)


@intrinsic("FormatCurrency", "Expression", "NumDigitsAfterDecimal", "IncludeLeadingDigit",
           "UseParensForNegativeNumbers", "GroupDigits", minimum=1)
def vba_format_currency(interpreter: Interpreter, value: object, digits: object, leading: object, parens: object,
                        group: object) -> object:
    locale = _locale.current()
    return _format_numeric(interpreter, value, digits, leading, parens, group, prefix=locale.currency_symbol,
                           parens_default=locale.currency_parens)


@intrinsic("FormatPercent", "Expression", "NumDigitsAfterDecimal", "IncludeLeadingDigit",
           "UseParensForNegativeNumbers", "GroupDigits", minimum=1)
def vba_format_percent(interpreter: Interpreter, value: object, digits: object, leading: object, parens: object,
                       group: object) -> object:
    return _format_numeric(interpreter, value, digits, leading, parens, group, suffix="%")


@intrinsic("FormatDateTime", "Date", "NamedFormat", minimum=1)
def vba_format_datetime(interpreter: Interpreter, value: object, named: object) -> object:
    which = 0 if named is MISSING else int(to_integer(named, "Long"))
    locale = _locale.current()
    patterns = {
        0: "",
        1: locale.long_date,
        2: locale.short_date,
        3: locale.long_time,
        4: locale.short_time,
    }
    if which not in patterns:
        raise error(5)
    if which == 0:
        return to_text(to_date(value))
    return vba_format(interpreter, to_date(value), patterns[which], MISSING, MISSING)


# --- dates --------------------------------------------------------------------------------


@intrinsic("Now")
def vba_now(interpreter: Interpreter) -> object:
    return VBADate.from_datetime(interpreter.clock())


@intrinsic("Date")
def vba_date(interpreter: Interpreter) -> object:
    return VBADate.from_datetime(interpreter.clock().date())


@intrinsic("Time")
def vba_time(interpreter: Interpreter) -> object:
    return VBADate.from_datetime(interpreter.clock().time())


@intrinsic("Timer")
def vba_timer(interpreter: Interpreter) -> object:
    moment = interpreter.clock()
    seconds = moment.hour * 3600 + moment.minute * 60 + moment.second + moment.microsecond / 1e6
    return VBASingle(seconds)


@intrinsic("DateSerial", "Year", "Month", "Day", minimum=3)
def vba_dateserial(interpreter: Interpreter, year: object, month: object, day: object) -> object:
    y = int(to_integer(year, "Long"))
    m = int(to_integer(month, "Long"))
    d = int(to_integer(day, "Long"))
    if y < 100:
        # The same window as a two-digit year in text: 30 is 2030, 99 is 1999, -1 is 1999 (native probes).
        y += 2000 if y < 50 else 1900
    # Out-of-range months and days roll over, as VBA's do.
    y += (m - 1) // 12
    m = (m - 1) % 12 + 1
    try:
        base = _dt.datetime(y, m, 1)
    except ValueError:
        raise error(5) from None
    return VBADate.from_datetime(base + _dt.timedelta(days=d - 1))


@intrinsic("TimeSerial", "Hour", "Minute", "Second", minimum=3)
def vba_timeserial(interpreter: Interpreter, hour: object, minute: object, second: object) -> object:
    # Each part is an Integer: TimeSerial(0, 0, 86400) is error 6 (native probe).
    seconds = (
        int(to_integer(hour, "Integer")) * 3600
        + int(to_integer(minute, "Integer")) * 60
        + int(to_integer(second, "Integer"))
    )
    return VBADate(seconds / 86400.0)


@intrinsic("DateValue", "Date", minimum=1)
def vba_datevalue(interpreter: Interpreter, value: object) -> object:
    when = to_date(value)
    return VBADate(float(math.floor(when.serial)))


@intrinsic("TimeValue", "Time", minimum=1)
def vba_timevalue(interpreter: Interpreter, value: object) -> object:
    when = to_date(value)
    return VBADate(when.serial - math.floor(when.serial))


def _moment(value: object) -> _dt.datetime:
    """The moment Year, Month, Day, Hour, Minute and Second read: a number past
    the years a Date holds is a type mismatch to them, not an overflow (native probe)."""
    try:
        return to_date(value).to_datetime()
    except VBARuntimeError as failure:
        if failure.number == 6 and not isinstance(value, (str, VBADate)):
            raise error(ERR_TYPE_MISMATCH) from None
        raise


@intrinsic("Year", "Date", minimum=1)
def vba_year(interpreter: Interpreter, value: object) -> object:
    return NULL if value is NULL else VBAInt(_moment(value).year, "Integer")


@intrinsic("Month", "Date", minimum=1)
def vba_month(interpreter: Interpreter, value: object) -> object:
    return NULL if value is NULL else VBAInt(_moment(value).month, "Integer")


@intrinsic("Day", "Date", minimum=1)
def vba_day(interpreter: Interpreter, value: object) -> object:
    return NULL if value is NULL else VBAInt(_moment(value).day, "Integer")


@intrinsic("Hour", "Time", minimum=1)
def vba_hour(interpreter: Interpreter, value: object) -> object:
    return NULL if value is NULL else VBAInt(_moment(value).hour, "Integer")


@intrinsic("Minute", "Time", minimum=1)
def vba_minute(interpreter: Interpreter, value: object) -> object:
    return NULL if value is NULL else VBAInt(_moment(value).minute, "Integer")


@intrinsic("Second", "Time", minimum=1)
def vba_second(interpreter: Interpreter, value: object) -> object:
    return NULL if value is NULL else VBAInt(_moment(value).second, "Integer")


@intrinsic("Weekday", "Date", "FirstDayOfWeek", minimum=1)
def vba_weekday(interpreter: Interpreter, value: object, first: object) -> object:
    if value is NULL:
        return NULL
    start = 1 if first is MISSING or int(to_integer(first, "Long")) == 0 else int(to_integer(first, "Long"))
    # Python counts Monday as 0; VBA counts Sunday as 1.
    sunday_based = (to_date(value).to_datetime().weekday() + 1) % 7 + 1
    return VBAInt((sunday_based - start) % 7 + 1, "Integer")


@intrinsic("WeekdayName", "Weekday", "Abbreviate", "FirstDayOfWeek", minimum=1)
def vba_weekdayname(interpreter: Interpreter, number: object, short: object, first: object) -> object:
    locale = _locale.current()
    start = 1 if first is MISSING or int(to_integer(first, "Long")) == 0 else int(to_integer(first, "Long"))
    index = int(to_integer(number, "Long"))
    if not 1 <= index <= 7:
        raise error(5)
    names = locale.day_abbreviations if short is not MISSING and to_bool(short) else locale.days
    return names[(index - 1 + start - 1) % 7]


@intrinsic("MonthName", "Month", "Abbreviate", minimum=1)
def vba_monthname(interpreter: Interpreter, number: object, short: object) -> object:
    locale = _locale.current()
    index = int(to_integer(number, "Long"))
    if not 1 <= index <= 12:
        raise error(5)
    names = locale.month_abbreviations if short is not MISSING and to_bool(short) else locale.months
    return names[index - 1]


_INTERVALS: Final = {"yyyy", "q", "m", "y", "d", "w", "ww", "h", "n", "s"}


@intrinsic("DateAdd", "Interval", "Number", "Date", minimum=3)
def vba_dateadd(interpreter: Interpreter, interval: object, count: object, value: object) -> object:
    unit = to_text(interval).lower()
    if unit not in _INTERVALS:
        raise error(5)
    if value is NULL and count is not NULL:
        return NULL
    # The number is cut to a whole one, not rounded: DateAdd("d", 1.5, x) adds one day (native probes).
    how_many = int(to_integer(math.trunc(to_number(count)) if count is not NULL else count, "Long"))
    when = to_date(value).to_datetime()
    try:
        if unit in ("yyyy", "q", "m"):
            months = how_many * (12 if unit == "yyyy" else 3 if unit == "q" else 1)
            total = when.year * 12 + when.month - 1 + months
            year, month = divmod(total, 12)
            day = min(when.day, _days_in_month(year, month + 1))
            result = when.replace(year=year, month=month + 1, day=day)
        else:
            seconds = {"d": 86400, "y": 86400, "w": 86400, "ww": 604800, "h": 3600, "n": 60, "s": 1}[unit]
            result = when + _dt.timedelta(seconds=how_many * seconds)
    except (ValueError, OverflowError):
        result = None
    # Past the years a Date holds is error 5, not 6 (native probes).
    if result is None or not 100 <= result.year <= 9999:
        raise error(ERR_INVALID_PROCEDURE_CALL)
    return VBADate.from_datetime(result)


def _days_in_month(year: int, month: int) -> int:
    if month == 12:
        return 31
    return (_dt.date(year, month + 1, 1) - _dt.date(year, month, 1)).days


@intrinsic("DateDiff", "Interval", "Date1", "Date2", "FirstDayOfWeek", "FirstWeekOfYear", minimum=3)
def vba_datediff(
    interpreter: Interpreter,
    interval: object,
    first: object,
    second: object,
    week_start: object,
    year_start: object,
) -> object:
    unit = to_text(interval).lower()
    if unit not in _INTERVALS:
        raise error(5)
    start = to_date(first).to_datetime()
    stop = to_date(second).to_datetime()
    if unit == "yyyy":
        return VBAInt(stop.year - start.year, "Long")
    if unit == "q":
        return VBAInt((stop.year * 4 + (stop.month - 1) // 3) - (start.year * 4 + (start.month - 1) // 3), "Long")
    if unit == "m":
        return VBAInt((stop.year * 12 + stop.month) - (start.year * 12 + start.month), "Long")
    if unit in ("d", "y"):
        return VBAInt((stop.date() - start.date()).days, "Long")
    if unit == "w":
        # Whole weeks, cut toward zero either way: 430 days back is -61 (native probe).
        return VBAInt(math.trunc((stop.date() - start.date()).days / 7), "Long")
    if unit == "ww":
        begin = 1 if week_start is MISSING else int(to_integer(week_start, "Long")) or 1
        return VBAInt((_week_start(stop.date(), begin) - _week_start(start.date(), begin)).days // 7, "Long")
    # Boundaries crossed, as for days: 11:59:59 PM to midnight is one hour (native probes).
    size = {"h": 3600, "n": 60, "s": 1}[unit]
    return VBAInt(_seconds_since_epoch(stop) // size - _seconds_since_epoch(start) // size, "Long")


def _seconds_since_epoch(when: _dt.datetime) -> int:
    delta = when - VBADate.EPOCH
    return delta.days * 86400 + delta.seconds


def _week_start(day: _dt.date, first: int) -> _dt.date:
    sunday_based = (day.weekday() + 1) % 7 + 1
    return day - _dt.timedelta(days=(sunday_based - first) % 7)


@intrinsic("DatePart", "Interval", "Date", "FirstDayOfWeek", "FirstWeekOfYear", minimum=2)
def vba_datepart(
    interpreter: Interpreter, interval: object, value: object, week_start: object, year_start: object
) -> object:
    unit = to_text(interval).lower()
    when = to_date(value).to_datetime()
    if unit == "yyyy":
        return VBAInt(when.year, "Integer")
    if unit == "q":
        return VBAInt((when.month - 1) // 3 + 1, "Integer")
    if unit == "m":
        return VBAInt(when.month, "Integer")
    if unit == "y":
        return VBAInt(when.timetuple().tm_yday, "Integer")
    if unit == "d":
        return VBAInt(when.day, "Integer")
    if unit == "w":
        return vba_weekday(interpreter, VBADate.from_datetime(when), week_start)
    if unit == "ww":
        from pyopenvba.interpreter._format import week_of_year

        day = 1 if week_start is MISSING else int(to_integer(week_start, "Integer")) or 1
        week = 1 if year_start is MISSING else int(to_integer(year_start, "Integer")) or 1
        return VBAInt(week_of_year(when.date(), day, week), "Integer")
    if unit == "h":
        return VBAInt(when.hour, "Integer")
    if unit == "n":
        return VBAInt(when.minute, "Integer")
    if unit == "s":
        return VBAInt(when.second, "Integer")
    raise error(5)


# --- tests and information ------------------------------------------------------------------


def _information_value(value: object) -> object:
    return value.vba_information_value() if isinstance(value, VBAObject) else value


@intrinsic("IsNull", "Expression", minimum=1)
def vba_isnull(interpreter: Interpreter, value: object) -> object:
    return _information_value(value) is NULL


@intrinsic("IsEmpty", "Expression", minimum=1)
def vba_isempty(interpreter: Interpreter, value: object) -> object:
    return _information_value(value) is EMPTY


@intrinsic("IsMissing", "ArgName", minimum=1)
def vba_ismissing(interpreter: Interpreter, value: object) -> object:
    return value is MISSING


@intrinsic("IsNumeric", "Expression", minimum=1)
def vba_isnumeric(interpreter: Interpreter, value: object) -> object:
    """Whether CDbl would read the value: the same text forms, measured. Empty
    is numeric, as zero is; Null and a Date are not (native probes)."""
    value = _information_value(value)
    if isinstance(value, (bool, int, float, Decimal)):
        return True
    if value is EMPTY:
        return True
    if isinstance(value, str):
        try:
            to_number(value)
        except VBARuntimeError:
            return False
        return True
    return False


@intrinsic("IsDate", "Expression", minimum=1)
def vba_isdate(interpreter: Interpreter, value: object) -> object:
    value = _information_value(value)
    if isinstance(value, VBADate):
        return True
    if isinstance(value, str):
        return read_date_text(value) is not None
    # A number is not a date, though CDate takes it: IsDate(45000) is False (native probes).
    return False


@intrinsic("IsArray", "VarName", minimum=1)
def vba_isarray(interpreter: Interpreter, value: object) -> object:
    return isinstance(value, VBAArray)


@intrinsic("IsObject", "Expression", minimum=1)
def vba_isobject(interpreter: Interpreter, value: object) -> object:
    return isinstance(value, VBAObject) or value is NOTHING


@intrinsic("IsError", "Expression", minimum=1)
def vba_iserror(interpreter: Interpreter, value: object) -> object:
    return isinstance(_information_value(value), VBAErrorValue)


@intrinsic("TypeName", "VarName", minimum=1)
def vba_typename(interpreter: Interpreter, value: object) -> object:
    return type_name(value)


@intrinsic("VarType", "VarName", minimum=1)
def vba_vartype(interpreter: Interpreter, value: object) -> object:
    from pyopenvba.interpreter._values import VAR_TYPES, holds_objects

    value = _information_value(value)

    if isinstance(value, VBAArray):
        return VBAInt(8192 + (9 if holds_objects(value) else VAR_TYPES.get(value.element_type, 12)), "Integer")
    if isinstance(value, VBAObject):
        return VBAInt(9, "Integer")
    return VBAInt(VAR_TYPES.get(type_name(value), 12), "Integer")


# --- arrays and choice -----------------------------------------------------------------------


def vba_array_dispatch(interpreter: Interpreter, args: list[object], named: dict[str, object]) -> object:
    """Array() takes any number of arguments, so it binds its own."""
    return VBAArray([(0, len(args) - 1)] if args else [(0, -1)], items=list(args))


INTRINSICS["array"] = vba_array_dispatch


@intrinsic("LBound", "ArrayName", "Dimension", minimum=1)
def vba_lbound(interpreter: Interpreter, array: object, dimension: object) -> object:
    if not isinstance(array, VBAArray):
        raise error(ERR_TYPE_MISMATCH, "LBound needs an array")
    which = 1 if dimension is MISSING else int(to_integer(dimension, "Long"))
    if not 1 <= which <= array.dimensions:
        raise error(ERR_SUBSCRIPT_OUT_OF_RANGE)
    return VBAInt(array.bounds[which - 1][0], "Long")


@intrinsic("UBound", "ArrayName", "Dimension", minimum=1)
def vba_ubound(interpreter: Interpreter, array: object, dimension: object) -> object:
    if not isinstance(array, VBAArray):
        raise error(ERR_TYPE_MISMATCH, "UBound needs an array")
    which = 1 if dimension is MISSING else int(to_integer(dimension, "Long"))
    if not 1 <= which <= array.dimensions:
        raise error(ERR_SUBSCRIPT_OUT_OF_RANGE)
    return VBAInt(array.bounds[which - 1][1], "Long")


def vba_iif(interpreter: Interpreter, args: list[object], named: dict[str, object]) -> object:
    """IIf evaluates both arms, as VBA's does, so both can still fail."""
    if len(args) != 3:
        raise error(450, "IIf takes three arguments")
    return args[1] if condition(args[0]) else args[2]


INTRINSICS["iif"] = vba_iif


def vba_choose(interpreter: Interpreter, args: list[object], named: dict[str, object]) -> object:
    if not args:
        raise error(449)
    index = int(to_integer(args[0], "Long"))
    if 1 <= index < len(args):
        return args[index]
    return NULL


INTRINSICS["choose"] = vba_choose


def vba_switch(interpreter: Interpreter, args: list[object], named: dict[str, object]) -> object:
    if len(args) % 2:
        raise error(450, "Switch takes pairs")
    for index in range(0, len(args), 2):
        if to_bool(args[index]):
            return args[index + 1]
    return NULL


INTRINSICS["switch"] = vba_switch


@intrinsic("RGB", "Red", "Green", "Blue", minimum=3)
def vba_rgb(interpreter: Interpreter, red: object, green: object, blue: object) -> object:
    def channel(value: object) -> int:
        number = int(to_integer(value, "Long"))
        return 255 if number > 255 else max(0, number)

    return VBAInt(channel(red) + channel(green) * 256 + channel(blue) * 65536, "Long")


# --- dialogs and objects -----------------------------------------------------------------------


@intrinsic("MsgBox", "Prompt", "Buttons", "Title", "HelpFile", "Context", minimum=1)
def vba_msgbox(
    interpreter: Interpreter,
    prompt: object,
    buttons: object,
    title: object,
    help_file: object,
    context: object,
) -> object:
    style = 0 if buttons is MISSING else int(to_integer(buttons, "Long"))
    caption = to_text(title) if title is not MISSING else "Microsoft Excel"
    return interpreter.show_message(to_text(prompt), style, caption)


@intrinsic("InputBox", "Prompt", "Title", "Default", "XPos", "YPos", "HelpFile", "Context", minimum=1)
def vba_inputbox(
    interpreter: Interpreter,
    prompt: object,
    title: object,
    default: object,
    x: object,
    y: object,
    help_file: object,
    context: object,
) -> object:
    return interpreter.ask_for_input(
        to_text(prompt),
        to_text(title) if title is not MISSING else "",
        to_text(default) if default is not MISSING else "",
    )


@intrinsic("CreateObject", "Class", "ServerName", minimum=1)
def vba_createobject(interpreter: Interpreter, class_name: object, server: object) -> object:
    return interpreter.create_com(to_text(class_name))


# --- finance ------------------------------------------------------------------------------------


@intrinsic('Rate', 'NPer', 'Pmt', 'PV', 'FV', 'Due', 'Guess', minimum=3)
def vba_rate(interpreter: Interpreter, periods: object, paid: object, present: object,
             future: object, due: object, guess: object) -> object:
    from pyopenvba.interpreter import _financial as financial

    try:
        return financial.rate(financial.number(periods), financial.number(paid), financial.number(present),
                              0.0 if future is MISSING else financial.number(future),
                              0 if due is MISSING else financial.due(due),
                              0.1 if guess is MISSING else financial.number(guess))
    except OverflowError:
        raise error(6) from None
    except (ValueError, ZeroDivisionError):
        raise error(5) from None


@intrinsic('IRR', 'ValueArray', 'Guess', minimum=1)
def vba_irr(interpreter: Interpreter, values: object, guess: object) -> object:
    from pyopenvba.interpreter import _financial as financial

    try:
        return financial.irr(financial.flows(values), 0.1 if guess is MISSING else financial.number(guess))
    except OverflowError:
        raise error(6) from None
    except (ValueError, ZeroDivisionError):
        raise error(5) from None


@intrinsic('MIRR', 'ValueArray', 'FinanceRate', 'ReinvestRate', minimum=3)
def vba_mirr(interpreter: Interpreter, values: object, finance: object, reinvest: object) -> object:
    from pyopenvba.interpreter import _financial as financial

    try:
        return financial.mirr(financial.flows(values), financial.number(finance), financial.number(reinvest))
    except OverflowError:
        raise error(6) from None
    except (ValueError, ZeroDivisionError):
        raise error(5) from None


@intrinsic('NPV', 'Rate', 'ValueArray', minimum=2)
def vba_npv(interpreter: Interpreter, rate: object, values: object) -> object:
    from pyopenvba.interpreter import _financial as financial

    try:
        return financial.npv(financial.number(rate), financial.flows(values))
    except OverflowError:
        raise error(6) from None
    except (ValueError, ZeroDivisionError):
        raise error(5) from None


@intrinsic('IPmt', 'Rate', 'Per', 'NPer', 'PV', 'FV', 'Due', minimum=4)
def vba_ipmt(interpreter: Interpreter, rate: object, period: object, periods: object,
             present: object, future: object, due: object) -> object:
    from pyopenvba.interpreter import _financial as financial

    try:
        return financial.interest(financial.number(rate), financial.number(period), financial.number(periods),
                                  financial.number(present), 0.0 if future is MISSING else financial.number(future),
                                  0 if due is MISSING else financial.due(due))
    except OverflowError:
        raise error(6) from None
    except (ValueError, ZeroDivisionError):
        raise error(5) from None


@intrinsic('PPmt', 'Rate', 'Per', 'NPer', 'PV', 'FV', 'Due', minimum=4)
def vba_ppmt(interpreter: Interpreter, rate: object, period: object, periods: object,
             present: object, future: object, due: object) -> object:
    from pyopenvba.interpreter import _financial as financial

    r, at, n, pv = (financial.number(value) for value in (rate, period, periods, present))
    fv, timing = 0.0 if future is MISSING else financial.number(future), 0 if due is MISSING else financial.due(due)
    try:
        return financial.payment(r, n, pv, fv, timing) - financial.interest(r, at, n, pv, fv, timing)
    except OverflowError:
        raise error(6) from None
    except (ValueError, ZeroDivisionError):
        raise error(5) from None


def _annuity(rate: float, periods: float, present: float, future: float, due: int) -> float:
    if periods == 0:
        raise error(5)
    if rate == 0:
        return -(present + future) / periods
    growth = (1 + rate) ** periods
    return -(future + present * growth) / ((1 + rate * due) * (growth - 1) / rate)


def _financial_due(value: object) -> int:
    from pyopenvba.interpreter._financial import due

    return 0 if value is MISSING else due(value)


@intrinsic("Pmt", "Rate", "NPer", "PV", "FV", "Due", minimum=3)
def vba_pmt(
    interpreter: Interpreter, rate: object, periods: object, present: object, future: object, due: object
) -> object:
    return _annuity(
        float(to_number(rate)),
        float(to_number(periods)),
        float(to_number(present)),
        0.0 if future is MISSING else float(to_number(future)),
        _financial_due(due),
    )


@intrinsic("FV", "Rate", "NPer", "Pmt", "PV", "Due", minimum=3)
def vba_fv(
    interpreter: Interpreter, rate: object, periods: object, payment: object, present: object, due: object
) -> object:
    r = float(to_number(rate))
    n = float(to_number(periods))
    p = float(to_number(payment))
    pv = 0.0 if present is MISSING else float(to_number(present))
    at_start = _financial_due(due)
    if r == 0:
        return -(pv + p * n)
    growth = (1 + r) ** n
    return -(pv * growth + p * (1 + r * at_start) * (growth - 1) / r)


@intrinsic("PV", "Rate", "NPer", "Pmt", "FV", "Due", minimum=3)
def vba_pv(
    interpreter: Interpreter, rate: object, periods: object, payment: object, future: object, due: object
) -> object:
    r = float(to_number(rate))
    n = float(to_number(periods))
    p = float(to_number(payment))
    fv = 0.0 if future is MISSING else float(to_number(future))
    at_start = _financial_due(due)
    if r == 0:
        return -(fv + p * n)
    growth = (1 + r) ** n
    return -(fv + p * (1 + r * at_start) * (growth - 1) / r) / growth


@intrinsic("NPer", "Rate", "Pmt", "PV", "FV", "Due", minimum=3)
def vba_nper(
    interpreter: Interpreter, rate: object, payment: object, present: object, future: object, due: object
) -> object:
    r = float(to_number(rate))
    p = float(to_number(payment))
    pv = float(to_number(present))
    fv = 0.0 if future is MISSING else float(to_number(future))
    at_start = _financial_due(due)
    if r == 0:
        if p == 0:
            raise error(5)
        return -(pv + fv) / p
    adjusted = p * (1 + r * at_start) / r
    return math.log((adjusted - fv) / (adjusted + pv)) / math.log(1 + r)


@intrinsic("SLN", "Cost", "Salvage", "Life", minimum=3)
def vba_sln(interpreter: Interpreter, cost: object, salvage: object, life: object) -> object:
    span = float(to_number(life))
    if span == 0:
        raise error(5)
    return (float(to_number(cost)) - float(to_number(salvage))) / span


@intrinsic("SYD", "Cost", "Salvage", "Life", "Period", minimum=4)
def vba_syd(interpreter: Interpreter, cost: object, salvage: object, life: object, period: object) -> object:
    span = float(to_number(life))
    at = float(to_number(period))
    if span <= 0 or at <= 0 or at > span:
        raise error(5)
    return (float(to_number(cost)) - float(to_number(salvage))) * (span - at + 1) * 2 / (span * (span + 1))


@intrinsic("DDB", "Cost", "Salvage", "Life", "Period", "Factor", minimum=4)
def vba_ddb(
    interpreter: Interpreter, cost: object, salvage: object, life: object, period: object, factor: object
) -> object:
    start = float(to_number(cost))
    floor = float(to_number(salvage))
    span = float(to_number(life))
    at = float(to_number(period))
    rate = 2.0 if factor is MISSING else float(to_number(factor))
    if span <= 0 or at <= 0:
        raise error(5)
    book = start
    written = 0.0
    for _ in range(int(at)):
        written = min(book * rate / span, book - floor)
        written = max(0.0, written)
        book -= written
    return written
