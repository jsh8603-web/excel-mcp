"""Power Query: the M code in a workbook, which is code the same way VBA is.

Excel keeps Get and Transform queries in one custom XML part, base64-encoded,
outside the VBA project. That is why a plain .xlsx with no macros still has
queries in it, and why an agent asked to explain what a workbook does has to look
here as well as at the modules.

Loading a query onto a sheet is deliberately not exposed as a write. It takes a
connection, a query table, a table and the sheet's reference to it, and the column
names have to be given because knowing them means running the query. Getting that
wrong produces a workbook that opens and then fails on refresh, which is a worse
outcome than not offering it.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated, Any

from mcp.server.mcpserver import MCPServer
from pydantic import Field

from .. import locks, xlide_vscode
from ..config import Settings
from ..errors import ToolError
from ..hosts import host_info
from ..paths import require_writable, resolve_path
from ..tokens import content_token
from ._common import change_summary, page, read_only, truncate, unified_diff, writes


def register(server: MCPServer, settings: Settings) -> None:
    @server.tool(
        name="xlide_list_queries",
        title="List Power Query",
        annotations=read_only("List Power Query"),
        description=(
            "Lists the Power Query queries in an Excel workbook: name, group, description, "
            "where each loads, and its applied step names. If the M formula cannot be parsed, "
            "steps is null with steps_error rather than an empty list. Queries live outside "
            "the VBA project, so a plain .xlsx has them too. Call this when asked what a workbook "
            "does; a workbook with no macros can still be doing most of its work here. "
            "Use offset and next_offset to read large query lists in pages."
        ),
    )
    def list_queries(
        file_path: Annotated[str, Field(description="Absolute path to the Excel workbook.")],
        offset: Annotated[
            int, Field(default=0, ge=0, description="Skip this many queries before a page.")
        ] = 0,
        max_results: Annotated[
            int, Field(default=300, ge=1, le=300, description="Return at most this many queries.")
        ] = 300,
    ) -> dict[str, Any]:
        path = _query_path(file_path, settings)
        with _open(path) as book:
            queries = [
                {
                    "name": query.name,
                    "group": _group_name(query),
                    "description": query.description or "",
                    "load_target": str(query.load_target or ""),
                    **_steps(query),
                    "is_function": bool(query.is_function),
                }
                for query in book.queries()
            ]
            groups = [group.name for group in book.groups()]
        shown, next_offset = page(queries, "queries", offset, max_results)
        result: dict[str, Any] = {
            "path": str(path),
            "count": len(queries),
            "queries": shown,
            "groups": groups,
            "offset": offset,
            "next_offset": next_offset,
        }
        if next_offset is not None:
            result["note"] = (
                f"{len(queries)} queries in all; call again with offset={next_offset} "
                "for the next page."
            )
        return result

    @server.tool(
        name="xlide_read_query",
        title="Read Power Query",
        annotations=read_only("Read Power Query"),
        description=(
            "Reads one query's M formula, with its description, group, load target and refresh "
            "settings. The formula is the let ... in expression as the Advanced Editor "
            "shows it. start_line and end_line read a slice of a long formula; the "
            "content_token always describes the whole query. If applied steps cannot be read, "
            "steps is null and steps_error gives the reason; the M formula remains available."
        ),
    )
    def read_query(
        file_path: Annotated[str, Field(description="Absolute path to the Excel workbook.")],
        query_name: Annotated[str, Field(description="Query name, matched without case.")],
        start_line: Annotated[
            int, Field(default=0, ge=0, description="First formula line. 0 means the start.")
        ] = 0,
        end_line: Annotated[
            int, Field(default=0, ge=0, description="Last formula line. 0 means the end.")
        ] = 0,
    ) -> dict[str, Any]:
        path = _query_path(file_path, settings)
        import pyopenvba

        with _open(path) as book:
            query = _find_query(book, query_name)
            full_formula = query.formula or ""
            lines = full_formula.splitlines()
            first = start_line or 1
            last = min(len(lines), end_line or len(lines))
            if end_line and end_line < first:
                raise ToolError(
                    f"end_line {end_line} is before start_line {first}. "
                    "Use an end line at or after the start line."
                )
            if lines and first > len(lines):
                raise ToolError(
                    f"{query.name} has {len(lines)} formula lines; "
                    f"start_line {start_line} is past the end."
                )
            if not lines and (start_line or end_line):
                raise ToolError(f"{query.name} has no formula lines to read.")
            sliced = (
                full_formula.replace("\r\n", "\n")
                if first == 1 and last == len(lines)
                else "\n".join(lines[first - 1 : last])
            )
            formula, was_cut = truncate(
                sliced, hint="Read a narrower range with start_line and end_line."
            )
            result: dict[str, Any] = {
                "path": str(path),
                "query": query.name,
                "group": _group_name(query),
                "description": getattr(query, "description", "") or "",
                "load_target": str(getattr(query, "load_target", "") or ""),
                **_steps(query),
                "content_token": _query_token(query),
                "total_lines": len(lines),
                "first_line": first if lines else 0,
                "last_line": last,
                "truncated": was_cut,
                "formula": formula,
            }
            if lines and (first != 1 or last != len(lines)):
                result["note"] = (
                    "This is a slice. The content_token describes the whole query; "
                    "send the whole formula when using xlide_write_query."
                )
            # `refresh` is a property that raises for a query loading nowhere,
            # so getattr with a default does not shield the call: a query with no
            # sheet behind it has no connection, and therefore no refresh settings.
            try:
                refresh = query.refresh
            except pyopenvba.PowerQueryError:
                refresh = None
                result["refresh_note"] = (
                    "This query loads nowhere, so it has no connection and no refresh "
                    "settings. Those exist once a query is loaded onto a sheet."
                )
            if refresh is not None:
                result["refresh"] = {
                    "on_open": getattr(refresh, "on_open", None),
                    "interval_minutes": getattr(refresh, "interval_minutes", None),
                    "background": getattr(refresh, "background", None),
                    "keep_data": getattr(refresh, "keep_data", None),
                    "in_refresh_all": getattr(refresh, "in_refresh_all", None),
                    "enabled": getattr(refresh, "enabled", None),
                }
        return result

    @server.tool(
        name="xlide_write_query",
        title="Write Power Query",
        annotations=writes("Write Power Query", destructive=True),
        description=(
            "Changes a workbook's Power Query and saves it. action='set' replaces a query's M "
            "formula, creating it if it does not exist; 'rename' renames it and rewrites the "
            "queries that reference it by name; 'remove' deletes it and everything that loaded "
            "it onto a sheet, which has no undo, so ask the user first. 'load' puts a query's "
            "result on a worksheet and 'unload' takes it back off. Loading needs the column "
            "names, because writing the connection means naming the columns and knowing them "
            "means running the query, which nothing here does; Excel settles them against the "
            "real result on the first refresh. A query already loaded keeps its rows until "
            "Excel refreshes it. Pass expected_content_token from xlide_read_query to "
            "refuse a change if that query changed meanwhile."
        ),
    )
    def write_query(
        file_path: Annotated[str, Field(description="Absolute path to the Excel workbook.")],
        action: Annotated[
            str, Field(description="'set', 'rename', 'remove', 'load' or 'unload'.")
        ],
        query_name: Annotated[str, Field(description="The query to change.")],
        formula: Annotated[
            str,
            Field(
                default="",
                description="For set: the whole M expression, such as 'let Source = 1 in Source'.",
            ),
        ] = "",
        new_name: Annotated[
            str, Field(default="", description="For rename: the new name.")
        ] = "",
        description: Annotated[
            str, Field(default="", description="For set: the query's description.")
        ] = "",
        group: Annotated[
            str,
            Field(
                default="",
                description="For set on a new query: the folder in the Queries pane.",
            ),
        ] = "",
        columns: Annotated[
            list[str] | None,
            Field(
                default=None,
                description=(
                    "For load: the column names the query returns, in order. Required, "
                    "because the connection has to name them and nothing here runs the query "
                    "to find out. Excel corrects them on the first refresh."
                ),
            ),
        ] = None,
        sheet: Annotated[
            str,
            Field(default="", description="For load: the worksheet. Empty uses the first."),
        ] = "",
        cell: Annotated[
            str, Field(default="A1", description="For load: the table's top-left cell.")
        ] = "A1",
        include_diff: Annotated[
            bool,
            Field(
                default=True,
                description=(
                    "For set: include a unified diff of the M that changed. Nothing to "
                    "diff for the other actions."
                ),
            ),
        ] = True,
        expected_content_token: Annotated[
            str,
            Field(default="", description="Optional read token to guard the change."),
        ] = "",
    ) -> dict[str, Any]:
        require_writable(settings, "xlide_write_query")
        path = _query_path(file_path, settings)
        wanted = (action or "").strip().lower()
        if wanted not in {"set", "rename", "remove", "load", "unload"}:
            raise ToolError(
                "action must be 'set', 'rename', 'remove', 'load' or 'unload'."
            )

        import pyopenvba

        with _open(path) as book:
            existing = {name.casefold() for name in book.query_names()}
            if expected_content_token:
                if query_name.strip().casefold() not in existing:
                    raise ToolError(
                        f"No query named {query_name!r} remains. Read the query list and "
                        "decide whether to create it or use its current name."
                    )
                current = _find_query(book, query_name)
                actual = _query_token(current)
                if expected_content_token != actual:
                    raise ToolError(
                        f"Query {current.name!r} changed since it was read, so the write "
                        "was refused. Read it again and retry with its current "
                        f"content_token ({actual})."
                    )
            detail: dict[str, Any] = {}
            try:
                if wanted == "set":
                    if not formula.strip():
                        raise ToolError("formula is required for action='set'.")
                    if query_name.casefold() in existing:
                        query = _find_query(book, query_name)
                        was = query.formula or ""
                        query.formula = formula
                        if description:
                            query.description = description
                        detail = {"query": query.name, "created": False}
                        if include_diff:
                            detail.update(_diff_detail(was, formula, query.name))
                    else:
                        target_group = _resolve_group(book, group)
                        query = book.add_query(query_name, formula, group=target_group)
                        if description:
                            query.description = description
                        detail = {"query": query_name, "created": True}
                        if include_diff:
                            detail.update(_diff_detail("", formula, query_name))
                elif wanted == "rename":
                    if not new_name.strip():
                        raise ToolError("new_name is required for action='rename'.")
                    book.rename_query(query_name, new_name.strip())
                    detail = {"renamed_from": query_name, "renamed_to": new_name.strip()}
                elif wanted == "load":
                    if not columns:
                        raise ToolError(
                            "columns is required for action='load'. The connection names the "
                            "columns the query returns, and knowing them means running the "
                            "query, which nothing here does. Give the names you expect; Excel "
                            "settles them against the real result on the first refresh."
                        )
                    query = _find_query(book, query_name)
                    target = book.load_to_sheet(
                        query.name,
                        list(columns),
                        sheet=sheet.strip() or 1,
                        cell=cell.strip() or "A1",
                    )
                    detail = {
                        "query": query.name,
                        "loaded_to": str(target),
                        "columns": list(columns),
                    }
                elif wanted == "unload":
                    query = _find_query(book, query_name)
                    was_loaded = bool(book.unload(query.name))
                    detail = {"query": query.name, "was_loaded": was_loaded}
                else:
                    # A query loaded onto a sheet is four things: the definition,
                    # a connection, a query table and the table itself. Removing
                    # only the definition leaves a connection pointing at a query
                    # that no longer exists, which Excel meets on the next
                    # refresh rather than on open, so nothing says so at the time.
                    unloaded = bool(book.unload(query_name))
                    book.remove_query(query_name)
                    detail = {"removed": query_name, "unloaded_from_sheet": unloaded}
                book.save()
            except ToolError:
                raise
            except pyopenvba.PowerQueryError as exc:
                raise ToolError(f"Power Query refused the change: {exc}") from exc
            except PermissionError as exc:
                raise ToolError(locks.lock_message(path, "Excel")) from exc
        xlide_vscode.file_changed(path, "queries", tool="xlide_write_query")

        if wanted == "remove":
            next_token = None
        else:
            current_name = new_name.strip() if wanted == "rename" else query_name
            with _open(path) as book:
                next_token = _query_token(_find_query(book, current_name))

        return {
            "path": str(path),
            "action": wanted,
            "saved": True,
            "content_token": next_token,
            **detail,
            "note": (
                "The query definition is stored. Its loaded rows, if it loads to a sheet, "
                "change when Excel next refreshes it."
            ),
        }


def _diff_detail(before: str, after: str, name: str) -> dict[str, Any]:
    """What a set changed, in the shape every other diff in this server has."""
    diff, was_cut = unified_diff(
        before, after, label=f"query {name}", narrower="Read it with xlide_read_query."
    )
    detail: dict[str, Any] = {**change_summary(before, after), "diff": diff}
    if was_cut:
        detail["diff_truncated"] = True
    return detail


def _query_path(raw: str, settings: Settings) -> Path:
    path = resolve_path(raw, settings)
    info = host_info(path)
    if not info.supports_power_query:
        raise ToolError(
            f"Power Query lives in Excel packages. {path.name} is {info.title}"
            f"{' (' + info.extension + ')' if info.extension else ''}. "
            "Supported: .xlsx, .xlsm, .xlsb and .xlam."
        )
    return path


def _open(path: Path) -> Any:
    import pyopenvba

    try:
        return pyopenvba.PowerQueryWorkbook(path)
    except pyopenvba.PyOpenVBAError as exc:
        raise ToolError(f"{path.name}: {exc}") from exc


def _find_query(book: Any, name: str) -> Any:
    wanted = (name or "").strip().casefold()
    for query in book.queries():
        if query.name.casefold() == wanted:
            return query
    listed = ", ".join(book.query_names()) or "(none)"
    raise ToolError(f"No query named {name!r}. Queries in this workbook: {listed}.")


def _query_token(query: Any) -> str:
    """Token for the query state exposed here, not just its M formula."""
    state = {
        "name": query.name,
        "formula": query.formula or "",
        "description": getattr(query, "description", "") or "",
        "group": _group_name(query),
        "load_target": str(getattr(query, "load_target", "") or ""),
    }
    return content_token(json.dumps(state, sort_keys=True, ensure_ascii=False))


def _steps(query: Any) -> dict[str, Any]:
    """A query's applied steps, or a reason they could not be read."""
    try:
        return {"steps": list(query.steps or [])}
    except Exception as exc:
        return {
            "steps": None,
            "steps_error": (
                f"Applied step names could not be read: {exc}. Read the M formula directly."
            ),
        }


def _group_name(query: Any) -> str:
    group = getattr(query, "group", None)
    if group is None:
        return ""
    return getattr(group, "name", str(group))


def _resolve_group(book: Any, name: str) -> Any:
    """An existing group of that name, or a new one. Empty means no group."""
    if not name.strip():
        return None
    for group in book.groups():
        if getattr(group, "name", "").casefold() == name.strip().casefold():
            return group
    return book.add_group(name.strip())
